/**
 * Offset-encoded f32 geometry (§4/§16) and shared encode helpers.
 * Bit-identical to python/xyg/lod.encode_f32_values when calling xyg_encode_f32.
 */
import { pointer, xyAlignedWindow, xyArgsortStable, xyArrowEndDecoration, xyArrowGeometry, xyArrowShaftPoints, xyArrowStylePack, xyArrowTaperPolygon, xyArrowTrimPolylineEnd, xyBarStack, xyBin2d, xyBin2dIndices, xyBin2dMeanColor, xyBinnedEcdf, xyBoxGeometry, xyBoxStats, xyColormapLut, xyColormapLutRgba8, xyColormapRgba, xyColormapRgbaCanonical, xyColormapStops, xyContourLevels, xyContourfBands, xyContourfDensify, xyCurveFlatten, xyDefaultPaletteRgba8, xyDefaultPaletteRows, xyDefaultPaletteUtf8, xyDefaultPaletteVersion, xyGraphDefaultEdgeColorUtf8, xyDensityBinCoordEndpoints, xyDensityBinWindow, xyDensityColorClassify, xyDensityTraceColorClassify, xyDensityEmitMeta, xyDensityFormatBinning, xyDensityFullIdentity, xyDensityGridPath, xyDensityLogU8, xyDensityOverlayOpacity, xyDensityPyramidPreflight, xyDensityRgbaLinear, xyDensityWasmEligible, xyDrillDecision, xyEncodeF32, xyEncodedColumnMeta, xyF32SafeScale, xyGeometryOffset, xyHashRowIds, xyHeatmapRgba, xyHexbin, xyHexbinGroups, xyHexbinIngress, xyHexbinRing, xyHistogramBins, xyHistogramEdges, xyHistogramMarkEdges, xyHistogramUniform, xyIsSorted, xyLegendBestLoc, xyLegendNormalize, xyLodPlan, xyM4Indices, xyM4Points, xyMarchingSquares, xyMarkerPathScale, xyMinMax, xyMonotoneTangents, xyNormalizeF32, xyNormalizeWindow, xyPaintEffectiveRgba, xyPayloadBarCompactAdmit, xyPayloadBarHistEmitPlan, xyPayloadColumnShipPlan, xyPayloadColumnGatherMaterialize, xyPayloadChannelMaterialize, xyPayloadDensityGridMaterialize, xyPayloadDensityGridShipPlan, xyPayloadChannelShipPlan, xyPayloadChannelWireEncode, xyPayloadHeatmapEmitPlan, xyPayloadMeshEmitPlan, xyPayloadRibbonEmitPlan, xyPayloadScatterEmitPlan, xyPayloadDensityTraceEmitPlan, xyPayloadBuildPlan, xyPayloadAxisSpecAttachPlan, xyPayloadSegmentsEmitPlan, xyPayloadBaseEntryPlan, xyPayloadNonxyEmitPlan, xyPayloadErrorbarIndices, xyPayloadErrorbarRoleKeys, xyPayloadErrorbarRoleMaps, xyPayloadEvenIndices, xyPayloadM4Indices, xyPayloadSampleTargetIndices, xyPayloadSegmentBudget, xyPayloadSegmentsEmitGather, xyPayloadTier, xyPayloadTraceChannelsShipAttach, xyPayloadTransitionEntryAttach, xyPayloadTransitionKeysAdmit, xyPayloadVisibleIndices, xyPayloadVisibleMask, xyPayloadVisibleNeeded, xyQuantiles, xySampleFraction, xyStratifiedSampleRangePlan, xySampleMaskU32, xySampleThreshold, xyScreenShape, xyRibbonEdge, xyRibbonPolygon, xyRoundedRectPoly, xyScalePinsOffset, xySceneAnnotationStyleAdmit, xySceneArraysEqual, xySceneChannelConstantCss, xySceneConstantColorAdmit, xySceneCurveClassify, xySceneDashAdmit, xySceneEncodeProductAttachPlan, xySceneFillGradientAdmit, xySceneFiniteAll, xySceneGradientDir, xySceneGradientSolidCss, xySceneGradientSpace, xySceneGradientSpecPack, xySceneHeatmapColormapAdmit, xySceneHeatmapExtentAdmit, xySceneHeatmapShapeAdmit, xySceneHexbinColormapPlaneAdmit, xySceneHexbinPitchAdmit, xySceneHexbinReduceAdmit, xySceneHexbinRgbaPlaneAdmit, xySceneHiddenOrPerItemAdmit, xySceneItemApplyOpacity, xySceneItemFillT, xySceneItemWidthsAdmit, xySceneKindAdmit, xySceneKindClass, xySceneLinearGradientPrefix, xySceneLinecapAdmit, xySceneMarkerBlobPack, xySceneMarkerGlyphAdmit, xySceneMarkerPathAdmit, xySceneMeshPaintPlaneAdmit, xySceneParseLinearGradient, xyScenePolarFigurePlan, xySceneRectExtraFlags, xySceneRibbonColor2Classify, xySceneScatterPaintChannelAdmit, xySceneTickAnchor, xySceneTickLabelStrategy, xySceneXyhfColormapPack, xySceneFigureSupportFigurePlan, xySceneFigureSupportPack, xySceneFigureSupportTraceDispatchPlan, xySceneXyclFigurePlan, xyScenePublicExportFigurePlan, xyScenePublicExportTraceDispatchPlan, xySceneXyafAnnotationDispatchPlan, xySceneXyafPack, xySceneXycfFigurePlan, xySceneXycfPack, xySceneXynmFigurePlan, xySceneXytaColormapPack, xySceneXytaFigurePlan, xySceneXytaTraceDispatchPlan, xySceneXytaTracePack, xySceneXytcColor2FlagsPack, xySceneXytcColorChannelPack, xySceneXytcDashPatternPack, xySceneXytcHexPitchPack, xySceneXytcMetaFlagsPack, xySceneXytcFigurePlan, xySceneXytcTraceDispatchPlan, xySceneXytcTracePack, xySceneXytcNumericStylePack, xySceneXytcOpacityPack, xySceneXytcPaintPresencePack, xySceneXytcRadiusPack, xySceneXytcStrokePerimeterPack, xySceneXytcSymbolIntPack, xyStepArrays, xyStreamAppend, xyStreamCapacity, xyStreamCopy, xyStreamFree, xyStreamLen, xyStreamNew, xyStreamSeal, xyValidIndicesF64, xyViewVisibleMask, xyViolinDensity, xyViolinRects, xyWeightedEcdf, xyWindRoseBins, xyDensityUsesChannelColormap, xyDensityReductionKind, xyDensityOverlayOmittedWire, xyDensityGridPathIdentityState, xyDensityConstantColorWireAdmit, xyDensityWasmSourceAdmit, xyDensityWasmDensityWireKind, xyDensityCategoricalColorWireAdmit, xyDensityMeanColorWireAdmit, xyDensityChannelsDroppedCompat, xyDensityDroppedChannelWireAdmit, xyDensityMeanColorRgbaWireAdmit } from "./native.js";


export const PROTOCOL_VERSION = 13;
export const DECIMATION_THRESHOLD = 10_000;
export const SCATTER_DENSITY_THRESHOLD = 200_000;
export const DIRECT_SOFT_CEILING = 2_000_000;
/** Default density grid (w, h) matching Python `config.DENSITY_GRID`. */
export const DENSITY_GRID = Object.freeze([512, 384]);
/** Default density overlay sample size matching Python `DENSITY_SAMPLE_TARGET`. */
export const DENSITY_SAMPLE_TARGET = 8_192;
/** Default density overlay seed matching Python `DENSITY_SAMPLE_SEED`. */
export const DENSITY_SAMPLE_SEED = 0;
/** Split WASM replay source capacity matching Python `WASM_AGGREGATE_MAX_POINTS`. */
export const WASM_AGGREGATE_MAX_POINTS = 8_000_000;
export const DENSITY_TARGET_POINTS_PER_CELL = 16;
export const DRILL_EXIT_FACTOR = 1.15;
/** Tier-3 pyramid thresholds — lockstep with `python/xyg/config.py`. */
export const PYRAMID_MIN_POINTS = 2_000_000;
export const PYRAMID_BASE_DIM = 2048;
export const PYRAMID_NO_RESCAN_ROWS = 200_000_000;
export const PYRAMID_MAX_DIM = 16384;
/** Phase-4 resident-tile byte budget (roadmap D2); mirrored via xyTileBudgetSet. */
export const PYRAMID_RESIDENT_BYTES = 512 * (1 << 20);
export const F32_SAFE_MAG = 1e37;
/** Documented log-family names. Admission is ABI 216 `xyg_scale_pins_offset`. */
export const LOG_FAMILY_SCALES = Object.freeze(["log", "symlog"]);

/** Versioned Rust-owned default categorical palette (ABI 360). */
/** Rust-owned default graph edge paint (#898). */
export function graphDefaultEdgeColor() {
  const length = Number(xyGraphDefaultEdgeColorUtf8(null, 0n));
  const text = new Uint8Array(length);
  if (Number(xyGraphDefaultEdgeColorUtf8(pointer(text, "uint8_t *"), BigInt(length))) !== length) {
    throw new Error("native default graph edge color copy failed");
  }
  return new TextDecoder("ascii", { fatal: true }).decode(text);
}

export function defaultPaletteContract() {
  const version = Number(xyDefaultPaletteVersion());
  const rows = Number(xyDefaultPaletteRows());
  const textLength = Number(xyDefaultPaletteUtf8(null, 0n));
  const rgbaLength = Number(xyDefaultPaletteRgba8(null, 0n));
  if (!Number.isSafeInteger(rows) || rows <= 0 || textLength !== rows * 7 || rgbaLength !== rows * 4) {
    throw new Error("native default palette contract is malformed");
  }
  const text = new Uint8Array(textLength), rgba = new Uint8Array(rgbaLength);
  if (Number(xyDefaultPaletteUtf8(pointer(text, "uint8_t *"), BigInt(text.length))) !== text.length
      || Number(xyDefaultPaletteRgba8(pointer(rgba, "uint8_t *"), BigInt(rgba.length))) !== rgba.length) {
    throw new Error("native default palette contract copy failed");
  }
  const colors = [];
  const decoder = new TextDecoder("ascii", { fatal: true });
  for (let index = 0; index < rows; index += 1) {
    const color = decoder.decode(text.subarray(index * 7, index * 7 + 7));
    if (!/^#[0-9a-f]{6}$/.test(color)) throw new Error("native default palette text row is malformed");
    const expected = [1, 3, 5].map((offset) => Number.parseInt(color.slice(offset, offset + 2), 16));
    if (expected.some((channel, channelIndex) => rgba[index * 4 + channelIndex] !== channel)
        || rgba[index * 4 + 3] !== 255) {
      throw new Error("native default palette text/RGBA rows disagree");
    }
    colors.push(color);
  }
  return Object.freeze({ version, colors: Object.freeze(colors), rgba });
}

export const DEFAULT_PALETTE_CONTRACT = defaultPaletteContract();
/** Rust-owned default graph edge paint (#898); edges never take a palette slot. */
export const GRAPH_DEFAULT_EDGE_COLOR = graphDefaultEdgeColor();
export const DEFAULT_PALETTE = DEFAULT_PALETTE_CONTRACT.colors;
export const DEFAULT_MARK_COLOR = DEFAULT_PALETTE[0];

export function pinsOffsetToZero(scale) {
  if (scale == null) return false;
  const encoded = new TextEncoder().encode(String(scale));
  const code = Number(
    xyScalePinsOffset(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code < 0) throw new RangeError("invalid scale-pins-offset request");
  return code === 1;
}

/** Scene dash admit (ABI 218). None/omitted → null, unusable → false, else 2–8 lengths. */
export function sceneDashAdmit(value) {
  if (value == null) return null;
  const out = new Float64Array(8);
  const outN = new BigUint64Array(1);
  let encoded = new Uint8Array(0);
  let lengths = new Float64Array(0);
  let useLengths = 0;
  if (typeof value === "string") {
    if (value.length === 0) return false;
    encoded = new TextEncoder().encode(value);
  } else if (Array.isArray(value)) {
    lengths = asF64Array(value, "dash");
    useLengths = 1;
  } else {
    return false;
  }
  const code = Number(
    xySceneDashAdmit(
      encoded.length ? u8Ptr(encoded) : 0,
      BigInt(encoded.length),
      lengths.length ? f64Ptr(lengths) : 0,
      BigInt(lengths.length),
      useLengths,
      f64Ptr(out),
      8n,
      pointer(outN, "size_t *"),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-dash-admit request");
  if (code < 0) return false;
  if (code === 0) return null;
  return Array.from(out.subarray(0, Number(outN[0])));
}

/** Scene linecap admit (ABI 219). None/omitted/round → null, unusable → false, butt → 0, square → 2. */
export function sceneLinecapAdmit(value) {
  if (value == null) return null;
  const text = String(value);
  if (!text.trim()) return false;
  const encoded = new TextEncoder().encode(text);
  const code = Number(
    xySceneLinecapAdmit(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-linecap-admit request");
  if (code < 0) return false;
  if (code === 255) return null;
  return code;
}

/** Density overlay sample opacity (ABI 220). Finite values cap at 0.55; non-finite → 0.55. */
export function densityOverlayOpacity(authored) {
  const out = new Float64Array(1);
  const ok = xyDensityOverlayOpacity(Number(authored), f64Ptr(out));
  if (ok !== 1) {
    throw new RangeError("invalid density-overlay-opacity request");
  }
  return out[0];
}

/** Scene marker-path admit (ABI 221). Object + contours in, null if unusable. */
export function sceneMarkerPathAdmit(value) {
  if (value == null || typeof value !== "object" || Array.isArray(value)) return null;
  const contours = value.contours;
  if (!Array.isArray(contours)) return null;
  const packed = [];
  const lengths = [];
  const result = [];
  for (const contour of contours) {
    if (!Array.isArray(contour)) return null;
    const values = contour.map(Number);
    packed.push(...values);
    lengths.push(values.length);
    result.push(values);
  }
  const values = asF64Array(packed, "marker_path");
  const lens = Uint32Array.from(lengths);
  const code = Number(
    xySceneMarkerPathAdmit(
      values.length ? f64Ptr(values) : 0,
      BigInt(values.length),
      lens.length ? u32Ptr(lens) : 0,
      BigInt(lens.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-marker-path-admit request");
  if (code !== 1) return null;
  return { contours: result, filled: value.filled == null ? true : Boolean(value.filled) };
}

/** Scene annotation style-key admit (ABI 222). Hosts still skip markup/typography/rotation. */
export function sceneAnnotationStyleAdmit(kind, wrapped, labelled, key) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const keyBytes = new TextEncoder().encode(String(key ?? ""));
  const code = Number(
    xySceneAnnotationStyleAdmit(
      kindBytes.length ? u8Ptr(kindBytes) : 0,
      BigInt(kindBytes.length),
      wrapped ? 1 : 0,
      labelled ? 1 : 0,
      keyBytes.length ? u8Ptr(keyBytes) : 0,
      BigInt(keyBytes.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-annotation-style-admit request");
  return code === 1;
}

/** Scene f64 arrays-equal (ABI 250). Field picking and null checks stay host. */
export function sceneArraysEqual(left, right) {
  const leftArr = asF64Array(left ?? [], "arrays_equal_left");
  const rightArr = asF64Array(right ?? [], "arrays_equal_right");
  const code = Number(
    xySceneArraysEqual(
      leftArr.length ? f64Ptr(leftArr) : 0,
      BigInt(leftArr.length),
      rightArr.length ? f64Ptr(rightArr) : 0,
      BigInt(rightArr.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-arrays-equal request");
  return code === 1;
}

/** Scene constant-color admit (ABI 252). Ribbon-fail and field picking stay host. */
export function sceneConstantColorAdmit(hasChannel, constantOk, scatterDensity, packsPaintPlane) {
  const code = Number(
    xySceneConstantColorAdmit(
      hasChannel ? 1 : 0,
      constantOk ? 1 : 0,
      scatterDensity ? 1 : 0,
      packsPaintPlane ? 1 : 0,
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-constant-color-admit request");
  return code;
}

/** Scene channel-constant CSS (ABI 256). Hosts still pick `.mode` / `.constant`. */
export function sceneChannelConstantCss(mode, hasConstant, constant) {
  const modeBytes = new TextEncoder().encode(String(mode ?? ""));
  const constBytes = hasConstant ? new TextEncoder().encode(String(constant ?? "")) : new Uint8Array();
  const out = new Uint8Array(constBytes.length);
  const code = Number(
    xySceneChannelConstantCss(
      modeBytes.length ? u8Ptr(modeBytes) : 0,
      BigInt(modeBytes.length),
      hasConstant ? 1 : 0,
      constBytes.length ? u8Ptr(constBytes) : 0,
      BigInt(constBytes.length),
      out.length ? u8Ptr(out) : 0,
      BigInt(out.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-channel-constant-css request");
  if (code < 0) return null;
  return new TextDecoder().decode(out.subarray(0, code));
}

/** Scene hidden-or-per-item admit (ABI 253). Field picking stays host. */
export function sceneHiddenOrPerItemAdmit(hidden, hasPerItem, densityAggregates) {
  const code = Number(
    xySceneHiddenOrPerItemAdmit(
      hidden ? 1 : 0,
      hasPerItem ? 1 : 0,
      densityAggregates ? 1 : 0,
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-hidden-or-per-item-admit request");
  return code === 1;
}

const RIBBON_COLOR2_NAMES = ["absent", "solid", "gradient", "ends", "fail"];

/** Scene ribbon color2 classify (ABI 223). Hosts still coerce channels and pack end RGBA8. */
export function sceneRibbonColor2Classify(
  hasColor2,
  kindIsRibbon,
  sourceCss,
  targetCss,
  sourcePaint,
  hasFill,
  hasEndPair,
) {
  const sourceBytes = sourceCss == null ? new Uint8Array() : new TextEncoder().encode(String(sourceCss));
  const targetBytes = targetCss == null ? new Uint8Array() : new TextEncoder().encode(String(targetCss));
  const paintBytes = new TextEncoder().encode(String(sourcePaint ?? ""));
  const code = Number(
    xySceneRibbonColor2Classify(
      hasColor2 ? 1 : 0,
      kindIsRibbon ? 1 : 0,
      sourceCss == null ? 0 : 1,
      sourceBytes.length ? u8Ptr(sourceBytes) : 0,
      BigInt(sourceBytes.length),
      targetCss == null ? 0 : 1,
      targetBytes.length ? u8Ptr(targetBytes) : 0,
      BigInt(targetBytes.length),
      paintBytes.length ? u8Ptr(paintBytes) : 0,
      BigInt(paintBytes.length),
      hasFill ? 1 : 0,
      hasEndPair ? 1 : 0,
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-ribbon-color2-classify request");
  return RIBBON_COLOR2_NAMES[code] ?? "fail";
}

const COLOR2_CLASS_TO_CODE = Object.fromEntries(
  RIBBON_COLOR2_NAMES.map((name, code) => [name, code]),
);

/** XYTC numeric symbol flag bit (ABI 272). Symbol int wire value stays host. */
export function sceneXytcSymbolIntPack(symbolIsInt) {
  const flagsOut = new Uint32Array(1);
  const ok = Number(xySceneXytcSymbolIntPack(Number(symbolIsInt), u32Ptr(flagsOut)));
  if (ok === -2) throw new RangeError("invalid scene-xytc-symbol-int-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-symbol-int-pack request");
  return Number(flagsOut[0]);
}

/** XYTC ribbon color2 flag bits (ABI 271). Gradient spec construction stays host. */
export function sceneXytcColor2FlagsPack(color2Class, paintFlags, gradientPacked) {
  const flagsOut = new Uint32Array(1);
  const ok = Number(
    xySceneXytcColor2FlagsPack(
      Number(color2Class),
      Number(paintFlags) >>> 0,
      Number(gradientPacked),
      u32Ptr(flagsOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-color2-flags-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-color2-flags-pack request");
  return Number(flagsOut[0]);
}

export { COLOR2_CLASS_TO_CODE };

/** Scene tick-label strategy admit (ABI 224). Hosts still pick tick_label_strategy vs collision vs camelCase. */
export function sceneTickLabelStrategy(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneTickLabelStrategy(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-tick-label-strategy request");
  return code;
}

/** Scene tick-label anchor admit (ABI 225). Hosts still pick tick_label_anchor vs camelCase. */
export function sceneTickAnchor(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneTickAnchor(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-tick-anchor request");
  if (code < 0) return null;
  return code;
}

/** Scene fill-gradient admit (ABI 226). Hosts still coerce fill mappings; CSS parse is ABI 227. */
export function sceneFillGradientAdmit(space, dir, t, css, markColor) {
  const spaceBytes = new TextEncoder().encode(String(space ?? ""));
  const dirBytes = new TextEncoder().encode(String(dir ?? ""));
  const markBytes = new TextEncoder().encode(String(markColor ?? ""));
  const stops = asF64Array(t ?? [], "t");
  const encoded = Array.from(css ?? [], (item) => new TextEncoder().encode(String(item)));
  const lens = Uint32Array.from(encoded, (item) => item.length);
  const cssLen = encoded.reduce((sum, item) => sum + item.length, 0);
  const cssBytes = new Uint8Array(cssLen);
  let at = 0;
  for (const item of encoded) {
    cssBytes.set(item, at);
    at += item.length;
  }
  const out = new Uint8Array(stops.length * 4);
  const code = Number(
    xySceneFillGradientAdmit(
      spaceBytes.length ? u8Ptr(spaceBytes) : 0,
      BigInt(spaceBytes.length),
      dirBytes.length ? u8Ptr(dirBytes) : 0,
      BigInt(dirBytes.length),
      stops.length ? f64Ptr(stops) : 0,
      BigInt(stops.length),
      cssBytes.length ? u8Ptr(cssBytes) : 0,
      BigInt(cssBytes.length),
      lens.length ? u32Ptr(lens) : 0,
      BigInt(lens.length),
      markBytes.length ? u8Ptr(markBytes) : 0,
      BigInt(markBytes.length),
      out.length ? u8Ptr(out) : 0,
      BigInt(out.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-fill-gradient-admit request");
  if (code !== 1) return null;
  const rgba = [];
  for (let i = 0; i < stops.length; i += 1) {
    rgba.push(out.subarray(i * 4, i * 4 + 4));
  }
  return rgba;
}

/** Scene finite-all admit (ABI 248). Field picking stays host. */
export function sceneFiniteAll(values) {
  const valuesArr = asF64Array(values ?? [], "scene_finite_all");
  const code = Number(
    xySceneFiniteAll(
      valuesArr.length ? f64Ptr(valuesArr) : 0,
      BigInt(valuesArr.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-finite-all request");
  return code === 1;
}

const SCENE_PARSE_LINEAR_GRADIENT_DIRS = Object.freeze(["down", "up", "right", "left"]);

/** Scene linear-gradient CSS parse (ABI 227). Hosts still coerce fill mappings. */
export function sceneParseLinearGradient(css, space = "mark") {
  const cssBytes = new TextEncoder().encode(String(css ?? ""));
  const spaceBytes = new TextEncoder().encode(String(space ?? "mark"));
  const outDir = new Uint8Array(1);
  const outT = new Float64Array(8);
  const outCss = new Uint8Array(65536);
  const outLens = new Uint32Array(8);
  const outN = new BigUint64Array(1);
  const code = Number(
    xySceneParseLinearGradient(
      cssBytes.length ? u8Ptr(cssBytes) : 0,
      BigInt(cssBytes.length),
      spaceBytes.length ? u8Ptr(spaceBytes) : 0,
      BigInt(spaceBytes.length),
      u8Ptr(outDir),
      f64Ptr(outT),
      8n,
      u8Ptr(outCss),
      BigInt(outCss.length),
      u32Ptr(outLens),
      8n,
      pointer(outN, "size_t *"),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-parse-linear-gradient request");
  if (code !== 1) return null;
  const n = Number(outN[0]);
  const dirCode = outDir[0];
  if (!(dirCode >= 0 && dirCode < SCENE_PARSE_LINEAR_GRADIENT_DIRS.length) || n < 2 || n > 8) {
    return null;
  }
  const decoder = new TextDecoder();
  const stops = [];
  let at = 0;
  for (let i = 0; i < n; i += 1) {
    const length = outLens[i];
    stops.push([outT[i], decoder.decode(outCss.subarray(at, at + length))]);
    at += length;
  }
  return {
    space: String(space ?? "mark"),
    dir: SCENE_PARSE_LINEAR_GRADIENT_DIRS[dirCode],
    stops,
  };
}

/** Scene rect extra-flag pack (ABI 228). Hosts still coerce fill mappings, radius lists, and wedge_gap. */
export function sceneRectExtraFlags(kind, polar, gradientFail, radius, radiusSeq, wedgeGap) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const values = asF64Array(radius ?? [], "radius");
  const code = Number(
    xySceneRectExtraFlags(
      kindBytes.length ? u8Ptr(kindBytes) : 0,
      BigInt(kindBytes.length),
      polar ? 1 : 0,
      gradientFail ? 1 : 0,
      values.length ? f64Ptr(values) : 0,
      BigInt(values.length),
      radiusSeq ? 1 : 0,
      Number(wedgeGap),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-rect-extra-flags request");
  return code;
}

/** Scene fill-gradient direction pack (ABI 229). Hosts still pick dir vs missing keys. */
export function sceneGradientDir(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneGradientDir(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-gradient-dir request");
  return code;
}

/** Scene CSS linear-gradient( prefix (ABI 230). Hosts still treat dict/object fills as authoring. */
export function sceneLinearGradientPrefix(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneLinearGradientPrefix(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-linear-gradient-prefix request");
  return code === 1;
}

/** Scene fill-gradient space pack (ABI 231). Hosts still pick space vs missing keys. */
export function sceneGradientSpace(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneGradientSpace(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-gradient-space request");
  return code;
}

/** Scene gradient solid CSS (ABI 249). Field picking stays host. */
export function sceneGradientSolidCss(rgba) {
  const bytes = rgba instanceof Uint8Array
    ? rgba
    : Uint8Array.from(rgba ?? [], (item) => Number(item) & 255);
  const out = new Uint8Array(16);
  const code = Number(
    xySceneGradientSolidCss(
      bytes.length ? u8Ptr(bytes) : 0,
      BigInt(bytes.length),
      u8Ptr(out),
      BigInt(out.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-gradient-solid-css request");
  if (code <= 0) return null;
  return new TextDecoder().decode(out.subarray(0, code));
}

/** Scene fill-gradient spec blob (ABI 260). Field picking stays host. */
export function sceneGradientSpecPack(spaceText, dirText, stops) {
  if (!Array.isArray(stops)) return null;
  const stopT = new Float64Array(stops.length);
  const cssParts = [];
  const cssLens = new Uint32Array(stops.length);
  for (let index = 0; index < stops.length; index += 1) {
    const stop = stops[index];
    if (!Array.isArray(stop) || stop.length !== 2) return null;
    stopT[index] = Number(stop[0]);
    const css = new TextEncoder().encode(String(stop[1]));
    cssParts.push(css);
    cssLens[index] = css.length;
  }
  const cssLen = cssParts.reduce((sum, part) => sum + part.length, 0);
  const css = new Uint8Array(cssLen);
  let cssOff = 0;
  for (const part of cssParts) {
    css.set(part, cssOff);
    cssOff += part.length;
  }
  const cap = Math.max(4, 4 + stops.length * 10 + css.length);
  const out = new Uint8Array(cap);
  const space = new TextEncoder().encode(String(spaceText ?? ""));
  const dir = new TextEncoder().encode(String(dirText ?? ""));
  const code = Number(
    xySceneGradientSpecPack(
      space.length ? u8Ptr(space) : 0,
      BigInt(space.length),
      dir.length ? u8Ptr(dir) : 0,
      BigInt(dir.length),
      stopT.length ? f64Ptr(stopT) : 0,
      BigInt(stopT.length),
      css.length ? u8Ptr(css) : 0,
      BigInt(css.length),
      cssLens.length ? u32Ptr(cssLens) : 0,
      BigInt(cssLens.length),
      u8Ptr(out),
      BigInt(out.length),
    ),
  );
  if (code <= 0) return null;
  return out.subarray(0, code);
}

/** Scene XYTC marker-path blob (ABI 261). Field picking stays host. */
export function sceneMarkerBlobPack(value) {
  if (
    value == null
    || typeof value !== "object"
    || Array.isArray(value)
    || !Array.isArray(value.contours)
  ) {
    return null;
  }
  const values = [];
  const lens = new Uint32Array(value.contours.length);
  for (let index = 0; index < value.contours.length; index += 1) {
    const contour = value.contours[index];
    if (!Array.isArray(contour)) return null;
    lens[index] = contour.length;
    for (const item of contour) values.push(Number(item));
  }
  const stopT = Float64Array.from(values);
  const cap = Math.max(8, 8 + lens.length * 4 + stopT.length * 8);
  const out = new Uint8Array(cap);
  const filled = value.filled == null || value.filled ? 1 : 0;
  const code = Number(
    xySceneMarkerBlobPack(
      filled,
      stopT.length ? f64Ptr(stopT) : 0,
      BigInt(stopT.length),
      lens.length ? u32Ptr(lens) : 0,
      BigInt(lens.length),
      u8Ptr(out),
      BigInt(out.length),
    ),
  );
  if (code <= 0) return null;
  return out.subarray(0, code);
}

/** XYTC trace meta flags (ABI 270). Marker/glyph blob packing stays host. */
export function sceneXytcMetaFlagsPack(
  hasName,
  showLegend,
  kind,
  useDensity,
  joinedFill,
  markerPathPresent,
  markerPacked,
  glyphPacked,
) {
  const kindB = new TextEncoder().encode(String(kind ?? ""));
  const flagsOut = new Uint32Array(1);
  const ok = Number(
    xySceneXytcMetaFlagsPack(
      Number(hasName),
      Number(showLegend),
      kindB,
      BigInt(kindB.length),
      Number(useDensity),
      Number(joinedFill),
      Number(markerPathPresent),
      Number(markerPacked),
      Number(glyphPacked),
      u32Ptr(flagsOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-meta-flags-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-meta-flags-pack request");
  return Number(flagsOut[0]);
}

/** XYTC fill/stroke/line_color presence flags (ABI 269). Field picking stays host. */
export function sceneXytcPaintPresencePack(hasFill, fillKind, hasStroke, hasLineColor) {
  const flagsOut = new Uint32Array(1);
  const ok = Number(
    xySceneXytcPaintPresencePack(
      Number(hasFill),
      Number(fillKind),
      Number(hasStroke),
      Number(hasLineColor),
      u32Ptr(flagsOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-paint-presence-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-paint-presence-pack request");
  return Number(flagsOut[0]);
}

/** XYTC dash-array flag bit (ABI 268). Field picking and coercion stay host. */
export function sceneXytcDashPatternPack(isArray) {
  const flagsOut = new Uint32Array(1);
  const ok = Number(
    xySceneXytcDashPatternPack(Number(isArray), u32Ptr(flagsOut)),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-dash-pattern-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-dash-pattern-pack request");
  return Number(flagsOut[0]);
}

/** XYTC fill/stroke/line opacity trailer (ABI 267). Field picking stays host. */
export function sceneXytcOpacityPack(hasOpacityClass, hasBandClass, style) {
  const record = style ?? {};
  const fillOut = new Float64Array(1);
  const strokeOut = new Float64Array(1);
  const lineOut = new Float64Array(1);
  const ok = Number(
    xySceneXytcOpacityPack(
      Number(hasOpacityClass),
      Number(hasBandClass),
      Number(record.fill_opacity ?? 1),
      Number(record.stroke_opacity ?? 1),
      Number(record.line_opacity ?? 1),
      f64Ptr(fillOut),
      f64Ptr(strokeOut),
      f64Ptr(lineOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-opacity-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-opacity-pack request");
  return {
    fillOpacity: Number(fillOut[0]),
    strokeOpacity: Number(strokeOut[0]),
    lineOpacity: Number(lineOut[0]),
  };
}

/** XYTC hexbin pitch flag/values (ABI 266). Field picking stays host. */
export function sceneXytcHexPitchPack(hexbin, style) {
  const record = style ?? {};
  const rawDx = record.hex_dx ?? record.dx;
  const rawDy = record.hex_dy ?? record.dy;
  const hasDx = rawDx != null ? 1 : 0;
  const hasDy = rawDy != null ? 1 : 0;
  const flagsOut = new Uint32Array(1);
  const hexDxOut = new Float64Array(1);
  const hexDyOut = new Float64Array(1);
  const ok = Number(
    xySceneXytcHexPitchPack(
      Number(hexbin),
      hasDx,
      hasDy,
      hasDx ? Number(rawDx) : Number.NaN,
      hasDy ? Number(rawDy) : Number.NaN,
      u32Ptr(flagsOut),
      f64Ptr(hexDxOut),
      f64Ptr(hexDyOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-hex-pitch-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-hex-pitch-pack request");
  return {
    flags: Number(flagsOut[0]),
    hexDx: Number(hexDxOut[0]),
    hexDy: Number(hexDyOut[0]),
  };
}

/** XYTC stroke-perimeter flag bits (ABI 265). Field picking stays host. */
export function sceneXytcStrokePerimeterPack(band, present, perimeterIsBool, perimeterTrue) {
  const flagsOut = new Uint32Array(1);
  const ok = Number(
    xySceneXytcStrokePerimeterPack(
      Number(band),
      Number(present),
      Number(perimeterIsBool),
      Number(perimeterTrue),
      u32Ptr(flagsOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-stroke-perimeter-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-stroke-perimeter-pack request");
  return Number(flagsOut[0]);
}

/** XYTC numeric style fields (ABI 264). Field picking stays host. */
export function sceneXytcNumericStylePack(trace, style) {
  const record = style ?? {};
  const hasSize = Object.hasOwn(record, "size") ? 1 : 0;
  const sizeChannel = (trace ?? {}).size_ch;
  const hasSizeCh = sizeChannel == null ? 0 : 1;
  const hasSizeChConstant = hasSizeCh && sizeChannel.constant != null ? 1 : 0;
  const hasStrokeWidth = Object.hasOwn(record, "stroke_width") ? 1 : 0;
  const hasWidth = Object.hasOwn(record, "width") ? 1 : 0;
  const hasLineWidth = Object.hasOwn(record, "line_width") ? 1 : 0;
  const flagsOut = new Uint32Array(1);
  const sizeOut = new Float64Array(1);
  const sizeChOut = new Float64Array(1);
  const strokeWidthOut = new Float64Array(1);
  const widthOut = new Float64Array(1);
  const lineWidthOut = new Float64Array(1);
  const ok = Number(
    xySceneXytcNumericStylePack(
      hasSize,
      hasSizeCh,
      hasSizeChConstant,
      hasStrokeWidth,
      hasWidth,
      hasLineWidth,
      hasSize ? Number(record.size) : Number.NaN,
      hasSizeChConstant ? Number(sizeChannel.constant) : Number.NaN,
      hasStrokeWidth ? Number(record.stroke_width) : 0,
      hasWidth ? Number(record.width) : 0,
      hasLineWidth ? Number(record.line_width) : 0,
      u32Ptr(flagsOut),
      f64Ptr(sizeOut),
      f64Ptr(sizeChOut),
      f64Ptr(strokeWidthOut),
      f64Ptr(widthOut),
      f64Ptr(lineWidthOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-numeric-style-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-numeric-style-pack request");
  return {
    flags: Number(flagsOut[0]),
    size: Number(sizeOut[0]),
    sizeCh: Number(sizeChOut[0]),
    strokeWidth: Number(strokeWidthOut[0]),
    width: Number(widthOut[0]),
    lineWidth: Number(lineWidthOut[0]),
  };
}

/** XYTC color_ch flag bits (ABI 263). Field picking and UTF-8 stay host. */
export function sceneXytcColorChannelPack(present, hasConstant) {
  const flagsOut = new Uint32Array(1);
  const ok = Number(
    xySceneXytcColorChannelPack(
      Number(present),
      Number(hasConstant),
      u32Ptr(flagsOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-color-channel-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-color-channel-pack request");
  return Number(flagsOut[0]);
}

/** XYTC corner-radius/wedge-gap trailer fields (ABI 262). Field picking stays host. */
export function sceneXytcRadiusPack(kind, style) {
  const record = style ?? {};
  const radius = record.corner_radius ?? 0;
  let radiusSeq = 1;
  let r0 = 0;
  let r1 = 0;
  if (Array.isArray(radius) && radius.length === 2) {
    radiusSeq = 2;
    r0 = Number(radius[0]);
    r1 = Number(radius[1]);
  } else {
    r0 = Number(radius || 0);
  }
  const wedgeGapRaw = Number(record.wedge_gap ?? 0);
  const flagsOut = new Uint32Array(1);
  const rTipOut = new Float64Array(1);
  const rBaseOut = new Float64Array(1);
  const wedgeGapOut = new Float64Array(1);
  const encoded = new TextEncoder().encode(String(kind ?? ""));
  const ok = Number(
    xySceneXytcRadiusPack(
      encoded.length ? u8Ptr(encoded) : 0,
      BigInt(encoded.length),
      radiusSeq,
      r0,
      r1,
      wedgeGapRaw,
      u32Ptr(flagsOut),
      f64Ptr(rTipOut),
      f64Ptr(rBaseOut),
      f64Ptr(wedgeGapOut),
    ),
  );
  if (ok === -2) throw new RangeError("invalid scene-xytc-radius-pack request");
  if (ok === 0) throw new RangeError("invalid scene-xytc-radius-pack request");
  return {
    flags: Number(flagsOut[0]),
    rTip: Number(rTipOut[0]),
    rBase: Number(rBaseOut[0]),
    wedgeGap: Number(wedgeGapOut[0]),
  };
}

/** Scene heatmap colormap eligibility (ABI 239). Field picking stays host. */
export function sceneHeatmapColormapAdmit(truecolor, hasColormap, hasRgbaGrid, hasRgba) {
  const code = Number(
    xySceneHeatmapColormapAdmit(
      Number(truecolor),
      Number(hasColormap),
      Number(hasRgbaGrid),
      Number(hasRgba),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-heatmap-colormap-admit request");
  return code === 1;
}

/** RGB stop rows as flat u8 triples; invalid rows return null (host swallow). */
export function colormapStopBytes(colormap) {
  try {
    const rows = [];
    for (const row of colormap) {
      if (row == null || typeof row === "number" || typeof row === "string") return null;
      const parts = [...row];
      if (parts.length !== 3) return null;
      const rgb = [];
      for (const value of parts) {
        const n = Number(value);
        if (!Number.isFinite(n)) return null;
        rgb.push(n | 0);
      }
      rows.push(rgb);
    }
    if (rows.length < 1) return null;
    const out = new Uint8Array(rows.length * 3);
    for (let i = 0; i < rows.length; i += 1) {
      out[i * 3] = rows[i][0];
      out[i * 3 + 1] = rows[i][1];
      out[i * 3 + 2] = rows[i][2];
    }
    return out;
  } catch {
    return null;
  }
}

function sceneColormapInputs(style) {
  const colormap = style?.colormap;
  if (typeof colormap === "string") {
    return {
      mode: 1,
      named: new TextEncoder().encode(colormap),
      stops: new Uint8Array(),
    };
  }
  if (colormap != null) {
    return {
      mode: 2,
      named: new Uint8Array(),
      stops: colormapStopBytes(colormap) ?? new Uint8Array(),
    };
  }
  return { mode: 0, named: new Uint8Array(), stops: new Uint8Array() };
}

function sceneColormapPack(entrypoint, mode, named, stops, namedBit, stopsBit) {
  const flagsOut = new Uint32Array(1);
  const cmapOut = new Uint8Array(named.length);
  const stopsOut = new Uint8Array(stops.length);
  const ok = Number(
    entrypoint(
      Number(mode),
      named.length ? u8Ptr(named) : 0,
      BigInt(named.length),
      stops.length ? u8Ptr(stops) : 0,
      BigInt(stops.length),
      u32Ptr(flagsOut),
      cmapOut.length ? u8Ptr(cmapOut) : 0,
      BigInt(cmapOut.length),
      stopsOut.length ? u8Ptr(stopsOut) : 0,
      BigInt(stopsOut.length),
    ),
  );
  if (ok === 0) throw new RangeError("invalid scene-colormap-pack request");
  if (ok < 0) throw new RangeError("scene-colormap-pack output buffer too small");
  const flags = Number(flagsOut[0]);
  if (flags & namedBit) return { flags, cmap: named, stops: new Uint8Array() };
  if (flags & stopsBit) {
    if (stops.length >= 3 && stops.length % 3 === 0) {
      return { flags, cmap: new Uint8Array(), stops: stopsOut.subarray(0, stops.length) };
    }
    return { flags, cmap: new Uint8Array(), stops: new Uint8Array() };
  }
  return { flags: 0, cmap: new Uint8Array(), stops: new Uint8Array() };
}

/** Scene XYTA colormap pack (ABI 258). Field picking stays host. */
export function sceneXytaColormapPack(style) {
  const { mode, named, stops } = sceneColormapInputs(style ?? {});
  return sceneColormapPack(xySceneXytaColormapPack, mode, named, stops, 1 << 6, 1 << 7);
}

/** Scene XYHF colormap pack (ABI 259). Field picking stays host. */
export function sceneXyhfColormapPack(style) {
  const { mode, named, stops } = sceneColormapInputs(style ?? {});
  if (mode === 0) return null;
  return sceneColormapPack(xySceneXyhfColormapPack, mode, named, stops, 1 << 5, 1 << 6);
}

/** Scene heatmap cell-extent admit (ABI 238). Length==2 stays host. */
export function sceneHeatmapExtentAdmit(x0, x1, y0, y1) {
  const code = Number(
    xySceneHeatmapExtentAdmit(Number(x0), Number(x1), Number(y0), Number(y1)),
  );
  if (code === -2) throw new RangeError("invalid scene-heatmap-extent-admit request");
  return code === 1;
}

/** Scene heatmap lattice-shape admit (ABI 240). Length==2 stays host. XYTA uses the same kernel. */
export function sceneHeatmapShapeAdmit(rows, cols) {
  const code = Number(xySceneHeatmapShapeAdmit(Number(rows), Number(cols)));
  if (code === -2) throw new RangeError("invalid scene-heatmap-shape-admit request");
  return code === 1;
}

/** Scene hexbin colormap-plane admit (ABI 242). Kind checks and field picking stay host. */
export function sceneHexbinColormapPlaneAdmit(text, hasValues) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneHexbinColormapPlaneAdmit(
      encoded.length ? u8Ptr(encoded) : 0,
      BigInt(encoded.length),
      hasValues ? 1 : 0,
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-hexbin-colormap-plane-admit request");
  return code === 1;
}

/** Scene hexbin RGBA-plane admit (ABI 243). Kind checks, field picking, and RGBA8 packing stay host. */
export function sceneHexbinRgbaPlaneAdmit(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneHexbinRgbaPlaneAdmit(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-hexbin-rgba-plane-admit request");
  return code === 1;
}

/** Scene mesh paint-plane admit (ABI 244). joined_fill field picking and has_per_item gathering stay host. */
export function sceneMeshPaintPlaneAdmit(text, joinedFill, hasPerItem) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneMeshPaintPlaneAdmit(
      encoded.length ? u8Ptr(encoded) : 0,
      BigInt(encoded.length),
      joinedFill ? 1 : 0,
      hasPerItem ? 1 : 0,
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-mesh-paint-plane-admit request");
  return code === 1;
}

/** Scene per-item RGBA8 artist-alpha then opacity (ABI 245). Field picking stays host. */
export function sceneItemApplyOpacity(packed, n, artist, opacity) {
  const count = Number(n);
  if (!Number.isInteger(count) || count < 0) return null;
  const src = packed == null ? new Uint8Array() : Uint8Array.from(packed);
  const out = new Uint8Array(count * 4);
  let artistArr = new Float64Array(0);
  let hasArtist = 0;
  if (artist != null) {
    artistArr = asF64Array(artist, "artist");
    hasArtist = 1;
  }
  let opacityArr = new Float64Array(0);
  let hasOpacity = 0;
  if (opacity != null) {
    opacityArr = asF64Array(opacity, "opacity");
    hasOpacity = 1;
  }
  const code = Number(
    xySceneItemApplyOpacity(
      src.length ? u8Ptr(src) : 0,
      BigInt(src.length),
      BigInt(count),
      artistArr.length ? f64Ptr(artistArr) : 0,
      BigInt(artistArr.length),
      hasArtist,
      opacityArr.length ? f64Ptr(opacityArr) : 0,
      BigInt(opacityArr.length),
      hasOpacity,
      out.length ? u8Ptr(out) : 0,
      BigInt(out.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-item-apply-opacity request");
  if (code !== 1) return null;
  return out;
}

/** Scene per-item stroke-width admit (ABI 246). Field picking and f64 packing stay host. */
export function sceneItemWidthsAdmit(values, n, scalar) {
  const count = Number(n);
  if (!Number.isInteger(count) || count < 0) return false;
  let valuesArr = new Float64Array(0);
  let hasValues = 0;
  if (values != null) {
    valuesArr = asF64Array(values, "item_widths");
    hasValues = 1;
  }
  const code = Number(
    xySceneItemWidthsAdmit(
      valuesArr.length ? f64Ptr(valuesArr) : 0,
      BigInt(valuesArr.length),
      hasValues,
      BigInt(count),
      Number(scalar),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-item-widths-admit request");
  return code === 1;
}

/** Scene continuous per-item fill unit-t (ABI 247). Field picking and colormap lookup stay host. */
export function sceneItemFillT(values, n, domain) {
  const count = Number(n);
  if (!Number.isInteger(count) || count < 0) return null;
  const valuesArr = asF64Array(values ?? [], "item_fill_t");
  const out = new Float64Array(count);
  let hasDomain = 0;
  let lo = 0;
  let hi = 0;
  if (domain != null) {
    hasDomain = 1;
    lo = Number(domain[0]);
    hi = Number(domain[1]);
  }
  const code = Number(
    xySceneItemFillT(
      valuesArr.length ? f64Ptr(valuesArr) : 0,
      BigInt(valuesArr.length),
      BigInt(count),
      lo,
      hi,
      hasDomain,
      out.length ? f64Ptr(out) : 0,
      BigInt(out.length),
    ),
  );
  if (code === -2) throw new RangeError("invalid scene-item-fill-t request");
  if (code !== 1) return null;
  return out;
}

/** Scene hexbin cell-pitch admit (ABI 237). Field picking stays host. */
export function sceneHexbinPitchAdmit(dx, dy) {
  const code = Number(xySceneHexbinPitchAdmit(Number(dx), Number(dy)));
  if (code === -2) throw new RangeError("invalid scene-hexbin-pitch-admit request");
  return code === 1;
}

/** Scene hexbin reduce admit (ABI 232). Hosts still check hexbin kind. */
export function sceneHexbinReduceAdmit(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneHexbinReduceAdmit(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-hexbin-reduce-admit request");
  return code === 1;
}

/** Scene curve-name classify (ABI 233). Hosts still check kind for smooth. */
export function sceneCurveClassify(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneCurveClassify(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-curve-classify request");
  return code;
}

/** Scene marker-glyph admit (ABI 234). Hosts still coerce non-strings and check scatter kind. */
export function sceneMarkerGlyphAdmit(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneMarkerGlyphAdmit(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-marker-glyph-admit request");
  return code === 1;
}

/** Scene scatter paint-plane channel admit (ABI 241). Kind/density/name gathering stay host. */
export function sceneScatterPaintChannelAdmit(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneScatterPaintChannelAdmit(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-scatter-paint-channel-admit request");
  return code === 1;
}

/** Scene product-kind admit (ABI 235). Packing-family bits are ABI 236. */
export function sceneKindAdmit(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneKindAdmit(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-kind-admit request");
  return code === 1;
}

/** Scene packing-family bits (ABI 236). Hosts still pick channels and pack rows. */
export function sceneKindClass(text) {
  const encoded = new TextEncoder().encode(String(text ?? ""));
  const code = Number(
    xySceneKindClass(encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length)),
  );
  if (code === -2) throw new RangeError("invalid scene-kind-class request");
  return code;
}

export function geometryOffset(scale, lo, hi) {
  const out = new Float64Array(1);
  const ok = xyGeometryOffset(pinsOffsetToZero(scale) ? 1 : 0, Number(lo), Number(hi), f64Ptr(out));
  if (ok !== 1) {
    throw new Error("xyg_geometry_offset failed");
  }
  return out[0];
}

export function f32SafeScale(offset, lo, hi) {
  const out = new Float64Array(1);
  const ok = xyF32SafeScale(Number(offset), Number(lo), Number(hi), f64Ptr(out));
  if (ok !== 1) {
    throw new Error("xyg_f32_safe_scale failed");
  }
  return out[0];
}

/** Snap a 1-D window outward to the power-of-two grid over its extent (ABI 326, LOD T13). */
export function alignedWindow(lo, hi, extentLo, extentHi, pad) {
  const outLo = new Float64Array(1);
  const outHi = new Float64Array(1);
  const ok = xyAlignedWindow(
    Number(lo),
    Number(hi),
    Number(extentLo),
    Number(extentHi),
    Number(pad),
    f64Ptr(outLo),
    f64Ptr(outHi),
  );
  if (ok !== 1) {
    throw new Error("xyg_aligned_window failed");
  }
  return [outLo[0], outHi[0]];
}

/** Order a possibly-flipped viewport window (ABI 334, §5). */
export function normalizeWindow(x0, x1, y0, y1, { requireArea = true } = {}) {
  const out = new Float64Array(4);
  const ok = xyNormalizeWindow(
    Number(x0),
    Number(x1),
    Number(y0),
    Number(y1),
    requireArea ? 1 : 0,
    f64Ptr(out),
  );
  if (ok === 0) {
    throw new Error("view window bounds must be finite");
  }
  if (ok < 0) {
    throw new Error("view window must have non-zero width and height");
  }
  return [out[0], out[1], out[2], out[3]];
}

/** Cartesian viewport visibility mask (ABI 335, §19). */
export function viewVisibleMask(x, y, loX, hiX, loY, hiY) {
  const xv = Float64Array.from(x);
  const yv = Float64Array.from(y);
  if (xv.length !== yv.length) {
    throw new Error("viewVisibleMask expects equal-length x/y arrays");
  }
  const n = xv.length;
  if (n === 0) return new Uint8Array(0);
  const out = new Uint8Array(n);
  const written = Number(
    xyViewVisibleMask(
      f64Ptr(xv),
      f64Ptr(yv),
      BigInt(n),
      Number(loX),
      Number(hiX),
      Number(loY),
      Number(hiY),
      u8Ptr(out),
    ),
  );
  if (written === Number(USIZE_MAX_64)) {
    throw new Error("native view_visible_mask rejected the coordinate arrays");
  }
  if (written !== n) {
    throw new Error("native view_visible_mask returned an unexpected row count");
  }
  return out;
}

/** SplitMix64 row-id hashes (ABI 327, §5/§17). */
export function hashRowIds(ids, seed) {
  const view =
    ids instanceof BigUint64Array
      ? ids
      : BigUint64Array.from(ids, (value) => BigInt(value));
  const out = new BigUint64Array(view.length);
  if (view.length) {
    const ok = xyHashRowIds(u64Ptr(view), BigInt(view.length), BigInt(seed), u64Ptr(out));
    if (ok !== 1) {
      throw new Error("xyg_hash_row_ids failed");
    }
  }
  return out;
}

/** EncodedColumn offset/scale/kind-presence (ABI 255). Hosts copy the original kind. */
export function encodedColumnMeta(offset, lo, hi, kind = null) {
  const out = new Float64Array(2);
  let kindPtr = 0;
  let kindLen = 0n;
  let keep = null;
  if (kind != null) {
    const encoded = new TextEncoder().encode(String(kind));
    kindLen = BigInt(encoded.length);
    keep = encoded.length ? encoded : new Uint8Array(1);
    kindPtr = u8Ptr(keep);
  }
  const code = Number(
    xyEncodedColumnMeta(
      Number(offset),
      Number(lo),
      Number(hi),
      kindPtr,
      kindLen,
      f64Ptr(out),
      2n,
    ),
  );
  if (code < 0) {
    throw new RangeError("invalid encoded-column-meta request");
  }
  return { offset: out[0], scale: out[1], hasKind: code === 1 };
}

/** Canonical scatter column — preserves Column.kind like Python Column ingest. */
export function canonicalScatterColumn(value, name = "values") {
  if (value instanceof Column) return value;
  if (
    value != null
    && typeof value === "object"
    && !ArrayBuffer.isView(value)
    && value.kind != null
  ) {
    const values = value.values != null ? asF64Array(value.values, name) : asF64Array(value, name);
    return new Column(values, { kind: String(value.kind) });
  }
  if (Array.isArray(value) && value.length > 0 && value[0] instanceof Date) {
    return new Column(Float64Array.from(value, (item) => item.getTime()), { kind: "time_ms" });
  }
  return new Column(asF64Array(value, name));
}

export function asF64Array(value, name = "values") {
  if (value instanceof Float64Array) {
    return value;
  }
  if (value == null) {
    return new Float64Array(0);
  }
  if (ArrayBuffer.isView(value)) {
    return Float64Array.from(value, (item) => Number(item));
  }
  return Float64Array.from(value, (item) => {
    const number = Number(item);
    if (!Number.isFinite(number) && number !== number) {
      return Number.NaN;
    }
    return number;
  });
}

export function minMax(data) {
  const arr = asF64Array(data);
  if (arr.length === 0) {
    return null;
  }
  const lo = new Float64Array(1);
  const hi = new Float64Array(1);
  const ok = xyMinMax(f64Ptr(arr), BigInt(arr.length), f64Ptr(lo), f64Ptr(hi));
  if (ok !== 1) {
    return null;
  }
  return [lo[0], hi[0]];
}

export function isSorted(data) {
  const arr = asF64Array(data);
  if (arr.length <= 1) {
    return true;
  }
  return xyIsSorted(f64Ptr(arr), BigInt(arr.length)) === 1;
}

/** NumPy `argsort(..., kind="stable")` for f64 (NaNs last). */
export function argsortStable(data) {
  const arr = asF64Array(data);
  if (arr.length === 0) {
    return new Uint32Array(0);
  }
  const out = new Uint32Array(arr.length);
  const written = Number(xyArgsortStable(f64Ptr(arr), BigInt(arr.length), u32Ptr(out), BigInt(out.length)));
  if (written !== arr.length) {
    throw new Error("xyg_argsort_stable failed");
  }
  return out;
}

export function encodeF32(data, offset, scale = 1.0) {
  const arr = asF64Array(data);
  if (arr.length === 0) {
    return new Float32Array(0);
  }
  const out = new Float32Array(arr.length);
  const ok = xyEncodeF32(f64Ptr(arr), BigInt(arr.length), Number(offset), Number(scale), f32Ptr(out));
  if (ok !== 1) {
    throw new Error("xyg_encode_f32 failed");
  }
  return out;
}

export function encodeF32Values(values, offset, lo, hi, { kind = null } = {}) {
  const vals = asF64Array(values);
  const packed = encodedColumnMeta(offset, lo, hi, kind);
  const encoded = vals.length === 0 ? new Float32Array(0) : encodeF32(vals, packed.offset, packed.scale);
  const meta = { offset: packed.offset, scale: packed.scale };
  if (packed.hasKind) {
    meta.kind = kind;
  }
  return { values: encoded, meta, length: encoded.length };
}

export function m4Points(x, y, x0, x1, nBuckets) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("m4Points x/y length mismatch");
  }
  const cap = nBuckets * 4;
  const outX = new Float64Array(cap);
  const outY = new Float64Array(cap);
  const written = Number(
    xyM4Points(
      f64Ptr(xa),
      f64Ptr(ya),
      BigInt(xa.length),
      Number(x0),
      Number(x1),
      BigInt(nBuckets),
      f64Ptr(outX),
      f64Ptr(outY),
    ),
  );
  if (written === Number.MAX_SAFE_INTEGER || !Number.isFinite(written) || written < 0) {
    // usize::MAX from Rust — invalid args
    throw new Error("xyg_m4_points failed");
  }
  return [outX.subarray(0, written), outY.subarray(0, written)];
}

export function m4Indices(x, y, x0, x1, nBuckets) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  const cap = nBuckets * 4;
  const out = new Uint32Array(cap);
  const written = Number(
    xyM4Indices(
      f64Ptr(xa),
      f64Ptr(ya),
      BigInt(xa.length),
      Number(x0),
      Number(x1),
      BigInt(nBuckets),
      u32Ptr(out),
    ),
  );
  if (!Number.isFinite(written) || written < 0) {
    throw new Error("xyg_m4_indices failed");
  }
  return out.subarray(0, written);
}

export function histogramUniform(data, lo, hi, nBins, { density = false } = {}) {
  const arr = asF64Array(data);
  const counts = new Float64Array(nBins);
  const total = Number(
    xyHistogramUniform(
      f64Ptr(arr),
      BigInt(arr.length),
      Number(lo),
      Number(hi),
      BigInt(nBins),
      density ? 1 : 0,
      f64Ptr(counts),
    ),
  );
  if (!Number.isFinite(total) || total < 0) {
    throw new Error("xyg_histogram_uniform failed");
  }
  const edges = new Float64Array(nBins + 1);
  const width = (hi - lo) / nBins;
  for (let i = 0; i <= nBins; i += 1) {
    edges[i] = lo + i * width;
  }
  return { counts, edges, total };
}

export function histogramBins(data, edges, { density = false, cumulative = false } = {}) {
  const values = asF64Array(data);
  const binEdges = asF64Array(edges, "edges");
  if (binEdges.length < 2 || binEdges.length > 10_001) {
    throw new RangeError("histogram edges must contain 2 through 10,001 values");
  }
  const counts = new Float64Array(binEdges.length - 1);
  const written = Number(
    xyHistogramBins(
      f64Ptr(values),
      BigInt(values.length),
      f64Ptr(binEdges),
      BigInt(binEdges.length),
      density ? 1 : 0,
      cumulative ? 1 : 0,
      f64Ptr(counts),
    ),
  );
  if (!Number.isFinite(written) || written !== counts.length) {
    throw new Error("xyg_histogram_bins failed");
  }
  return counts;
}

/** NumPy-compatible auto/sturges edges (`method`: `"auto"` | `"sturges"`). */
export function histogramEdges(data, { range = null, method = "auto" } = {}) {
  const arr = asF64Array(data);
  const methodId = method === "sturges" ? 1 : method === "auto" ? 0 : -1;
  if (methodId < 0) {
    throw new Error("histogramEdges method must be 'auto' or 'sturges'");
  }
  const useRange = range == null ? 0 : 1;
  const lo = range == null ? 0 : Number(range[0]);
  const hi = range == null ? 0 : Number(range[1]);
  // ABI 98 caps Rust auto resolution at 10,000 bins (10,001 edges).
  const capacity = 10_001;
  const out = new Float64Array(capacity);
  const written = Number(
    xyHistogramEdges(
      f64Ptr(arr),
      BigInt(arr.length),
      lo,
      hi,
      useRange,
      methodId,
      f64Ptr(out),
      BigInt(capacity),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > capacity) {
    throw new Error("xyg_histogram_edges failed");
  }
  return out.subarray(0, written);
}

const HISTOGRAM_MARK_METHOD = Object.freeze({ auto: 0, sturges: 1, uniform: 2 });

/** Composition histogram edges (empty auto/sturges → 10 bins; uniform uses auto_domain). */
export function histogramMarkEdges(data, { range = null, method = "auto", nBins = 0 } = {}) {
  const arr = asF64Array(data);
  const methodId = HISTOGRAM_MARK_METHOD[method];
  if (methodId == null) {
    throw new Error("histogramMarkEdges method must be 'auto', 'sturges', or 'uniform'");
  }
  const useRange = range == null ? 0 : 1;
  const lo = range == null ? 0 : Number(range[0]);
  const hi = range == null ? 0 : Number(range[1]);
  const capacity = 10_001;
  const out = new Float64Array(capacity);
  const written = Number(
    xyHistogramMarkEdges(
      f64Ptr(arr),
      BigInt(arr.length),
      lo,
      hi,
      useRange,
      methodId,
      BigInt(nBins),
      f64Ptr(out),
      BigInt(capacity),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > capacity) {
    throw new Error("xyg_histogram_mark_edges failed");
  }
  return out.subarray(0, written);
}

/** Composition contour isolines. `nLevels > 0` auto-spaces; `nLevels === 0` sorts authored levels. */
export function contourLevels(data, nLevels = 0) {
  const arr = asF64Array(data);
  const capacity = 256;
  const out = new Float64Array(capacity);
  const written = Number(
    xyContourLevels(f64Ptr(arr), BigInt(arr.length), BigInt(nLevels), f64Ptr(out), BigInt(capacity)),
  );
  if (!Number.isFinite(written) || written < 0 || written > capacity) {
    throw new Error("xyg_contour_levels failed");
  }
  return out.subarray(0, written);
}

const LEGEND_SCALE = Object.freeze({ linear: 0, log: 1, symlog: 2 });

/** Matplotlib `loc="best"` candidates in preference order (ABI 120). */
export const LEGEND_CANDIDATE_ORDER = Object.freeze([
  "upper right",
  "upper left",
  "lower left",
  "lower right",
  "center right",
  "center left",
  "lower center",
  "upper center",
  "center",
]);

function legendScaleCode(scale) {
  if (scale == null || scale === "linear") return 0;
  const code = LEGEND_SCALE[scale];
  return code == null ? 0 : code;
}

/** Display-space occupancy sample. Returns null when nothing is scorable. */
export function legendNormalize(x, y, {
  xDomain, yDomain,
  xReverse = false, yReverse = false,
  xScale = "linear", yScale = "linear",
  xConstant = 1, yConstant = 1,
} = {}) {
  const xv = asF64Array(x);
  const yv = asF64Array(y);
  if (xv.length !== yv.length) {
    throw new Error("legendNormalize x and y must have equal length");
  }
  const capacity = Math.min(xv.length, 512);
  const outX = new Float64Array(capacity);
  const outY = new Float64Array(capacity);
  const written = Number(
    xyLegendNormalize(
      f64Ptr(xv),
      f64Ptr(yv),
      BigInt(xv.length),
      Number(xDomain[0]),
      Number(xDomain[1]),
      Number(yDomain[0]),
      Number(yDomain[1]),
      xReverse ? 1 : 0,
      yReverse ? 1 : 0,
      legendScaleCode(xScale),
      legendScaleCode(yScale),
      Number(xConstant),
      Number(yConstant),
      capacity ? f64Ptr(outX) : null,
      capacity ? f64Ptr(outY) : null,
      BigInt(capacity),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > capacity) {
    throw new Error("xyg_legend_normalize failed");
  }
  if (written === 0) return null;
  return { x: outX.subarray(0, written), y: outY.subarray(0, written) };
}

/** Least-occupied candidate name for concatenated normalized series. */
export function legendBestLoc(series, labelLens = []) {
  const rows = Array.isArray(series) ? series : [];
  const starts = new BigUint64Array(rows.length);
  let total = 0;
  for (let i = 0; i < rows.length; i += 1) {
    starts[i] = BigInt(total);
    const row = rows[i];
    const xv = row.x ?? row[0];
    total += xv.length;
  }
  const xs = new Float64Array(total);
  const ys = new Float64Array(total);
  let at = 0;
  for (const row of rows) {
    const xv = row.x ?? row[0];
    const yv = row.y ?? row[1];
    if (xv.length !== yv.length) {
      throw new Error("legendBestLoc series x and y must have equal length");
    }
    xs.set(xv, at);
    ys.set(yv, at);
    at += xv.length;
  }
  const labels = Uint32Array.from(labelLens, (value) => Number(value) >>> 0);
  const code = xyLegendBestLoc(
    total ? f64Ptr(xs) : null,
    total ? f64Ptr(ys) : null,
    BigInt(total),
    rows.length ? pointer(starts, "size_t *") : null,
    BigInt(rows.length),
    labels.length ? u32Ptr(labels) : null,
    BigInt(labels.length),
  );
  if (!Number.isInteger(code) || code < 0 || code >= LEGEND_CANDIDATE_ORDER.length) {
    throw new Error("xyg_legend_best_loc failed");
  }
  return LEGEND_CANDIDATE_ORDER[code];
}

function requireWritten(written, capacity, name) {
  if (!Number.isFinite(written) || written < 0 || written > capacity) {
    throw new Error(`${name} failed`);
  }
  return written;
}

/** Flatten one d3 curveBumpX edge. Returns `{ x, y }` of length `steps + 1`. */
export function ribbonEdge(x0, x1, ya, yb, steps = 96) {
  const nSteps = Number(steps);
  if (!Number.isInteger(nSteps) || nSteps <= 0) {
    throw new Error("ribbonEdge steps must be a positive integer");
  }
  const capacity = nSteps + 1;
  const outX = new Float64Array(capacity);
  const outY = new Float64Array(capacity);
  const written = requireWritten(
    Number(xyRibbonEdge(Number(x0), Number(x1), Number(ya), Number(yb), BigInt(nSteps), f64Ptr(outX), f64Ptr(outY), BigInt(capacity))),
    capacity,
    "xyg_ribbon_edge",
  );
  return { x: outX.subarray(0, written), y: outY.subarray(0, written) };
}

/** Closed flow-band polygon: upper edge then reversed lower. */
export function ribbonPolygon(x0, x1, srcLo, srcHi, dstLo, dstHi, steps = 96) {
  const nSteps = Number(steps);
  if (!Number.isInteger(nSteps) || nSteps <= 0) {
    throw new Error("ribbonPolygon steps must be a positive integer");
  }
  const capacity = 2 * (nSteps + 1);
  const outX = new Float64Array(capacity);
  const outY = new Float64Array(capacity);
  const written = requireWritten(
    Number(xyRibbonPolygon(
      Number(x0),
      Number(x1),
      Number(srcLo),
      Number(srcHi),
      Number(dstLo),
      Number(dstHi),
      BigInt(nSteps),
      f64Ptr(outX),
      f64Ptr(outY),
      BigInt(capacity),
    )),
    capacity,
    "xyg_ribbon_polygon",
  );
  return { x: outX.subarray(0, written), y: outY.subarray(0, written) };
}

/** Fritsch–Carlson monotone-cubic tangents. */
export function monotoneTangents(x, y) {
  const xv = asF64Array(x);
  const yv = asF64Array(y);
  if (xv.length !== yv.length) {
    throw new Error("monotoneTangents x and y must have equal length");
  }
  const out = new Float64Array(xv.length);
  const written = requireWritten(
    Number(xyMonotoneTangents(
      xv.length ? f64Ptr(xv) : null,
      yv.length ? f64Ptr(yv) : null,
      BigInt(xv.length),
      xv.length ? f64Ptr(out) : null,
      BigInt(out.length),
    )),
    out.length,
    "xyg_monotone_tangents",
  );
  return out.subarray(0, written);
}

/** Data-space monotone-cubic Hermite flatten. */
export function curveFlatten(x, y, bezierSteps = 16) {
  const xv = asF64Array(x);
  const yv = asF64Array(y);
  if (xv.length !== yv.length) {
    throw new Error("curveFlatten x and y must have equal length");
  }
  const steps = Number(bezierSteps);
  if (!Number.isInteger(steps) || steps < 2) {
    throw new Error("curveFlatten bezierSteps must be an integer >= 2");
  }
  const n = xv.length;
  const capacity = n === 0 ? 0 : n === 1 ? 1 : 1 + (n - 1) * steps;
  const outX = new Float64Array(capacity);
  const outY = new Float64Array(capacity);
  const written = requireWritten(
    Number(xyCurveFlatten(
      n ? f64Ptr(xv) : null,
      n ? f64Ptr(yv) : null,
      BigInt(n),
      BigInt(steps),
      capacity ? f64Ptr(outX) : null,
      capacity ? f64Ptr(outY) : null,
      BigInt(capacity),
    )),
    capacity,
    "xyg_curve_flatten",
  );
  return { x: outX.subarray(0, written), y: outY.subarray(0, written) };
}

const USIZE_MAX_64 = (1n << 64n) - 1n;

function stepMode(where) {
  if (where === "pre" || where === 1) return 1;
  if (where === "mid" || where === 2) return 2;
  if (where === "post" || where === 3) return 3;
  if (typeof where === "string") return 3;
  throw new RangeError("stepArrays where must be pre, mid, or post");
}

/** Expand compact vertices into a step polyline (ABI 211). */
export function stepArrays(x, y, where = "post") {
  const xv = asF64Array(x);
  const yv = asF64Array(y);
  if (xv.length !== yv.length) {
    throw new Error("stepArrays x and y must have equal length");
  }
  const mode = stepMode(where);
  const n = xv.length;
  const probed = xyStepArrays(
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    mode,
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid step-arrays request");
  const count = Number(probed);
  if (count === 0) return { x: new Float64Array(0), y: new Float64Array(0) };
  const outX = new Float64Array(count);
  const outY = new Float64Array(count);
  const written = xyStepArrays(
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    mode,
    f64Ptr(outX),
    f64Ptr(outY),
    count,
  );
  if (written === USIZE_MAX_64 || Number(written) !== count) {
    throw new RangeError("invalid step-arrays request");
  }
  return { x: outX, y: outY };
}

/** Pixel-space authored marker vertices (ABI 212). */
export function markerPathScale(cx, cy, scale, x, y) {
  const xv = asF64Array(x);
  const yv = asF64Array(y);
  if (xv.length !== yv.length) {
    throw new Error("markerPathScale x and y must have equal length");
  }
  const n = xv.length;
  const probed = xyMarkerPathScale(
    Number(cx),
    Number(cy),
    Number(scale),
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid marker-path-scale request");
  const count = Number(probed);
  if (count === 0) return { x: new Float64Array(0), y: new Float64Array(0) };
  const outX = new Float64Array(count);
  const outY = new Float64Array(count);
  const written = xyMarkerPathScale(
    Number(cx),
    Number(cy),
    Number(scale),
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    f64Ptr(outX),
    f64Ptr(outY),
    count,
  );
  if (written === USIZE_MAX_64 || Number(written) !== count) {
    throw new RangeError("invalid marker-path-scale request");
  }
  return { x: outX, y: outY };
}

/** Packed annotation-arrow style (ABI 254). NaN slots are absent. */
export function packArrowStyle(style = {}) {
  const startOffset =
    typeof style.start_offset === "string"
      ? new TextEncoder().encode(style.start_offset)
      : new Uint8Array();
  const labelClear =
    typeof style.label_clear === "string"
      ? new TextEncoder().encode(style.label_clear)
      : new Uint8Array();
  const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : Number.NaN);
  const packed = new Float64Array(12);
  const ok = xyArrowStylePack(
    startOffset.length ? u8Ptr(startOffset) : 0,
    BigInt(startOffset.length),
    num(style.angle_a),
    num(style.angle_b),
    num(style.curve),
    num(style.gap_start),
    num(style.gap_end),
    labelClear.length ? u8Ptr(labelClear) : 0,
    BigInt(labelClear.length),
    style.elbow ? 1 : Number.NaN,
    f64Ptr(packed),
    12n,
  );
  if (ok !== 0) throw new RangeError("invalid arrow-style-pack request");
  return packed;
}

/** Annotation arrow connectionstyle geometry (ABI 217 + ABI 254 style pack). */
export function arrowGeometry(x0, y0, x1, y1, style = {}) {
  const packed = packArrowStyle(style);
  const out = new Float64Array(11);
  const ok = xyArrowGeometry(
    Number(x0),
    Number(y0),
    Number(x1),
    Number(y1),
    f64Ptr(packed),
    12n,
    f64Ptr(out),
    11n,
  );
  if (ok !== 1) throw new Error("xyg_arrow_geometry failed");
  const hasControl = out[6] !== 0;
  return {
    p0: [out[0], out[1]],
    p1: [out[2], out[3]],
    control: hasControl ? [out[4], out[5]] : null,
    elbow: Boolean(style.elbow),
    dir0: [out[7], out[8]],
    dir1: [out[9], out[10]],
  };
}

/** Quadratic / elbow / linear shaft samples (ABI 217). */
export function arrowShaftPoints(geom, samples = 24) {
  const [p0x, p0y] = geom.p0;
  const [p1x, p1y] = geom.p1;
  const hasControl = geom.control != null;
  const [cx, cy] = hasControl ? geom.control : [0, 0];
  const probed = xyArrowShaftPoints(
    Number(p0x),
    Number(p0y),
    Number(p1x),
    Number(p1y),
    Number(cx),
    Number(cy),
    hasControl ? 1 : 0,
    geom.elbow ? 1 : 0,
    BigInt(samples),
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid arrow-shaft-points request");
  const count = Number(probed);
  if (count === 0) return [];
  const outX = new Float64Array(count);
  const outY = new Float64Array(count);
  const written = xyArrowShaftPoints(
    Number(p0x),
    Number(p0y),
    Number(p1x),
    Number(p1y),
    Number(cx),
    Number(cy),
    hasControl ? 1 : 0,
    geom.elbow ? 1 : 0,
    BigInt(samples),
    f64Ptr(outX),
    f64Ptr(outY),
    count,
  );
  if (written === USIZE_MAX_64 || Number(written) !== count) {
    throw new RangeError("invalid arrow-shaft-points request");
  }
  return Array.from({ length: count }, (_, i) => [outX[i], outY[i]]);
}

/** Endpoint decoration vertices (ABI 217). kind 0 none / 1 fill / 2 stroke. */
export function arrowEndDecoration(point, direction, style, head) {
  const encoded = new TextEncoder().encode(String(style));
  const kind = new Int32Array([-1]);
  const probed = xyArrowEndDecoration(
    Number(point[0]),
    Number(point[1]),
    Number(direction[0]),
    Number(direction[1]),
    encoded.length ? u8Ptr(encoded) : 0,
    BigInt(encoded.length),
    Number(head),
    0,
    0,
    0,
    pointer(kind, "int32_t *"),
  );
  if (probed === USIZE_MAX_64 || kind[0] < 0) {
    throw new RangeError("invalid arrow-end-decoration request");
  }
  const count = Number(probed);
  if (count === 0) return { kind: kind[0], points: [] };
  const outX = new Float64Array(count);
  const outY = new Float64Array(count);
  kind[0] = -1;
  const written = xyArrowEndDecoration(
    Number(point[0]),
    Number(point[1]),
    Number(direction[0]),
    Number(direction[1]),
    encoded.length ? u8Ptr(encoded) : 0,
    BigInt(encoded.length),
    Number(head),
    f64Ptr(outX),
    f64Ptr(outY),
    count,
    pointer(kind, "int32_t *"),
  );
  if (written === USIZE_MAX_64 || Number(written) !== count || kind[0] < 0) {
    throw new RangeError("invalid arrow-end-decoration request");
  }
  return {
    kind: kind[0],
    points: Array.from({ length: count }, (_, i) => [outX[i], outY[i]]),
  };
}

/** Tapered shaft polygon (ABI 217). */
export function arrowTaperPolygon(points, widthStart, widthEnd) {
  const xv = new Float64Array(points.map((p) => p[0]));
  const yv = new Float64Array(points.map((p) => p[1]));
  const n = xv.length;
  const probed = xyArrowTaperPolygon(
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    Number(widthStart),
    Number(widthEnd),
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid arrow-taper-polygon request");
  const count = Number(probed);
  if (count === 0) return [];
  const outX = new Float64Array(count);
  const outY = new Float64Array(count);
  const written = xyArrowTaperPolygon(
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    Number(widthStart),
    Number(widthEnd),
    f64Ptr(outX),
    f64Ptr(outY),
    count,
  );
  if (written === USIZE_MAX_64 || Number(written) !== count) {
    throw new RangeError("invalid arrow-taper-polygon request");
  }
  return Array.from({ length: count }, (_, i) => [outX[i], outY[i]]);
}

/** Trim arclength from a polyline end (ABI 217). */
export function arrowTrimPolylineEnd(points, trim) {
  const xv = new Float64Array(points.map((p) => p[0]));
  const yv = new Float64Array(points.map((p) => p[1]));
  const n = xv.length;
  const probed = xyArrowTrimPolylineEnd(
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    Number(trim),
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid arrow-trim-polyline-end request");
  const count = Number(probed);
  if (count === 0) return [];
  const outX = new Float64Array(count);
  const outY = new Float64Array(count);
  const written = xyArrowTrimPolylineEnd(
    n ? f64Ptr(xv) : 0,
    n ? f64Ptr(yv) : 0,
    BigInt(n),
    Number(trim),
    f64Ptr(outX),
    f64Ptr(outY),
    count,
  );
  if (written === USIZE_MAX_64 || Number(written) !== count) {
    throw new RangeError("invalid arrow-trim-polyline-end request");
  }
  return Array.from({ length: count }, (_, i) => [outX[i], outY[i]]);
}

/** CW rounded-rect outline with independent tip/base radii. */
export function roundedRectPoly(x, y, w, h, rTip, rBase, tipTop = true) {
  const outX = new Float64Array(20);
  const outY = new Float64Array(20);
  const written = requireWritten(
    Number(xyRoundedRectPoly(
      Number(x),
      Number(y),
      Number(w),
      Number(h),
      Number(rTip),
      Number(rBase),
      tipTop ? 1 : 0,
      f64Ptr(outX),
      f64Ptr(outY),
      20n,
    )),
    20,
    "xyg_rounded_rect_poly",
  );
  return { x: outX.subarray(0, written), y: outY.subarray(0, written) };
}

const HEX_REDUCE = Object.freeze({ count: 0, mean: 1, sum: 2 });

function hexbinGridAndRange(gridsize, range) {
  const [w, h] = Array.isArray(gridsize) ? gridsize : [gridsize, 0];
  const width = Number(w);
  const height = Number(h);
  if (!Number.isInteger(width) || width < 2 || width > 2048) {
    throw new RangeError("hexbin gridsize dimensions must be in 2..=2048");
  }
  if (height !== 0 && (!Number.isInteger(height) || height < 2 || height > 2048)) {
    throw new RangeError("hexbin gridsize dimensions must be in 2..=2048");
  }
  if (range == null) {
    return { w: width, h: height, x0: 0, x1: 0, y0: 0, y1: 0, useRange: 0 };
  }
  const x0 = Number(range[0][0]);
  const x1 = Number(range[0][1]);
  const y0 = Number(range[1][0]);
  const y1 = Number(range[1][1]);
  if (!(Number.isFinite(x0) && Number.isFinite(x1) && x1 > x0 && Number.isFinite(y0) && Number.isFinite(y1) && y1 > y0)) {
    throw new RangeError("hexbin range must be a finite increasing rectangle");
  }
  return { w: width, h: height, x0, x1, y0, y1, useRange: 1 };
}

/** Pointy-top hexagon vertex offsets scaled by cell pitch (ABI 210). */
export function hexbinRing(hexDx, hexDy) {
  const probed = xyHexbinRing(Number(hexDx), Number(hexDy), 0, 0, 0);
  if (probed === USIZE_MAX_64) throw new RangeError("invalid hexbin-ring request");
  const n = Number(probed);
  const outX = new Float64Array(n);
  const outY = new Float64Array(n);
  const written = xyHexbinRing(
    Number(hexDx),
    Number(hexDy),
    f64Ptr(outX),
    f64Ptr(outY),
    n,
  );
  if (written === USIZE_MAX_64 || Number(written) !== n) {
    throw new RangeError("invalid hexbin-ring request");
  }
  return { x: outX, y: outY };
}

/** Rust-owned hexbin finite-pair domain and default grid aspect. */
export function hexbinIngress(x, y, { gridsize, range = null, C = null } = {}) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("hexbin x/y length mismatch");
  }
  const { w, h, x0, x1, y0, y1, useRange } = hexbinGridAndRange(gridsize, range);
  const ca = C == null ? null : asF64Array(C);
  if (ca != null && ca.length !== xa.length) {
    throw new RangeError("hexbin C length mismatch");
  }
  const outX0 = new Float64Array(1);
  const outX1 = new Float64Array(1);
  const outY0 = new Float64Array(1);
  const outY1 = new Float64Array(1);
  const outW = new BigUint64Array(1);
  const outH = new BigUint64Array(1);
  const ok = Number(
    xyHexbinIngress(
      f64Ptr(xa),
      f64Ptr(ya),
      ca == null ? null : f64Ptr(ca),
      BigInt(xa.length),
      BigInt(w),
      BigInt(h),
      x0,
      x1,
      y0,
      y1,
      useRange,
      f64Ptr(outX0),
      f64Ptr(outX1),
      f64Ptr(outY0),
      f64Ptr(outY1),
      pointer(outW, "size_t *"),
      pointer(outH, "size_t *"),
    ),
  );
  if (ok !== 1) {
    throw new RangeError("hexbin x and y must contain at least one finite pair");
  }
  return {
    range: [
      [outX0[0], outX1[0]],
      [outY0[0], outY1[0]],
    ],
    gridsize: [Number(outW[0]), Number(outH[0])],
  };
}

/** Matplotlib-compatible hexbin; `reduce` is count|mean|sum. */
export function hexbin(x, y, { gridsize, range = null, mincnt = 0, C = null, reduce = "count" } = {}) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("hexbin x/y length mismatch");
  }
  const { w, h, x0, x1, y0, y1, useRange } = hexbinGridAndRange(gridsize, range);
  const reduceId = HEX_REDUCE[reduce];
  if (reduceId == null) {
    throw new Error("hexbin reduce must be count, mean, or sum");
  }
  const ca = C == null ? null : asF64Array(C);
  if (ca != null && ca.length !== xa.length) {
    throw new RangeError("hexbin C length mismatch");
  }
  const hCap = h === 0 ? w : h;
  const capacity = (w + 1) * (hCap + 1) + w * hCap;
  const outCx = new Float64Array(capacity);
  const outCy = new Float64Array(capacity);
  const outMetric = new Float64Array(capacity);
  const outCounts = new Float64Array(capacity);
  const dx = new Float64Array(1);
  const dy = new Float64Array(1);
  const written = Number(
    xyHexbin(
      f64Ptr(xa),
      f64Ptr(ya),
      ca == null ? null : f64Ptr(ca),
      BigInt(xa.length),
      BigInt(w),
      BigInt(h),
      x0,
      x1,
      y0,
      y1,
      useRange,
      BigInt(mincnt),
      reduceId,
      f64Ptr(outCx),
      f64Ptr(outCy),
      f64Ptr(outMetric),
      f64Ptr(outCounts),
      BigInt(capacity),
      f64Ptr(dx),
      f64Ptr(dy),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > capacity) {
    throw new RangeError("hexbin x and y must contain at least one finite pair");
  }
  return {
    centersX: outCx.subarray(0, written),
    centersY: outCy.subarray(0, written),
    metrics: outMetric.subarray(0, written),
    counts: outCounts.subarray(0, written),
    dx: dx[0],
    dy: dy[0],
  };
}

/** Occupied hex-cell memberships for a host custom reducer. */
export function hexbinGroups(x, y, { gridsize, range = null, mincnt = 0, C = null } = {}) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("hexbin x/y length mismatch");
  }
  const { w, h, x0, x1, y0, y1, useRange } = hexbinGridAndRange(gridsize, range);
  const ca = C == null ? null : asF64Array(C);
  if (ca != null && ca.length !== xa.length) {
    throw new RangeError("hexbin C length mismatch");
  }
  const hCap = h === 0 ? w : h;
  const cellCapacity = (w + 1) * (hCap + 1) + w * hCap;
  const outCx = new Float64Array(cellCapacity);
  const outCy = new Float64Array(cellCapacity);
  const outCounts = new Float64Array(cellCapacity);
  const outStarts = new Uint32Array(cellCapacity);
  const outLens = new Uint32Array(cellCapacity);
  const outIndices = new Uint32Array(xa.length);
  const nIndices = new BigUint64Array(1);
  const dx = new Float64Array(1);
  const dy = new Float64Array(1);
  const written = Number(
    xyHexbinGroups(
      f64Ptr(xa),
      f64Ptr(ya),
      ca == null ? null : f64Ptr(ca),
      BigInt(xa.length),
      BigInt(w),
      BigInt(h),
      x0,
      x1,
      y0,
      y1,
      useRange,
      BigInt(mincnt),
      f64Ptr(outCx),
      f64Ptr(outCy),
      f64Ptr(outCounts),
      u32Ptr(outStarts),
      u32Ptr(outLens),
      BigInt(cellCapacity),
      u32Ptr(outIndices),
      BigInt(outIndices.length),
      pointer(nIndices, "size_t *"),
      f64Ptr(dx),
      f64Ptr(dy),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > cellCapacity) {
    throw new RangeError("hexbin x and y must contain at least one finite pair");
  }
  const nIdx = Number(nIndices[0]);
  return {
    centersX: outCx.subarray(0, written),
    centersY: outCy.subarray(0, written),
    counts: outCounts.subarray(0, written),
    starts: outStarts.subarray(0, written),
    lengths: outLens.subarray(0, written),
    indices: outIndices.subarray(0, nIdx),
    dx: dx[0],
    dy: dy[0],
  };
}

/** Violin density: edges (n_bins+1) + smoothed density (n_bins). */
export function violinDensity(data, nBins) {
  const arr = asF64Array(data);
  if (!Number.isInteger(nBins) || nBins < 4 || nBins > 1024) {
    throw new RangeError("violinDensity nBins must be in 4..=1024");
  }
  const edges = new Float64Array(nBins + 1);
  const density = new Float64Array(nBins);
  const ok = xyViolinDensity(
    f64Ptr(arr),
    BigInt(arr.length),
    BigInt(nBins),
    f64Ptr(edges),
    f64Ptr(density),
  );
  if (ok !== 1) {
    throw new Error("xy_violin_density failed");
  }
  return { edges, density };
}

export function violinRects(groups, positions, nBins, width, orientation) {
  const offsets = new BigUint64Array(groups.length + 1);
  let total = 0;
  for (let i = 0; i < groups.length; i += 1) { total += groups[i].length; offsets[i + 1] = BigInt(total); }
  const values = new Float64Array(total); let at = 0;
  for (const group of groups) { values.set(group, at); at += group.length; }
  const centers = Float64Array.from(positions);
  const call = (x0,y0,x1,y1,active,edges,density,cap) => Number(xyViolinRects(
    f64Ptr(values), BigInt(values.length), pointer(offsets, "size_t *"), BigInt(offsets.length),
    f64Ptr(centers), BigInt(centers.length), BigInt(nBins), Number(width), orientation === "vertical" ? 0 : orientation === "horizontal" ? 1 : 2,
    f64Ptr(x0), f64Ptr(y0), f64Ptr(x1), f64Ptr(y1), u32Ptr(active), f64Ptr(edges), f64Ptr(density), BigInt(cap),
  ));
  const required = call(null,null,null,null,null,null,null,0);
  if (!Number.isSafeInteger(required) || required <= 0 || required > 10_000) throw new RangeError("invalid bounded violin geometry");
  const activeCount = required / nBins;
  const x0=new Float64Array(required), y0=new Float64Array(required), x1=new Float64Array(required), y1=new Float64Array(required);
  const active=new Uint32Array(activeCount), edges=new Float64Array(activeCount*(nBins+1)), density=new Float64Array(required);
  if (call(x0,y0,x1,y1,active,edges,density,required) !== required) throw new Error("xy_violin_rects failed");
  return { x0,y0,x1,y1,activeGroups:active,
    groupEdges:Array.from({length:activeCount},(_,i)=>edges.slice(i*(nBins+1),(i+1)*(nBins+1))),
    groupDensity:Array.from({length:activeCount},(_,i)=>density.slice(i*nBins,(i+1)*nBins)) };
}

/** Weighted ECDF: sorted unique values + cumulative mass in [0, 1]. */
export function weightedEcdf(values, weights) {
  const vals = asF64Array(values);
  const wts = asF64Array(weights);
  if (vals.length !== wts.length || vals.length === 0) {
    throw new RangeError("weightedEcdf values/weights must have equal non-zero length");
  }
  const outValues = new Float64Array(vals.length);
  const cumulative = new Float64Array(vals.length);
  const written = Number(
    xyWeightedEcdf(
      f64Ptr(vals),
      f64Ptr(wts),
      BigInt(vals.length),
      f64Ptr(outValues),
      f64Ptr(cumulative),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > vals.length) {
    throw new Error("xy_weighted_ecdf failed");
  }
  return {
    values: outValues.subarray(0, written),
    cumulative: cumulative.subarray(0, written),
  };
}

/** Uniformly binned ECDF with Rust-owned finite filtering and compaction. */
export function binnedEcdf(values, nBins, { range = null } = {}) {
  const vals = asF64Array(values);
  const bins = Number(nBins);
  if (!Number.isInteger(bins) || bins <= 0) {
    throw new RangeError("ecdf bins must be a positive integer");
  }
  if (bins > 10_000) {
    throw new RangeError("ecdf bins must be <= 10000");
  }
  const useRange = range == null ? 0 : 1;
  const lo = range == null ? 0 : Number(range[0]);
  const hi = range == null ? 0 : Number(range[1]);
  const capacity = bins + 1;
  const x = new Float64Array(capacity);
  const cumulative = new Float64Array(capacity);
  const written = Number(
    xyBinnedEcdf(
      f64Ptr(vals),
      BigInt(vals.length),
      BigInt(bins),
      lo,
      hi,
      useRange,
      f64Ptr(x),
      f64Ptr(cumulative),
      BigInt(capacity),
    ),
  );
  if (!Number.isSafeInteger(written) || written <= 0 || written > capacity) {
    throw new RangeError("ecdf values must contain a finite representable distribution");
  }
  return { x: x.slice(0, written), cumulative: cumulative.slice(0, written) };
}

/** Map scalar heatmap grid to vertically flipped RGBA bytes (h, w, 4). */
export function heatmapRgba(raw, w, h, stops, alpha = 255) {
  const ww = Number(w);
  const hh = Number(h);
  const values = asF64Array(raw);
  if (values.length !== ww * hh) {
    throw new RangeError("heatmapRgba scalar count must match width * height");
  }
  const stopArr = stops instanceof Uint8Array ? stops : Uint8Array.from(stops);
  if (stopArr.length % 3 !== 0 || stopArr.length < 3) {
    throw new RangeError("heatmapRgba stops must be a non-empty multiple of 3");
  }
  const stopCount = stopArr.length / 3;
  const out = new Uint8Array(hh * ww * 4);
  const ok = xyHeatmapRgba(
    f64Ptr(values),
    BigInt(ww),
    BigInt(hh),
    u8Ptr(stopArr),
    BigInt(stopCount),
    Number(alpha),
    u8Ptr(out),
    BigInt(out.byteLength),
  );
  if (ok !== 1) {
    throw new Error("xy_heatmap_rgba failed");
  }
  return { rgba: out, width: ww, height: hh };
}

/** Map normalized scalars t ∈ [0, 1] to vertically flipped RGBA bytes (h, w, 4). */
export function colormapRgba(raw, w, h, stops, alpha = 255) {
  const ww = Number(w);
  const hh = Number(h);
  const values = asF64Array(raw);
  if (values.length !== ww * hh) {
    throw new RangeError("colormapRgba scalar count must match width * height");
  }
  const stopArr = stops instanceof Uint8Array ? stops : Uint8Array.from(stops);
  if (stopArr.length % 3 !== 0 || stopArr.length < 3) {
    throw new RangeError("colormapRgba stops must be a non-empty multiple of 3");
  }
  const stopCount = stopArr.length / 3;
  const out = new Uint8Array(hh * ww * 4);
  const ok = xyColormapRgba(
    f64Ptr(values),
    BigInt(ww),
    BigInt(hh),
    u8Ptr(stopArr),
    BigInt(stopCount),
    Number(alpha),
    u8Ptr(out),
    BigInt(out.byteLength),
  );
  if (ok !== 1) {
    throw new Error("xy_colormap_rgba failed");
  }
  return { rgba: out, width: ww, height: hh };
}

/** Map canonical f64 scalars through domain normalization to RGBA bytes. */
export function colormapRgbaCanonical(raw, w, h, domain, stops, alpha = 255) {
  const ww = Number(w);
  const hh = Number(h);
  const values = asF64Array(raw);
  if (values.length !== ww * hh) {
    throw new RangeError("colormapRgbaCanonical scalar count must match width * height");
  }
  const stopArr = stops instanceof Uint8Array ? stops : Uint8Array.from(stops);
  if (stopArr.length % 3 !== 0 || stopArr.length < 3) {
    throw new RangeError("colormapRgbaCanonical stops must be a non-empty multiple of 3");
  }
  const stopCount = stopArr.length / 3;
  const out = new Uint8Array(hh * ww * 4);
  const ok = xyColormapRgbaCanonical(
    f64Ptr(values),
    BigInt(ww),
    BigInt(hh),
    Number(domain[0]),
    Number(domain[1]),
    u8Ptr(stopArr),
    BigInt(stopCount),
    Number(alpha),
    u8Ptr(out),
    BigInt(out.byteLength),
  );
  if (ok !== 1) {
    throw new Error("xy_colormap_rgba_canonical failed");
  }
  return { rgba: out, width: ww, height: hh };
}

/** 1D colormap sample matching `_svg._lut` (ABI 206). */
export function colormapLut(t, stops) {
  const values = asF64Array(t);
  const stopArr = stops instanceof Uint8Array ? stops : Uint8Array.from(stops);
  if (stopArr.length % 3 !== 0 || stopArr.length < 3) {
    throw new RangeError("colormapLut stops must be a non-empty multiple of 3");
  }
  const n = values.length;
  const out = new Uint8Array(n * 3);
  const ok = xyColormapLut(
    n ? f64Ptr(values) : 0,
    BigInt(n),
    u8Ptr(stopArr),
    BigInt(stopArr.length / 3),
    n ? u8Ptr(out) : 0,
  );
  if (ok !== 1) {
    throw new Error("xy_colormap_lut failed");
  }
  return out;
}

/** 256-texel RGBA8 LUT matching Python `colormap_lut_rgba8` (ABI 343). */
export function colormapLutRgba8(nameOrStops, nTexels = 256) {
  const count = Math.max(1, Math.floor(Number(nTexels)));
  const out = new Uint8Array(count * 4);
  let ok;
  if (typeof nameOrStops === "string" || nameOrStops == null) {
    const encoded = new TextEncoder().encode(String(nameOrStops ?? "viridis"));
    ok = Number(
      xyColormapLutRgba8(
        encoded.length ? u8Ptr(encoded) : 0,
        BigInt(encoded.length),
        0,
        0n,
        BigInt(count),
        u8Ptr(out),
        BigInt(out.length),
      ),
    );
  } else {
    const stopArr = nameOrStops instanceof Uint8Array ? nameOrStops : Uint8Array.from(nameOrStops);
    if (stopArr.length % 3 !== 0 || stopArr.length < 3) {
      throw new RangeError("colormapLutRgba8 stops must be a non-empty multiple of 3");
    }
    ok = Number(
      xyColormapLutRgba8(
        0,
        0n,
        stopArr.length ? u8Ptr(stopArr) : 0,
        BigInt(stopArr.length / 3),
        BigInt(count),
        u8Ptr(out),
        BigInt(out.length),
      ),
    );
  }
  if (ok !== 1) {
    throw new Error("xy_colormap_lut_rgba8 failed");
  }
  return out;
}

/** Legacy f64 count-grid density colormap (ABI 206). */
export function densityRgbaLinear(counts, w, h, maximum, stops, opacity) {
  const ww = Number(w);
  const hh = Number(h);
  const values = asF64Array(counts);
  if (values.length !== ww * hh) {
    throw new RangeError("densityRgbaLinear scalar count must match width * height");
  }
  const stopArr = stops instanceof Uint8Array ? stops : Uint8Array.from(stops);
  if (stopArr.length % 3 !== 0 || stopArr.length < 3) {
    throw new RangeError("densityRgbaLinear stops must be a non-empty multiple of 3");
  }
  const out = new Uint8Array(hh * ww * 4);
  const ok = xyDensityRgbaLinear(
    f64Ptr(values),
    BigInt(ww),
    BigInt(hh),
    Number(maximum),
    u8Ptr(stopArr),
    BigInt(stopArr.length / 3),
    Number(opacity),
    u8Ptr(out),
    BigInt(out.byteLength),
  );
  if (ok !== 1) {
    throw new Error("xy_density_rgba_linear failed");
  }
  return { rgba: out, width: ww, height: hh };
}

/** Matplotlib artist-alpha replace then xy opacity multiply (ABI 206). */
export function paintEffectiveRgba(intrinsic, artistAlpha, opacity, componentOpacity) {
  const rgba = asF64Array(intrinsic);
  if (rgba.length % 4 !== 0) {
    throw new RangeError("paintEffectiveRgba intrinsic must be N*4 f64s");
  }
  const n = rgba.length / 4;
  const artist = asF64Array(artistAlpha);
  const opac = asF64Array(opacity);
  if (artist.length !== n || opac.length !== n) {
    throw new RangeError("paintEffectiveRgba artist/opacity length must match N");
  }
  const out = new Float64Array(rgba.length);
  const ok = xyPaintEffectiveRgba(
    n ? f64Ptr(rgba) : 0,
    BigInt(n),
    n ? f64Ptr(artist) : 0,
    n ? f64Ptr(opac) : 0,
    Number(componentOpacity),
    n ? f64Ptr(out) : 0,
  );
  if (ok !== 1) {
    throw new Error("xy_paint_effective_rgba failed");
  }
  return out;
}

/** Resolve a named colormap to packed RGB triples (`n * 3` bytes). */
export function colormapNamedStops(name) {
  const encoded = new TextEncoder().encode(String(name ?? ""));
  const out = new Uint8Array(256 * 3);
  const count = Number(xyColormapStops(
    encoded.length ? u8Ptr(encoded) : null,
    BigInt(encoded.length),
    u8Ptr(out),
    BigInt(out.length),
  ));
  if (count <= 0) {
    throw new Error("xy_colormap_stops failed");
  }
  return out.subarray(0, count * 3);
}

export function boxStats(data) {
  const arr = asF64Array(data);
  const stats = new Float64Array(5);
  const outliers = new Float64Array(arr.length);
  const nOut = new BigUint64Array(1);
  const ok = xyBoxStats(
    f64Ptr(arr),
    BigInt(arr.length),
    f64Ptr(stats),
    arr.length ? f64Ptr(outliers) : null,
    BigInt(arr.length),
    pointer(nOut, "size_t *"),
  );
  if (ok !== 1) {
    throw new Error("xy_box_stats failed");
  }
  return {
    q1: stats[0],
    median: stats[1],
    q3: stats[2],
    low: stats[3],
    high: stats[4],
    outliers: outliers.subarray(0, Number(nOut[0])),
  };
}

export function boxGeometry(groups, positions, width, orientation, showOutliers = true) {
  const offsets = new BigUint64Array(groups.length + 1);
  let total = 0;
  for (let index = 0; index < groups.length; index += 1) {
    total += groups[index].length;
    offsets[index + 1] = BigInt(total);
  }
  const values = new Float64Array(total);
  let at = 0;
  for (const group of groups) { values.set(group, at); at += group.length; }
  const centers = Float64Array.from(positions);
  const nOutliers = new BigUint64Array(1);
  const call = (active, records, outlierOffsets, outlierRecords, groupCap, outlierCap) => Number(xyBoxGeometry(
    f64Ptr(values), BigInt(values.length), pointer(offsets, "size_t *"), BigInt(offsets.length),
    f64Ptr(centers), BigInt(centers.length), Number(width),
    orientation === "vertical" ? 0 : orientation === "horizontal" ? 1 : 2,
    showOutliers ? 1 : 0, pointer(nOutliers, "size_t *"), u32Ptr(active), f64Ptr(records),
    pointer(outlierOffsets, "size_t *"), f64Ptr(outlierRecords), BigInt(groupCap), BigInt(outlierCap),
  ));
  const required = call(null, null, null, null, 0, 0);
  const outliers = Number(nOutliers[0]);
  if (!Number.isSafeInteger(required) || required <= 0 || required > 2_000 ||
      !Number.isSafeInteger(outliers) || outliers < 0 || required * 5 + outliers > 10_000) {
    throw new RangeError("invalid bounded box geometry");
  }
  const active = new Uint32Array(required);
  const records = new Float64Array(required * 25);
  const outlierOffsets = new BigUint64Array(required + 1);
  const outlierRecords = new Float64Array(outliers * 3);
  if (call(active, records, outlierOffsets, outlierRecords, required, outliers) !== required) {
    throw new Error("xy_box_geometry failed");
  }
  const body = [0, 1, 2, 3].map(() => new Float64Array(required));
  const whiskers = [0, 1, 2, 3].map(() => new Float64Array(required * 3));
  const medians = [0, 1, 2, 3].map(() => new Float64Array(required));
  const groupStats = [];
  for (let group = 0; group < required; group += 1) {
    const base = group * 25;
    for (let coordinate = 0; coordinate < 4; coordinate += 1) {
      body[coordinate][group] = records[base + 5 + coordinate];
      medians[coordinate][group] = records[base + 21 + coordinate];
      for (let segment = 0; segment < 3; segment += 1) {
        whiskers[coordinate][group * 3 + segment] = records[base + 9 + segment * 4 + coordinate];
      }
    }
    const start = Number(outlierOffsets[group]);
    const end = Number(outlierOffsets[group + 1]);
    groupStats.push({
      q1: records[base], median: records[base + 1], q3: records[base + 2],
      low: records[base + 3], high: records[base + 4],
      outliers: Float64Array.from({ length: end - start }, (_, index) => outlierRecords[(start + index) * 3]),
    });
  }
  return {
    activeGroups: active, groupStats, body, whiskers, medians,
    outlierX: showOutliers ? Float64Array.from({ length: outliers }, (_, index) => outlierRecords[index * 3 + 1]) : new Float64Array(),
    outlierY: showOutliers ? Float64Array.from({ length: outliers }, (_, index) => outlierRecords[index * 3 + 2]) : new Float64Array(),
  };
}

export function quantiles(data, probs) {
  const arr = asF64Array(data);
  const p = asF64Array(probs);
  const out = new Float64Array(p.length);
  const written = Number(xyQuantiles(f64Ptr(arr), BigInt(arr.length), f64Ptr(p), BigInt(p.length), f64Ptr(out)));
  if (!Number.isFinite(written) || written < 0) {
    throw new Error("xy_quantiles failed");
  }
  return out;
}


/** Wind-rose directional/speed binning; `speedEdges` omitted → auto quartiles. */
export function windRoseBins(directions, speeds, sectors, speedEdges = null) {
  const dirs = asF64Array(directions);
  const mags = asF64Array(speeds);
  if (dirs.length !== mags.length) {
    throw new RangeError("windRoseBins directions/speeds length mismatch");
  }
  if (!Number.isInteger(sectors) || sectors < 3 || sectors > 3600) {
    throw new RangeError("windRoseBins sectors must be in 3..=3600");
  }
  const edgesIn = speedEdges == null ? null : asF64Array(speedEdges);
  const nEdges = edgesIn == null ? 0 : edgesIn.length;
  const capacityEdges = edgesIn == null ? 4 : Math.max(nEdges, 1);
  const outEdges = new Float64Array(capacityEdges);
  const outCentres = new Float64Array(sectors);
  const capacityCounts = capacityEdges * sectors;
  const outCounts = new Float64Array(capacityCounts);
  const nObs = new BigUint64Array(1);
  const written = Number(
    xyWindRoseBins(
      f64Ptr(dirs),
      f64Ptr(mags),
      BigInt(dirs.length),
      BigInt(sectors),
      edgesIn == null ? null : f64Ptr(edgesIn),
      BigInt(nEdges),
      f64Ptr(outEdges),
      BigInt(capacityEdges),
      f64Ptr(outCentres),
      f64Ptr(outCounts),
      BigInt(capacityCounts),
      pointer(nObs, "size_t *"),
    ),
  );
  if (!Number.isFinite(written) || written < 0 || written > capacityEdges) {
    throw new Error("xy_wind_rose_bins failed");
  }
  return {
    edges: outEdges.subarray(0, written),
    centres: outCentres,
    counts: outCounts.subarray(0, written * sectors),
    nObs: Number(nObs[0]),
    sectors,
  };
}

/** Bilinear contourf densify (paired with contourfBands for corner-mask). */
export function contourfDensify(z, rows, cols, xpos, ypos) {
  const zz = asF64Array(z);
  const xx = asF64Array(xpos);
  const yy = asF64Array(ypos);
  if (zz.length !== rows * cols || xx.length !== cols || yy.length !== rows) {
    throw new RangeError("contourfDensify shape mismatch");
  }
  const sampleCount = (size) => {
    if (size > 512) return size;
    return Math.min(512, Math.max(256, (size - 1) * 8 + 1));
  };
  const outRows = sampleCount(rows);
  const outCols = sampleCount(cols);
  const outZ = new Float64Array(outRows * outCols);
  const outX = new Float64Array(outCols);
  const outY = new Float64Array(outRows);
  const gotRows = new BigUint64Array(1);
  const gotCols = new BigUint64Array(1);
  const ok = xyContourfDensify(
    f64Ptr(zz),
    BigInt(rows),
    BigInt(cols),
    f64Ptr(xx),
    f64Ptr(yy),
    f64Ptr(outZ),
    f64Ptr(outX),
    f64Ptr(outY),
    BigInt(outZ.length),
    BigInt(outX.length),
    BigInt(outY.length),
    pointer(gotRows, "size_t *"),
    pointer(gotCols, "size_t *"),
  );
  if (ok !== 1) {
    throw new Error("xy_contourf_densify failed");
  }
  const r = Number(gotRows[0]);
  const c = Number(gotCols[0]);
  return {
    z: outZ.subarray(0, r * c),
    x: outX.subarray(0, c),
    y: outY.subarray(0, r),
    rows: r,
    cols: c,
  };
}

const BAR_MODES = { grouped: 0, stacked: 1, normalized: 2 };
const BAR_ORIENT = { vertical: 0, horizontal: 1 };

/** Grouped / stacked / normalized bar rect corners via xyg_bar_stack. */
export function barStack(pos, values, nSeries, width = 0.8, base = 0, mode = "grouped", orientation = "vertical") {
  const p = asF64Array(pos);
  const vals = asF64Array(values);
  const nItems = p.length;
  if (!Number.isInteger(nSeries) || nSeries < 1 || vals.length !== nSeries * nItems) {
    throw new RangeError("barStack values must be row-major nSeries * nItems");
  }
  if (!(mode in BAR_MODES) || !(orientation in BAR_ORIENT)) {
    throw new RangeError("barStack mode/orientation invalid");
  }
  const widthArr = typeof width === "number" ? new Float64Array([width]) : asF64Array(width);
  const baseArr = typeof base === "number" ? new Float64Array([base]) : asF64Array(base);
  const outX0 = new Float64Array(nSeries * nItems);
  const outX1 = new Float64Array(nSeries * nItems);
  const outY0 = new Float64Array(nSeries * nItems);
  const outY1 = new Float64Array(nSeries * nItems);
  const ok = xyBarStack(
    f64Ptr(p),
    BigInt(nItems),
    f64Ptr(vals),
    BigInt(nSeries),
    f64Ptr(widthArr),
    BigInt(widthArr.length),
    f64Ptr(baseArr),
    BigInt(baseArr.length),
    BAR_MODES[mode],
    BAR_ORIENT[orientation],
    f64Ptr(outX0),
    f64Ptr(outX1),
    f64Ptr(outY0),
    f64Ptr(outY1),
  );
  if (ok !== 1) {
    throw new Error("xyg_bar_stack failed");
  }
  return { x0: outX0, x1: outX1, y0: outY0, y1: outY1, nSeries, nItems };
}

/** Corner-mask contourf band triangles via xy_contourf_bands. */
export function contourfBands(z, rows, cols, xpos, ypos, edges, { extendMin = false, extendMax = false } = {}) {
  const zz = asF64Array(z);
  const xx = asF64Array(xpos);
  const yy = asF64Array(ypos);
  const ee = asF64Array(edges);
  if (zz.length !== rows * cols || xx.length !== cols || yy.length !== rows || ee.length < 2) {
    throw new RangeError("contourfBands shape mismatch");
  }
  const needed = Number(
    xyContourfBands(
      f64Ptr(zz),
      BigInt(rows),
      BigInt(cols),
      f64Ptr(xx),
      f64Ptr(yy),
      f64Ptr(ee),
      BigInt(ee.length),
      extendMin ? 1 : 0,
      extendMax ? 1 : 0,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      0n,
    ),
  );
  if (!Number.isFinite(needed) || needed < 0) {
    throw new Error("xy_contourf_bands failed");
  }
  if (needed === 0) {
    return {
      x0: new Float64Array(0),
      y0: new Float64Array(0),
      x1: new Float64Array(0),
      y1: new Float64Array(0),
      x2: new Float64Array(0),
      y2: new Float64Array(0),
      slots: new BigInt64Array(0),
    };
  }
  const x0 = new Float64Array(needed);
  const y0 = new Float64Array(needed);
  const x1 = new Float64Array(needed);
  const y1 = new Float64Array(needed);
  const x2 = new Float64Array(needed);
  const y2 = new Float64Array(needed);
  const slots = new BigInt64Array(needed);
  const written = Number(
    xyContourfBands(
      f64Ptr(zz),
      BigInt(rows),
      BigInt(cols),
      f64Ptr(xx),
      f64Ptr(yy),
      f64Ptr(ee),
      BigInt(ee.length),
      extendMin ? 1 : 0,
      extendMax ? 1 : 0,
      f64Ptr(x0),
      f64Ptr(y0),
      f64Ptr(x1),
      f64Ptr(y1),
      f64Ptr(x2),
      f64Ptr(y2),
      pointer(slots, "int64_t *"),
      BigInt(needed),
    ),
  );
  if (written !== needed) {
    throw new Error("xy_contourf_bands inconsistent count");
  }
  return { x0, y0, x1, y1, x2, y2, slots };
}

/**
 * Axis-aligned 2-D density counts via `xyg_bin_2d` (row-major float grid).
 * @returns {Float32Array} length w*h
 */
export function bin2d(x, y, x0, x1, y0, y1, w, h) {
  const xa = asF64Array(x, "x");
  const ya = asF64Array(y, "y");
  if (xa.length !== ya.length) {
    throw new RangeError("bin2d x/y length mismatch");
  }
  const ww = Math.max(1, Math.floor(Number(w)));
  const hh = Math.max(1, Math.floor(Number(h)));
  const out = new Float32Array(ww * hh);
  const ok = xyBin2d(
    f64Ptr(xa),
    f64Ptr(ya),
    BigInt(xa.length),
    Number(x0),
    Number(x1),
    Number(y0),
    Number(y1),
    BigInt(ww),
    BigInt(hh),
    f32Ptr(out),
  );
  if (ok !== 1) {
    throw new Error("xyg_bin_2d failed");
  }
  return out;
}

/**
 * Fused density scan: `(bin2d grid, range_indices rows)` in one pass.
 * @returns {{grid: Float32Array, indices: Uint32Array}}
 */
export function bin2dIndices(x, y, x0, x1, y0, y1, w, h) {
  const xa = asF64Array(x, "x");
  const ya = asF64Array(y, "y");
  if (xa.length !== ya.length) {
    throw new RangeError("bin2dIndices x/y length mismatch");
  }
  const ww = Math.max(1, Math.floor(Number(w)));
  const hh = Math.max(1, Math.floor(Number(h)));
  const grid = new Float32Array(ww * hh);
  const idx = new Uint32Array(xa.length);
  if (xa.length === 0) {
    return { grid, indices: idx };
  }
  const written = Number(xyBin2dIndices(
    f64Ptr(xa),
    f64Ptr(ya),
    BigInt(xa.length),
    Number(x0),
    Number(x1),
    Number(y0),
    Number(y1),
    BigInt(ww),
    BigInt(hh),
    f32Ptr(grid),
    u32Ptr(idx),
  ));
  if (written === Number.MAX_SAFE_INTEGER) {
    throw new Error("xyg_bin_2d_indices failed");
  }
  const indices = written === xa.length ? idx : idx.subarray(0, written);
  return { grid, indices };
}

const SAMPLE_UINT64_MAX = 18446744073709551615n;

export function sampleFraction(level, baseFraction, growth) {
  return Number(xySampleFraction(BigInt(Math.floor(Number(level))), Number(baseFraction), Number(growth)));
}

/** Stratified sample range planning (ABI 345, Python `lod._stratified_sample_range_plan`). */
export function stratifiedSampleRangePlan(
  nRows,
  nGroups,
  target,
  level,
  growth,
  seed,
  minPerCategory,
) {
  const fraction = new Float64Array(1);
  const seedOut = new BigUint64Array(1);
  const minCount = new Uint32Array(1);
  const capacity = new BigUint64Array(1);
  const keepAll = new Uint32Array(1);
  const code = Number(xyStratifiedSampleRangePlan(
    BigInt(Math.max(0, Math.floor(Number(nRows)))),
    Number(nGroups) >>> 0,
    Number(target) >>> 0,
    BigInt(Math.floor(Number(level))),
    Number(growth),
    BigInt(seed),
    Number(minPerCategory) >>> 0,
    pointer(fraction, "double *"),
    pointer(seedOut, "uint64_t *"),
    pointer(minCount, "uint32_t *"),
    pointer(capacity, "size_t *"),
    pointer(keepAll, "uint32_t *"),
  ));
  if (code !== 1) {
    throw new RangeError("invalid stratified-sample-range-plan request");
  }
  return {
    fraction: fraction[0],
    seed: seedOut[0],
    minCount: minCount[0],
    capacity: Number(capacity[0]),
    keepAll: keepAll[0] === 1,
  };
}

export function sampleThreshold(fraction) {
  return xySampleThreshold(Number(fraction));
}

/** Deterministic subset mask for explicit row ids (`xyg_sample_mask_u32`). */
export function sampleMaskU32(ids, seed, threshold) {
  const arr = ids instanceof Uint32Array ? ids : Uint32Array.from(ids, (value) => value >>> 0);
  const out = new Uint8Array(arr.length);
  if (arr.length === 0) {
    return out;
  }
  const ok = Number(xySampleMaskU32(
    u32Ptr(arr),
    BigInt(arr.length),
    BigInt(seed),
    threshold,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new Error("xyg_sample_mask_u32 failed");
  }
  return out;
}

/** Target-sized row subset matching Python `lod.sample_rows_for_target`. */
export function sampleRowsForTarget(rowIds, target, {
  level = 0,
  growth = 2.0,
  seed = 0,
} = {}) {
  const ids = rowIds instanceof Uint32Array ? rowIds : Uint32Array.from(rowIds, (value) => value >>> 0);
  if (ids.length === 0) {
    return ids;
  }
  const targetI = Math.floor(Number(target));
  if (!Number.isFinite(targetI) || targetI <= 0) {
    throw new RangeError("sampleRowsForTarget target must be >= 1");
  }
  const baseFraction = Math.min(1.0, targetI / Math.max(1, ids.length));
  const fraction = sampleFraction(level, baseFraction, growth);
  if (fraction >= 1.0) {
    return ids;
  }
  const mask = sampleMaskU32(ids, seed, sampleThreshold(fraction));
  let kept = 0;
  for (let i = 0; i < mask.length; i++) {
    if (mask[i]) kept += 1;
  }
  const out = new Uint32Array(kept);
  let j = 0;
  for (let i = 0; i < ids.length; i++) {
    if (mask[i]) {
      out[j] = ids[i];
      j += 1;
    }
  }
  return out;
}

/**
 * Encode a float density grid as log-u8 for the wire (§5 Tier 2).
 * @returns {{encoded: Uint8Array, max: number}}
 */
export function densityLogU8(grid) {
  const arr = grid instanceof Float32Array ? grid : Float32Array.from(grid, Number);
  const out = new Uint8Array(arr.length);
  const maxBuf = new Float64Array(1);
  const ok = xyDensityLogU8(f32Ptr(arr), BigInt(arr.length), u8Ptr(out), f64Ptr(maxBuf));
  if (ok !== 1) {
    throw new Error("xy_density_log_u8 failed");
  }
  return { encoded: out, max: maxBuf[0] };
}

/**
 * Mean-color companion grid to `bin2d` (LOD doc §2): (h*w*4) straight-alpha
 * RGBA8, row 0 = bottom. `source` is either `{ rgba: Uint8Array }` or
 * `{ idx: Uint8Array, lut: Uint8Array }` with lut length a multiple of 4.
 */
export function bin2dMeanColor(x, y, x0, x1, y0, y1, w, h, source) {
  const xa = asF64Array(x, "x");
  const ya = asF64Array(y, "y");
  if (xa.length !== ya.length) {
    throw new RangeError("bin2dMeanColor x/y length mismatch");
  }
  const ww = Math.max(1, Math.floor(Number(w)));
  const hh = Math.max(1, Math.floor(Number(h)));
  const out = new Uint8Array(ww * hh * 4);
  let idxPtr = 0;
  let rgbaPtr = 0;
  let lutPtr = 0;
  let lutLen = 0n;
  if (source?.rgba != null) {
    const rgba = source.rgba instanceof Uint8Array ? source.rgba : Uint8Array.from(source.rgba);
    if (rgba.length !== xa.length * 4) {
      throw new RangeError("bin2dMeanColor rgba length must be 4 * n");
    }
    rgbaPtr = xa.length ? u8Ptr(rgba) : 0;
  } else if (source?.idx != null && source?.lut != null) {
    const idx = source.idx instanceof Uint8Array ? source.idx : Uint8Array.from(source.idx);
    const lut = source.lut instanceof Uint8Array ? source.lut : Uint8Array.from(source.lut);
    if (idx.length !== xa.length) {
      throw new RangeError("bin2dMeanColor idx length must match x/y");
    }
    if (lut.length < 4 || lut.length % 4 !== 0 || lut.length / 4 > 256) {
      throw new RangeError("bin2dMeanColor lut must be 1..256 RGBA8 entries");
    }
    idxPtr = xa.length ? u8Ptr(idx) : 0;
    lutPtr = u8Ptr(lut);
    lutLen = BigInt(lut.length / 4);
  } else {
    throw new RangeError("bin2dMeanColor requires rgba or idx+lut");
  }
  const ok = xyBin2dMeanColor(
    f64Ptr(xa),
    f64Ptr(ya),
    BigInt(xa.length),
    idxPtr,
    rgbaPtr,
    lutPtr,
    lutLen,
    Number(x0),
    Number(x1),
    Number(y0),
    Number(y1),
    BigInt(ww),
    BigInt(hh),
    u8Ptr(out),
    BigInt(out.byteLength),
  );
  if (ok !== 1) {
    throw new Error("xyg_bin_2d_mean_color failed");
  }
  return out;
}

/**
 * Regular-grid contour isolines via `xy_marching_squares`.
 * @returns {{x0: Float64Array, x1: Float64Array, y0: Float64Array, y1: Float64Array, levels: Float64Array}}
 */
export function marchingSquares(z, rows, cols, xCoords, yCoords, levels, { cornerMask = false } = {}) {
  const zz = asF64Array(z, "z");
  const xc = asF64Array(xCoords, "x_coords");
  const yc = asF64Array(yCoords, "y_coords");
  const lv = asF64Array(levels, "levels");
  const r = Math.floor(Number(rows));
  const c = Math.floor(Number(cols));
  if (zz.length !== r * c || r < 2 || c < 2) {
    throw new RangeError("marchingSquares z must be rows*cols with rows,cols ≥ 2");
  }
  if (xc.length !== c || yc.length !== r) {
    throw new RangeError("marchingSquares x/y coords must match cols/rows");
  }
  if (lv.length === 0 || lv.length > 256) {
    throw new RangeError("marchingSquares levels must contain 1..256 values");
  }
  let capacity = Math.max(64, (r - 1) * (c - 1) * lv.length);
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const x0 = new Float64Array(capacity);
    const x1 = new Float64Array(capacity);
    const y0 = new Float64Array(capacity);
    const y1 = new Float64Array(capacity);
    const outLevels = new Float64Array(capacity);
    const written = Number(
      xyMarchingSquares(
        f64Ptr(zz),
        BigInt(r),
        BigInt(c),
        f64Ptr(xc),
        f64Ptr(yc),
        f64Ptr(lv),
        BigInt(lv.length),
        cornerMask ? 1 : 0,
        f64Ptr(x0),
        f64Ptr(x1),
        f64Ptr(y0),
        f64Ptr(y1),
        f64Ptr(outLevels),
        BigInt(capacity),
      ),
    );
    if (!Number.isFinite(written) || written < 0) {
      throw new Error("xy_marching_squares failed");
    }
    if (written <= capacity) {
      return {
        x0: x0.subarray(0, written),
        x1: x1.subarray(0, written),
        y0: y0.subarray(0, written),
        y1: y1.subarray(0, written),
        levels: outLevels.subarray(0, written),
      };
    }
    capacity = written;
  }
  throw new Error("xy_marching_squares inconsistent capacity");
}

/** Clamp screen dimensions to LOD grid bounds (ABI 329, §5). */
export function screenShape(width, height) {
  const i32Max = 2_147_483_647;
  const outW = new Int32Array(1);
  const outH = new Int32Array(1);
  const ok = xyScreenShape(
    Math.min(Math.trunc(Number(width)), i32Max),
    Math.min(Math.trunc(Number(height)), i32Max),
    pointer(outW, "int32_t *"),
    pointer(outH, "int32_t *"),
  );
  if (ok !== 1) {
    throw new Error("xyg_screen_shape failed");
  }
  return [outW[0], outH[0]];
}

/**
 * View LOD plan — Rust owns exact vs density mode + grid shape (§28).
 */
export function lodPlan(visible, budget, { inDrill = false, exitFactor = DRILL_EXIT_FACTOR, pxW = 640, pxH = 360, targetPerCell = DENSITY_TARGET_POINTS_PER_CELL } = {}) {
  const exact = new Int32Array(1);
  const mode = new Uint32Array(1);
  const gw = new Int32Array(1);
  const gh = new Int32Array(1);
  const ok = xyLodPlan(
    BigInt(visible),
    Number(budget),
    inDrill ? 1 : 0,
    Number(exitFactor),
    Math.floor(Number(pxW)),
    Math.floor(Number(pxH)),
    Number(targetPerCell),
    pointer(exact, "int32_t *"),
    u32Ptr(mode),
    pointer(gw, "int32_t *"),
    pointer(gh, "int32_t *"),
  );
  if (ok !== 1) {
    throw new Error("xy_lod_plan failed");
  }
  return {
    exact: exact[0] === 1,
    mode: mode[0],
    gridW: gw[0],
    gridH: gh[0],
  };
}

/**
 * Drill hysteresis decision — Rust owns exact/density toggle (§28).
 */
export function drillDecision(visible, budget, { inDrill = false, exitFactor = DRILL_EXIT_FACTOR } = {}) {
  const exact = new Int32Array(1);
  const ok = xyDrillDecision(
    BigInt(visible),
    Number(budget),
    inDrill ? 1 : 0,
    Number(exitFactor),
    pointer(exact, "int32_t *"),
  );
  if (ok !== 1) {
    throw new Error("xy_drill_decision failed");
  }
  return { exact: exact[0] === 1 };
}

/**
 * Compile-time payload tier via `xyg_payload_tier` (ABI 122).
 * `kind` 0=line/area, 1=scatter. Returns 0=direct, 1=decimated, 2=density.
 */
export function payloadTier({
  kind,
  nPoints,
  polar = false,
  forceDensity = -1,
  forceDirect = false,
  perItem = false,
} = {}) {
  const code = xyPayloadTier(
    Number(kind),
    BigInt(nPoints),
    polar ? 1 : 0,
    Number(forceDensity),
    forceDirect ? 1 : 0,
    perItem ? 1 : 0,
  );
  if (code < 0) {
    throw new Error("xyg_payload_tier failed");
  }
  return code;
}

/**
 * Whether the payload visible-row mask can drop rows (ABI 122).
 */
export function payloadVisibleNeeded({
  xLog = false,
  yLog = false,
  prefiltered = false,
  xHasNulls = false,
  yHasNulls = false,
  hasBase = false,
  baseHasNulls = false,
} = {}) {
  const code = xyPayloadVisibleNeeded(
    xLog ? 1 : 0,
    yLog ? 1 : 0,
    prefiltered ? 1 : 0,
    xHasNulls ? 1 : 0,
    yHasNulls ? 1 : 0,
    hasBase ? 1 : 0,
    baseHasNulls ? 1 : 0,
  );
  if (code < 0) {
    throw new Error("xyg_payload_visible_needed failed");
  }
  return code === 1;
}

/**
 * Finite + log-positive keep mask via `xyg_payload_visible_mask`.
 */
export function payloadVisibleMask(x, y, { xLog = false, yLog = false, base = null } = {}) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("payloadVisibleMask x/y length mismatch");
  }
  const n = xa.length;
  const out = new Uint8Array(n);
  const hasBase = base != null;
  const ba = hasBase ? asF64Array(base) : null;
  if (hasBase && ba.length !== n) {
    throw new RangeError("payloadVisibleMask base length mismatch");
  }
  const written = requireWritten(
    Number(xyPayloadVisibleMask(
      n ? f64Ptr(xa) : null,
      n ? f64Ptr(ya) : null,
      BigInt(n),
      xLog ? 1 : 0,
      yLog ? 1 : 0,
      hasBase && n ? f64Ptr(ba) : null,
      hasBase ? 1 : 0,
      n ? u8Ptr(out) : null,
      BigInt(n),
    )),
    n,
    "xyg_payload_visible_mask",
  );
  return { mask: out, kept: written };
}

/**
 * Line M4 indices via `xyg_payload_m4_indices` (ABI 204).
 * Returns `{ tier, indices }`. `tier` is 0=direct (empty indices) or 1=decimated.
 * Rust owns the threshold, polar skip, and closed-window ulp.
 */
export function payloadM4Indices({
  nPoints,
  x,
  y,
  x0,
  x1,
  nBuckets,
  polar = false,
  binX = null,
  binX0 = 0,
  binX1 = 0,
} = {}) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("payloadM4Indices x/y length mismatch");
  }
  const n = xa.length;
  const ba = binX == null ? null : asF64Array(binX);
  if (ba != null && ba.length !== n) {
    throw new RangeError("payloadM4Indices binX length mismatch");
  }
  const cap = Math.max(0, Math.floor(Number(nBuckets))) * 4;
  const out = new Uint32Array(cap);
  const tier = new Int32Array([-1]);
  const written = requireWritten(
    Number(xyPayloadM4Indices(
      BigInt(nPoints),
      polar ? 1 : 0,
      n ? f64Ptr(xa) : 0,
      n ? f64Ptr(ya) : 0,
      BigInt(n),
      Number(x0),
      Number(x1),
      BigInt(Math.max(0, Math.floor(Number(nBuckets)))),
      ba != null && n ? f64Ptr(ba) : 0,
      Number(binX0),
      Number(binX1),
      pointer(tier, "int32_t *"),
      cap ? u32Ptr(out) : 0,
      BigInt(cap),
    )),
    cap,
    "xyg_payload_m4_indices",
  );
  return { tier: tier[0], indices: out.subarray(0, written) };
}

function readKeepAllIndices(written, keepAll, out, name) {
  if (!Number.isFinite(written) || written < 0 || written === Number.MAX_SAFE_INTEGER) {
    throw new Error(`${name} failed`);
  }
  if (keepAll[0] === 1) {
    return { keepAll: true, indices: new Uint32Array(0) };
  }
  if (written > out.length) {
    return { keepAll: false, required: written, indices: out };
  }
  return { keepAll: false, indices: out.subarray(0, written) };
}

/**
 * Fused keep-all vs keep-indices via `xyg_payload_visible_indices` (ABI 205).
 * `keepAll` means ship every row without an N-index allocation.
 */
export function payloadVisibleIndices(x, y, {
  xLog = false,
  yLog = false,
  base = null,
  prefiltered = false,
  xHasNulls = false,
  yHasNulls = false,
  hasBase = false,
  baseHasNulls = false,
} = {}) {
  const xa = asF64Array(x);
  const ya = asF64Array(y);
  if (xa.length !== ya.length) {
    throw new RangeError("payloadVisibleIndices x/y length mismatch");
  }
  const n = xa.length;
  const hasBaseFlag = Boolean(hasBase) || base != null;
  const ba = hasBaseFlag ? asF64Array(base) : null;
  if (hasBaseFlag && ba != null && ba.length !== n) {
    throw new RangeError("payloadVisibleIndices base length mismatch");
  }
  const cap = n;
  const out = new Uint32Array(cap);
  const keepAll = new Int32Array([-1]);
  const written = Number(xyPayloadVisibleIndices(
    n ? f64Ptr(xa) : 0,
    n ? f64Ptr(ya) : 0,
    BigInt(n),
    xLog ? 1 : 0,
    yLog ? 1 : 0,
    hasBaseFlag && n ? f64Ptr(ba) : 0,
    hasBaseFlag ? 1 : 0,
    prefiltered ? 1 : 0,
    xHasNulls ? 1 : 0,
    yHasNulls ? 1 : 0,
    baseHasNulls ? 1 : 0,
    pointer(keepAll, "int32_t *"),
    cap ? u32Ptr(out) : 0,
    BigInt(cap),
  ));
  const result = readKeepAllIndices(written, keepAll, out, "xyg_payload_visible_indices");
  if (result.required != null) {
    throw new Error("xyg_payload_visible_indices failed");
  }
  return result;
}

/**
 * Rows finite across every column, or `null` when every row is valid (ABI
 * `xyg_valid_indices_f64`). Matches Python `kernels.valid_indices_f64`.
 */
export function validIndicesF64(columns, { positiveColumns = [] } = {}) {
  if (!Array.isArray(columns) || columns.length < 1 || columns.length > 64) {
    throw new RangeError("columns must contain between 1 and 64 arrays");
  }
  const arrays = columns.map((column, index) => asF64Array(column, `columns[${index}]`));
  const size = arrays[0].length;
  if (arrays.some((array) => array.length !== size)) {
    throw new RangeError("validity columns must have equal length");
  }
  let positiveMask = 0n;
  for (const column of positiveColumns) {
    const index = Number(column);
    if (!Number.isInteger(index) || index < 0 || index >= arrays.length) {
      throw new RangeError("invalid positive column");
    }
    positiveMask |= 1n << BigInt(index);
  }
  const invoke = (output) => xyValidIndicesF64(
    arrays,
    BigInt(arrays.length),
    BigInt(size),
    positiveMask,
    output != null && output.length ? u32Ptr(output) : null,
    BigInt(output != null ? output.length : 0),
  );
  const written = invoke(null);
  if (written === USIZE_MAX_64 || Number(written) > size) {
    throw new RangeError("invalid valid_indices_f64 arguments");
  }
  if (Number(written) === size) return null;
  const output = new Uint32Array(size);
  const repeated = invoke(output);
  if (Number(repeated) !== Number(written)) {
    throw new Error("native valid_indices_f64 returned an inconsistent count");
  }
  return output.subarray(0, Number(written));
}

/**
 * Rows that can safely become rectangle/segment vertices, or `null` for all
 * rows. Matches Python `Figure._rect_finite_sel` (§19).
 */
export function rectFiniteSel(t, x0v, x1v, y0v, y1v) {
  const kind = t?.kind ?? "rect";
  if (t == null || t.x0 == null || t.x1 == null || t.y0 == null || t.y1 == null) {
    throw new Error(`${kind} trace missing rectangle columns`);
  }
  const candidates = [
    asF64Array(x0v),
    asF64Array(x1v),
    asF64Array(y0v),
    asF64Array(y1v),
  ];
  const channel = t.color_ch;
  if (channel && channel.mode === "continuous") {
    if (channel.values == null) {
      throw new Error(`${kind} continuous color channel missing values`);
    }
    candidates.push(asF64Array(channel.values));
  } else if (channel && channel.mode === "categorical") {
    if (channel.codes == null) {
      throw new Error(`${kind} categorical color channel missing codes`);
    }
  }
  return validIndicesF64(candidates);
}

/**
 * Even keep indices via `xyg_payload_even_indices` (ABI 205).
 * Matches NumPy `linspace(0, n-1, count, dtype=np.int64)`.
 */
export function payloadEvenIndices(n, count) {
  const nI = Math.floor(Number(n));
  const countI = Math.floor(Number(count));
  if (!Number.isFinite(nI) || nI < 0 || !Number.isFinite(countI) || countI <= 0) {
    throw new RangeError("payloadEvenIndices n/count must be n>=0 and count>=1");
  }
  const out = new Uint32Array(countI);
  const keepAll = new Int32Array([-1]);
  const written = Number(xyPayloadEvenIndices(
    BigInt(nI),
    BigInt(countI),
    pointer(keepAll, "int32_t *"),
    u32Ptr(out),
    BigInt(countI),
  ));
  const result = readKeepAllIndices(written, keepAll, out, "xyg_payload_even_indices");
  if (result.required != null) {
    throw new Error("xyg_payload_even_indices failed");
  }
  return result;
}

/**
 * Errorbar role-block keep indices via `xyg_payload_errorbar_indices` (ABI 215).
 * Even-samples `nPoints` at `budget` then expands `chosen[i] + k * nPoints`.
 */
export function payloadErrorbarIndices(nSegments, nPoints, budget) {
  const nSeg = Math.floor(Number(nSegments));
  const nPts = Math.floor(Number(nPoints));
  const budgetI = Math.floor(Number(budget));
  if (
    !Number.isFinite(nSeg) || nSeg < 0
    || !Number.isFinite(nPts) || nPts <= 0
    || !Number.isFinite(budgetI) || budgetI <= 0
  ) {
    throw new RangeError("payloadErrorbarIndices nSegments>=0, nPoints>=1, budget>=1");
  }
  const out = new Uint32Array(nSeg);
  const keepAll = new Int32Array([-1]);
  const written = Number(xyPayloadErrorbarIndices(
    BigInt(nSeg),
    BigInt(nPts),
    BigInt(budgetI),
    pointer(keepAll, "int32_t *"),
    nSeg ? u32Ptr(out) : 0,
    BigInt(nSeg),
  ));
  const result = readKeepAllIndices(written, keepAll, out, "xyg_payload_errorbar_indices");
  if (result.required != null) {
    throw new Error("xyg_payload_errorbar_indices failed");
  }
  return result;
}

/** Errorbar role-qualified transition keys via `xyg_payload_errorbar_role_keys` (ABI 273). */
export function payloadErrorbarRoleKeys(pointKeysLo, pointKeysHi, segmentSources, segmentRoles) {
  const nPoints = pointKeysLo.length;
  const nOutput = segmentSources.length;
  if (pointKeysHi.length !== nPoints || segmentRoles.length !== nOutput) {
    throw new RangeError("payloadErrorbarRoleKeys length mismatch");
  }
  const outLo = new Uint32Array(nOutput);
  const outHi = new Uint32Array(nOutput);
  const collision = new Int32Array(1);
  const written = Number(xyPayloadErrorbarRoleKeys(
    BigInt(nPoints),
    BigInt(nOutput),
    nPoints ? u32Ptr(pointKeysLo) : 0,
    nPoints ? u32Ptr(pointKeysHi) : 0,
    nOutput ? u32Ptr(segmentSources) : 0,
    nOutput ? u32Ptr(segmentRoles) : 0,
    nOutput ? u32Ptr(outLo) : 0,
    nOutput ? u32Ptr(outHi) : 0,
    pointer(collision, "int32_t *"),
  ));
  if (written === Number(USIZE_MAX_64)) {
    if (collision[0] === 1) {
      throw new RangeError("errorbar role-qualified animation key collision");
    }
    throw new RangeError("invalid payload-errorbar-role-keys request");
  }
  if (written !== nOutput) {
    throw new Error("xyg_payload_errorbar_role_keys returned an inconsistent count");
  }
  return { lo: outLo, hi: outHi };
}

/** Errorbar segment role/source maps via `xyg_payload_errorbar_role_maps` (ABI 261). */
export function payloadErrorbarRoleMaps(nSegments, nPoints) {
  const nSeg = Math.floor(Number(nSegments));
  const nPts = Math.floor(Number(nPoints));
  if (!Number.isFinite(nSeg) || nSeg < 0 || !Number.isFinite(nPts) || nPts <= 0) {
    throw new RangeError("payloadErrorbarRoleMaps nSegments>=0 and nPoints>=1");
  }
  const outSources = new Uint32Array(nSeg);
  const outRoles = new Uint32Array(nSeg);
  const applicable = new Int32Array(1);
  const ok = Number(xyPayloadErrorbarRoleMaps(
    BigInt(nSeg),
    BigInt(nPts),
    nSeg ? u32Ptr(outSources) : 0,
    nSeg ? u32Ptr(outRoles) : 0,
    pointer(applicable, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-errorbar-role-maps request");
  }
  if (applicable[0] !== 1) {
    return null;
  }
  return { segmentSources: outSources, segmentRoles: outRoles };
}

/** Segment emit gather via `xyg_payload_segments_emit_gather` (ABI 292). */
export function payloadSegmentsEmitGather(kind, nSegments, nPoints, pxWidth) {
  const kindText = String(kind ?? "");
  const kindBytes = new TextEncoder().encode(kindText);
  const nSeg = Math.floor(Number(nSegments));
  const nPts = Math.floor(Number(nPoints));
  const px = Number(pxWidth);
  if (!Number.isFinite(nSeg) || nSeg < 0 || !Number.isFinite(nPts) || nPts < 0 || !Number.isFinite(px)) {
    throw new RangeError("payloadSegmentsEmitGather requires finite non-negative counts and pxWidth");
  }
  const tier = new Int32Array(1);
  const roleMaps = new Int32Array(1);
  const keepAll = new Int32Array(1);
  const indices = new Uint32Array(nSeg);
  const sources = new Uint32Array(nSeg);
  const roles = new Uint32Array(nSeg);
  const written = Number(xyPayloadSegmentsEmitGather(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    BigInt(nSeg),
    BigInt(nPts),
    px,
    pointer(tier, "int32_t *"),
    pointer(roleMaps, "int32_t *"),
    pointer(keepAll, "int32_t *"),
    nSeg ? u32Ptr(indices) : 0,
    nSeg ? u32Ptr(sources) : 0,
    nSeg ? u32Ptr(roles) : 0,
    BigInt(nSeg),
  ));
  if (written === Number.MAX_SAFE_INTEGER) {
    throw new RangeError("invalid payload-segments-emit-gather request");
  }
  if (written > nSeg) {
    throw new Error("xyg_payload_segments_emit_gather returned an inconsistent count");
  }
  const out = {
    tier: tier[0],
    roleMaps: roleMaps[0] === 1,
    keepAll: keepAll[0] === 1,
    nOut: written,
  };
  if (!out.keepAll) {
    out.indices = indices.slice(0, written);
  }
  if (out.roleMaps) {
    out.sources = sources.slice(0, written);
    out.roles = roles.slice(0, written);
  }
  return out;
}

/** Always ship color/size via `_ship_channels` (scatter, hexbin, density sample). */
export const PAYLOAD_SHIP_CHANNELS_ALWAYS = 0;
/** Ship color/size only when `color_ch` is present (geometry marks). */
export const PAYLOAD_SHIP_CHANNELS_IF_COLOR = 1;

/** Rectangle / histogram / bar geometry emit (`_emit_rect`). */
export const PAYLOAD_NONXY_KIND_RECT = 0;
/** Hexbin center emit (`_emit_hexbin`). */
export const PAYLOAD_NONXY_KIND_HEXBIN = 1;
/** Density overlay sample sub-spec (`_density_sample_spec`). */
export const PAYLOAD_NONXY_KIND_DENSITY_SAMPLE = 2;

/** Histogram rect skeleton (`_emit_histogram`). */
export const PAYLOAD_BAR_HIST_KIND_HISTOGRAM = 0;
/** Bar/column compact skeleton (`_emit_bar_compact`). */
export const PAYLOAD_BAR_HIST_KIND_BAR_COMPACT = 1;

/** Vertical bar orientation. */
export const PAYLOAD_BAR_ORIENTATION_VERTICAL = 0;
/** Horizontal bar orientation. */
export const PAYLOAD_BAR_ORIENTATION_HORIZONTAL = 1;

const PAYLOAD_BAR_HIST_KIND_BY_NAME = {
  histogram: PAYLOAD_BAR_HIST_KIND_HISTOGRAM,
  bar_compact: PAYLOAD_BAR_HIST_KIND_BAR_COMPACT,
};

const PAYLOAD_BAR_ORIENTATION_BY_NAME = {
  vertical: PAYLOAD_BAR_ORIENTATION_VERTICAL,
  horizontal: PAYLOAD_BAR_ORIENTATION_HORIZONTAL,
};

const PAYLOAD_VALUE_AXIS_BY_CODE = ["y", "x"];

const PAYLOAD_NONXY_KIND_BY_NAME = {
  rect: PAYLOAD_NONXY_KIND_RECT,
  hexbin: PAYLOAD_NONXY_KIND_HEXBIN,
  density_sample: PAYLOAD_NONXY_KIND_DENSITY_SAMPLE,
};

/** Trace channel attach via `xyg_payload_trace_channels_ship_attach` (ABI 293). */
export function payloadTraceChannelsShipAttach(
  slot,
  {
    includeTraceStyles = false,
    hasColorCh = false,
    hasStrokeCh = false,
    hasStyleChannels = false,
  } = {},
) {
  const shipColor = new Int32Array(1);
  const shipSize = new Int32Array(1);
  const shipStroke = new Int32Array(1);
  const shipStyleChannels = new Int32Array(1);
  const ok = Number(xyPayloadTraceChannelsShipAttach(
    Number(slot),
    includeTraceStyles ? 1 : 0,
    hasColorCh ? 1 : 0,
    hasStrokeCh ? 1 : 0,
    hasStyleChannels ? 1 : 0,
    pointer(shipColor, "int32_t *"),
    pointer(shipSize, "int32_t *"),
    pointer(shipStroke, "int32_t *"),
    pointer(shipStyleChannels, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-trace-channels-ship-attach request");
  }
  return {
    shipColor: shipColor[0] === 1,
    shipSize: shipSize[0] === 1,
    shipStroke: shipStroke[0] === 1,
    shipStyleChannels: shipStyleChannels[0] === 1,
  };
}

/** Transition/tooltip attach via `xyg_payload_transition_entry_attach` (ABI 294). */
export function payloadTransitionEntryAttach({
  hasTraceAnimation = false,
  entryHasAnimation = false,
  hasTraceKeys = false,
  hasKeyValues = false,
  hasSel = false,
  tierDirect = false,
  nMarks = 0,
  nTraceKeyRows = 0,
  nKeyValueRows = 0,
  nSelRows = 0,
  maxRows = 200_000,
  hasTooltipRows = false,
  nTooltipRows = 0,
  nPoints = 0,
} = {}) {
  const attachAnimation = new Int32Array(1);
  const attemptKeys = new Int32Array(1);
  const filterKeysBySel = new Int32Array(1);
  const shipKeys = new Int32Array(1);
  const animationFallback = new Int32Array(1);
  const attachTooltip = new Int32Array(1);
  const filterTooltipBySel = new Int32Array(1);
  const tooltipLengthOk = new Int32Array(1);
  const ok = Number(xyPayloadTransitionEntryAttach(
    hasTraceAnimation ? 1 : 0,
    entryHasAnimation ? 1 : 0,
    hasTraceKeys ? 1 : 0,
    hasKeyValues ? 1 : 0,
    hasSel ? 1 : 0,
    tierDirect ? 1 : 0,
    BigInt(nMarks),
    BigInt(nTraceKeyRows),
    BigInt(nKeyValueRows),
    BigInt(nSelRows),
    BigInt(maxRows),
    hasTooltipRows ? 1 : 0,
    BigInt(nTooltipRows),
    BigInt(nPoints),
    pointer(attachAnimation, "int32_t *"),
    pointer(attemptKeys, "int32_t *"),
    pointer(filterKeysBySel, "int32_t *"),
    pointer(shipKeys, "int32_t *"),
    pointer(animationFallback, "int32_t *"),
    pointer(attachTooltip, "int32_t *"),
    pointer(filterTooltipBySel, "int32_t *"),
    pointer(tooltipLengthOk, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-transition-entry-attach request");
  }
  const fallbackCode = animationFallback[0];
  return {
    attachAnimation: attachAnimation[0] === 1,
    attemptKeys: attemptKeys[0] === 1,
    filterKeysBySel: filterKeysBySel[0] === 1,
    shipKeys: shipKeys[0] === 1,
    animationFallback: TRANSITION_FALLBACK_BY_CODE[fallbackCode] ?? null,
    attachTooltip: attachTooltip[0] === 1,
    filterTooltipBySel: filterTooltipBySel[0] === 1,
    tooltipLengthOk: tooltipLengthOk[0] === 1,
  };
}

const PAYLOAD_AXIS_TYPE_BY_SCALE = {
  log: 1,
  symlog: 2,
};

const PAYLOAD_SHIP_SCALE_BY_CODE = ["linear", "log", "symlog"];

function payloadAxisTypeCode(scale) {
  return PAYLOAD_AXIS_TYPE_BY_SCALE[scale] ?? 0;
}

/** Base-entry skeleton via `xyg_payload_base_entry_plan` (ABI 295). */
export function payloadBaseEntryPlan({
  hasTraceAnimation = false,
  nXv = 0,
  styleColorIsNone = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
} = {}) {
  const attachAnimation = new Int32Array(1);
  const nMarks = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const ok = Number(xyPayloadBaseEntryPlan(
    hasTraceAnimation ? 1 : 0,
    BigInt(nXv),
    styleColorIsNone ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    pointer(attachAnimation, "int32_t *"),
    pointer(nMarks, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-base-entry-plan request");
  }
  const xCode = xShipScale[0];
  const yCode = yShipScale[0];
  if (xCode < 0 || xCode >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
    throw new RangeError("invalid payload-base-entry-plan x ship scale");
  }
  if (yCode < 0 || yCode >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
    throw new RangeError("invalid payload-base-entry-plan y ship scale");
  }
  return {
    attachAnimation: attachAnimation[0] === 1,
    nMarks: Number(nMarks[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    xShipScale: PAYLOAD_SHIP_SCALE_BY_CODE[xCode],
    yShipScale: PAYLOAD_SHIP_SCALE_BY_CODE[yCode],
  };
}

/** Non-xy trace skeleton via `xyg_payload_nonxy_emit_plan` (ABI 296). */
export function payloadNonxyEmitPlan({
  kind = "rect",
  nMarks = 0,
  styleColorIsNone = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
} = {}) {
  const kindCode = PAYLOAD_NONXY_KIND_BY_NAME[kind];
  if (kindCode == null) {
    throw new RangeError(`invalid payload-nonxy-emit-plan kind ${kind}`);
  }
  const tierDirect = new Int32Array(1);
  const nMarksOut = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const channelSlot = new Int32Array(1);
  const includeTraceStyles = new Int32Array(1);
  const attachTransition = new Int32Array(1);
  const ok = Number(xyPayloadNonxyEmitPlan(
    kindCode,
    BigInt(nMarks),
    styleColorIsNone ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    pointer(tierDirect, "int32_t *"),
    pointer(nMarksOut, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    pointer(channelSlot, "int32_t *"),
    pointer(includeTraceStyles, "int32_t *"),
    pointer(attachTransition, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-nonxy-emit-plan request");
  }
  const xCode = xShipScale[0];
  const yCode = yShipScale[0];
  if (xCode < 0 || xCode >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
    throw new RangeError("invalid payload-nonxy-emit-plan x ship scale");
  }
  if (yCode < 0 || yCode >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
    throw new RangeError("invalid payload-nonxy-emit-plan y ship scale");
  }
  return {
    tierDirect: tierDirect[0] === 1,
    nMarks: Number(nMarksOut[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    xShipScale: PAYLOAD_SHIP_SCALE_BY_CODE[xCode],
    yShipScale: PAYLOAD_SHIP_SCALE_BY_CODE[yCode],
    channelSlot: channelSlot[0],
    includeTraceStyles: includeTraceStyles[0] === 1,
    attachTransition: attachTransition[0] === 1,
  };
}

/** Histogram / bar-compact skeleton via `xyg_payload_bar_hist_emit_plan` (ABI 297). */
export function payloadBarHistEmitPlan({
  kind = "histogram",
  compact = true,
  nMarks = 0,
  styleColorIsNone = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
  orientation = "vertical",
} = {}) {
  const kindCode = PAYLOAD_BAR_HIST_KIND_BY_NAME[kind];
  if (kindCode == null) {
    throw new RangeError(`invalid payload-bar-hist-emit-plan kind ${kind}`);
  }
  const orientationCode = PAYLOAD_BAR_ORIENTATION_BY_NAME[orientation];
  if (kindCode === PAYLOAD_BAR_HIST_KIND_BAR_COMPACT && orientationCode == null) {
    throw new RangeError(`invalid payload-bar-hist-emit-plan orientation ${orientation}`);
  }
  const emitBar = new Int32Array(1);
  const tierDirect = new Int32Array(1);
  const nMarksOut = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const posShipScale = new Int32Array(1);
  const valueShipScale = new Int32Array(1);
  const valueAxis = new Int32Array(1);
  const channelSlot = new Int32Array(1);
  const includeTraceStyles = new Int32Array(1);
  const attachTransition = new Int32Array(1);
  const ok = Number(xyPayloadBarHistEmitPlan(
    kindCode,
    compact ? 1 : 0,
    BigInt(nMarks),
    styleColorIsNone ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    kindCode === PAYLOAD_BAR_HIST_KIND_HISTOGRAM
      ? PAYLOAD_BAR_ORIENTATION_VERTICAL
      : orientationCode,
    pointer(emitBar, "int32_t *"),
    pointer(tierDirect, "int32_t *"),
    pointer(nMarksOut, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    pointer(posShipScale, "int32_t *"),
    pointer(valueShipScale, "int32_t *"),
    pointer(valueAxis, "int32_t *"),
    pointer(channelSlot, "int32_t *"),
    pointer(includeTraceStyles, "int32_t *"),
    pointer(attachTransition, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-bar-hist-emit-plan request");
  }
  const scaleName = (code) => {
    if (code < 0 || code >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
      throw new RangeError("invalid payload-bar-hist-emit-plan ship scale");
    }
    return PAYLOAD_SHIP_SCALE_BY_CODE[code];
  };
  const valueAxisCode = valueAxis[0];
  if (valueAxisCode < 0 || valueAxisCode >= PAYLOAD_VALUE_AXIS_BY_CODE.length) {
    throw new RangeError("invalid payload-bar-hist-emit-plan value axis");
  }
  return {
    emitBar: emitBar[0] === 1,
    tierDirect: tierDirect[0] === 1,
    nMarks: Number(nMarksOut[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    xShipScale: scaleName(xShipScale[0]),
    yShipScale: scaleName(yShipScale[0]),
    posShipScale: scaleName(posShipScale[0]),
    valueShipScale: scaleName(valueShipScale[0]),
    valueAxis: PAYLOAD_VALUE_AXIS_BY_CODE[valueAxisCode],
    channelSlot: channelSlot[0],
    includeTraceStyles: includeTraceStyles[0] === 1,
    attachTransition: attachTransition[0] === 1,
  };
}

export const PAYLOAD_HEATMAP_PATH_RGBA = 0;
/** @type {const} */
export const PAYLOAD_HEATMAP_PATH_GRID = 1;

const PAYLOAD_HEATMAP_PATH_BY_CODE = ["rgba", "grid"];

/** Heatmap emit skeleton via `xyg_payload_heatmap_emit_plan` (ABI 298). */
export function payloadHeatmapEmitPlan({
  hasRgbaGrid = false,
  gridRows = 0,
  gridCols = 0,
  styleColormapIsNone = false,
  borrowHeatmaps = false,
} = {}) {
  const path = new Int32Array(1);
  const tierDirect = new Int32Array(1);
  const nMarksOut = new BigUint64Array(1);
  const attachColor = new Int32Array(1);
  const borrowCanonical = new Int32Array(1);
  const attachEncoding = new Int32Array(1);
  const useConstantColormapFallback = new Int32Array(1);
  const ok = Number(xyPayloadHeatmapEmitPlan(
    hasRgbaGrid ? 1 : 0,
    BigInt(gridRows),
    BigInt(gridCols),
    styleColormapIsNone ? 1 : 0,
    borrowHeatmaps ? 1 : 0,
    pointer(path, "int32_t *"),
    pointer(tierDirect, "int32_t *"),
    pointer(nMarksOut, "size_t *"),
    pointer(attachColor, "int32_t *"),
    pointer(borrowCanonical, "int32_t *"),
    pointer(attachEncoding, "int32_t *"),
    pointer(useConstantColormapFallback, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-heatmap-emit-plan request");
  }
  const pathCode = path[0];
  if (pathCode < 0 || pathCode >= PAYLOAD_HEATMAP_PATH_BY_CODE.length) {
    throw new RangeError("invalid payload-heatmap-emit-plan path");
  }
  return {
    path: PAYLOAD_HEATMAP_PATH_BY_CODE[pathCode],
    tierDirect: tierDirect[0] === 1,
    nMarks: Number(nMarksOut[0]),
    attachColor: attachColor[0] === 1,
    borrowCanonical: borrowCanonical[0] === 1,
    attachEncoding: attachEncoding[0] === 1,
    useConstantColormapFallback: useConstantColormapFallback[0] === 1,
  };
}

/** Triangle-mesh emit skeleton via `xyg_payload_mesh_emit_plan` (ABI 298). */
export function payloadMeshEmitPlan({
  nMarks = 0,
  styleColorIsNone = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
  anyGeometryNulls = false,
  hasContinuousColor = false,
  continuousColorValuesMissing = false,
} = {}) {
  const tierDirect = new Int32Array(1);
  const nMarksOut = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const channelSlot = new Int32Array(1);
  const includeTraceStyles = new Int32Array(1);
  const attachTransition = new Int32Array(1);
  const attemptGather = new Int32Array(1);
  const gatherIncludeColor = new Int32Array(1);
  const ok = Number(xyPayloadMeshEmitPlan(
    BigInt(nMarks),
    styleColorIsNone ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    anyGeometryNulls ? 1 : 0,
    hasContinuousColor ? 1 : 0,
    continuousColorValuesMissing ? 1 : 0,
    pointer(tierDirect, "int32_t *"),
    pointer(nMarksOut, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    pointer(channelSlot, "int32_t *"),
    pointer(includeTraceStyles, "int32_t *"),
    pointer(attachTransition, "int32_t *"),
    pointer(attemptGather, "int32_t *"),
    pointer(gatherIncludeColor, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-mesh-emit-plan request");
  }
  const scaleName = (code) => {
    if (code < 0 || code >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
      throw new RangeError("invalid payload-mesh-emit-plan ship scale");
    }
    return PAYLOAD_SHIP_SCALE_BY_CODE[code];
  };
  return {
    tierDirect: tierDirect[0] === 1,
    nMarks: Number(nMarksOut[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    xShipScale: scaleName(xShipScale[0]),
    yShipScale: scaleName(yShipScale[0]),
    channelSlot: channelSlot[0],
    includeTraceStyles: includeTraceStyles[0] === 1,
    attachTransition: attachTransition[0] === 1,
    attemptGather: attemptGather[0] === 1,
    gatherIncludeColor: gatherIncludeColor[0] === 1,
  };
}

const PAYLOAD_COLUMN_SHIP_MAX = 8;
const PAYLOAD_COL_REGISTRY_KEY_BY_CODE = [
  "x", "y", "x0", "x1", "y0", "y1", "x2", "y2", "base", "target_y0", "target_y1",
  "pos", "value0", "value1",
];
const PAYLOAD_TRACE_SLOT_ATTR = ["x", "y", "x0", "x1", "y0", "y1", "base"];
const PAYLOAD_COL_SHIP_METHOD_BY_CODE = ["offset", "values", "f64"];
const PAYLOAD_GATHER_POLICY_BY_CODE = [
  "none",
  "visible_sel",
  "rect_finite",
  "valid_indices",
  "segments",
  "m4",
];

/** Column registry / gather plan via `xyg_payload_column_ship_plan` (ABI 310/314). */
export function payloadColumnShipPlan({
  kind = "rect",
  xAxisScale = "linear",
  yAxisScale = "linear",
  orientation = "vertical",
} = {}) {
  const kindBytes = Buffer.from(String(kind), "utf8");
  let orientationCode = PAYLOAD_BAR_ORIENTATION_BY_NAME[orientation];
  if (kind === "bar_compact") {
    if (orientationCode == null) {
      throw new RangeError(`invalid payload-column-ship-plan orientation ${orientation}`);
    }
  } else {
    orientationCode = PAYLOAD_BAR_ORIENTATION_VERTICAL;
  }
  const gatherPolicy = new Int32Array(1);
  const gatherIncludeColor = new Int32Array(1);
  const nColumns = new BigUint64Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const columns = Buffer.alloc(PAYLOAD_COLUMN_SHIP_MAX * 20);
  const ok = Number(xyPayloadColumnShipPlan(
    kindBytes,
    BigInt(kindBytes.length),
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    orientationCode,
    pointer(gatherPolicy, "int32_t *"),
    pointer(gatherIncludeColor, "int32_t *"),
    pointer(nColumns, "size_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    columns,
    BigInt(PAYLOAD_COLUMN_SHIP_MAX),
  ));
  if (ok !== 1) {
    throw new RangeError(`invalid payload-column-ship-plan kind ${kind}`);
  }
  const scaleName = (code) => {
    if (code < 0 || code >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
      throw new RangeError("invalid payload-column-ship-plan ship scale");
    }
    return PAYLOAD_SHIP_SCALE_BY_CODE[code];
  };
  const gatherCode = gatherPolicy[0];
  if (gatherCode < 0 || gatherCode >= PAYLOAD_GATHER_POLICY_BY_CODE.length) {
    throw new RangeError("invalid payload-column-ship-plan gather policy");
  }
  const n = Number(nColumns[0]);
  const xScale = scaleName(xShipScale[0]);
  const yScale = scaleName(yShipScale[0]);
  const outColumns = [];
  for (let idx = 0; idx < n; idx += 1) {
    const base = idx * 20;
    const keyCode = columns.readInt32LE(base);
    const slotCode = columns.readInt32LE(base + 4);
    const methodCode = columns.readInt32LE(base + 8);
    const scaleCode = columns.readInt32LE(base + 12);
    const gather = columns.readUInt32LE(base + 16) !== 0;
    if (
      keyCode < 0
      || keyCode >= PAYLOAD_COL_REGISTRY_KEY_BY_CODE.length
      || slotCode < 0
      || slotCode >= PAYLOAD_TRACE_SLOT_ATTR.length
      || methodCode < 0
      || methodCode >= PAYLOAD_COL_SHIP_METHOD_BY_CODE.length
      || (scaleCode !== 0 && scaleCode !== 1)
    ) {
      throw new RangeError("invalid payload-column-ship-plan column descriptor");
    }
    outColumns.push({
      registryKey: PAYLOAD_COL_REGISTRY_KEY_BY_CODE[keyCode],
      traceSlot: PAYLOAD_TRACE_SLOT_ATTR[slotCode],
      shipMethod: PAYLOAD_COL_SHIP_METHOD_BY_CODE[methodCode],
      shipScale: scaleCode === 1 ? yScale : xScale,
      gather,
    });
  }
  return {
    gatherPolicy: PAYLOAD_GATHER_POLICY_BY_CODE[gatherCode],
    gatherIncludeColor: gatherIncludeColor[0] === 1,
    nColumns: n,
    xShipScale: scaleName(xShipScale[0]),
    yShipScale: scaleName(yShipScale[0]),
    columns: outColumns,
  };
}

/**
 * Ship gathered geometry arrays into `entry` per the column registry (ABI 310/314).
 * @param {Record<string, unknown>} entry
 * @param {Record<string, unknown>} trace
 * @param {{ ship: Function, shipValues: Function, shipF64?: Function, columns: unknown[] }} pw
 * @param {ReturnType<typeof payloadColumnShipPlan>} columnPlan
 * @param {Record<string, ArrayLike<number>>} arrays
 * @param {{ skipKeys?: Set<string>, nestedKeys?: Set<string> }} [opts]
 */
export function shipRegistryColumns(entry, trace, pw, columnPlan, arrays, opts = {}) {
  const { skipKeys, nestedKeys } = opts;
  for (const col of columnPlan.columns) {
    const key = col.registryKey;
    if (skipKeys?.has(key)) {
      continue;
    }
    const slot = col.traceSlot;
    const values = arrays[key] ?? arrays[slot];
    let colIdx;
    if (col.shipMethod === "offset") {
      const slotCol = trace[`_${slot}Col`];
      const column = slotCol instanceof Column
        ? slotCol
        : (trace[slot] instanceof Column ? trace[slot] : new Column(trace[slot]));
      colIdx = pw.ship(values, column, { scale: col.shipScale });
    } else if (col.shipMethod === "f64") {
      if (typeof pw.shipF64 !== "function") {
        throw new RangeError("payload shipF64 unavailable");
      }
      colIdx = pw.shipF64(values);
    } else {
      const column = trace[slot];
      const kind = column?.kind ?? "float";
      colIdx = pw.shipValues(values, { kind, scale: col.shipScale });
    }
    if (nestedKeys?.has(key)) {
      entry[key] = { col: colIdx, ...pw.columns[colIdx] };
    } else {
      entry[key] = colIdx;
    }
  }
}

const PAYLOAD_DENSITY_GRID_SHIP_MAX_BUFFERS = 2;
const PAYLOAD_DENSITY_GRID_SHIP_MAX_ATTACH = 10;
const PAYLOAD_DENSITY_REGISTRY_KEY_BY_CODE = ["buf", "rgba"];
const PAYLOAD_DENSITY_BUFFER_SLOT_BY_CODE = ["count", "rgba"];
const PAYLOAD_DENSITY_SHIP_METHOD_BY_CODE = ["u8"];
const PAYLOAD_DENSITY_ATTACH_KIND_BY_CODE = [
  "wasm_source",
  "tiles",
  "rgba",
  "channels_dropped",
  "dropped_channels",
  "constant_color",
  "overlay_rows_exceed",
  "sample",
  "overlay_static_raster",
  "entry_color",
];

/** Density grid buffer registry and attach-order plan via `xyg_payload_density_grid_ship_plan` (ABI 315). */
export function payloadDensityGridShipPlan({
  shipMeanColorRgba = false,
  shipWasmSource = false,
  attachSample = false,
  hasTiles = false,
  shipConstantColor = false,
  overlayWireRowsExceed = false,
  overlayWireStaticRaster = false,
  shipCategoricalEntryColor = false,
} = {}) {
  const nBuffers = new BigUint64Array(1);
  const nAttach = new BigUint64Array(1);
  const buffers = Buffer.alloc(PAYLOAD_DENSITY_GRID_SHIP_MAX_BUFFERS * 12);
  const attach = Buffer.alloc(PAYLOAD_DENSITY_GRID_SHIP_MAX_ATTACH * 4);
  const ok = Number(xyPayloadDensityGridShipPlan(
    shipMeanColorRgba ? 1 : 0,
    shipWasmSource ? 1 : 0,
    attachSample ? 1 : 0,
    hasTiles ? 1 : 0,
    shipConstantColor ? 1 : 0,
    overlayWireRowsExceed ? 1 : 0,
    overlayWireStaticRaster ? 1 : 0,
    shipCategoricalEntryColor ? 1 : 0,
    pointer(nBuffers, "size_t *"),
    buffers,
    BigInt(PAYLOAD_DENSITY_GRID_SHIP_MAX_BUFFERS),
    pointer(nAttach, "size_t *"),
    attach,
    BigInt(PAYLOAD_DENSITY_GRID_SHIP_MAX_ATTACH),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-density-grid-ship-plan arguments");
  }
  const outBuffers = [];
  const bufN = Number(nBuffers[0]);
  for (let idx = 0; idx < bufN; idx += 1) {
    const base = idx * 12;
    const keyCode = buffers.readInt32LE(base);
    const slotCode = buffers.readInt32LE(base + 4);
    const methodCode = buffers.readInt32LE(base + 8);
    if (
      keyCode < 0
      || keyCode >= PAYLOAD_DENSITY_REGISTRY_KEY_BY_CODE.length
      || slotCode < 0
      || slotCode >= PAYLOAD_DENSITY_BUFFER_SLOT_BY_CODE.length
      || methodCode < 0
      || methodCode >= PAYLOAD_DENSITY_SHIP_METHOD_BY_CODE.length
    ) {
      throw new RangeError("invalid payload-density-grid-ship-plan buffer descriptor");
    }
    outBuffers.push({
      registryKey: PAYLOAD_DENSITY_REGISTRY_KEY_BY_CODE[keyCode],
      bufferSlot: PAYLOAD_DENSITY_BUFFER_SLOT_BY_CODE[slotCode],
      shipMethod: PAYLOAD_DENSITY_SHIP_METHOD_BY_CODE[methodCode],
    });
  }
  const outAttach = [];
  const attachN = Number(nAttach[0]);
  for (let idx = 0; idx < attachN; idx += 1) {
    const kindCode = attach.readInt32LE(idx * 4);
    if (kindCode < 0 || kindCode >= PAYLOAD_DENSITY_ATTACH_KIND_BY_CODE.length) {
      throw new RangeError("invalid payload-density-grid-ship-plan attach kind");
    }
    outAttach.push({ attachKind: PAYLOAD_DENSITY_ATTACH_KIND_BY_CODE[kindCode] });
  }
  return {
    nBuffers: bufN,
    buffers: outBuffers,
    nAttach: attachN,
    attach: outAttach,
  };
}

/**
 * Ship u8 density grid planes into `density` per the ABI 315 buffer registry.
 * @param {Record<string, unknown>} density
 * @param {{ shipU8: Function }} pw
 * @param {ReturnType<typeof payloadDensityGridShipPlan>} gridPlan
 * @param {{ count: Uint8Array, rgba?: Uint8Array | null }} buffers
 */
export function shipDensityGridBuffers(density, pw, gridPlan, buffers) {
  for (const buf of gridPlan.buffers) {
    const values = buffers[buf.bufferSlot];
    if (values == null) {
      continue;
    }
    if (buf.shipMethod === "u8") {
      density[buf.registryKey] = pw.shipU8(values);
    }
  }
}

/** Pyramid/tile-store resource kind for ABI 316 density grid materialize. */
export const DENSITY_RESOURCE_NONE = 0;
export const DENSITY_RESOURCE_PYRAMID = 1;
export const DENSITY_RESOURCE_TILE_STORE = 2;

const PAYLOAD_DENSITY_GRID_MATERIALIZE_IN_BYTES = 344;
const PAYLOAD_DENSITY_GRID_MATERIALIZE_OUT_BYTES = 64;
const DENSITY_BINNING_CAP = 64;

function readPayloadDensityGridMaterializeOut(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const gmax = view.getFloat64(off, true);
  off += 8;
  const visible = Number(view.getBigUint64(off, true));
  off += 8;
  const gridFromPyramid = view.getUint32(off, true) === 1;
  off += 4;
  const hasPyramidRgba = view.getUint32(off, true) === 1;
  off += 4;
  const pyramidLevel = view.getInt32(off, true);
  off += 4;
  const fromTiles = view.getUint32(off, true) === 1;
  off += 4;
  const encodedLen = Number(view.getBigUint64(off, true));
  off += 8;
  const rgbaLen = Number(view.getBigUint64(off, true));
  off += 8;
  const sampleSelLen = Number(view.getBigUint64(off, true));
  off += 8;
  const visibleSelLen = Number(view.getBigUint64(off, true));
  return {
    gmax,
    visible,
    gridFromPyramid,
    hasPyramidRgba,
    pyramidLevel,
    fromTiles,
    encodedLen,
    rgbaLen,
    sampleSelLen,
    visibleSelLen,
  };
}

function densityBinColorPtrs(source, n) {
  if (source == null || n <= 0) {
    return { idxPtr: 0, rgbaPtr: 0, lutPtr: 0, lutLen: 0n };
  }
  if (source.rgba != null) {
    const rgba = source.rgba instanceof Uint8Array ? source.rgba : Uint8Array.from(source.rgba);
    if (rgba.length !== n * 4) {
      throw new RangeError("payloadDensityGridMaterialize rgba length must be 4 * n");
    }
    return { idxPtr: 0, rgbaPtr: u8Ptr(rgba), lutPtr: 0, lutLen: 0n };
  }
  if (source.idx != null && source.lut != null) {
    const idx = source.idx instanceof Uint8Array ? source.idx : Uint8Array.from(source.idx);
    const lut = source.lut instanceof Uint8Array ? source.lut : Uint8Array.from(source.lut);
    if (idx.length !== n) {
      throw new RangeError("payloadDensityGridMaterialize idx length must match geometry");
    }
    if (lut.length < 4 || lut.length % 4 !== 0 || lut.length / 4 > 256) {
      throw new RangeError("payloadDensityGridMaterialize lut must be 1..256 RGBA8 entries");
    }
    return {
      idxPtr: u8Ptr(idx),
      rgbaPtr: 0,
      lutPtr: u8Ptr(lut),
      lutLen: BigInt(lut.length / 4),
    };
  }
  return { idxPtr: 0, rgbaPtr: 0, lutPtr: 0, lutLen: 0n };
}

function packPayloadDensityGridMaterializeIn(fields) {
  const buf = Buffer.alloc(PAYLOAD_DENSITY_GRID_MATERIALIZE_IN_BYTES);
  const setI32 = (off, value) => {
    buf.writeInt32LE(Number(value), off);
  };
  const setF64 = (off, value) => {
    buf.writeDoubleLE(Number(value), off);
  };
  const setU64 = (off, value) => {
    buf.writeBigUInt64LE(BigInt(value), off);
  };
  setI32(0, fields.cartesian);
  setI32(4, fields.xLinear);
  setI32(8, fields.yLinear);
  setI32(12, fields.categorical);
  setI32(16, fields.compactCategorical);
  setI32(20, fields.stratifiedCounts);
  setI32(24, fields.xHasNulls);
  setI32(28, fields.yHasNulls);
  setI32(32, fields.pointOverlay);
  setI32(36, fields.gridFromPyramid);
  setI32(40, fields.xMemmapped);
  setI32(44, fields.yMemmapped);
  setI32(48, fields.hasPyramidResource);
  setI32(52, fields.forceBin2d);
  setI32(56, fields.forcePyramid);
  setI32(60, fields.colorMode);
  setF64(64, fields.xMin);
  setF64(72, fields.xMax);
  setF64(80, fields.yMin);
  setF64(88, fields.yMax);
  setF64(96, fields.xr0);
  setF64(104, fields.xr1);
  setF64(112, fields.yr0);
  setF64(120, fields.yr1);
  setF64(128, fields.bx0);
  setF64(136, fields.bx1);
  setF64(144, fields.by0);
  setF64(152, fields.by1);
  setF64(160, fields.xC0);
  setF64(168, fields.xC1);
  setF64(176, fields.yC0);
  setF64(184, fields.yC1);
  setU64(192, fields.nPoints);
  setU64(200, fields.w);
  setU64(208, fields.h);
  setU64(216, fields.len);
  setI32(224, fields.pyramidAttempt);
  setI32(228, fields.pyramidResource);
  setU64(232, fields.pyramidHandle);
  setI32(240, fields.pyrColored);
  setU64(248, fields.maxUpsample);
  setU64(256, fields.tileUpsample);
  setI32(264, fields.pyramidNoRescan);
  setI32(268, fields.needsPyramidSample);
  setI32(272, fields.pyramidSampleStratified);
  setU64(280, fields.nColorCounts);
  setU64(288, fields.colorLutLen);
  setI32(296, fields.shipMeanColor);
  setU64(304, fields.binningCap);
  setU64(312, fields.encodedCap);
  setU64(320, fields.rgbaCap);
  setU64(328, fields.sampleSelCap);
  setU64(336, fields.visibleSelCap);
  return buf;
}

/** Density grid materialize via `xyg_payload_density_grid_materialize` (ABI 316). */
export function payloadDensityGridMaterialize({
  emitPlan,
  cartesian = true,
  xLinear = true,
  yLinear = true,
  xHasNulls = false,
  yHasNulls = false,
  pointOverlay = true,
  xMemmapped = false,
  yMemmapped = false,
  hasPyramidResource = false,
  forceBin2d = false,
  forcePyramid = false,
  xMin = 0,
  xMax = 1,
  yMin = 0,
  yMax = 1,
  xr0 = 0,
  xr1 = 1,
  yr0 = 0,
  yr1 = 1,
  bx0 = 0,
  bx1 = 1,
  by0 = 0,
  by1 = 1,
  nPoints = 0,
  w = DENSITY_GRID[0],
  h = DENSITY_GRID[1],
  xRaw,
  yRaw,
  bx,
  by,
  pyramidAttempt = false,
  pyramidResource = DENSITY_RESOURCE_NONE,
  pyramidHandle = 0n,
  pyrColored = false,
  maxUpsample = 2,
  tileUpsample = 2,
  pyramidNoRescan = false,
  needsPyramidSample = false,
  pyramidSampleStratified = false,
  colorCodes = null,
  colorCounts = null,
  binColors = null,
  shipMeanColor = false,
} = {}) {
  const xa = asF64Array(xRaw, "x");
  const ya = asF64Array(yRaw, "y");
  const bxa = asF64Array(bx, "bx");
  const bya = asF64Array(by, "by");
  const len = xa.length;
  if (len !== ya.length || len !== bxa.length || len !== bya.length) {
    throw new RangeError("payloadDensityGridMaterialize geometry length mismatch");
  }
  const ww = Math.max(1, Math.floor(Number(w)));
  const hh = Math.max(1, Math.floor(Number(h)));
  const cells = ww * hh;
  const outBinning = new Uint8Array(DENSITY_BINNING_CAP);
  const outEncoded = new Uint8Array(cells);
  const outRgba = new Uint8Array(cells * 4);
  const outSampleSel = new Uint32Array(len);
  const outVisibleSel = new Uint32Array(len);
  const summary = new Uint8Array(PAYLOAD_DENSITY_GRID_MATERIALIZE_OUT_BYTES);
  const plan = emitPlan ?? {};
  let codesPtr = 0;
  if (colorCodes != null) {
    const codes = colorCodes instanceof Uint8Array ? colorCodes : Uint8Array.from(colorCodes);
    if (codes.length !== len) {
      throw new RangeError("payloadDensityGridMaterialize color codes length must match geometry");
    }
    codesPtr = len ? u8Ptr(codes) : 0;
  }
  let countsPtr = 0;
  let nColorCounts = 0;
  if (colorCounts != null) {
    const counts = colorCounts instanceof BigUint64Array
      ? colorCounts
      : BigUint64Array.from(colorCounts, (v) => BigInt(v));
    if (counts.length === 0) {
      throw new RangeError("payloadDensityGridMaterialize color counts must be non-empty");
    }
    countsPtr = pointer(counts, "uint64_t *");
    nColorCounts = counts.length;
  }
  const colorPtrs = densityBinColorPtrs(binColors, len);
  const input = packPayloadDensityGridMaterializeIn({
    cartesian: cartesian ? 1 : 0,
    xLinear: xLinear ? 1 : 0,
    yLinear: yLinear ? 1 : 0,
    categorical: plan.categorical ? 1 : 0,
    compactCategorical: plan.compactCategorical ? 1 : 0,
    stratifiedCounts: plan.stratifiedCounts ? 1 : 0,
    xHasNulls: xHasNulls ? 1 : 0,
    yHasNulls: yHasNulls ? 1 : 0,
    pointOverlay: pointOverlay ? 1 : 0,
    gridFromPyramid: 0,
    xMemmapped: xMemmapped ? 1 : 0,
    yMemmapped: yMemmapped ? 1 : 0,
    hasPyramidResource: hasPyramidResource ? 1 : 0,
    forceBin2d: forceBin2d ? 1 : 0,
    forcePyramid: forcePyramid ? 1 : 0,
    colorMode: plan.colorMode ?? 0,
    xMin,
    xMax,
    yMin,
    yMax,
    xr0,
    xr1,
    yr0,
    yr1,
    bx0,
    bx1,
    by0,
    by1,
    xC0: plan.xC0 ?? 0,
    xC1: plan.xC1 ?? 1,
    yC0: plan.yC0 ?? 0,
    yC1: plan.yC1 ?? 1,
    nPoints,
    w: ww,
    h: hh,
    len,
    pyramidAttempt: pyramidAttempt ? 1 : 0,
    pyramidResource,
    pyramidHandle,
    pyrColored: pyrColored ? 1 : 0,
    maxUpsample,
    tileUpsample,
    pyramidNoRescan: pyramidNoRescan ? 1 : 0,
    needsPyramidSample: needsPyramidSample ? 1 : 0,
    pyramidSampleStratified: pyramidSampleStratified ? 1 : 0,
    nColorCounts,
    colorLutLen: Number(colorPtrs.lutLen),
    shipMeanColor: shipMeanColor ? 1 : 0,
    binningCap: DENSITY_BINNING_CAP,
    encodedCap: cells,
    rgbaCap: outRgba.length,
    sampleSelCap: len,
    visibleSelCap: len,
  });
  const code = Number(xyPayloadDensityGridMaterialize(
    input,
    len ? f64Ptr(xa) : 0,
    len ? f64Ptr(ya) : 0,
    len ? f64Ptr(bxa) : 0,
    len ? f64Ptr(bya) : 0,
    codesPtr,
    countsPtr,
    colorPtrs.idxPtr,
    colorPtrs.rgbaPtr,
    colorPtrs.lutPtr,
    u8Ptr(outBinning),
    u8Ptr(outEncoded),
    u8Ptr(outRgba),
    len ? u32Ptr(outSampleSel) : 0,
    len ? u32Ptr(outVisibleSel) : 0,
    u8Ptr(summary),
  ));
  if (code === -1) {
    throw new RangeError("invalid payload-density-grid-materialize request");
  }
  if (code === -2) {
    throw new Error("xyg_payload_density_grid_materialize hit an unexpected grid path");
  }
  if (code === -3) {
    throw new Error("xyg_payload_density_grid_materialize stratified sample failed");
  }
  if (code !== 0) {
    throw new Error(`xyg_payload_density_grid_materialize failed (${code})`);
  }
  const parsed = readPayloadDensityGridMaterializeOut(summary);
  let binning = "";
  for (let idx = 0; idx < outBinning.length; idx += 1) {
    if (outBinning[idx] === 0) break;
    binning += String.fromCharCode(outBinning[idx]);
  }
  return {
    encoded: outEncoded.subarray(0, parsed.encodedLen),
    max: parsed.gmax,
    rgba: parsed.rgbaLen > 0 ? outRgba.subarray(0, parsed.rgbaLen) : null,
    sampleSel: parsed.sampleSelLen > 0 ? outSampleSel.slice(0, parsed.sampleSelLen) : null,
    visibleSel: parsed.visibleSelLen > 0 ? outVisibleSel.slice(0, parsed.visibleSelLen) : null,
    visible: parsed.visible,
    binning,
    gridFromPyramid: parsed.gridFromPyramid,
    hasPyramidRgba: parsed.hasPyramidRgba,
    pyramidLevel: parsed.pyramidLevel,
    fromTiles: parsed.fromTiles,
    reduction: parsed.gridFromPyramid ? "pyramid-count" : "bin2d",
  };
}

const PAYLOAD_CHANNEL_SHIP_MAX = 5;
const PAYLOAD_CHAN_REGISTRY_KEY_BY_CODE = [
  "color", "size", "stroke", "channels", "color_target",
];
const PAYLOAD_CHAN_TRACE_SLOT_BY_CODE = [
  "color_ch", "size_ch", "stroke_ch", "style_channels", "color2_ch",
];
const PAYLOAD_CHAN_SHIP_METHOD_BY_CODE = ["color_size", "color", "style"];

/** Channel registry / attach-order plan via `xyg_payload_channel_ship_plan` (ABI 311). */
export function payloadChannelShipPlan({
  slot = PAYLOAD_SHIP_CHANNELS_ALWAYS,
  includeTraceStyles = false,
  hasColor2Ch = false,
  hasColorCh = false,
  hasStrokeCh = false,
  hasStyleChannels = false,
} = {}) {
  const nChannels = new BigUint64Array(1);
  const channels = Buffer.alloc(PAYLOAD_CHANNEL_SHIP_MAX * 12);
  const ok = Number(xyPayloadChannelShipPlan(
    Number(slot),
    includeTraceStyles ? 1 : 0,
    hasColor2Ch ? 1 : 0,
    hasColorCh ? 1 : 0,
    hasStrokeCh ? 1 : 0,
    hasStyleChannels ? 1 : 0,
    pointer(nChannels, "size_t *"),
    channels,
    BigInt(PAYLOAD_CHANNEL_SHIP_MAX),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-channel-ship-plan arguments");
  }
  const n = Number(nChannels[0]);
  const outChannels = [];
  for (let idx = 0; idx < n; idx += 1) {
    const base = idx * 12;
    const keyCode = channels.readInt32LE(base);
    const slotCode = channels.readInt32LE(base + 4);
    const methodCode = channels.readInt32LE(base + 8);
    if (
      keyCode < 0
      || keyCode >= PAYLOAD_CHAN_REGISTRY_KEY_BY_CODE.length
      || slotCode < 0
      || slotCode >= PAYLOAD_CHAN_TRACE_SLOT_BY_CODE.length
      || methodCode < 0
      || methodCode >= PAYLOAD_CHAN_SHIP_METHOD_BY_CODE.length
    ) {
      throw new RangeError("invalid payload-channel-ship-plan channel descriptor");
    }
    outChannels.push({
      registryKey: PAYLOAD_CHAN_REGISTRY_KEY_BY_CODE[keyCode],
      traceSlot: PAYLOAD_CHAN_TRACE_SLOT_BY_CODE[slotCode],
      shipMethod: PAYLOAD_CHAN_SHIP_METHOD_BY_CODE[methodCode],
    });
  }
  return {
    nChannels: n,
    channels: outChannels,
  };
}

const PAYLOAD_CHAN_WIRE_ROLE_BY_NAME = Object.freeze({
  color: 0,
  size: 1,
  style: 2,
});
const PAYLOAD_CHAN_MODE_BY_NAME = Object.freeze({
  constant: 0,
  continuous: 1,
  categorical: 2,
  direct_rgba: 3,
  match_fill: 4,
  direct: 5,
});
const PAYLOAD_CHAN_BUF_KIND_BY_CODE = Object.freeze(["none", "u8", "f32"]);
const PAYLOAD_CHAN_XFORM_BY_CODE = Object.freeze([
  "none",
  "normalize",
  "quantize_u8",
  "rgba_pack",
  "raw",
]);

/** Channel wire encoding policy via `xyg_payload_channel_wire_encode` (ABI 312). */
export function payloadChannelWireEncode({
  role = "color",
  mode = "constant",
  nCategories = 0,
  styleDtypeU8 = false,
  quantizeContinuous = false,
} = {}) {
  const roleCode = PAYLOAD_CHAN_WIRE_ROLE_BY_NAME[role];
  const modeCode = PAYLOAD_CHAN_MODE_BY_NAME[mode];
  if (roleCode == null || modeCode == null) {
    throw new RangeError("invalid payload-channel-wire-encode role or mode");
  }
  const bufKind = new Int32Array(1);
  const transform = new Int32Array(1);
  const markDtypeU8 = new Int32Array(1);
  const shipPalette = new Int32Array(1);
  const setN = new Int32Array(1);
  const ok = Number(xyPayloadChannelWireEncode(
    roleCode,
    modeCode,
    BigInt(nCategories),
    styleDtypeU8 ? 1 : 0,
    quantizeContinuous ? 1 : 0,
    pointer(bufKind, "int32_t *"),
    pointer(transform, "int32_t *"),
    pointer(markDtypeU8, "int32_t *"),
    pointer(shipPalette, "int32_t *"),
    pointer(setN, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-channel-wire-encode arguments");
  }
  const bufCode = bufKind[0];
  const xformCode = transform[0];
  if (
    bufCode < 0
    || bufCode >= PAYLOAD_CHAN_BUF_KIND_BY_CODE.length
    || xformCode < 0
    || xformCode >= PAYLOAD_CHAN_XFORM_BY_CODE.length
  ) {
    throw new RangeError("invalid payload-channel-wire-encode descriptor");
  }
  return {
    bufKind: PAYLOAD_CHAN_BUF_KIND_BY_CODE[bufCode],
    transform: PAYLOAD_CHAN_XFORM_BY_CODE[xformCode],
    markDtypeU8: markDtypeU8[0] === 1,
    shipPalette: shipPalette[0] === 1,
    setN: setN[0] === 1,
  };
}

/** Ribbon emit skeleton via `xyg_payload_ribbon_emit_plan` (ABI 299). */
export function payloadRibbonEmitPlan({
  nMarks = 0,
  styleColorIsNone = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
  anyGeometryNulls = false,
  hasColor2Ch = false,
} = {}) {
  const tierDirect = new Int32Array(1);
  const nMarksOut = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const channelSlot = new Int32Array(1);
  const includeTraceStyles = new Int32Array(1);
  const attachTransition = new Int32Array(1);
  const attemptGather = new Int32Array(1);
  const attachColor2 = new Int32Array(1);
  const ok = Number(xyPayloadRibbonEmitPlan(
    BigInt(nMarks),
    styleColorIsNone ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    anyGeometryNulls ? 1 : 0,
    hasColor2Ch ? 1 : 0,
    pointer(tierDirect, "int32_t *"),
    pointer(nMarksOut, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    pointer(channelSlot, "int32_t *"),
    pointer(includeTraceStyles, "int32_t *"),
    pointer(attachTransition, "int32_t *"),
    pointer(attemptGather, "int32_t *"),
    pointer(attachColor2, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-ribbon-emit-plan request");
  }
  const scaleName = (code) => {
    if (code < 0 || code >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
      throw new RangeError("invalid payload-ribbon-emit-plan ship scale");
    }
    return PAYLOAD_SHIP_SCALE_BY_CODE[code];
  };
  return {
    tierDirect: tierDirect[0] === 1,
    nMarks: Number(nMarksOut[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    xShipScale: scaleName(xShipScale[0]),
    yShipScale: scaleName(yShipScale[0]),
    channelSlot: channelSlot[0],
    includeTraceStyles: includeTraceStyles[0] === 1,
    attachTransition: attachTransition[0] === 1,
    attemptGather: attemptGather[0] === 1,
    attachColor2: attachColor2[0] === 1,
  };
}

/** Scatter emit skeleton via `xyg_payload_scatter_emit_plan` (ABI 301). */
export function payloadScatterEmitPlan({
  nPoints = 0,
  polar = false,
  forceDensity = -1,
  forceDirect = false,
  perItem = false,
  nMarks = 0,
  hasTraceAnimation = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
  hasTransitionKeys = false,
  hasTooltipRows = false,
  nTooltipRows = 0,
} = {}) {
  const emitDensity = new Int32Array(1);
  const clearShippedSel = new Int32Array(1);
  const drillModeFalse = new Int32Array(1);
  const setShippedSel = new Int32Array(1);
  const tierDirect = new Int32Array(1);
  const nMarksOut = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const attachAnimation = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const channelSlot = new Int32Array(1);
  const includeTraceStyles = new Int32Array(1);
  const attachTransition = new Int32Array(1);
  const attachTooltip = new Int32Array(1);
  const filterTooltipBySel = new Int32Array(1);
  const tooltipLengthOk = new Int32Array(1);
  const ok = Number(xyPayloadScatterEmitPlan(
    BigInt(nPoints),
    polar ? 1 : 0,
    Number(forceDensity),
    forceDirect ? 1 : 0,
    perItem ? 1 : 0,
    BigInt(nMarks),
    hasTraceAnimation ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    hasTransitionKeys ? 1 : 0,
    hasTooltipRows ? 1 : 0,
    BigInt(nTooltipRows),
    pointer(emitDensity, "int32_t *"),
    pointer(clearShippedSel, "int32_t *"),
    pointer(drillModeFalse, "int32_t *"),
    pointer(setShippedSel, "int32_t *"),
    pointer(tierDirect, "int32_t *"),
    pointer(nMarksOut, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(attachAnimation, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    pointer(channelSlot, "int32_t *"),
    pointer(includeTraceStyles, "int32_t *"),
    pointer(attachTransition, "int32_t *"),
    pointer(attachTooltip, "int32_t *"),
    pointer(filterTooltipBySel, "int32_t *"),
    pointer(tooltipLengthOk, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-scatter-emit-plan request");
  }
  const base = {
    emitDensity: emitDensity[0] === 1,
    clearShippedSel: clearShippedSel[0] === 1,
    drillModeFalse: drillModeFalse[0] === 1,
    setShippedSel: setShippedSel[0] === 1,
    attachTransition: attachTransition[0] === 1,
    attachTooltip: attachTooltip[0] === 1,
    filterTooltipBySel: filterTooltipBySel[0] === 1,
    tooltipLengthOk: tooltipLengthOk[0] === 1,
  };
  if (base.emitDensity) {
    return base;
  }
  const scaleName = (code) => {
    if (code < 0 || code >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
      throw new RangeError("invalid payload-scatter-emit-plan ship scale");
    }
    return PAYLOAD_SHIP_SCALE_BY_CODE[code];
  };
  return {
    ...base,
    tierDirect: tierDirect[0] === 1,
    nMarks: Number(nMarksOut[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    attachAnimation: attachAnimation[0] === 1,
    xShipScale: scaleName(xShipScale[0]),
    yShipScale: scaleName(yShipScale[0]),
    channelSlot: channelSlot[0],
    includeTraceStyles: includeTraceStyles[0] === 1,
  };
}

/** Density trace emit orchestration via `xyg_payload_density_trace_emit_plan` (ABI 302). */
export function payloadDensityTraceEmitPlan({
  hasChannel = false,
  mode = "",
  codesPresent = false,
  codesU8 = false,
  hasCounts = false,
  hasConstant = false,
  cartesian = true,
  xLinear = true,
  yLinear = true,
  xHasNulls = false,
  yHasNulls = false,
  pointOverlay = true,
  splitPayload = false,
  gridW = 512,
  gridH = 384,
  gridFromPyramid = false,
  hasPyramidResource = false,
  gridPresent = false,
  forceBin2d = false,
  forcePyramid = false,
  xMemmapped = false,
  yMemmapped = false,
  xMin = 0,
  xMax = 1,
  yMin = 0,
  yMax = 1,
  xr0 = 0,
  xr1 = 1,
  yr0 = 0,
  yr1 = 1,
  bx0 = 0,
  bx1 = 1,
  by0 = 0,
  by1 = 1,
  nPoints = 0,
  hasPyramidRgba = false,
  hasBinColors = false,
  droppedCount = 0,
} = {}) {
  const modeBytes = new TextEncoder().encode(String(mode ?? ""));
  const out = new Uint8Array(PAYLOAD_DENSITY_TRACE_EMIT_PLAN_BYTES);
  const ok = Number(xyPayloadDensityTraceEmitPlan(
    hasChannel ? 1 : 0,
    modeBytes.length ? u8Ptr(modeBytes) : 0,
    BigInt(modeBytes.length),
    codesPresent ? 1 : 0,
    codesU8 ? 1 : 0,
    hasCounts ? 1 : 0,
    hasConstant ? 1 : 0,
    cartesian ? 1 : 0,
    xLinear ? 1 : 0,
    yLinear ? 1 : 0,
    xHasNulls ? 1 : 0,
    yHasNulls ? 1 : 0,
    pointOverlay ? 1 : 0,
    splitPayload ? 1 : 0,
    Number(gridW),
    Number(gridH),
    gridFromPyramid ? 1 : 0,
    hasPyramidResource ? 1 : 0,
    gridPresent ? 1 : 0,
    forceBin2d ? 1 : 0,
    forcePyramid ? 1 : 0,
    xMemmapped ? 1 : 0,
    yMemmapped ? 1 : 0,
    Number(xMin),
    Number(xMax),
    Number(yMin),
    Number(yMax),
    Number(xr0),
    Number(xr1),
    Number(yr0),
    Number(yr1),
    Number(bx0),
    Number(bx1),
    Number(by0),
    Number(by1),
    BigInt(nPoints),
    hasPyramidRgba ? 1 : 0,
    hasBinColors ? 1 : 0,
    Number(droppedCount),
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-density-trace-emit-plan request");
  }
  return readPayloadDensityTraceEmitPlan(out);
}

/** Segment emit skeleton via `xyg_payload_segments_emit_plan` (ABI 300). */
export function payloadSegmentsEmitPlan({
  kind = "",
  nMarks = 0,
  styleColorIsNone = false,
  xAxisScale = "linear",
  yAxisScale = "linear",
  hasTransitionKeys = false,
} = {}) {
  const kindText = String(kind ?? "");
  const kindBytes = new TextEncoder().encode(kindText);
  const nMarksOut = new BigUint64Array(1);
  const applyPaletteDefault = new Int32Array(1);
  const xShipScale = new Int32Array(1);
  const yShipScale = new Int32Array(1);
  const channelSlot = new Int32Array(1);
  const includeTraceStyles = new Int32Array(1);
  const attachTransition = new Int32Array(1);
  const attemptGather = new Int32Array(1);
  const attemptRoleKeys = new Int32Array(1);
  const ok = Number(xyPayloadSegmentsEmitPlan(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    BigInt(nMarks),
    styleColorIsNone ? 1 : 0,
    payloadAxisTypeCode(xAxisScale),
    payloadAxisTypeCode(yAxisScale),
    hasTransitionKeys ? 1 : 0,
    pointer(nMarksOut, "size_t *"),
    pointer(applyPaletteDefault, "int32_t *"),
    pointer(xShipScale, "int32_t *"),
    pointer(yShipScale, "int32_t *"),
    pointer(channelSlot, "int32_t *"),
    pointer(includeTraceStyles, "int32_t *"),
    pointer(attachTransition, "int32_t *"),
    pointer(attemptGather, "int32_t *"),
    pointer(attemptRoleKeys, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-segments-emit-plan request");
  }
  const scaleName = (code) => {
    if (code < 0 || code >= PAYLOAD_SHIP_SCALE_BY_CODE.length) {
      throw new RangeError("invalid payload-segments-emit-plan ship scale");
    }
    return PAYLOAD_SHIP_SCALE_BY_CODE[code];
  };
  return {
    nMarks: Number(nMarksOut[0]),
    applyPaletteDefault: applyPaletteDefault[0] === 1,
    xShipScale: scaleName(xShipScale[0]),
    yShipScale: scaleName(yShipScale[0]),
    channelSlot: channelSlot[0],
    includeTraceStyles: includeTraceStyles[0] === 1,
    attachTransition: attachTransition[0] === 1,
    attemptGather: attemptGather[0] === 1,
    attemptRoleKeys: attemptRoleKeys[0] === 1,
  };
}

/**
 * Bar/column compact emit admit via `xyg_payload_bar_compact_admit` (ABI 274).
 */
export function payloadBarCompactAdmit(widths, value0) {
  const widthArr = widths instanceof Float64Array ? widths : Float64Array.from(widths);
  const value0Arr = value0 instanceof Float64Array ? value0 : Float64Array.from(value0);
  const outWidth = new Float64Array(1);
  const outValue0Const = new Float64Array(1);
  const outHasValue0Const = new Int32Array(1);
  const outCompact = new Int32Array(1);
  const ok = Number(xyPayloadBarCompactAdmit(
    BigInt(widthArr.length),
    widthArr.length ? f64Ptr(widthArr) : 0,
    BigInt(value0Arr.length),
    value0Arr.length ? f64Ptr(value0Arr) : 0,
    f64Ptr(outWidth),
    f64Ptr(outValue0Const),
    pointer(outHasValue0Const, "int32_t *"),
    pointer(outCompact, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-bar-compact-admit request");
  }
  return {
    compact: outCompact[0] === 1,
    width: outWidth[0],
    hasValue0Const: outHasValue0Const[0] === 1,
    value0Const: outValue0Const[0],
  };
}

const TRANSITION_FALLBACK_BY_CODE = [
  null,
  "snap:aggregate",
  "snap:key-limit",
  "index:key-count-mismatch",
];

/**
 * Transition-key shipping admit via `xyg_payload_transition_keys_admit` (ABI 275).
 */
export function payloadTransitionKeysAdmit({
  hasKeys = false,
  tierDirect = false,
  nKeys = 0,
  nMarks = 0,
  maxRows = 200_000,
} = {}) {
  const code = Number(xyPayloadTransitionKeysAdmit(
    hasKeys ? 1 : 0,
    tierDirect ? 1 : 0,
    BigInt(nKeys),
    BigInt(nMarks),
    BigInt(maxRows),
  ));
  return TRANSITION_FALLBACK_BY_CODE[code] ?? (() => {
    throw new RangeError("invalid payload-transition-keys-admit result");
  })();
}

/**
 * Stem/errorbar emit count budget via `xyg_payload_segment_budget` (ABI 214).
 * `max(1024, floor(pxWidth) * 4)`.
 */
export function payloadSegmentBudget(pxWidth) {
  const width = Number(pxWidth);
  if (!Number.isFinite(width)) {
    throw new RangeError("payloadSegmentBudget pxWidth must be finite");
  }
  const raw = xyPayloadSegmentBudget(width);
  if (raw === USIZE_MAX_64) {
    throw new RangeError("invalid payload-segment-budget request");
  }
  return Number(raw);
}

/**
 * Density-overlay sample of implicit ids via `xyg_payload_sample_target_indices`.
 */
export function payloadSampleTargetIndices({
  n,
  target,
  seed = 0,
  level = 0,
  growth = 2.0,
} = {}) {
  const nI = Math.floor(Number(n));
  const targetI = Math.floor(Number(target));
  const seedI = Math.floor(Number(seed));
  const levelI = Math.floor(Number(level));
  const growthF = Number(growth);
  if (!Number.isFinite(nI) || nI < 0 || !Number.isFinite(targetI) || targetI <= 0) {
    throw new RangeError("payloadSampleTargetIndices n>=0 and target>=1");
  }
  if (!Number.isFinite(growthF) || growthF < 1) {
    throw new RangeError("payloadSampleTargetIndices growth must be >= 1");
  }
  const cap = nI ? Math.min(nI, Math.max(64, targetI * 2)) : 0;
  let out = new Uint32Array(cap);
  const keepAll = new Int32Array([-1]);
  let written = Number(xyPayloadSampleTargetIndices(
    BigInt(nI),
    BigInt(targetI),
    BigInt(seedI),
    levelI >>> 0,
    growthF,
    pointer(keepAll, "int32_t *"),
    cap ? u32Ptr(out) : 0,
    BigInt(cap),
  ));
  let result = readKeepAllIndices(written, keepAll, out, "xyg_payload_sample_target_indices");
  if (result.required != null) {
    out = new Uint32Array(result.required);
    keepAll[0] = -1;
    written = Number(xyPayloadSampleTargetIndices(
      BigInt(nI),
      BigInt(targetI),
      BigInt(seedI),
      levelI >>> 0,
      growthF,
      pointer(keepAll, "int32_t *"),
      u32Ptr(out),
      BigInt(result.required),
    ));
    result = readKeepAllIndices(written, keepAll, out, "xyg_payload_sample_target_indices");
    if (result.required != null || result.keepAll) {
      throw new Error("xyg_payload_sample_target_indices returned an inconsistent count");
    }
  }
  return result;
}

export const DENSITY_GRID_PATH_OVERSIZED_BIN2D = 0;
export const DENSITY_GRID_PATH_IDENTITY_GRID_ONLY = 1;
export const DENSITY_GRID_PATH_IDENTITY_STRATIFIED_FUSED = 2;
export const DENSITY_GRID_PATH_IDENTITY_STRATIFIED_SPLIT = 3;
export const DENSITY_GRID_PATH_IDENTITY_SAMPLE_FUSED = 4;
export const DENSITY_GRID_PATH_RANGE_INDICES = 5;

export const DENSITY_COLOR_MODE_NONE = 0;
export const DENSITY_COLOR_MODE_CONSTANT = 1;
export const DENSITY_COLOR_MODE_OTHER = 2;

export const DENSITY_CHANNEL_MODE_NONE = 0;
export const DENSITY_CHANNEL_MODE_CONSTANT = 1;
export const DENSITY_CHANNEL_MODE_CATEGORICAL = 2;
export const DENSITY_CHANNEL_MODE_CONTINUOUS = 3;
export const DENSITY_CHANNEL_MODE_OTHER = 4;

/**
 * Density color-channel classify via `xyg_density_color_classify` (ABI 260).
 */
export function densityColorClassify({
  channelMode = DENSITY_CHANNEL_MODE_NONE,
  codesPresent = false,
  codesU8 = false,
  hasCounts = false,
} = {}) {
  const outColorMode = new Int32Array(1);
  const outCategorical = new Int32Array(1);
  const outCompact = new Int32Array(1);
  const outStratified = new Int32Array(1);
  const ok = Number(xyDensityColorClassify(
    Number(channelMode),
    codesPresent ? 1 : 0,
    codesU8 ? 1 : 0,
    hasCounts ? 1 : 0,
    pointer(outColorMode, "int32_t *"),
    pointer(outCategorical, "int32_t *"),
    pointer(outCompact, "int32_t *"),
    pointer(outStratified, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid density-color-classify request");
  }
  return {
    colorMode: outColorMode[0],
    categorical: outCategorical[0] === 1,
    compactCategorical: outCompact[0] === 1,
    stratifiedCounts: outStratified[0] === 1,
  };
}

/** Density trace color classify via `xyg_density_trace_color_classify` (ABI 262). */
export function densityTraceColorClassify({
  hasChannel = false,
  mode = "",
  codesPresent = false,
  codesU8 = false,
  hasCounts = false,
} = {}) {
  const modeBytes = new TextEncoder().encode(String(mode ?? ""));
  const outColorMode = new Int32Array(1);
  const outCategorical = new Int32Array(1);
  const outCompact = new Int32Array(1);
  const outStratified = new Int32Array(1);
  const ok = Number(xyDensityTraceColorClassify(
    hasChannel ? 1 : 0,
    modeBytes.length ? u8Ptr(modeBytes) : 0,
    BigInt(modeBytes.length),
    codesPresent ? 1 : 0,
    codesU8 ? 1 : 0,
    hasCounts ? 1 : 0,
    pointer(outColorMode, "int32_t *"),
    pointer(outCategorical, "int32_t *"),
    pointer(outCompact, "int32_t *"),
    pointer(outStratified, "int32_t *"),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid density-trace-color-classify request");
  }
  return {
    colorMode: outColorMode[0],
    categorical: outCategorical[0] === 1,
    compactCategorical: outCompact[0] === 1,
    stratifiedCounts: outStratified[0] === 1,
  };
}

/** Density colormap source admit via `xyg_density_uses_channel_colormap` (ABI 264). */
export function densityUsesChannelColormap({ hasChannel = false, mode = "" } = {}) {
  const modeBytes = new TextEncoder().encode(String(mode ?? ""));
  const uses = Number(xyDensityUsesChannelColormap(
    hasChannel ? 1 : 0,
    modeBytes.length ? u8Ptr(modeBytes) : 0,
    BigInt(modeBytes.length),
  ));
  if (uses !== 0 && uses !== 1) {
    throw new RangeError("invalid density-uses-channel-colormap request");
  }
  return uses === 1;
}

/** Density constant-color wire admit via `xyg_density_constant_color_wire_admit` (ABI 268). */
export function densityConstantColorWireAdmit({
  hasChannel = false,
  mode = "",
  hasConstant = false,
} = {}) {
  const modeBytes = new TextEncoder().encode(String(mode ?? ""));
  const admit = Number(xyDensityConstantColorWireAdmit(
    hasChannel ? 1 : 0,
    modeBytes.length ? u8Ptr(modeBytes) : 0,
    BigInt(modeBytes.length),
    hasConstant ? 1 : 0,
  ));
  if (admit !== 0 && admit !== 1) {
    throw new RangeError("invalid density-constant-color-wire-admit request");
  }
  return admit === 1;
}

/** Density categorical color wire admit via `xyg_density_categorical_color_wire_admit` (ABI 271). */
export function densityCategoricalColorWireAdmit({
  categorical = false,
  hasChannel = false,
} = {}) {
  const admit = Number(xyDensityCategoricalColorWireAdmit(
    categorical ? 1 : 0,
    hasChannel ? 1 : 0,
  ));
  if (admit !== 0 && admit !== 1) {
    throw new RangeError("invalid density-categorical-color-wire-admit request");
  }
  return admit === 1;
}

/** Mean-color density plane wire admit via `xyg_density_mean_color_wire_admit` (ABI 272). */
export function densityMeanColorWireAdmit({ hasChannel = false, mode = "" } = {}) {
  const modeBytes = new TextEncoder().encode(String(mode ?? ""));
  const admit = Number(xyDensityMeanColorWireAdmit(
    hasChannel ? 1 : 0,
    modeBytes.length ? u8Ptr(modeBytes) : 0,
    BigInt(modeBytes.length),
  ));
  if (admit !== 0 && admit !== 1) {
    throw new RangeError("invalid density-mean-color-wire-admit request");
  }
  return admit === 1;
}

/** Density channels_dropped compat via `xyg_density_channels_dropped_compat` (ABI 273). */
export function densityChannelsDroppedCompat({ droppedCount = 0 } = {}) {
  const compat = Number(xyDensityChannelsDroppedCompat(Number(droppedCount)));
  if (compat !== 0 && compat !== 1) {
    throw new RangeError("invalid density-channels-dropped-compat request");
  }
  return compat === 1;
}

/** Dropped-channel list admit via `xyg_density_dropped_channel_wire_admit` (ABI 274). */
export function densityDroppedChannelWireAdmit({
  channel = "",
  meanColorAggregates = false,
} = {}) {
  const channelBytes = new TextEncoder().encode(String(channel ?? ""));
  const admit = Number(xyDensityDroppedChannelWireAdmit(
    channelBytes.length ? u8Ptr(channelBytes) : 0,
    BigInt(channelBytes.length),
    meanColorAggregates ? 1 : 0,
  ));
  if (admit !== 0 && admit !== 1) {
    throw new RangeError("invalid density-dropped-channel-wire-admit request");
  }
  return admit === 1;
}

/** Mean-color rgba wire admit via `xyg_density_mean_color_rgba_wire_admit` (ABI 275). */
export function densityMeanColorRgbaWireAdmit({
  hasPyramidRgba = false,
  hasBinColors = false,
} = {}) {
  const admit = Number(xyDensityMeanColorRgbaWireAdmit(
    hasPyramidRgba ? 1 : 0,
    hasBinColors ? 1 : 0,
  ));
  if (admit !== 0 && admit !== 1) {
    throw new RangeError("invalid density-mean-color-rgba-wire-admit request");
  }
  return admit === 1;
}

/** Density wasm_source wire admit via `xyg_density_wasm_source_admit` (ABI 269). */
export function densityWasmSourceAdmit({ splitPayload = false, wasmEligible = false } = {}) {
  const admit = Number(xyDensityWasmSourceAdmit(
    splitPayload ? 1 : 0,
    wasmEligible ? 1 : 0,
  ));
  if (admit !== 0 && admit !== 1) {
    throw new RangeError("invalid density-wasm-source-admit request");
  }
  return admit === 1;
}

export const DENSITY_WASM_DENSITY_NONE = 0;
export const DENSITY_WASM_DENSITY_AUTOMATIC = 1;
export const DENSITY_WASM_DENSITY_UNSUPPORTED = 2;

/** Payload wasm_density wire kind via `xyg_density_wasm_density_wire_kind` (ABI 270). */
export function densityWasmDensityWireKind({
  splitPayload = false,
  wasmSourceCount = 0,
  hasDensityTier = false,
} = {}) {
  const kind = Number(xyDensityWasmDensityWireKind(
    splitPayload ? 1 : 0,
    BigInt(Math.max(0, Number(wasmSourceCount))),
    hasDensityTier ? 1 : 0,
  ));
  if (
    kind !== DENSITY_WASM_DENSITY_NONE
    && kind !== DENSITY_WASM_DENSITY_AUTOMATIC
    && kind !== DENSITY_WASM_DENSITY_UNSUPPORTED
  ) {
    throw new RangeError("invalid density-wasm-density-wire-kind request");
  }
  return kind;
}

const PAYLOAD_BUILD_PLAN_BYTES = 88;

function readPayloadBuildPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const u32 = () => {
    const value = view.getUint32(off, true);
    off += 4;
    return value;
  };
  const i32 = () => {
    const value = view.getInt32(off, true);
    off += 4;
    return value;
  };
  const attachShowLegend = u32() !== 0;
  const wasmDensityKind = i32();
  return {
    attachShowLegend,
    wasmDensityKind,
    attachWasmDensity: u32() !== 0,
    attachTitleOptions: u32() !== 0,
    attachCoords: u32() !== 0,
    attachPalette: u32() !== 0,
    attachLegend: u32() !== 0,
    resolveLegendBest: u32() !== 0,
    attachExtraLegends: u32() !== 0,
    attachFrameSides: u32() !== 0,
    attachColorbar: u32() !== 0,
    attachShowModebar: u32() !== 0,
    attachExport: u32() !== 0,
    attachShowTooltip: u32() !== 0,
    attachPadding: u32() !== 0,
    attachDom: u32() !== 0,
    attachTooltip: u32() !== 0,
    attachMarkStyle: u32() !== 0,
    attachInteraction: u32() !== 0,
    attachAnnotations: u32() !== 0,
    attachAnimation: u32() !== 0,
    attachGraph: u32() !== 0,
  };
}

/** Top-level payload build attach orchestration via `xyg_payload_build_plan` (ABI 303). */
export function payloadBuildPlan({
  splitPayload = false,
  wasmSourceCount = 0,
  hasDensityTier = false,
  coordsCartesian = true,
  hasTitleOptions = false,
  hasPalette = false,
  hasLegendOptions = false,
  legendLocBest = false,
  hasExtraLegends = false,
  hasFrameSides = false,
  hasColorbarOptions = false,
  showModebarIsFalse = false,
  hasExportOptions = false,
  showTooltipIsFalse = false,
  hasPadding = false,
  hasDom = false,
  hasTooltip = false,
  hasMarkStyle = false,
  hasInteraction = false,
  hasAnnotations = false,
  hasAnimationOptions = false,
  hasGraphMeta = false,
} = {}) {
  const out = new Uint8Array(PAYLOAD_BUILD_PLAN_BYTES);
  const ok = Number(xyPayloadBuildPlan(
    splitPayload ? 1 : 0,
    BigInt(Math.max(0, Number(wasmSourceCount))),
    hasDensityTier ? 1 : 0,
    coordsCartesian ? 1 : 0,
    hasTitleOptions ? 1 : 0,
    hasPalette ? 1 : 0,
    hasLegendOptions ? 1 : 0,
    legendLocBest ? 1 : 0,
    hasExtraLegends ? 1 : 0,
    hasFrameSides ? 1 : 0,
    hasColorbarOptions ? 1 : 0,
    showModebarIsFalse ? 1 : 0,
    hasExportOptions ? 1 : 0,
    showTooltipIsFalse ? 1 : 0,
    hasPadding ? 1 : 0,
    hasDom ? 1 : 0,
    hasTooltip ? 1 : 0,
    hasMarkStyle ? 1 : 0,
    hasInteraction ? 1 : 0,
    hasAnnotations ? 1 : 0,
    hasAnimationOptions ? 1 : 0,
    hasGraphMeta ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-build-plan request");
  }
  const plan = readPayloadBuildPlan(out);
  if (
    plan.wasmDensityKind !== DENSITY_WASM_DENSITY_NONE
    && plan.wasmDensityKind !== DENSITY_WASM_DENSITY_AUTOMATIC
    && plan.wasmDensityKind !== DENSITY_WASM_DENSITY_UNSUPPORTED
  ) {
    throw new RangeError("invalid payload-build-plan wasm_density_kind");
  }
  return plan;
}

const PAYLOAD_AXIS_SPEC_ATTACH_PLAN_BYTES = 128;

function readPayloadAxisSpecAttachPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const u32 = () => {
    const value = view.getUint32(off, true);
    off += 4;
    return value;
  };
  const b = () => u32() !== 0;
  return {
    attachId: b(),
    attachKind: b(),
    attachSide: b(),
    attachLabel: b(),
    attachRange: b(),
    attachScale: b(),
    attachTicks: b(),
    attachTickSides: b(),
    attachTickLabelSides: b(),
    attachLabelPosition: b(),
    attachLabelOffset: b(),
    attachLabelAngle: b(),
    attachTickLabelAngle: b(),
    attachTickLabelStrategy: b(),
    attachTickLabelAnchor: b(),
    attachTickLabelMinGap: b(),
    attachConstant: b(),
    attachNonpositive: b(),
    attachReverse: b(),
    attachDomain: b(),
    attachBounds: b(),
    attachMinorStyle: b(),
    attachFormat: b(),
    attachStyle: b(),
    attachCategories: b(),
    attachThetaUnit: b(),
    attachThetaZero: b(),
    attachThetaDirection: b(),
    attachSector: b(),
    attachGridShape: b(),
    attachHole: b(),
    attachROrigin: b(),
  };
}

/** Axis-spec attach orchestration via `xyg_payload_axis_spec_attach_plan` (ABI 304). */
export function payloadAxisSpecAttachPlan({
  coordsCartesian = true,
  axisIsX = true,
} = {}) {
  const out = new Uint8Array(PAYLOAD_AXIS_SPEC_ATTACH_PLAN_BYTES);
  const ok = Number(xyPayloadAxisSpecAttachPlan(
    coordsCartesian ? 1 : 0,
    axisIsX ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid payload-axis-spec-attach-plan request");
  }
  return readPayloadAxisSpecAttachPlan(out);
}

const SCENE_XYTC_FIGURE_PLAN_BYTES = 4;
const SCENE_XYTC_TRACE_DISPATCH_PLAN_BYTES = 40;

function readSceneXytcFigurePlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return { showLegend: view.getUint32(0, true) !== 0 };
}

function readSceneXytcTraceDispatchPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const u32 = () => {
    const value = view.getUint32(off, true);
    off += 4;
    return value;
  };
  const b = () => u32() !== 0;
  return {
    kindClass: u32(),
    packOpacity: b(),
    packHexPitch: b(),
    packStrokePerimeter: b(),
    packColor2: b(),
    packRadius: b(),
    markerPathBranch: b(),
    markerGlyphBranch: b(),
    metaUseDensity: b(),
    metaJoinedFill: b(),
  };
}

/** Figure-level XYTC pack orchestration via `xyg_scene_xytc_figure_plan` (ABI 305). */
export function sceneXytcFigurePlan({ showLegend = true } = {}) {
  const out = new Uint8Array(SCENE_XYTC_FIGURE_PLAN_BYTES);
  const ok = Number(xySceneXytcFigurePlan(showLegend ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xytc-figure-plan request");
  }
  return readSceneXytcFigurePlan(out);
}

/** Per-trace XYTC pack dispatch via `xyg_scene_xytc_trace_dispatch_plan` (ABI 305). */
export function sceneXytcTraceDispatchPlan({
  kind = "",
  markerPathPresent = false,
  useDensity = false,
  joinedFill = false,
} = {}) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const out = new Uint8Array(SCENE_XYTC_TRACE_DISPATCH_PLAN_BYTES);
  const ok = Number(xySceneXytcTraceDispatchPlan(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    markerPathPresent ? 1 : 0,
    useDensity ? 1 : 0,
    joinedFill ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xytc-trace-dispatch-plan request");
  }
  return readSceneXytcTraceDispatchPlan(out);
}

const SCENE_XYTA_FIGURE_PLAN_BYTES = 4;
const SCENE_XYTA_TRACE_DISPATCH_PLAN_BYTES = 32;

function readSceneXytaFigurePlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return { polar: view.getUint32(0, true) !== 0 };
}

function readSceneXytaTraceDispatchPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const u32 = () => {
    const value = view.getUint32(off, true);
    off += 4;
    return value;
  };
  const b = () => u32() !== 0;
  return {
    kindClass: u32(),
    packHeatmap: b(),
    packHexbinColormap: b(),
    packHexbinRgba: b(),
    packRibbonEnds: b(),
    packMeshFaces: b(),
    packScatterPaint: b(),
    packDensity: b(),
  };
}

/** Figure-level XYTA attach orchestration via `xyg_scene_xyta_figure_plan` (ABI 306). */
export function sceneXytaFigurePlan({ polar = false } = {}) {
  const out = new Uint8Array(SCENE_XYTA_FIGURE_PLAN_BYTES);
  const ok = Number(xySceneXytaFigurePlan(polar ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xyta-figure-plan request");
  }
  return readSceneXytaFigurePlan(out);
}

/** Per-trace XYTA attach dispatch via `xyg_scene_xyta_trace_dispatch_plan` (ABI 306). */
export function sceneXytaTraceDispatchPlan({
  kind = "",
  polar = false,
  useDensity = false,
  hexbinColormapPlane = false,
  hexbinRgbaPlaneReady = false,
  ribbonColor2Class = 0,
  meshPaintPlane = false,
  scatterPaintPlane = false,
} = {}) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const out = new Uint8Array(SCENE_XYTA_TRACE_DISPATCH_PLAN_BYTES);
  const ok = Number(xySceneXytaTraceDispatchPlan(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    polar ? 1 : 0,
    useDensity ? 1 : 0,
    hexbinColormapPlane ? 1 : 0,
    hexbinRgbaPlaneReady ? 1 : 0,
    Number(ribbonColor2Class),
    meshPaintPlane ? 1 : 0,
    scatterPaintPlane ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xyta-trace-dispatch-plan request");
  }
  return readSceneXytaTraceDispatchPlan(out);
}

const SCENE_XYTC_TRACE_STYLE_IN_BYTES = 336;
const SCENE_XYTC_TRACE_PACK_IN_BYTES = 408;
const SCENE_XYTA_TRACE_PACK_IN_BYTES = 256;
export const SCENE_XYTC_TRACE_PACK_MAX_RECORD = 1 << 20;
export const SCENE_XYTA_TRACE_PACK_MAX_RECORD = 1 << 22;

function packSceneXytcTraceStyleIn(style) {
  const buf = Buffer.alloc(SCENE_XYTC_TRACE_STYLE_IN_BYTES);
  const setI32 = (off, value) => {
    buf.writeInt32LE(Number(value), off);
  };
  const setU16 = (off, value) => {
    buf.writeUInt16LE(Number(value) & 0xFFFF, off);
  };
  const setF64 = (off, value) => {
    buf.writeDoubleLE(Number(value), off);
  };
  const setU64 = (off, value) => {
    buf.writeBigUInt64LE(BigInt(value), off);
  };
  setI32(0, style.symbolIsInt);
  setU16(4, style.symbolInt);
  setF64(8, style.opacity);
  setF64(16, style.fillOpacity);
  setF64(24, style.strokeOpacity);
  setF64(32, style.lineOpacity);
  setI32(40, style.hasStroke);
  setI32(44, style.hasLineColor);
  setI32(48, style.hasSize);
  setF64(56, style.size);
  setI32(64, style.hasSizeCh);
  setI32(68, style.hasSizeChConstant);
  setF64(72, style.sizeChConstant);
  setI32(80, style.hasStrokeWidth);
  setF64(88, style.strokeWidth);
  setI32(96, style.hasWidth);
  setF64(104, style.width);
  setI32(112, style.hasLineWidth);
  setF64(120, style.lineWidth);
  setI32(128, style.hasHexDx);
  setF64(136, style.hexDx);
  setI32(144, style.hasHexDy);
  setF64(152, style.hexDy);
  setI32(160, style.hasStrokePerimeter);
  setI32(164, style.strokePerimeterIsBool);
  setI32(168, style.strokePerimeterTrue);
  setI32(172, style.dashIsArray);
  setI32(176, style.hasFill);
  setI32(180, style.fillKind);
  setI32(184, style.colorChPresent);
  setI32(188, style.colorChHasConstant);
  setI32(192, style.radiusSeq);
  setF64(200, style.r0);
  setF64(208, style.r1);
  setF64(216, style.wedgeGapRaw);
  setU64(224, style.symbolLen);
  setU64(232, style.dashLen);
  setU64(240, style.dashPatternLen);
  setU64(248, style.linecapLen);
  setU64(256, style.stepLen);
  setU64(264, style.curveLen);
  setU64(272, style.fillCssLen);
  setU64(280, style.fillSpaceLen);
  setU64(288, style.fillGradientLen);
  setU64(296, style.strokeCssLen);
  setU64(304, style.lineColorLen);
  setU64(312, style.colorCssLen);
  setU64(320, style.colorModeLen);
  setU64(328, style.colorConstLen);
  return buf;
}

function packSceneXytcTracePackIn(fields, styleBuf) {
  const buf = Buffer.alloc(SCENE_XYTC_TRACE_PACK_IN_BYTES);
  const setI32 = (off, value) => {
    buf.writeInt32LE(Number(value), off);
  };
  const setU64 = (off, value) => {
    buf.writeBigUInt64LE(BigInt(value), off);
  };
  setI32(0, fields.showLegend);
  setI32(4, fields.hasName);
  setI32(8, fields.markerPathPresent);
  setI32(12, fields.useDensity);
  setI32(16, fields.joinedFill);
  setI32(20, fields.markerPacked);
  setI32(24, fields.glyphPacked);
  setI32(28, fields.color2Class);
  setI32(32, fields.color2GradientPacked);
  setU64(40, fields.kindLen);
  setU64(48, fields.nameLen);
  setU64(56, fields.markerBlobLen);
  setU64(64, fields.color2GradientLen);
  styleBuf.copy(buf, 72);
  return buf;
}

function packSceneXytaTracePackIn(fields) {
  const buf = Buffer.alloc(SCENE_XYTA_TRACE_PACK_IN_BYTES);
  const setI32 = (off, value) => {
    buf.writeInt32LE(Number(value), off);
  };
  const setU32 = (off, value) => {
    buf.writeUInt32LE(Number(value) >>> 0, off);
  };
  const setF32 = (off, value) => {
    buf.writeFloatLE(Number(value), off);
  };
  const setF64 = (off, value) => {
    buf.writeDoubleLE(Number(value), off);
  };
  const setU64 = (off, value) => {
    buf.writeBigUInt64LE(BigInt(value), off);
  };
  setU32(0, fields.traceId);
  setI32(4, fields.packHeatmap);
  setI32(8, fields.packHexbinColormap);
  setI32(12, fields.packHexbinRgba);
  setI32(16, fields.packRibbonEnds);
  setI32(20, fields.packMeshFaces);
  setI32(24, fields.packScatterPaint);
  setI32(28, fields.packDensity);
  setF64(32, fields.gridShapeRows);
  setF64(40, fields.gridShapeCols);
  setI32(48, fields.hasGridShape);
  setI32(52, fields.hasGrid);
  setI32(56, fields.hasRgba);
  setI32(60, fields.hasRgbaGrid);
  setI32(64, fields.truecolor);
  setI32(68, fields.hasCmapDomain);
  setF64(72, fields.cmapLo);
  setF64(80, fields.cmapHi);
  setI32(88, fields.hasColorCh);
  setI32(92, fields.hasStyleColor);
  setI32(96, fields.hasOpacity);
  setI32(100, fields.hasFillOpacity);
  setF32(104, fields.opacity);
  setF32(108, fields.fillOpacity);
  setF64(112, fields.domainX0);
  setF64(120, fields.domainX1);
  setF64(128, fields.domainY0);
  setF64(136, fields.domainY1);
  setU32(144, fields.cmapFlags);
  setI32(148, fields.rows);
  setI32(152, fields.cols);
  setU64(160, fields.gridLen);
  setU64(168, fields.rgbaLen);
  setU64(176, fields.rgbaGridLen);
  setU64(184, fields.xLen);
  setU64(192, fields.yLen);
  setU64(200, fields.meanRgbaLen);
  setU64(208, fields.idxLen);
  setU64(216, fields.lutLen);
  setU64(224, fields.cmapLen);
  setU64(232, fields.stopsLen);
  setU64(240, fields.colorChLen);
  setU64(248, fields.styleColorLen);
  return buf;
}

/** Pack one authored trace into an XYTR v1 record via `xyg_scene_xytc_trace_pack` (ABI 317). */
export function sceneXytcTracePack({
  showLegend = true,
  kind,
  hasName = false,
  name,
  markerPathPresent = false,
  useDensity = false,
  joinedFill = false,
  markerPacked = false,
  glyphPacked = false,
  markerBlob,
  color2Class = 0,
  color2GradientBlob,
  color2GradientPacked = false,
  style,
  symbolB,
  dashB,
  dashPattern,
  linecapB,
  stepB,
  curveB,
  fillCss,
  fillSpace,
  fillGradientBlob,
  strokeCss,
  lineColor,
  colorCss,
  colorMode,
  colorConst,
}) {
  const kindBytes = kind instanceof Uint8Array ? kind : new TextEncoder().encode(String(kind ?? ""));
  const nameBytes = name instanceof Uint8Array ? name : new TextEncoder().encode(String(name ?? ""));
  const symbolBytes = symbolB instanceof Uint8Array ? symbolB : new Uint8Array();
  const dashBytes = dashB instanceof Uint8Array ? dashB : new Uint8Array();
  const dashPat = dashPattern instanceof Float64Array
    ? dashPattern
    : Float64Array.from(dashPattern ?? []);
  const linecapBytes = linecapB instanceof Uint8Array ? linecapB : new Uint8Array();
  const stepBytes = stepB instanceof Uint8Array ? stepB : new Uint8Array();
  const curveBytes = curveB instanceof Uint8Array ? curveB : new Uint8Array();
  const fillCssBytes = fillCss instanceof Uint8Array ? fillCss : new Uint8Array();
  const fillSpaceBytes = fillSpace instanceof Uint8Array ? fillSpace : new Uint8Array();
  const fillGradBytes = fillGradientBlob instanceof Uint8Array ? fillGradientBlob : new Uint8Array();
  const strokeBytes = strokeCss instanceof Uint8Array ? strokeCss : new Uint8Array();
  const lineColorBytes = lineColor instanceof Uint8Array ? lineColor : new Uint8Array();
  const colorCssBytes = colorCss instanceof Uint8Array ? colorCss : new Uint8Array();
  const colorModeBytes = colorMode instanceof Uint8Array ? colorMode : new Uint8Array();
  const colorConstBytes = colorConst instanceof Uint8Array ? colorConst : new Uint8Array();
  const markerBytes = markerBlob instanceof Uint8Array ? markerBlob : new Uint8Array();
  const color2GradBytes = color2GradientBlob instanceof Uint8Array ? color2GradientBlob : new Uint8Array();
  const styleBuf = packSceneXytcTraceStyleIn({
    symbolIsInt: style.symbolIsInt,
    symbolInt: style.symbolInt,
    opacity: style.opacity,
    fillOpacity: style.fillOpacity,
    strokeOpacity: style.strokeOpacity,
    lineOpacity: style.lineOpacity,
    hasStroke: style.hasStroke,
    hasLineColor: style.hasLineColor,
    hasSize: style.hasSize,
    size: style.size,
    hasSizeCh: style.hasSizeCh,
    hasSizeChConstant: style.hasSizeChConstant,
    sizeChConstant: style.sizeChConstant,
    hasStrokeWidth: style.hasStrokeWidth,
    strokeWidth: style.strokeWidth,
    hasWidth: style.hasWidth,
    width: style.width,
    hasLineWidth: style.hasLineWidth,
    lineWidth: style.lineWidth,
    hasHexDx: style.hasHexDx,
    hexDx: style.hexDx,
    hasHexDy: style.hasHexDy,
    hexDy: style.hexDy,
    hasStrokePerimeter: style.hasStrokePerimeter,
    strokePerimeterIsBool: style.strokePerimeterIsBool,
    strokePerimeterTrue: style.strokePerimeterTrue,
    dashIsArray: style.dashIsArray,
    hasFill: style.hasFill,
    fillKind: style.fillKind,
    colorChPresent: style.colorChPresent,
    colorChHasConstant: style.colorChHasConstant,
    radiusSeq: style.radiusSeq,
    r0: style.r0,
    r1: style.r1,
    wedgeGapRaw: style.wedgeGapRaw,
    symbolLen: symbolBytes.length,
    dashLen: dashBytes.length,
    dashPatternLen: dashPat.length,
    linecapLen: linecapBytes.length,
    stepLen: stepBytes.length,
    curveLen: curveBytes.length,
    fillCssLen: fillCssBytes.length,
    fillSpaceLen: fillSpaceBytes.length,
    fillGradientLen: fillGradBytes.length,
    strokeCssLen: strokeBytes.length,
    lineColorLen: lineColorBytes.length,
    colorCssLen: colorCssBytes.length,
    colorModeLen: colorModeBytes.length,
    colorConstLen: colorConstBytes.length,
  });
  const inputBuf = packSceneXytcTracePackIn({
    showLegend: showLegend ? 1 : 0,
    hasName: hasName ? 1 : 0,
    markerPathPresent: markerPathPresent ? 1 : 0,
    useDensity: useDensity ? 1 : 0,
    joinedFill: joinedFill ? 1 : 0,
    markerPacked: markerPacked ? 1 : 0,
    glyphPacked: glyphPacked ? 1 : 0,
    color2Class,
    color2GradientPacked: color2GradientPacked ? 1 : 0,
    kindLen: kindBytes.length,
    nameLen: nameBytes.length,
    markerBlobLen: markerBytes.length,
    color2GradientLen: color2GradBytes.length,
  }, styleBuf);
  const out = new Uint8Array(SCENE_XYTC_TRACE_PACK_MAX_RECORD);
  const outLen = new BigUint64Array(1);
  const code = Number(xySceneXytcTracePack(
    inputBuf,
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    nameBytes.length ? u8Ptr(nameBytes) : 0,
    symbolBytes.length ? u8Ptr(symbolBytes) : 0,
    dashBytes.length ? u8Ptr(dashBytes) : 0,
    dashPat.length ? f64Ptr(dashPat) : 0,
    linecapBytes.length ? u8Ptr(linecapBytes) : 0,
    stepBytes.length ? u8Ptr(stepBytes) : 0,
    curveBytes.length ? u8Ptr(curveBytes) : 0,
    fillCssBytes.length ? u8Ptr(fillCssBytes) : 0,
    fillSpaceBytes.length ? u8Ptr(fillSpaceBytes) : 0,
    fillGradBytes.length ? u8Ptr(fillGradBytes) : 0,
    strokeBytes.length ? u8Ptr(strokeBytes) : 0,
    lineColorBytes.length ? u8Ptr(lineColorBytes) : 0,
    colorCssBytes.length ? u8Ptr(colorCssBytes) : 0,
    colorModeBytes.length ? u8Ptr(colorModeBytes) : 0,
    colorConstBytes.length ? u8Ptr(colorConstBytes) : 0,
    markerBytes.length ? u8Ptr(markerBytes) : 0,
    color2GradBytes.length ? u8Ptr(color2GradBytes) : 0,
    u8Ptr(out),
    BigInt(out.length),
    pointer(outLen, "size_t *"),
  ));
  if (code === -2) {
    throw new RangeError("sceneXytcTracePack output buffer too small");
  }
  if (code !== 0) {
    throw new RangeError("invalid sceneXytcTracePack arguments");
  }
  return out.subarray(0, Number(outLen[0]));
}

/** Pack one attach trace into an XYTA v1 record via `xyg_scene_xyta_trace_pack` (ABI 318). */
export function sceneXytaTracePack({
  traceId = 0,
  packHeatmap = false,
  packHexbinColormap = false,
  packHexbinRgba = false,
  packRibbonEnds = false,
  packMeshFaces = false,
  packScatterPaint = false,
  packDensity = false,
  gridShapeRows = Number.NaN,
  gridShapeCols = Number.NaN,
  hasGridShape = false,
  hasGrid = false,
  hasRgba = false,
  hasRgbaGrid = false,
  truecolor = false,
  hasCmapDomain = false,
  cmapLo = Number.NaN,
  cmapHi = Number.NaN,
  hasColorCh = false,
  hasStyleColor = false,
  hasOpacity = false,
  hasFillOpacity = false,
  opacity = Number.NaN,
  fillOpacity = Number.NaN,
  domainX0 = Number.NaN,
  domainX1 = Number.NaN,
  domainY0 = Number.NaN,
  domainY1 = Number.NaN,
  cmapFlags = 0,
  rows = 0,
  cols = 0,
  grid,
  rgba,
  rgbaGrid,
  x,
  y,
  meanRgba,
  idx,
  lut,
  cmap,
  stops,
  colorCh,
  styleColor,
}) {
  const gridBytes = grid instanceof Uint8Array ? grid : new Uint8Array();
  const rgbaBytes = rgba instanceof Uint8Array ? rgba : new Uint8Array();
  const rgbaGridBytes = rgbaGrid instanceof Uint8Array ? rgbaGrid : new Uint8Array();
  const xBytes = x instanceof Uint8Array ? x : new Uint8Array();
  const yBytes = y instanceof Uint8Array ? y : new Uint8Array();
  const meanRgbaBytes = meanRgba instanceof Uint8Array ? meanRgba : new Uint8Array();
  const idxBytes = idx instanceof Uint8Array ? idx : new Uint8Array();
  const lutBytes = lut instanceof Uint8Array ? lut : new Uint8Array();
  const cmapBytes = cmap instanceof Uint8Array ? cmap : new Uint8Array();
  const stopsBytes = stops instanceof Uint8Array ? stops : new Uint8Array();
  const colorChBytes = colorCh instanceof Uint8Array ? colorCh : new Uint8Array();
  const styleColorBytes = styleColor instanceof Uint8Array ? styleColor : new Uint8Array();
  const inputBuf = packSceneXytaTracePackIn({
    traceId,
    packHeatmap: packHeatmap ? 1 : 0,
    packHexbinColormap: packHexbinColormap ? 1 : 0,
    packHexbinRgba: packHexbinRgba ? 1 : 0,
    packRibbonEnds: packRibbonEnds ? 1 : 0,
    packMeshFaces: packMeshFaces ? 1 : 0,
    packScatterPaint: packScatterPaint ? 1 : 0,
    packDensity: packDensity ? 1 : 0,
    gridShapeRows,
    gridShapeCols,
    hasGridShape: hasGridShape ? 1 : 0,
    hasGrid: hasGrid ? 1 : 0,
    hasRgba: hasRgba ? 1 : 0,
    hasRgbaGrid: hasRgbaGrid ? 1 : 0,
    truecolor: truecolor ? 1 : 0,
    hasCmapDomain: hasCmapDomain ? 1 : 0,
    cmapLo,
    cmapHi,
    hasColorCh: hasColorCh ? 1 : 0,
    hasStyleColor: hasStyleColor ? 1 : 0,
    hasOpacity: hasOpacity ? 1 : 0,
    hasFillOpacity: hasFillOpacity ? 1 : 0,
    opacity,
    fillOpacity,
    domainX0,
    domainX1,
    domainY0,
    domainY1,
    cmapFlags,
    rows,
    cols,
    gridLen: gridBytes.length,
    rgbaLen: rgbaBytes.length,
    rgbaGridLen: rgbaGridBytes.length,
    xLen: xBytes.length,
    yLen: yBytes.length,
    meanRgbaLen: meanRgbaBytes.length,
    idxLen: idxBytes.length,
    lutLen: lutBytes.length,
    cmapLen: cmapBytes.length,
    stopsLen: stopsBytes.length,
    colorChLen: colorChBytes.length,
    styleColorLen: styleColorBytes.length,
  });
  const out = new Uint8Array(SCENE_XYTA_TRACE_PACK_MAX_RECORD);
  const outLen = new BigUint64Array(1);
  const code = Number(xySceneXytaTracePack(
    inputBuf,
    gridBytes.length ? u8Ptr(gridBytes) : 0,
    rgbaBytes.length ? u8Ptr(rgbaBytes) : 0,
    rgbaGridBytes.length ? u8Ptr(rgbaGridBytes) : 0,
    xBytes.length ? u8Ptr(xBytes) : 0,
    yBytes.length ? u8Ptr(yBytes) : 0,
    meanRgbaBytes.length ? u8Ptr(meanRgbaBytes) : 0,
    idxBytes.length ? u8Ptr(idxBytes) : 0,
    lutBytes.length ? u8Ptr(lutBytes) : 0,
    cmapBytes.length ? u8Ptr(cmapBytes) : 0,
    stopsBytes.length ? u8Ptr(stopsBytes) : 0,
    colorChBytes.length ? u8Ptr(colorChBytes) : 0,
    styleColorBytes.length ? u8Ptr(styleColorBytes) : 0,
    u8Ptr(out),
    BigInt(out.length),
    pointer(outLen, "size_t *"),
  ));
  if (code === -2) {
    throw new RangeError("sceneXytaTracePack output buffer too small");
  }
  if (code !== 0) {
    throw new RangeError("invalid sceneXytaTracePack arguments");
  }
  return out.subarray(0, Number(outLen[0]));
}

const SCENE_XYAF_PACK_MAX_RECORD = 1 << 16;
const SCENE_XYCF_PACK_MAX = 1 << 20;
const SCENE_FIGURE_SUPPORT_PACK_MAX = 1 << 18;
const PAYLOAD_COLUMN_MATERIALIZE_MAX_BYTES = 1 << 28;
const PAYLOAD_CHANNEL_MATERIALIZE_MAX_BYTES = 1 << 28;
const SCENE_XYAF_PACK_IN_BYTES = 232;
const SCENE_XYCF_PACK_IN_BYTES = 344;

/** Pack one XYAF v1 record via `xyg_scene_xyaf_pack` (ABI 319). */
export function sceneXyafPack({
  index = 0,
  kindCode = 0,
  axisCode = 0,
  symbol = 0,
  anchor = 255,
  facts = 0,
  styleBits = 0,
  linecap = 255,
  dashCount = 0,
  nums = [],
  color = new Uint8Array(4),
  stroke = new Uint8Array(4),
  labelColor = new Uint8Array(4),
  labelFill = new Uint8Array(4),
  labelBorder = new Uint8Array(4),
  dash = new Float32Array(8),
  text = new Uint8Array(0),
} = {}) {
  const input = Buffer.alloc(232);
  input.writeUInt32LE(index >>> 0, 0);
  input.writeUInt8(kindCode & 0xff, 4);
  input.writeUInt8(axisCode & 0xff, 5);
  input.writeUInt8(symbol & 0xff, 6);
  input.writeUInt8(anchor & 0xff, 7);
  input.writeUInt32LE(facts >>> 0, 8);
  input.writeUInt32LE(styleBits >>> 0, 12);
  input.writeUInt8(linecap & 0xff, 16);
  input.writeUInt8(dashCount & 0xff, 17);
  input.writeBigUInt64LE(BigInt(text.length), 24);
  for (let i = 0; i < 18; i += 1) input.writeDoubleLE(Number(nums[i] ?? Number.NaN), 32 + i * 8);
  input.set(color.subarray(0, 4), 176);
  input.set(stroke.subarray(0, 4), 180);
  input.set(labelColor.subarray(0, 4), 184);
  input.set(labelFill.subarray(0, 4), 188);
  input.set(labelBorder.subarray(0, 4), 192);
  for (let i = 0; i < 8; i += 1) input.writeFloatLE(Number(dash[i] ?? 0), 196 + i * 4);
  const out = new Uint8Array(SCENE_XYAF_PACK_MAX_RECORD);
  const outLen = new BigUint64Array(1);
  const code = Number(xySceneXyafPack(
    u8Ptr(input),
    text.length ? u8Ptr(text) : 0,
    u8Ptr(out),
    BigInt(out.length),
    pointer(outLen, "size_t *"),
  ));
  if (code === -2) throw new RangeError("sceneXyafPack output buffer too small");
  if (code !== 0) throw new RangeError("invalid sceneXyafPack arguments");
  return out.subarray(0, Number(outLen[0]));
}

/** Pack XYFS v2 support envelope via `xyg_scene_figure_support_pack` (ABI 319). */
export function sceneFigureSupportPack({ flags = 0, axesBlob = new Uint8Array(0), tracesBlob = new Uint8Array(0) } = {}) {
  const out = new Uint8Array(SCENE_FIGURE_SUPPORT_PACK_MAX);
  const outLen = new BigUint64Array(1);
  const code = Number(xySceneFigureSupportPack(
    flags >>> 0,
    axesBlob.length ? u8Ptr(axesBlob) : 0,
    BigInt(axesBlob.length),
    tracesBlob.length ? u8Ptr(tracesBlob) : 0,
    BigInt(tracesBlob.length),
    u8Ptr(out),
    BigInt(out.length),
    pointer(outLen, "size_t *"),
  ));
  if (code === -2) throw new RangeError("sceneFigureSupportPack output buffer too small");
  if (code !== 0) throw new RangeError("invalid sceneFigureSupportPack arguments");
  return out.subarray(0, Number(outLen[0]));
}

/** Gather and offset-ship geometry columns via `xyg_payload_column_gather_materialize` (ABI 320). */
export function payloadColumnGatherMaterialize({ sel = null, columns = [], values = [], kinds = [], axisScales = [] } = {}) {
  const n = columns.length;
  const desc = Buffer.alloc(n * 56);
  const valuePtrs = Buffer.alloc(n * 8);
  const kindPtrs = Buffer.alloc(n * 8);
  const scalePtrs = Buffer.alloc(n * 8);
  const shipMethod = { offset: 0, values: 1, f64: 2 };
  const shipScale = { x: 0, y: 1 };
  for (let i = 0; i < n; i += 1) {
    const base = i * 56;
    desc.writeInt32LE(shipMethod[columns[i].shipMethod], base);
    desc.writeInt32LE(shipScale[columns[i].shipScale], base + 4);
    const arr = asF64Array(values[i]);
    desc.writeBigUInt64LE(BigInt(arr.length), base + 8);
    desc.writeDoubleLE(Number(columns[i].colMin ?? 0), base + 16);
    desc.writeDoubleLE(Number(columns[i].colMax ?? 0), base + 24);
    desc.writeBigUInt64LE(BigInt((kinds[i] ?? new Uint8Array(0)).length), base + 32);
    desc.writeDoubleLE(Number(columns[i].stickyOffset ?? 0), base + 40);
    const scaleBytes = new TextEncoder().encode(String(axisScales[i] ?? "linear"));
    desc.writeBigUInt64LE(BigInt(scaleBytes.length), base + 48);
    valuePtrs.writeBigUInt64LE(BigInt(f64Ptr(arr)), i * 8);
    kindPtrs.writeBigUInt64LE(BigInt((kinds[i] ?? new Uint8Array(0)).length ? u8Ptr(kinds[i]) : 0), i * 8);
    scalePtrs.writeBigUInt64LE(BigInt(scaleBytes.length ? u8Ptr(scaleBytes) : 0), i * 8);
  }
  const selArr = sel == null ? new Uint32Array(0) : sel;
  const outDesc = Buffer.alloc(n * 48);
  const outBytes = new Uint8Array(PAYLOAD_COLUMN_MATERIALIZE_MAX_BYTES);
  const outBytesLen = new BigUint64Array(1);
  const written = Number(xyPayloadColumnGatherMaterialize(
    selArr.length ? u32Ptr(selArr) : 0,
    BigInt(selArr.length),
    u8Ptr(desc),
    BigInt(n),
    u8Ptr(valuePtrs),
    u8Ptr(kindPtrs),
    u8Ptr(scalePtrs),
    u8Ptr(outDesc),
    u8Ptr(outBytes),
    BigInt(outBytes.length),
    pointer(outBytesLen, "size_t *"),
  ));
  if (written < 0) throw new RangeError("invalid payloadColumnGatherMaterialize arguments");
  const blob = outBytes.subarray(0, Number(outBytesLen[0]));
  const result = [];
  for (let i = 0; i < written; i += 1) {
    const base = i * 48;
    const view = new DataView(outDesc.buffer, outDesc.byteOffset + base, 48);
    const bytesOffset = Number(view.getBigUint64(32, true));
    const bytesLen = Number(view.getBigUint64(40, true));
    result.push({
      dtypeCode: view.getInt32(0, true),
      meta: {
        len: view.getUint32(16, true),
        offset: view.getFloat64(8, true),
        scale: view.getFloat64(24, true),
      },
      bytes: blob.subarray(bytesOffset, bytesOffset + bytesLen),
    });
  }
  return result;
}

/** Materialize one channel wire buffer via `xyg_payload_channel_materialize` (ABI 320). */
export function payloadChannelMaterialize({
  role = "color",
  mode = "continuous",
  nCategories = 0,
  styleDtypeU8 = false,
  quantizeContinuous = false,
  domain = [0, 1],
  nPalette = 0,
  sel = null,
  valuesF64 = new Float64Array(0),
  valuesU8 = new Uint8Array(0),
} = {}) {
  const roleCode = { color: 0, size: 1, style: 2 }[role];
  const modeCode = { constant: 0, continuous: 1, categorical: 2, direct_rgba: 3, match_fill: 4, direct: 5 }[mode];
  const selArr = sel == null ? new Uint32Array(0) : sel;
  const out = new Uint8Array(PAYLOAD_CHANNEL_MATERIALIZE_MAX_BYTES);
  const meta = new Int32Array(5);
  const nbytes = Number(xyPayloadChannelMaterialize(
    roleCode,
    modeCode,
    BigInt(nCategories),
    styleDtypeU8 ? 1 : 0,
    quantizeContinuous ? 1 : 0,
    Number(domain[0]),
    Number(domain[1]),
    BigInt(nPalette),
    selArr.length ? u32Ptr(selArr) : 0,
    BigInt(selArr.length),
    valuesF64.length ? f64Ptr(valuesF64) : 0,
    BigInt(valuesF64.length),
    valuesU8.length ? u8Ptr(valuesU8) : 0,
    BigInt(valuesU8.length),
    u8Ptr(out),
    BigInt(out.length),
    pointer(meta, "int32_t *"),
  ));
  if (nbytes < 0) throw new RangeError("invalid payloadChannelMaterialize arguments");
  return {
    bufKind: meta[0],
    markDtypeU8: meta[1] !== 0,
    shipPalette: meta[2] !== 0,
    setN: meta[3] !== 0,
    len: meta[4],
    bytes: out.subarray(0, nbytes),
  };
}

const SCENE_FIGURE_SUPPORT_FIGURE_PLAN_BYTES = 4;
const SCENE_FIGURE_SUPPORT_TRACE_DISPATCH_PLAN_BYTES = 32;
const SCENE_XYCL_FIGURE_PLAN_BYTES = 4;
const SCENE_XYNM_FIGURE_PLAN_BYTES = 4;

function readSceneFigureSupportFigurePlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return { polar: view.getUint32(0, true) !== 0 };
}

function readSceneFigureSupportTraceDispatchPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const u32 = () => {
    const value = view.getUint32(off, true);
    off += 4;
    return value;
  };
  const b = () => u32() !== 0;
  return {
    kindClass: u32(),
    probeMarkerGlyph: b(),
    probeMarkerPath: b(),
    probeCurveSmooth: b(),
    probeRectExtra: b(),
    probeHexbinReduce: b(),
    probeHeatmapColormap: b(),
    probeNonCssFill: b(),
  };
}

/** Figure-level XYFS support orchestration via `xyg_scene_figure_support_figure_plan` (ABI 307). */
export function sceneFigureSupportFigurePlan({ polar = false } = {}) {
  const out = new Uint8Array(SCENE_FIGURE_SUPPORT_FIGURE_PLAN_BYTES);
  const ok = Number(xySceneFigureSupportFigurePlan(polar ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-figure-support-figure-plan request");
  }
  return readSceneFigureSupportFigurePlan(out);
}

/** Per-trace XYFS support dispatch via `xyg_scene_figure_support_trace_dispatch_plan` (ABI 307). */
export function sceneFigureSupportTraceDispatchPlan({
  kind = "",
  markerGlyphPresent = false,
  markerPathPresent = false,
  curvePresent = false,
  fillPresent = false,
} = {}) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const out = new Uint8Array(SCENE_FIGURE_SUPPORT_TRACE_DISPATCH_PLAN_BYTES);
  const ok = Number(xySceneFigureSupportTraceDispatchPlan(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    markerGlyphPresent ? 1 : 0,
    markerPathPresent ? 1 : 0,
    curvePresent ? 1 : 0,
    fillPresent ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-figure-support-trace-dispatch-plan request");
  }
  return readSceneFigureSupportTraceDispatchPlan(out);
}

/** Figure-level XYCL attach orchestration via `xyg_scene_xycl_figure_plan` (ABI 307). */
export function sceneXyclFigurePlan({ polar = false } = {}) {
  const out = new Uint8Array(SCENE_XYCL_FIGURE_PLAN_BYTES);
  const ok = Number(xySceneXyclFigurePlan(polar ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xycl-figure-plan request");
  }
  return readSceneFigureSupportFigurePlan(out);
}

/** Figure-level XYNM attach orchestration via `xyg_scene_xynm_figure_plan` (ABI 307). */
export function sceneXynmFigurePlan({ showLegend = true } = {}) {
  const out = new Uint8Array(SCENE_XYNM_FIGURE_PLAN_BYTES);
  const ok = Number(xySceneXynmFigurePlan(showLegend ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xynm-figure-plan request");
  }
  const view = new DataView(out.buffer, out.byteOffset, out.byteLength);
  return { showLegend: view.getUint32(0, true) !== 0 };
}

const SCENE_XYCF_FIGURE_PLAN_BYTES = 16;
const SCENE_XYAF_ANNOTATION_DISPATCH_PLAN_BYTES = 20;
const SCENE_PUBLIC_EXPORT_FIGURE_PLAN_BYTES = 12;
const SCENE_PUBLIC_EXPORT_TRACE_DISPATCH_PLAN_BYTES = 12;

function readSceneXycfFigurePlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    showLegend: view.getUint32(0, true) !== 0,
    attachLegend: view.getUint32(4, true) !== 0,
    attachColorbar: view.getUint32(8, true) !== 0,
    polar: view.getUint32(12, true) !== 0,
  };
}

function readSceneXyafAnnotationDispatchPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    wrapped: view.getUint32(0, true) !== 0,
    packRuleDash: view.getUint32(4, true) !== 0,
    packRuleLinecap: view.getUint32(8, true) !== 0,
    packAxis: view.getUint32(12, true) !== 0,
    packSymbol: view.getUint32(16, true) !== 0,
  };
}

function readScenePublicExportFigurePlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    polar: view.getUint32(0, true) !== 0,
    hasChromeStyles: view.getUint32(4, true) !== 0,
    hasTitleOptions: view.getUint32(8, true) !== 0,
  };
}

function readScenePublicExportTraceDispatchPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    kindClass: view.getUint32(0, true),
    packDensityBlit: view.getUint32(4, true) !== 0,
    packHexbinPitch: view.getUint32(8, true) !== 0,
  };
}

/** Figure-level XYCF chrome attach orchestration via `xyg_scene_xycf_figure_plan` (ABI 308). */
export function sceneXycfFigurePlan({
  showLegend = true,
  colorbarOk = true,
  polar = false,
} = {}) {
  const out = new Uint8Array(SCENE_XYCF_FIGURE_PLAN_BYTES);
  const ok = Number(xySceneXycfFigurePlan(
    showLegend ? 1 : 0,
    colorbarOk ? 1 : 0,
    polar ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xycf-figure-plan request");
  }
  return readSceneXycfFigurePlan(out);
}

/** Per-annotation XYAF attach dispatch via `xyg_scene_xyaf_annotation_dispatch_plan` (ABI 308). */
export function sceneXyafAnnotationDispatchPlan({
  kind = "",
  authoredWrap = false,
  layoutText = false,
} = {}) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const out = new Uint8Array(SCENE_XYAF_ANNOTATION_DISPATCH_PLAN_BYTES);
  const ok = Number(xySceneXyafAnnotationDispatchPlan(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    authoredWrap ? 1 : 0,
    layoutText ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-xyaf-annotation-dispatch-plan request");
  }
  return readSceneXyafAnnotationDispatchPlan(out);
}

/** Figure-level XYEF export orchestration via `xyg_scene_public_export_figure_plan` (ABI 308). */
export function scenePublicExportFigurePlan({
  polar = false,
  hasChromeStyles = false,
  hasTitleOptions = false,
} = {}) {
  const out = new Uint8Array(SCENE_PUBLIC_EXPORT_FIGURE_PLAN_BYTES);
  const ok = Number(xyScenePublicExportFigurePlan(
    polar ? 1 : 0,
    hasChromeStyles ? 1 : 0,
    hasTitleOptions ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-public-export-figure-plan request");
  }
  return readScenePublicExportFigurePlan(out);
}

/** Per-trace XYEF export dispatch via `xyg_scene_public_export_trace_dispatch_plan` (ABI 308). */
export function scenePublicExportTraceDispatchPlan({
  kind = "",
  polar = false,
  useDensity = false,
} = {}) {
  const kindBytes = new TextEncoder().encode(String(kind ?? ""));
  const out = new Uint8Array(SCENE_PUBLIC_EXPORT_TRACE_DISPATCH_PLAN_BYTES);
  const ok = Number(xyScenePublicExportTraceDispatchPlan(
    kindBytes.length ? u8Ptr(kindBytes) : 0,
    BigInt(kindBytes.length),
    polar ? 1 : 0,
    useDensity ? 1 : 0,
    u8Ptr(out),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid scene-public-export-trace-dispatch-plan request");
  }
  return readScenePublicExportTraceDispatchPlan(out);
}

const SCENE_POLAR_FIGURE_PLAN_BYTES = 8;
const SCENE_ENCODE_PRODUCT_ATTACH_PLAN_BYTES = 40;

function readScenePolarFigurePlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    polar: view.getUint32(0, true) !== 0,
    attachXypl: view.getUint32(4, true) !== 0,
  };
}

function readSceneEncodeProductAttachPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    polar: view.getUint32(0, true) !== 0,
    attachXypl: view.getUint32(4, true) !== 0,
    stepXytc: view.getUint32(8, true),
    stepXyta: view.getUint32(12, true),
    stepXynm: view.getUint32(16, true),
    stepXycl: view.getUint32(20, true),
    stepXyaf: view.getUint32(24, true),
    stepXycf: view.getUint32(28, true),
    stepXypl: view.getUint32(32, true),
    stepXyfs: view.getUint32(36, true),
  };
}

/** Figure-level XYPL polar attach orchestration via `xyg_scene_polar_figure_plan` (ABI 309). */
export function scenePolarFigurePlan({ polar = false } = {}) {
  const out = new Uint8Array(SCENE_POLAR_FIGURE_PLAN_BYTES);
  const ok = Number(xyScenePolarFigurePlan(polar ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-polar-figure-plan request");
  }
  return readScenePolarFigurePlan(out);
}

/** Encode-product attach orchestration via `xyg_scene_encode_product_attach_plan` (ABI 309). */
export function sceneEncodeProductAttachPlan({ polar = false } = {}) {
  const out = new Uint8Array(SCENE_ENCODE_PRODUCT_ATTACH_PLAN_BYTES);
  const ok = Number(xySceneEncodeProductAttachPlan(polar ? 1 : 0, u8Ptr(out)));
  if (ok !== 1) {
    throw new RangeError("invalid scene-encode-product-attach-plan request");
  }
  return readSceneEncodeProductAttachPlan(out);
}

export const DENSITY_REDUCTION_BIN2D = 0;
export const DENSITY_REDUCTION_PYRAMID_COUNT = 1;

/** Density reduction label kind via `xyg_density_reduction_kind` (ABI 265). */
export function densityReductionKind({ binning = "" } = {}) {
  const binningBytes = new TextEncoder().encode(String(binning ?? ""));
  const kind = Number(xyDensityReductionKind(
    binningBytes.length ? u8Ptr(binningBytes) : 0,
    BigInt(binningBytes.length),
  ));
  if (kind !== DENSITY_REDUCTION_BIN2D && kind !== DENSITY_REDUCTION_PYRAMID_COUNT) {
    throw new RangeError("invalid density-reduction-kind request");
  }
  return kind;
}

/** Wire reduction label from density binning (ABI 265). */
export function densityReductionWire({ binning = "" } = {}) {
  return densityReductionKind({ binning }) === DENSITY_REDUCTION_PYRAMID_COUNT
    ? "pyramid-count"
    : "bin2d";
}

/** Wire density overlay-omitted reason via `xyg_density_overlay_omitted_wire` (ABI 266). */
export function densityOverlayOmittedWire({ overlayOmitted = 0, pointOverlay = true } = {}) {
  const out = new Uint8Array(32);
  const written = Number(xyDensityOverlayOmittedWire(
    Number(overlayOmitted) >>> 0,
    pointOverlay ? 1 : 0,
    u8Ptr(out),
    BigInt(out.length),
  ));
  if (written === Number.MAX_SAFE_INTEGER) {
    throw new RangeError("invalid density-overlay-omitted-wire request");
  }
  if (written === 0) {
    return null;
  }
  return new TextDecoder().decode(out.subarray(0, written));
}

/** Grid-path visible/sel init via `xyg_density_grid_path_identity_state` (ABI 267). */
export function densityGridPathIdentityState({ gridPath = 0 } = {}) {
  const state = Number(xyDensityGridPathIdentityState(Number(gridPath)));
  if (state !== 0 && state !== 1) {
    throw new RangeError("invalid density-grid-path-identity-state request");
  }
  return state === 1;
}

/** Density binning coordinate endpoints via `xyg_density_bin_coord_endpoints` (ABI 263). */
export function densityBinCoordEndpoints({
  xLinear = true,
  yLinear = true,
  xr0 = 0,
  xr1 = 0,
  yr0 = 0,
  yr1 = 0,
  bx0 = 0,
  bx1 = 0,
  by0 = 0,
  by1 = 0,
} = {}) {
  const outXC0 = new Float64Array(1);
  const outXC1 = new Float64Array(1);
  const outYC0 = new Float64Array(1);
  const outYC1 = new Float64Array(1);
  const ok = Number(xyDensityBinCoordEndpoints(
    xLinear ? 1 : 0,
    yLinear ? 1 : 0,
    Number(xr0),
    Number(xr1),
    Number(yr0),
    Number(yr1),
    Number(bx0),
    Number(bx1),
    Number(by0),
    Number(by1),
    f64Ptr(outXC0),
    f64Ptr(outXC1),
    f64Ptr(outYC0),
    f64Ptr(outYC1),
  ));
  if (ok !== 1) {
    throw new RangeError("invalid density-bin-coord-endpoints request");
  }
  return {
    xC0: outXC0[0],
    xC1: outXC1[0],
    yC0: outYC0[0],
    yC1: outYC1[0],
  };
}

export const DENSITY_OVERLAY_NONE = 0;
export const DENSITY_OVERLAY_ROWS_EXCEED_U32 = 1;
export const DENSITY_OVERLAY_STATIC_RASTER = 2;

const DENSITY_EMIT_META_BYTES = 96;
const PAYLOAD_DENSITY_TRACE_EMIT_PLAN_BYTES = 152;

function readPayloadDensityTraceEmitPlan(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let off = 0;
  const colorMode = view.getInt32(off, true);
  off += 4;
  const categorical = view.getUint32(off, true) === 1;
  off += 4;
  const compactCategorical = view.getUint32(off, true) === 1;
  off += 4;
  const stratifiedCounts = view.getUint32(off, true) === 1;
  off += 4;
  const xC0 = view.getFloat64(off, true);
  off += 8;
  const xC1 = view.getFloat64(off, true);
  off += 8;
  const yC0 = view.getFloat64(off, true);
  off += 8;
  const yC1 = view.getFloat64(off, true);
  off += 8;
  const gridPath = view.getInt32(off, true);
  off += 4;
  const pyramidEligible = view.getUint32(off, true) === 1;
  off += 4;
  const pyramidAttempt = view.getUint32(off, true) === 1;
  off += 4;
  const pyramidNoRescan = view.getUint32(off, true) === 1;
  off += 4;
  const pyramidMaxUpsample = view.getUint32(off, true);
  off += 4;
  const pyramidTileUpsample = view.getUint32(off, true);
  off += 4;
  const wasmEligible = view.getUint32(off, true) === 1;
  off += 4;
  const needsPyramidSample = view.getUint32(off, true) === 1;
  off += 4;
  const overlayOmitted = view.getUint32(off, true);
  off += 4;
  const visibleIsNPoints = view.getUint32(off, true) === 1;
  off += 4;
  const useRawRangeBin2d = view.getUint32(off, true) === 1;
  off += 4;
  const attachTransition = view.getUint32(off, true) === 1;
  off += 4;
  const nMarks = Number(view.getBigUint64(off, true));
  off += 8;
  const visibleInitNPoints = view.getUint32(off, true) === 1;
  off += 4;
  const attachSample = view.getUint32(off, true) === 1;
  off += 4;
  const pyramidSampleStratified = view.getUint32(off, true) === 1;
  off += 4;
  const useChannelColormap = view.getUint32(off, true) === 1;
  off += 4;
  const shipWasmSource = view.getUint32(off, true) === 1;
  off += 4;
  const shipMeanColorRgba = view.getUint32(off, true) === 1;
  off += 4;
  const shipConstantColor = view.getUint32(off, true) === 1;
  off += 4;
  const shipCategoricalEntryColor = view.getUint32(off, true) === 1;
  off += 4;
  const meanColorAggregates = view.getUint32(off, true) === 1;
  off += 4;
  const overlayWireStaticRaster = view.getUint32(off, true) === 1;
  off += 4;
  const overlayWireRowsExceed = view.getUint32(off, true) === 1;
  off += 4;
  const channelsDroppedCompat = view.getUint32(off, true) === 1;
  return {
    colorMode,
    categorical,
    compactCategorical,
    stratifiedCounts,
    xC0,
    xC1,
    yC0,
    yC1,
    gridPath,
    pyramidEligible,
    pyramidAttempt,
    pyramidNoRescan,
    pyramidMaxUpsample,
    pyramidTileUpsample,
    wasmEligible,
    needsPyramidSample,
    overlayOmitted,
    visibleIsNPoints,
    useRawRangeBin2d,
    attachTransition,
    nMarks,
    visibleInitNPoints,
    attachSample,
    pyramidSampleStratified,
    useChannelColormap,
    shipWasmSource,
    shipMeanColorRgba,
    shipConstantColor,
    shipCategoricalEntryColor,
    meanColorAggregates,
    overlayWireStaticRaster,
    overlayWireRowsExceed,
    channelsDroppedCompat,
  };
}

function readDensityEmitMeta(buf) {
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  return {
    grid_path: view.getInt32(0, true),
    bin_window_x0: view.getFloat64(8, true),
    bin_window_x1: view.getFloat64(16, true),
    bin_window_y0: view.getFloat64(24, true),
    bin_window_y1: view.getFloat64(32, true),
    full_identity: view.getUint32(40, true) === 1,
    oversized: view.getUint32(44, true) === 1,
    pyramid_eligible: view.getUint32(48, true) === 1,
    pyramid_attempt: view.getUint32(52, true) === 1,
    pyramid_no_rescan: view.getUint32(56, true) === 1,
    pyramid_max_upsample: view.getUint32(60, true),
    pyramid_tile_upsample: view.getUint32(64, true),
    wasm_eligible: view.getUint32(68, true) === 1,
    needs_pyramid_sample: view.getUint32(72, true) === 1,
    overlay_omitted: view.getUint32(76, true),
    visible_is_n_points: view.getUint32(80, true) === 1,
    use_raw_range_bin2d: view.getUint32(84, true) === 1,
  };
}

export function densityFormatBinning({
  exact = false,
  level = 0,
  tiles = false,
  upsampled = false,
} = {}) {
  const out = new Uint8Array(64);
  const written = Number(xyDensityFormatBinning(
    exact ? 1 : 0,
    Number(level),
    tiles ? 1 : 0,
    upsampled ? 1 : 0,
    u8Ptr(out),
    BigInt(out.length),
  ));
  if (!Number.isFinite(written) || written === Number.MAX_SAFE_INTEGER) {
    throw new Error("xyg_density_format_binning failed");
  }
  return new TextDecoder().decode(out.subarray(0, written));
}

export function densityEmitPlan({
  cartesian = true,
  xLinear = true,
  yLinear = true,
  categorical = false,
  compactCategorical = false,
  stratifiedCounts = false,
  xHasNulls = false,
  yHasNulls = false,
  pointOverlay = true,
  gridFromPyramid = false,
  xMemmapped = false,
  yMemmapped = false,
  hasPyramidResource = false,
  forceBin2d = false,
  forcePyramid = false,
  colorMode = DENSITY_COLOR_MODE_NONE,
  xMin = 0,
  xMax = 1,
  yMin = 0,
  yMax = 1,
  xr0 = 0,
  xr1 = 1,
  yr0 = 0,
  yr1 = 1,
  xC0 = 0,
  xC1 = 1,
  yC0 = 0,
  yC1 = 1,
  nPoints = 0,
} = {}) {
  const out = new Uint8Array(DENSITY_EMIT_META_BYTES);
  const code = Number(xyDensityEmitMeta(
    cartesian ? 1 : 0,
    xLinear ? 1 : 0,
    yLinear ? 1 : 0,
    categorical ? 1 : 0,
    compactCategorical ? 1 : 0,
    stratifiedCounts ? 1 : 0,
    xHasNulls ? 1 : 0,
    yHasNulls ? 1 : 0,
    pointOverlay ? 1 : 0,
    gridFromPyramid ? 1 : 0,
    xMemmapped ? 1 : 0,
    yMemmapped ? 1 : 0,
    hasPyramidResource ? 1 : 0,
    forceBin2d ? 1 : 0,
    forcePyramid ? 1 : 0,
    Number(colorMode),
    Number(xMin),
    Number(xMax),
    Number(yMin),
    Number(yMax),
    Number(xr0),
    Number(xr1),
    Number(yr0),
    Number(yr1),
    Number(xC0),
    Number(xC1),
    Number(yC0),
    Number(yC1),
    BigInt(nPoints),
    u8Ptr(out),
  ));
  if (code !== 0) {
    throw new Error("xyg_density_emit_meta failed");
  }
  return readDensityEmitMeta(out);
}

export function densityWasmEligible({
  cartesian = true,
  xLinear = true,
  yLinear = true,
  colorMode = DENSITY_COLOR_MODE_NONE,
  xHasNulls = false,
  yHasNulls = false,
  nPoints = 0,
} = {}) {
  const code = Number(xyDensityWasmEligible(
    cartesian ? 1 : 0,
    xLinear ? 1 : 0,
    yLinear ? 1 : 0,
    Number(colorMode),
    xHasNulls ? 1 : 0,
    yHasNulls ? 1 : 0,
    BigInt(nPoints),
  ));
  if (code < 0) {
    throw new Error("xyg_density_wasm_eligible failed");
  }
  return code === 1;
}

/**
 * Whether a scatter should use the density tier (Python Trace.use_density).
 * Polar / forceDirect always ship direct; threshold is strict `>` (ABI 122).
 * Tri-state `forceDensity`: undefined auto (`-1`), true forced on (`1`), false forced off (`0`).
 */
export function shouldUseDensity(nPoints, {
  forceDensity,
  forceDirect = false,
  coords = "cartesian",
  perItemChannels = false,
} = {}) {
  let fd = -1;
  if (forceDensity === true) fd = 1;
  else if (forceDensity === false) fd = 0;
  return payloadTier({
    kind: 1,
    nPoints,
    polar: coords === "polar",
    forceDensity: fd,
    forceDirect,
    perItem: perItemChannels,
  }) === 2;
}

export function normalizeF32(data, lo, hi, { nanMode = "nan" } = {}) {
  const arr = asF64Array(data);
  const out = new Float32Array(arr.length);
  if (arr.length === 0) {
    return out;
  }
  const ok = xyNormalizeF32(
    f64Ptr(arr),
    BigInt(arr.length),
    Number(lo),
    Number(hi),
    nanMode === "nan" ? 1 : 0,
    f32Ptr(out),
  );
  if (ok !== 1) {
    throw new Error("xyg_normalize_f32 failed");
  }
  return out;
}

export class Column {
  constructor(values, { kind = "float" } = {}) {
    this.values = asF64Array(values);
    this.kind = kind;
    this._bounds = undefined;
    this._nullCount = undefined;
    this._shipOffset = null;
    this._stream = 0n;
  }

  get length() {
    return this.values.length;
  }

  get min() {
    return this.bounds()[0];
  }

  get max() {
    return this.bounds()[1];
  }

  get nullCount() {
    if (this._nullCount === undefined) {
      let n = 0;
      for (let i = 0; i < this.values.length; i += 1) {
        if (!Number.isFinite(this.values[i])) {
          n += 1;
        }
      }
      this._nullCount = n;
    }
    return this._nullCount;
  }

  bounds() {
    if (this._bounds === undefined) {
      const mm = minMax(this.values);
      this._bounds = mm == null ? [Number.NaN, Number.NaN] : mm;
    }
    return this._bounds;
  }

  suggestOffset() {
    const [lo, hi] = this.bounds();
    if (Number.isNaN(lo) || Number.isNaN(hi)) {
      return 0.0;
    }
    const mid = (lo + hi) / 2.0;
    const prev = this._shipOffset;
    if (prev != null && Number.isFinite(prev)) {
      const span = hi - lo;
      if (Math.max(Math.abs(lo - prev), Math.abs(hi - prev)) <= (span > 0 ? span : 0.0)) {
        return prev;
      }
    }
    this._shipOffset = mid;
    return mid;
  }

  /** Grow this column through `xyg_stream_*`. The TypedArray is a snapshot. */
  append(data) {
    const tail = asF64Array(data);
    if (tail.length === 0) {
      return;
    }
    if (this._stream === 0n) {
      this._stream = xyStreamNew(f64Ptr(this.values), BigInt(this.values.length));
      if (this._stream === 0n) {
        throw new Error("xyg_stream_new failed");
      }
    }
    const ok = xyStreamAppend(this._stream, f64Ptr(tail), BigInt(tail.length));
    if (ok !== 1) {
      throw new Error("stale or busy stream handle");
    }
    if (xyStreamSeal(this._stream) !== 1) {
      throw new Error("stale or busy stream handle");
    }
    const n = Number(xyStreamLen(this._stream));
    const out = new Float64Array(n);
    if (xyStreamCopy(this._stream, f64Ptr(out), BigInt(n)) !== 1) {
      throw new Error("stale stream handle");
    }
    this.values = out;
    this._bounds = undefined;
    this._nullCount = undefined;
  }

  get capacityValues() {
    if (this._stream === 0n) {
      return this.values.length;
    }
    return Number(xyStreamCapacity(this._stream));
  }

  freeStream() {
    if (this._stream !== 0n) {
      xyStreamFree(this._stream);
      this._stream = 0n;
    }
  }
}

export {
  xyStreamNew,
  xyStreamAppend,
  xyStreamSeal,
  xyStreamFree,
  xyStreamLen,
  xyStreamCapacity,
  xyStreamCopy,
};

export function f64Ptr(view) {
  return pointer(view, "double *");
}

export function f32Ptr(view) {
  return pointer(view, "float *");
}

export function u32Ptr(view) {
  return pointer(view, "uint32_t *");
}

export function u64Ptr(view) {
  return pointer(view, "uint64_t *");
}

export function u8Ptr(view) {
  return pointer(view, "uint8_t *");
}
