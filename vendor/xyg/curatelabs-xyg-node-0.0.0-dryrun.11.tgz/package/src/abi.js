/**
 * Low-level Node bindings over the shared `xyg_core` C ABI.
 * Composition helpers live in graph.js / figure.js / sankey.js.
 */
export {
  encodeF32,
  encodeF32Values,
  m4Points,
  m4Indices,
  minMax,
  isSorted,
  histogramUniform,
  normalizeF32,
  Column,
  PROTOCOL_VERSION,
} from "./encode.js";

import koffi from "koffi";

import {
  nativeLibraryPath,
  pointer,
  xyAbiVersion,
  xyGraphBuildCsr,
  xyGraphBuildRender,
  xyGraphEdgeRouteSegments,
  xyGraphEdgeRouteEnds,
  xyGraphCompoundBounds,
  xyGraphCompoundTransition,
  xyGraphCompoundScene,
  xyGraphLabelAccept,
  xyGraphLabelPlan,
  xyGraphCompoundCollapse,
  xyGraphCompoundFrames,
  xyGraphOrdinalColors,
  xyGraphComposedScene,
  xyGraphHomeDomain,
  xyGraphDivergingDomain,
  xyGraphSemanticLegendText,
  xyGraphSemanticStyleResolve,
  xyGraphSemanticPaintLayers,
  xyGraphSemanticLegend,
  xyGraphVisualStateResolve,
  xyGraphClusterAggregate,
  xyGraphForceCreate,
  xyGraphForceCreateCose,
  xyGraphForceDestroy,
  xyGraphForceTick,
  xyGraphLayout,
  xyGraphLodDecision,
  xyGraphProjectionCopyEdgeIds,
  xyGraphProjectionCopyEndpoints,
  xyGraphProjectionCopyNodeIds,
  xyGraphProjectionCopyParents,
  xyGraphProjectionCounts,
  xyGraphProjectionCreate,
  xyGraphProjectionDestroy,
  xyGraphSampleEdges,
  xySankeyLayout,
  xyTemporalColumnCopy,
  xyTemporalColumnCreate,
  xyTemporalColumnDestroy,
  xyTemporalColumnMeta,
  xyTemporalColumnTimezone,
  xyTemporalEventsInRange,
  xyTemporalIntervalIndexCreate,
  xyTemporalIntervalIndexDestroy,
  xyTemporalIntervalIndexLen,
  xyTemporalIntervalVisibilityAt,
  xyGeoColumnCrs,
  xyGeoColumnFree,
  xyGeoColumnGeometry,
  xyGeoColumnLen,
  xyGeoColumnNew,
  xyGeoColumnVertexCount,
  xyTemporalControllerApplyEvent,
  xyTemporalControllerCreate,
  xyTemporalControllerDestroy,
  xyTemporalControllerDispose,
  xyTemporalControllerPause,
  xyTemporalControllerPlay,
  xyTemporalControllerPollEvent,
  xyTemporalControllerSetCursor,
  xyTemporalControllerSetDirection,
  xyTemporalControllerSetLoop,
  xyTemporalControllerSetRange,
  xyTemporalControllerSetRateMilli,
  xyTemporalControllerSetReducedMotion,
  xyTemporalControllerSetSelection,
  xyTemporalControllerState,
  xyTemporalControllerStep,
  xyTemporalControllerTick,
  xyTemporalCoordinateDeliver,
  xyTemporalSelectionLimit,
  xyTemporalGraphCancel,
  xyTemporalGraphCreate,
  xyTemporalGraphDestroy,
  xyTemporalGraphFrame,
  xyTemporalGraphRequiredBudget,
  xyTemporalGraphSetFocus,
  xyTemporalGraphSetPinned,
  xyTemporalGraphSetSelection,
  xyTemporalGraphSnapshotCopy,
  xyTemporalGraphSnapshotMeta,
} from "./native.js";

export { nativeLibraryPath };

const U64_MAX = (1n << 64n) - 1n;
const I64_MIN = -(1n << 63n);
const I64_MAX = (1n << 63n) - 1n;

export const GRAPH_LAYOUT_PRESET = 0;
export const GRAPH_LAYOUT_GRID = 1;
export const GRAPH_LAYOUT_CIRCLE = 2;
export const GRAPH_LAYOUT_FORCE = 3;
export const GRAPH_LAYOUT_BREADTHFIRST = 4;
export const GRAPH_LAYOUT_AUTO = 5;
export const GRAPH_LAYOUT_RADIAL = 6;
export const GRAPH_LAYOUT_CONCENTRIC = 7;
export const GRAPH_LAYOUT_HIERARCHICAL = 8;
export const GRAPH_LAYOUT_BARNES_HUT = 9;
export const GRAPH_LAYOUT_SPRING = 10;
export const GRAPH_LAYOUT_FORCEATLAS2 = 11;
export const GRAPH_LAYOUT_KAMADA_KAWAI = 12;
export const GRAPH_LAYOUT_YIFANHU = 13;
export const GRAPH_LAYOUT_LINLOG = 14;
export const GRAPH_LAYOUT_STRESS = 15;
export const GRAPH_LAYOUT_COSE = 16;

export const GRAPH_LAYOUT_IDS = Object.freeze({
  preset: GRAPH_LAYOUT_PRESET,
  grid: GRAPH_LAYOUT_GRID,
  circle: GRAPH_LAYOUT_CIRCLE,
  force: GRAPH_LAYOUT_FORCE,
  fr: GRAPH_LAYOUT_FORCE,
  fruchterman_reingold: GRAPH_LAYOUT_FORCE,
  breadthfirst: GRAPH_LAYOUT_BREADTHFIRST,
  dagre: GRAPH_LAYOUT_HIERARCHICAL,
  hierarchical: GRAPH_LAYOUT_HIERARCHICAL,
  auto: GRAPH_LAYOUT_AUTO,
  radial: GRAPH_LAYOUT_RADIAL,
  concentric: GRAPH_LAYOUT_CONCENTRIC,
  barnes_hut: GRAPH_LAYOUT_BARNES_HUT,
  spring: GRAPH_LAYOUT_SPRING,
  forceatlas2: GRAPH_LAYOUT_FORCEATLAS2,
  fa2: GRAPH_LAYOUT_FORCEATLAS2,
  kamada_kawai: GRAPH_LAYOUT_KAMADA_KAWAI,
  kk: GRAPH_LAYOUT_KAMADA_KAWAI,
  yifanhu: GRAPH_LAYOUT_YIFANHU,
  linlog: GRAPH_LAYOUT_LINLOG,
  stress: GRAPH_LAYOUT_STRESS,
  cose: GRAPH_LAYOUT_COSE,
});

/** Progressive force families that share xyg_graph_force_create/tick. */
export const GRAPH_PROGRESSIVE_FORCE = Object.freeze(
  new Set([
    GRAPH_LAYOUT_FORCE,
    GRAPH_LAYOUT_BARNES_HUT,
    GRAPH_LAYOUT_SPRING,
    GRAPH_LAYOUT_FORCEATLAS2,
    GRAPH_LAYOUT_YIFANHU,
    GRAPH_LAYOUT_LINLOG,
    GRAPH_LAYOUT_KAMADA_KAWAI,
    GRAPH_LAYOUT_STRESS,
    GRAPH_LAYOUT_COSE,
  ]),
);

export const SANKEY_ALIGN_IDS = Object.freeze({
  justify: 0,
  left: 1,
  right: 2,
  center: 3,
});

export class SankeyLayoutError extends Error {
  constructor(code, errNodes, message) {
    super(message);
    this.name = "SankeyLayoutError";
    this.code = code;
    this.errNodes = errNodes;
  }
}

// Packed to match `XygGraphProjectionDescriptor` in crates/xyg-core. The generated
// ABI exposes create as `const void *`, so the host owns this layout.
const GraphProjectionDescriptor = koffi.struct("XygGraphProjectionDescriptor", {
  node_ids: "const void *",
  node_count: "uint64_t",
  edge_ids: "const void *",
  edge_count: "uint64_t",
  source_ids: "const void *",
  target_ids: "const void *",
  parent_ids: "const void *",
  parent_validity: "const void *",
  directed: "uint32_t",
  reserved: "uint32_t",
});

const GraphCompoundSceneDescriptor = koffi.struct("XygGraphCompoundSceneDescriptor", {
  version: "uint32_t", theme: "uint32_t", width: "double", height: "double",
  node_count: "uint64_t", edge_count: "uint64_t", title: "const void *", title_len: "uint64_t",
  x: "const void *", y: "const void *", node_classes: "const void *", node_epistemic: "const void *",
  node_statuses: "const void *", node_metric: "const void *", node_flags: "const void *",
  node_label_lengths: "const void *", sources: "const void *", targets: "const void *",
  edge_classes: "const void *", edge_epistemic: "const void *", edge_statuses: "const void *",
  edge_metric: "const void *", edge_flags: "const void *", edge_label_lengths: "const void *",
  label_payload: "const void *", label_payload_len: "uint64_t", parents: "const void *",
  parent_validity: "const void *", collapsed: "const void *", reserved: "uint64_t",
});

// Mirror of Rust `XygComposedGraphSceneDescriptor` (#34).
const ComposedGraphSceneDescriptor = koffi.struct("XygComposedGraphSceneDescriptor", {
  version: "uint32_t", reserved0: "uint32_t", base: "const void *", base_len: "uint64_t",
  node_count: "uint64_t", x: "const void *", y: "const void *", fill: "const void *",
  stroke: "const void *", stroke_width: "const void *", diameter: "const void *",
  symbol: "const void *", opacity: "const void *", halo: "const void *",
  halo_diameter: "const void *", node_label_plan: "const void *",
  node_label_lengths: "const void *", frames: "const void *", segment_count: "uint64_t",
  x0: "const void *", y0: "const void *", x1: "const void *", y1: "const void *",
  segment_rgba: "const void *", segment_width: "const void *", segment_opacity: "const void *",
  segment_halo: "const void *", segment_halo_width: "const void *", segment_body: "const void *",
  segment_body_width: "const void *", segment_dash: "const void *", edge_ends: "const void *",
  segment_label_plan: "const void *", segment_label_lengths: "const void *",
  label_payload: "const void *", label_payload_len: "uint64_t", legend_count: "uint64_t",
  legend_title: "const void *", legend_title_len: "uint64_t", legend_rgba: "const void *",
  legend_symbol: "const void *", legend_label_lengths: "const void *",
  legend_payload: "const void *", legend_payload_len: "uint64_t", legend_loc: "const void *",
  legend_loc_len: "uint64_t", text_rgba: "const void *", reserved: "uint64_t",
});

// Mirror of Rust `XygGraphHomeLayout` (#910).
const GraphHomeLayout = koffi.struct("XygGraphHomeLayout", {
  version: "uint32_t", reserved0: "uint32_t", viewport_width: "double", viewport_height: "double",
  padding: "const void *", title: "const void *", title_len: "uint64_t",
  base_x_lo: "double", base_x_hi: "double", base_y_lo: "double", base_y_hi: "double",
});

const CoseDescriptor = koffi.struct("XygCoseDescriptor", {
  in_x: "const void *",
  in_y: "const void *",
  pinned: "const void *",
  parents: "const void *",
  ideal_edge_length: "double",
  repulsion_strength: "double",
  gravity_strength: "double",
  cooling_factor: "double",
  overlap_padding: "double",
  component_spacing: "double",
  bounds: "const void *",
  has_bounds: "uint32_t",
  reserved: "uint32_t",
});

const TemporalColumnDescriptor = koffi.struct("XygTemporalColumnDescriptor", {
  values: "const void *",
  validity: "const void *",
  len: "uint64_t",
  unit: "uint32_t",
  timezone: "const void *",
  timezone_len: "uint32_t",
  naive: "uint32_t",
  disambiguation: "uint32_t",
  dst_status: "const void *",
  offset_seconds: "const void *",
  fold_later_offset_seconds: "const void *",
  reserved: "uint32_t",
});

const TemporalIntervalDescriptor = koffi.struct("XygTemporalIntervalDescriptor", {
  starts: "const void *",
  start_valid: "const void *",
  ends: "const void *",
  end_valid: "const void *",
  len: "uint64_t",
  reserved: "uint32_t",
});

const TemporalControllerDescriptor = koffi.struct("XygTemporalControllerDescriptor", {
  instance_id: "uint64_t",
  group_id: "uint64_t",
  domain_start: "int64_t",
  domain_end: "int64_t",
  cursor: "int64_t",
  window: "int64_t",
  step: "int64_t",
  direction: "int32_t",
  rate_milli: "uint32_t",
  loop_enabled: "uint32_t",
  reduced_motion: "uint32_t",
  reserved: "uint32_t",
});

const TemporalGraphDescriptor = koffi.struct("XygTemporalGraphDescriptor", {
  projection_handle: "uint64_t",
  node_valid_from: "uint64_t",
  node_valid_to: "uint64_t",
  node_event_at: "uint64_t",
  edge_valid_from: "uint64_t",
  edge_valid_to: "uint64_t",
  edge_event_at: "uint64_t",
  reserved: "uint64_t",
});

const TemporalGraphSnapshotMeta = koffi.struct("XygTemporalGraphSnapshotMeta", {
  revision: "uint64_t",
  cursor_micros: "int64_t",
  range_start_micros: "int64_t",
  range_end_micros: "int64_t",
  node_count: "uint64_t",
  edge_count: "uint64_t",
  visible_node_count: "uint64_t",
  visible_edge_count: "uint64_t",
  selected_visible_node_count: "uint64_t",
  selected_visible_edge_count: "uint64_t",
  pinned_visible_node_count: "uint64_t",
  selected_node_count: "uint64_t",
  selected_edge_count: "uint64_t",
  pinned_node_count: "uint64_t",
  focused_visible_kind: "uint32_t",
  focused_kind: "uint32_t",
  focused_visible_id: koffi.array("uint8_t", 16),
  focused_id: koffi.array("uint8_t", 16),
});

const TemporalGraphSnapshotBuffers = koffi.struct("XygTemporalGraphSnapshotBuffers", {
  node_visibility: "uint8_t *",
  node_capacity: "uint64_t",
  edge_visibility: "uint8_t *",
  edge_capacity: "uint64_t",
  visible_node_ids: "uint8_t *",
  visible_node_capacity: "uint64_t",
  visible_edge_ids: "uint8_t *",
  visible_edge_capacity: "uint64_t",
  selected_visible_node_ids: "uint8_t *",
  selected_visible_node_capacity: "uint64_t",
  selected_visible_edge_ids: "uint8_t *",
  selected_visible_edge_capacity: "uint64_t",
  pinned_visible_node_ids: "uint8_t *",
  pinned_visible_node_capacity: "uint64_t",
  selected_node_ids: "uint8_t *",
  selected_node_capacity: "uint64_t",
  selected_edge_ids: "uint8_t *",
  selected_edge_capacity: "uint64_t",
  pinned_node_ids: "uint8_t *",
  pinned_node_capacity: "uint64_t",
});

export const TEMPORAL_PRECISION = Object.freeze({
  second: 0,
  millisecond: 1,
  microsecond: 2,
  nanosecond: 3,
});

export const TEMPORAL_DISAMBIGUATION = Object.freeze({
  reject: 0,
  preferEarlier: 1,
  preferLater: 2,
});

export const TEMPORAL_DST = Object.freeze({
  unique: 0,
  gap: 1,
  fold: 2,
});

export const TEMPORAL_DIRECTION = Object.freeze({
  reverse: -1,
  forward: 1,
});

const TEMPORAL_MESSAGES = Object.freeze({
  [-1]: "temporal arguments are incomplete or inconsistent",
  [-2]: "temporal input exceeds native capacity",
  [-3]: "temporal integer conversion overflowed",
  [-4]: "timezone is required",
  [-5]: "local time falls in a DST gap",
  [-6]: "local time is ambiguous at a DST fold",
  [-7]: "temporal interval is reversed",
  [-8]: "temporal handle is stale or closed",
  [-9]: "temporal output buffer is too small",
  [-10]: "temporal work was cancelled",
  [-11]: "temporal work exceeds the supplied budget",
  [-12]: "temporal precision unit is unsupported",
  [-13]: "temporal resource is disposed",
  [-14]: "temporal revision is stale",
  [-15]: "temporal coordination rejected a self-echo",
});

export class TemporalNativeError extends Error {
  constructor(code, message) {
    super(message ?? TEMPORAL_MESSAGES[code] ?? `native temporal failed with status ${code}`);
    this.name = "TemporalNativeError";
    this.nativeCode = code;
  }
}

export const TemporalGraphError = TemporalNativeError;

export const GEO_GEOMETRY = Object.freeze({
  point: 1,
  linestring: 2,
  polygon: 3,
  multipoint: 4,
  multilinestring: 5,
  multipolygon: 6,
});

export const GEO_CRS = Object.freeze({
  epsg4326: 4326,
  epsg3857: 3857,
});

const GEO_MESSAGES = Object.freeze({
  [-1]: "geographic descriptor is incomplete or inconsistent",
  [-2]: "CRS is not in the certified EPSG:4326 / EPSG:3857 profile",
  [-3]: "geometry kind does not match the supplied offset planes",
  [-4]: "offset planes are malformed or disagree with vertex counts",
  [-5]: "nested geometry parts cannot be null",
  [-6]: "coordinate is non-finite",
  [-7]: "coordinate is outside the declared CRS bounds",
  [-8]: "polygon ring is too short or not closed",
  [-9]: "geometry exceeds feature, vertex, or byte limits",
  [-10]: "geographic column handle is stale or freed",
});

export class GeoNativeError extends Error {
  constructor(code, message) {
    super(message ?? GEO_MESSAGES[code] ?? `native geo failed with status ${code}`);
    this.name = "GeoNativeError";
    this.nativeCode = code;
  }
}

export function abiVersion() {
  return xyAbiVersion();
}

/** Validate and materialize canonical GraphForge identity through Rust. */
export function graphProjectionCreate({
  nodeIds,
  edgeIds,
  sourceIds,
  targetIds,
  parentIds = null,
  parentValidity = null,
  directed = true,
}) {
  nodeIds = asUuidBytes(nodeIds, "nodeIds");
  edgeIds = asUuidBytes(edgeIds, "edgeIds");
  sourceIds = asUuidBytes(sourceIds, "sourceIds");
  targetIds = asUuidBytes(targetIds, "targetIds");
  const nodeCount = nodeIds.byteLength / 16;
  const edgeCount = edgeIds.byteLength / 16;
  if (sourceIds.byteLength !== edgeIds.byteLength || targetIds.byteLength !== edgeIds.byteLength) {
    throw new RangeError("edgeIds, sourceIds, and targetIds must contain equal UUID counts");
  }
  if ((parentIds == null) !== (parentValidity == null)) {
    throw new TypeError("parentIds and parentValidity must be provided together");
  }
  if (parentIds != null) {
    parentIds = asUuidBytes(parentIds, "parentIds");
    parentValidity = asU8Array(parentValidity, "parentValidity");
    if (parentIds.byteLength !== nodeIds.byteLength || parentValidity.byteLength !== nodeCount) {
      throw new RangeError("parent buffers must match the node UUID count");
    }
  }
  const outHandle = new BigUint64Array(1);
  const encoded = Buffer.alloc(koffi.sizeof(GraphProjectionDescriptor));
  koffi.encode(encoded, GraphProjectionDescriptor, {
    node_ids: pointer(nodeIds, "uint8_t *"),
    node_count: BigInt(nodeCount),
    edge_ids: pointer(edgeIds, "uint8_t *"),
    edge_count: BigInt(edgeCount),
    source_ids: pointer(sourceIds, "uint8_t *"),
    target_ids: pointer(targetIds, "uint8_t *"),
    parent_ids: pointer(parentIds, "uint8_t *"),
    parent_validity: pointer(parentValidity, "uint8_t *"),
    directed: directed ? 1 : 0,
    reserved: 0,
  });
  const code = xyGraphProjectionCreate(koffi.as(encoded, "const void *"), u64Ptr(outHandle));
  if (code !== 0 || outHandle[0] === 0n) {
    const error = new Error(`xyg_graph_projection_create failed with code ${code}`);
    error.nativeCode = code;
    throw error;
  }
  return outHandle[0];
}

export function graphProjectionRead(handle) {
  const nodeCount = new BigUint64Array(1);
  const edgeCount = new BigUint64Array(1);
  const directed = new Uint32Array(1);
  let code = xyGraphProjectionCounts(
    toU64(handle, "handle"), u64Ptr(nodeCount), u64Ptr(edgeCount), u32Ptr(directed),
  );
  if (code !== 0) throw new Error(`xyg_graph_projection_counts failed with code ${code}`);
  const nodes = toLength(nodeCount[0], "nodeCount");
  const edges = toLength(edgeCount[0], "edgeCount");
  const nodeIds = new Uint8Array(nodes * 16);
  const edgeIds = new Uint8Array(edges * 16);
  const sources = new BigUint64Array(edges);
  const targets = new BigUint64Array(edges);
  const parents = new BigUint64Array(nodes);
  const parentValidity = new Uint8Array(nodes);
  code = xyGraphProjectionCopyNodeIds(toU64(handle, "handle"), pointer(nodeIds, "uint8_t *"), BigInt(nodes));
  if (code === 0) code = xyGraphProjectionCopyEdgeIds(toU64(handle, "handle"), pointer(edgeIds, "uint8_t *"), BigInt(edges));
  if (code === 0) code = xyGraphProjectionCopyEndpoints(toU64(handle, "handle"), u64Ptr(sources), u64Ptr(targets), BigInt(edges));
  if (code === 0) code = xyGraphProjectionCopyParents(toU64(handle, "handle"), u64Ptr(parents), pointer(parentValidity, "uint8_t *"), BigInt(nodes));
  if (code !== 0) throw new Error(`xyg_graph_projection_copy failed with code ${code}`);
  return { nodeIds, edgeIds, sources, targets, parents, parentValidity, directed: directed[0] !== 0 };
}

export function graphProjectionDestroy(handle) {
  return xyGraphProjectionDestroy(toU64(handle, "handle")) === 0;
}

/** Create a Rust-owned temporal column (UTC microseconds). */
export function temporalColumnCreate({
  values,
  validity,
  timezone,
  unit = TEMPORAL_PRECISION.microsecond,
  naive = false,
  disambiguation = TEMPORAL_DISAMBIGUATION.reject,
  dstStatus = null,
  offsetSeconds = null,
  foldLaterOffsetSeconds = null,
}) {
  if (typeof timezone !== "string" || timezone.length === 0) {
    throw new TypeError("timezone is required");
  }
  const valueArray = asI64Array(values, "values");
  const validityArray = asU8Array(validity, "validity");
  if (valueArray.length !== validityArray.length) {
    throw new RangeError("values and validity must have equal length");
  }
  let dst = null;
  let offsets = null;
  let foldLater = null;
  if (naive) {
    if (dstStatus == null || offsetSeconds == null || foldLaterOffsetSeconds == null) {
      throw new TypeError("naive ingest requires dstStatus and offset planes");
    }
    dst = asU8Array(dstStatus, "dstStatus");
    offsets = asI32Array(offsetSeconds, "offsetSeconds");
    foldLater = asI32Array(foldLaterOffsetSeconds, "foldLaterOffsetSeconds");
    if (
      dst.length !== valueArray.length
      || offsets.length !== valueArray.length
      || foldLater.length !== valueArray.length
    ) {
      throw new RangeError("naive DST planes must match values length");
    }
  }
  const tz = Buffer.from(timezone, "utf8");
  const outHandle = new BigUint64Array(1);
  const encoded = Buffer.alloc(koffi.sizeof(TemporalColumnDescriptor));
  koffi.encode(encoded, TemporalColumnDescriptor, {
    values: pointer(valueArray, "int64_t *"),
    validity: pointer(validityArray, "uint8_t *"),
    len: BigInt(valueArray.length),
    unit,
    timezone: pointer(tz, "uint8_t *"),
    timezone_len: tz.byteLength,
    naive: naive ? 1 : 0,
    disambiguation,
    dst_status: pointer(dst, "uint8_t *"),
    offset_seconds: pointer(offsets, "int32_t *"),
    fold_later_offset_seconds: pointer(foldLater, "int32_t *"),
    reserved: 0,
  });
  const code = xyTemporalColumnCreate(koffi.as(encoded, "const void *"), u64Ptr(outHandle));
  if (code !== 0 || outHandle[0] === 0n) {
    throw new TemporalNativeError(code);
  }
  return outHandle[0];
}

export function temporalColumnRead(handle) {
  const length = new BigUint64Array(1);
  const precision = new Uint32Array(1);
  const tzLen = new Uint32Array(1);
  let code = xyTemporalColumnMeta(
    toU64(handle, "handle"),
    u64Ptr(length),
    u32Ptr(precision),
    u32Ptr(tzLen),
  );
  if (code !== 0) throw new TemporalNativeError(code);
  const n = toLength(length[0], "length");
  const values = new BigInt64Array(n);
  const validity = new Uint8Array(n);
  code = xyTemporalColumnCopy(
    toU64(handle, "handle"),
    pointer(values, "int64_t *"),
    pointer(validity, "uint8_t *"),
    BigInt(n),
  );
  if (code !== 0) throw new TemporalNativeError(code);
  const tz = Buffer.alloc(tzLen[0]);
  code = xyTemporalColumnTimezone(
    toU64(handle, "handle"),
    pointer(tz, "uint8_t *"),
    tzLen[0],
  );
  if (code !== 0) throw new TemporalNativeError(code);
  return {
    values,
    validity,
    timezone: tz.toString("utf8"),
    precision: precision[0],
  };
}

export function temporalColumnDestroy(handle) {
  const code = xyTemporalColumnDestroy(toU64(handle, "handle"));
  if (code !== 0) throw new TemporalNativeError(code);
  return true;
}

/** Create a Rust-owned geographic column from a typed host descriptor (#47). */
export function geoColumnNew({
  geometry,
  crs,
  xy,
  validity,
  featureIds = null,
  offsets0 = null,
  offsets1 = null,
  offsets2 = null,
}) {
  const coords = asF64Array(xy, "xy");
  const valid = asU8Array(validity, "validity");
  if (coords.length % 2 !== 0) {
    throw new RangeError("xy must be interleaved [x0,y0,…]");
  }
  const ids = featureIds == null ? null : asU64Array(featureIds, "featureIds");
  if (ids != null && ids.length !== valid.length) {
    throw new RangeError("featureIds must match validity length");
  }
  const o0 = offsets0 == null ? new Uint32Array(0) : asU32Array(offsets0, "offsets0");
  const o1 = offsets1 == null ? new Uint32Array(0) : asU32Array(offsets1, "offsets1");
  const o2 = offsets2 == null ? new Uint32Array(0) : asU32Array(offsets2, "offsets2");
  const err = new Int32Array(1);
  const handle = xyGeoColumnNew(
    geometry >>> 0,
    crs >>> 0,
    pointer(coords, "double *"),
    BigInt(coords.length),
    pointer(valid, "uint8_t *"),
    BigInt(valid.length),
    pointer(ids, "uint64_t *"),
    pointer(o0, "uint32_t *"),
    BigInt(o0.length),
    pointer(o1, "uint32_t *"),
    BigInt(o1.length),
    pointer(o2, "uint32_t *"),
    BigInt(o2.length),
    i32Ptr(err),
  );
  if (handle === 0n || handle === 0) {
    throw new GeoNativeError(err[0] || -1);
  }
  return handle;
}

export function geoColumnMeta(handle) {
  const h = toU64(handle, "handle");
  const length = Number(xyGeoColumnLen(h));
  const vertices = Number(xyGeoColumnVertexCount(h));
  if (!Number.isFinite(length) || !Number.isFinite(vertices) || length < 0 || vertices < 0) {
    throw new GeoNativeError(-10);
  }
  // Rust returns usize::MAX on stale handles; treat huge sentinels as errors.
  if (length === Number.MAX_SAFE_INTEGER || vertices === Number.MAX_SAFE_INTEGER) {
    throw new GeoNativeError(-10);
  }
  const geometry = xyGeoColumnGeometry(h) >>> 0;
  const crs = xyGeoColumnCrs(h) >>> 0;
  if (geometry === 0 || crs === 0) throw new GeoNativeError(-10);
  return { length, vertexCount: vertices, geometry, crs };
}

export function geoColumnFree(handle) {
  return xyGeoColumnFree(toU64(handle, "handle")) === 1;
}

export function temporalIntervalIndexCreate({ starts, startValid, ends, endValid }) {
  const startValues = asI64Array(starts, "starts");
  const startBits = asU8Array(startValid, "startValid");
  const endValues = asI64Array(ends, "ends");
  const endBits = asU8Array(endValid, "endValid");
  const n = startValues.length;
  if (startBits.length !== n || endValues.length !== n || endBits.length !== n) {
    throw new RangeError("interval endpoint arrays must have equal length");
  }
  const outHandle = new BigUint64Array(1);
  const encoded = Buffer.alloc(koffi.sizeof(TemporalIntervalDescriptor));
  koffi.encode(encoded, TemporalIntervalDescriptor, {
    starts: pointer(startValues, "int64_t *"),
    start_valid: pointer(startBits, "uint8_t *"),
    ends: pointer(endValues, "int64_t *"),
    end_valid: pointer(endBits, "uint8_t *"),
    len: BigInt(n),
    reserved: 0,
  });
  const code = xyTemporalIntervalIndexCreate(koffi.as(encoded, "const void *"), u64Ptr(outHandle));
  if (code !== 0 || outHandle[0] === 0n) {
    throw new TemporalNativeError(code);
  }
  return outHandle[0];
}

export function temporalIntervalVisibilityAt(handle, instantMicros, opts = {}) {
  const length = new BigUint64Array(1);
  let code = xyTemporalIntervalIndexLen(toU64(handle, "handle"), u64Ptr(length));
  if (code !== 0) throw new TemporalNativeError(code);
  const n = toLength(length[0], "length");
  const budget = opts.budget == null ? n : toLength(opts.budget, "budget");
  if (budget < n) throw new RangeError("budget must be at least index length");
  const out = new Uint8Array(n);
  const cancel = new Uint32Array([opts.cancelFlag ? 1 : 0]);
  code = xyTemporalIntervalVisibilityAt(
    toU64(handle, "handle"),
    BigInt(instantMicros),
    pointer(out, "uint8_t *"),
    BigInt(n),
    BigInt(budget),
    u32Ptr(cancel),
  );
  if (code !== 0) throw new TemporalNativeError(code);
  return out;
}

export function temporalIntervalIndexDestroy(handle) {
  const code = xyTemporalIntervalIndexDestroy(toU64(handle, "handle"));
  if (code !== 0) throw new TemporalNativeError(code);
  return true;
}

export function temporalEventsInRange({
  eventMicros,
  eventValid,
  rangeStart = null,
  rangeEnd = null,
  budget = null,
  cancelFlag = 0,
}) {
  const events = asI64Array(eventMicros, "eventMicros");
  const valid = asU8Array(eventValid, "eventValid");
  if (events.length !== valid.length) {
    throw new RangeError("eventMicros and eventValid must have equal length");
  }
  const n = events.length;
  const rowBudget = budget == null ? n : toLength(budget, "budget");
  if (rowBudget < n) throw new RangeError("budget must be at least event length");
  const out = new Uint8Array(n);
  const cancel = new Uint32Array([cancelFlag ? 1 : 0]);
  const code = xyTemporalEventsInRange(
    pointer(events, "int64_t *"),
    pointer(valid, "uint8_t *"),
    BigInt(n),
    BigInt(rangeStart == null ? 0 : rangeStart),
    rangeStart == null ? 0 : 1,
    BigInt(rangeEnd == null ? 0 : rangeEnd),
    rangeEnd == null ? 0 : 1,
    pointer(out, "uint8_t *"),
    BigInt(n),
    BigInt(rowBudget),
    u32Ptr(cancel),
  );
  if (code !== 0) throw new TemporalNativeError(code);
  return out;
}

function temporalStatus(code) {
  if (code !== 0) throw new TemporalNativeError(code);
}

function asTemporalSelection(value, name) {
  if (value == null || typeof value[Symbol.iterator] !== "function") {
    throw new TypeError(`${name} must be an iterable of u64 stable IDs`);
  }
  const limit = Number(xyTemporalSelectionLimit());
  if (value instanceof BigUint64Array) {
    if (value.length > limit) throw new RangeError(`${name} may contain at most ${limit} IDs`);
    return value;
  }
  const ids = [];
  for (const item of value) {
    if (ids.length >= limit) throw new RangeError(`${name} may contain at most ${limit} IDs`);
    ids.push(toU64(item, `${name}[${ids.length}]`));
  }
  return BigUint64Array.from(ids);
}

export function temporalControllerCreate({
  instanceId,
  domainStart,
  domainEnd,
  cursor = null,
  window: windowUs = 0,
  step = 1,
  direction = TEMPORAL_DIRECTION.forward,
  rateMilli = 1000,
  loopEnabled = false,
  reducedMotion = false,
  groupId = 0,
}) {
  const outHandle = new BigUint64Array(1);
  const encoded = Buffer.alloc(koffi.sizeof(TemporalControllerDescriptor));
  koffi.encode(encoded, TemporalControllerDescriptor, {
    instance_id: toU64(instanceId, "instanceId"),
    group_id: toU64(groupId, "groupId"),
    domain_start: toI64(domainStart, "domainStart"),
    domain_end: toI64(domainEnd, "domainEnd"),
    cursor: toI64(cursor == null ? domainStart : cursor, "cursor"),
    window: toI64(windowUs, "window"),
    step: toI64(step, "step"),
    direction: toI32(direction, "direction"),
    rate_milli: toStrictU32(rateMilli, "rateMilli"),
    loop_enabled: toStrictBool(loopEnabled, "loopEnabled") ? 1 : 0,
    reduced_motion: toStrictBool(reducedMotion, "reducedMotion") ? 1 : 0,
    reserved: 0,
  });
  temporalStatus(xyTemporalControllerCreate(koffi.as(encoded, "const void *"), u64Ptr(outHandle)));
  return outHandle[0];
}

export function temporalControllerState(handle) {
  const instanceId = new BigUint64Array(1);
  const groupId = new BigUint64Array(1);
  const domainStart = new BigInt64Array(1);
  const domainEnd = new BigInt64Array(1);
  const rangeStart = new BigInt64Array(1);
  const rangeEnd = new BigInt64Array(1);
  const cursor = new BigInt64Array(1);
  const windowUs = new BigInt64Array(1);
  const step = new BigInt64Array(1);
  const direction = new Int32Array(1);
  const rateMilli = new Uint32Array(1);
  const loopEnabled = new Uint32Array(1);
  const playing = new Uint32Array(1);
  const reducedMotion = new Uint32Array(1);
  const revision = new BigUint64Array(1);
  const disposed = new Uint32Array(1);
  const selection = new BigUint64Array(Number(xyTemporalSelectionLimit()));
  const selectionCount = new BigUint64Array(1);
  temporalStatus(xyTemporalControllerState(
    toU64(handle, "handle"),
    u64Ptr(instanceId),
    u64Ptr(groupId),
    pointer(domainStart, "int64_t *"),
    pointer(domainEnd, "int64_t *"),
    pointer(rangeStart, "int64_t *"),
    pointer(rangeEnd, "int64_t *"),
    pointer(cursor, "int64_t *"),
    pointer(windowUs, "int64_t *"),
    pointer(step, "int64_t *"),
    pointer(direction, "int32_t *"),
    u32Ptr(rateMilli),
    u32Ptr(loopEnabled),
    u32Ptr(playing),
    u32Ptr(reducedMotion),
    u64Ptr(revision),
    u32Ptr(disposed),
    u64Ptr(selection),
    BigInt(selection.length),
    u64Ptr(selectionCount),
  ));
  return {
    instanceId: instanceId[0],
    groupId: groupId[0],
    domainStart: domainStart[0],
    domainEnd: domainEnd[0],
    rangeStart: rangeStart[0],
    rangeEnd: rangeEnd[0],
    cursor: cursor[0],
    window: windowUs[0],
    step: step[0],
    direction: direction[0],
    rateMilli: rateMilli[0],
    loopEnabled: loopEnabled[0] !== 0,
    playing: playing[0] !== 0,
    reducedMotion: reducedMotion[0] !== 0,
    revision: revision[0],
    disposed: disposed[0] !== 0,
    selection: selection.slice(0, Number(selectionCount[0])),
  };
}

export function temporalControllerSetRange(handle, start, end) {
  temporalStatus(xyTemporalControllerSetRange(
    toU64(handle, "handle"), toI64(start, "start"), toI64(end, "end"),
  ));
}

export function temporalControllerSetCursor(handle, cursor) {
  temporalStatus(xyTemporalControllerSetCursor(toU64(handle, "handle"), toI64(cursor, "cursor")));
}

export function temporalControllerSetSelection(handle, ids) {
  const selection = asTemporalSelection(ids, "selection");
  temporalStatus(xyTemporalControllerSetSelection(
    toU64(handle, "handle"), u64Ptr(selection), BigInt(selection.length),
  ));
}

export function temporalControllerStep(handle) {
  temporalStatus(xyTemporalControllerStep(toU64(handle, "handle")));
}

export function temporalControllerPlay(handle) {
  temporalStatus(xyTemporalControllerPlay(toU64(handle, "handle")));
}

export function temporalControllerPause(handle) {
  temporalStatus(xyTemporalControllerPause(toU64(handle, "handle")));
}

export function temporalControllerSetRateMilli(handle, rateMilli) {
  temporalStatus(xyTemporalControllerSetRateMilli(
    toU64(handle, "handle"), toStrictU32(rateMilli, "rateMilli"),
  ));
}

export function temporalControllerSetDirection(handle, direction) {
  temporalStatus(xyTemporalControllerSetDirection(
    toU64(handle, "handle"), toI32(direction, "direction"),
  ));
}

export function temporalControllerSetLoop(handle, enabled) {
  temporalStatus(xyTemporalControllerSetLoop(
    toU64(handle, "handle"), toStrictBool(enabled, "enabled") ? 1 : 0,
  ));
}

export function temporalControllerSetReducedMotion(handle, enabled) {
  temporalStatus(xyTemporalControllerSetReducedMotion(
    toU64(handle, "handle"), toStrictBool(enabled, "enabled") ? 1 : 0,
  ));
}

export function temporalControllerTick(handle, dtMicros) {
  const advanced = new Uint32Array(1);
  temporalStatus(xyTemporalControllerTick(
    toU64(handle, "handle"), toI64(dtMicros, "dtMicros"), u32Ptr(advanced),
  ));
  return advanced[0] !== 0;
}

export function temporalControllerPollEvent(handle) {
  const hasEvent = new Uint32Array(1);
  const groupId = new BigUint64Array(1);
  const source = new BigUint64Array(1);
  const revision = new BigUint64Array(1);
  const rangeStart = new BigInt64Array(1);
  const rangeEnd = new BigInt64Array(1);
  const cursor = new BigInt64Array(1);
  const windowUs = new BigInt64Array(1);
  const selection = new BigUint64Array(Number(xyTemporalSelectionLimit()));
  const selectionCount = new BigUint64Array(1);
  temporalStatus(xyTemporalControllerPollEvent(
    toU64(handle, "handle"),
    u32Ptr(hasEvent),
    u64Ptr(groupId),
    u64Ptr(source),
    u64Ptr(revision),
    pointer(rangeStart, "int64_t *"),
    pointer(rangeEnd, "int64_t *"),
    pointer(cursor, "int64_t *"),
    pointer(windowUs, "int64_t *"),
    u64Ptr(selection),
    BigInt(selection.length),
    u64Ptr(selectionCount),
  ));
  if (hasEvent[0] === 0) return null;
  return {
    groupId: groupId[0],
    sourceInstance: source[0],
    revision: revision[0],
    rangeStart: rangeStart[0],
    rangeEnd: rangeEnd[0],
    cursor: cursor[0],
    window: windowUs[0],
    selection: selection.slice(0, Number(selectionCount[0])),
  };
}

export function temporalControllerApplyEvent(handle, event) {
  const applied = new Uint32Array(1);
  if (event?.selection == null) throw new TypeError("event.selection is required");
  const selection = asTemporalSelection(event.selection, "event.selection");
  temporalStatus(xyTemporalControllerApplyEvent(
    toU64(handle, "handle"),
    toU64(event.groupId, "groupId"),
    toU64(event.sourceInstance, "sourceInstance"),
    toU64(event.revision, "revision"),
    toI64(event.rangeStart, "rangeStart"),
    toI64(event.rangeEnd, "rangeEnd"),
    toI64(event.cursor, "cursor"),
    toI64(event.window, "window"),
    u64Ptr(selection),
    BigInt(selection.length),
    u32Ptr(applied),
  ));
  return applied[0] !== 0;
}

export function temporalCoordinateDeliver(event) {
  const applied = new Uint32Array(1);
  if (event?.selection == null) throw new TypeError("event.selection is required");
  const selection = asTemporalSelection(event.selection, "event.selection");
  temporalStatus(xyTemporalCoordinateDeliver(
    toU64(event.groupId, "groupId"),
    toU64(event.sourceInstance, "sourceInstance"),
    toU64(event.revision, "revision"),
    toI64(event.rangeStart, "rangeStart"),
    toI64(event.rangeEnd, "rangeEnd"),
    toI64(event.cursor, "cursor"),
    toI64(event.window, "window"),
    u64Ptr(selection),
    BigInt(selection.length),
    u32Ptr(applied),
  ));
  return applied[0];
}

export function temporalControllerDispose(handle) {
  temporalStatus(xyTemporalControllerDispose(toU64(handle, "handle")));
}

export function temporalControllerDestroy(handle) {
  temporalStatus(xyTemporalControllerDestroy(toU64(handle, "handle")));
}

function asUuidBytes(value, name) {
  if (!(value instanceof Uint8Array) || value.byteLength % 16 !== 0) {
    throw new TypeError(`${name} must be a Uint8Array with a multiple-of-16 byte length`);
  }
  return value;
}

export function temporalGraphCreate({
  projectionHandle,
  nodeValidFrom = 0n,
  nodeValidTo = 0n,
  nodeEventAt = 0n,
  edgeValidFrom = 0n,
  edgeValidTo = 0n,
  edgeEventAt = 0n,
}) {
  const encoded = Buffer.alloc(koffi.sizeof(TemporalGraphDescriptor));
  koffi.encode(encoded, TemporalGraphDescriptor, {
    projection_handle: toU64(projectionHandle, "projectionHandle"),
    node_valid_from: toU64(nodeValidFrom, "nodeValidFrom"),
    node_valid_to: toU64(nodeValidTo, "nodeValidTo"),
    node_event_at: toU64(nodeEventAt, "nodeEventAt"),
    edge_valid_from: toU64(edgeValidFrom, "edgeValidFrom"),
    edge_valid_to: toU64(edgeValidTo, "edgeValidTo"),
    edge_event_at: toU64(edgeEventAt, "edgeEventAt"),
    reserved: 0n,
  });
  const out = new BigUint64Array(1);
  temporalStatus(xyTemporalGraphCreate(koffi.as(encoded, "const void *"), u64Ptr(out)));
  return out[0];
}

export function temporalGraphSetSelection(handle, { nodes = new Uint8Array(), edges = new Uint8Array() } = {}) {
  nodes = asUuidBytes(nodes, "nodes");
  edges = asUuidBytes(edges, "edges");
  temporalStatus(xyTemporalGraphSetSelection(
    toU64(handle, "handle"),
    pointer(nodes, "uint8_t *"), BigInt(nodes.byteLength / 16),
    pointer(edges, "uint8_t *"), BigInt(edges.byteLength / 16),
  ));
}

export function temporalGraphSetFocus(handle, focus = null) {
  if (focus == null) {
    temporalStatus(xyTemporalGraphSetFocus(toU64(handle, "handle"), 0, null));
    return;
  }
  if (focus.kind !== "node" && focus.kind !== "edge") {
    throw new TypeError("focus.kind must be 'node' or 'edge'");
  }
  const id = asUuidBytes(focus.id, "focus.id");
  if (id.byteLength !== 16) throw new TypeError("focus.id must contain exactly 16 bytes");
  temporalStatus(xyTemporalGraphSetFocus(
    toU64(handle, "handle"), focus.kind === "node" ? 1 : 2, pointer(id, "uint8_t *"),
  ));
}

export function temporalGraphSetPinned(handle, nodes = new Uint8Array()) {
  nodes = asUuidBytes(nodes, "nodes");
  temporalStatus(xyTemporalGraphSetPinned(
    toU64(handle, "handle"), pointer(nodes, "uint8_t *"), BigInt(nodes.byteLength / 16),
  ));
}

export function temporalGraphRequiredBudget(handle) {
  const out = new BigUint64Array(1);
  temporalStatus(xyTemporalGraphRequiredBudget(toU64(handle, "handle"), u64Ptr(out)));
  return out[0];
}

export function temporalGraphFrame(handle, {
  revision,
  cursor,
  range,
  budget = null,
}) {
  if (!Array.isArray(range) || range.length !== 2) {
    throw new TypeError("range must be a [start, end] pair");
  }
  const requestedRevision = toU64(revision, "revision");
  const resolvedBudget = budget == null ? temporalGraphRequiredBudget(handle) : toU64(budget, "budget");
  temporalStatus(xyTemporalGraphFrame(
    toU64(handle, "handle"), requestedRevision, toI64(cursor, "cursor"),
    toI64(range[0], "range[0]"), toI64(range[1], "range[1]"), resolvedBudget,
  ));
  const snapshot = temporalGraphSnapshot(handle);
  _assertTemporalGraphRevision(snapshot, requestedRevision);
  return snapshot;
}

/** @internal Fail closed when another same-handle frame wins before snapshot copy. */
export function _assertTemporalGraphRevision(snapshot, requestedRevision) {
  if (snapshot.revision !== requestedRevision) throw new TemporalNativeError(-14);
}

export function temporalGraphCancel(handle) {
  temporalStatus(xyTemporalGraphCancel(toU64(handle, "handle")));
}

function uuidOutput(count) {
  return new Uint8Array(toLength(count, "UUID count") * 16);
}

function decodeFocus(kind, id) {
  if (kind === 0) return null;
  return { kind: kind === 1 ? "node" : "edge", id: Uint8Array.from(id) };
}

function decodeTemporalGraphMeta(encoded) {
  const u64 = (offset) => encoded.readBigUInt64LE(offset);
  const i64 = (offset) => encoded.readBigInt64LE(offset);
  return {
    revision: u64(0),
    cursor_micros: i64(8),
    range_start_micros: i64(16),
    range_end_micros: i64(24),
    node_count: u64(32),
    edge_count: u64(40),
    visible_node_count: u64(48),
    visible_edge_count: u64(56),
    selected_visible_node_count: u64(64),
    selected_visible_edge_count: u64(72),
    pinned_visible_node_count: u64(80),
    selected_node_count: u64(88),
    selected_edge_count: u64(96),
    pinned_node_count: u64(104),
    focused_visible_kind: encoded.readUInt32LE(112),
    focused_kind: encoded.readUInt32LE(116),
    focused_visible_id: encoded.subarray(120, 136),
    focused_id: encoded.subarray(136, 152),
  };
}

export function temporalGraphSnapshot(handle) {
  const encoded = Buffer.alloc(koffi.sizeof(TemporalGraphSnapshotMeta));
  temporalStatus(xyTemporalGraphSnapshotMeta(
    toU64(handle, "handle"), koffi.as(encoded, "void *"),
  ));
  const meta = decodeTemporalGraphMeta(encoded);
  const nodeVisibility = new Uint8Array(toLength(meta.node_count, "nodeCount"));
  const edgeVisibility = new Uint8Array(toLength(meta.edge_count, "edgeCount"));
  const outputs = {
    visibleNodeIds: uuidOutput(meta.visible_node_count),
    visibleEdgeIds: uuidOutput(meta.visible_edge_count),
    selectedVisibleNodeIds: uuidOutput(meta.selected_visible_node_count),
    selectedVisibleEdgeIds: uuidOutput(meta.selected_visible_edge_count),
    pinnedVisibleNodeIds: uuidOutput(meta.pinned_visible_node_count),
    selectedNodeIds: uuidOutput(meta.selected_node_count),
    selectedEdgeIds: uuidOutput(meta.selected_edge_count),
    pinnedNodeIds: uuidOutput(meta.pinned_node_count),
  };
  const buffers = Buffer.alloc(koffi.sizeof(TemporalGraphSnapshotBuffers));
  koffi.encode(buffers, TemporalGraphSnapshotBuffers, {
    node_visibility: pointer(nodeVisibility, "uint8_t *"),
    node_capacity: meta.node_count,
    edge_visibility: pointer(edgeVisibility, "uint8_t *"),
    edge_capacity: meta.edge_count,
    visible_node_ids: pointer(outputs.visibleNodeIds, "uint8_t *"),
    visible_node_capacity: meta.visible_node_count,
    visible_edge_ids: pointer(outputs.visibleEdgeIds, "uint8_t *"),
    visible_edge_capacity: meta.visible_edge_count,
    selected_visible_node_ids: pointer(outputs.selectedVisibleNodeIds, "uint8_t *"),
    selected_visible_node_capacity: meta.selected_visible_node_count,
    selected_visible_edge_ids: pointer(outputs.selectedVisibleEdgeIds, "uint8_t *"),
    selected_visible_edge_capacity: meta.selected_visible_edge_count,
    pinned_visible_node_ids: pointer(outputs.pinnedVisibleNodeIds, "uint8_t *"),
    pinned_visible_node_capacity: meta.pinned_visible_node_count,
    selected_node_ids: pointer(outputs.selectedNodeIds, "uint8_t *"),
    selected_node_capacity: meta.selected_node_count,
    selected_edge_ids: pointer(outputs.selectedEdgeIds, "uint8_t *"),
    selected_edge_capacity: meta.selected_edge_count,
    pinned_node_ids: pointer(outputs.pinnedNodeIds, "uint8_t *"),
    pinned_node_capacity: meta.pinned_node_count,
  });
  temporalStatus(xyTemporalGraphSnapshotCopy(
    toU64(handle, "handle"), meta.revision,
    koffi.as(buffers, "const void *"),
  ));
  return {
    revision: meta.revision,
    cursor: meta.cursor_micros,
    range: [meta.range_start_micros, meta.range_end_micros],
    nodeVisibility,
    edgeVisibility,
    ...outputs,
    focusedVisible: decodeFocus(meta.focused_visible_kind, meta.focused_visible_id),
    focused: decodeFocus(meta.focused_kind, meta.focused_id),
  };
}

export function temporalGraphDestroy(handle) {
  temporalStatus(xyTemporalGraphDestroy(toU64(handle, "handle")));
}

export function graphLayout(layout, nNodes, sources, targets, opts = {}) {
  const layoutId = graphLayoutId(layout);
  const nodeCount = toLength(nNodes, "nNodes");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  const outX = new Float64Array(nodeCount);
  const outY = new Float64Array(nodeCount);
  const inX = opts.x == null ? null : asF64Array(opts.x, "opts.x");
  const inY = opts.y == null ? null : asF64Array(opts.y, "opts.y");
  if ((inX == null) !== (inY == null)) {
    throw new TypeError("graphLayout requires both opts.x and opts.y or neither");
  }
  if (inX != null && (inX.length !== nodeCount || inY.length !== nodeCount)) {
    throw new RangeError("opts.x and opts.y must have length nNodes");
  }
  const roots = opts.roots == null ? new BigUint64Array(0) : asU64Array(opts.roots, "opts.roots");
  const code = xyGraphLayout(
    layoutId,
    toU64(nNodes, "nNodes"),
    toU64(sourceArray.length, "nEdges"),
    u64Ptr(sourceArray),
    u64Ptr(targetArray),
    f64Ptr(inX),
    f64Ptr(inY),
    u64Ptr(roots),
    toU64(roots.length, "nRoots"),
    toU64(opts.seed ?? 0, "opts.seed"),
    f64Ptr(outX),
    f64Ptr(outY),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_layout failed with code ${code}`);
  }
  return { x: outX, y: outY };
}

export function graphForceCreate(nNodes, sources, targets, opts = {}) {
  const nodeCount = toLength(nNodes, "nNodes");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  const inX = opts.x == null ? null : asF64Array(opts.x, "opts.x");
  const inY = opts.y == null ? null : asF64Array(opts.y, "opts.y");
  if ((inX == null) !== (inY == null)) {
    throw new TypeError("graphForceCreate requires both opts.x and opts.y or neither");
  }
  if (inX != null && (inX.length !== nodeCount || inY.length !== nodeCount)) {
    throw new RangeError("opts.x and opts.y must have length nNodes");
  }
  const algorithm = graphLayoutId(opts.algorithm ?? opts.layout ?? "force");
  const handle = new BigUint64Array(1);
  const configuredCose = opts.cose != null || opts.pinned != null || opts.parents != null;
  let code;
  if (configuredCose) {
    if (algorithm !== GRAPH_LAYOUT_COSE) {
      throw new TypeError("CoSE options, pins, and parents require algorithm='cose'");
    }
    const cose = opts.cose ?? {};
    const allowed = new Set([
      "idealEdgeLength", "repulsionStrength", "gravityStrength", "coolingFactor",
      "overlapPadding", "componentSpacing", "bounds",
    ]);
    const unknown = Object.keys(cose).filter((key) => !allowed.has(key));
    if (unknown.length > 0) {
      throw new TypeError(`unknown CoSE option(s): ${unknown.sort().join(", ")}`);
    }
    const pinned = opts.pinned == null ? null : asU8Array(opts.pinned, "opts.pinned");
    const parents = opts.parents == null ? null : asU64Array(opts.parents, "opts.parents");
    if (pinned != null && pinned.length !== nodeCount) {
      throw new RangeError("opts.pinned must have length nNodes");
    }
    if (pinned?.some((value) => value > 1)) {
      throw new RangeError("opts.pinned must contain only booleans or 0/1 integers");
    }
    if (parents != null && parents.length !== nodeCount) {
      throw new RangeError("opts.parents must have length nNodes");
    }
    if (pinned?.some((value) => value !== 0) && inX == null) {
      throw new TypeError("pinned nodes require explicit opts.x and opts.y initial positions");
    }
    const bounds = cose.bounds == null ? null : asF64Array(cose.bounds, "opts.cose.bounds");
    if (bounds != null && bounds.length !== 4) {
      throw new RangeError("opts.cose.bounds must be [x0, y0, x1, y1]");
    }
    const coseNumber = (value, fallback, name) => {
      const number = Number(value ?? fallback);
      if (!Number.isFinite(number)) {
        throw new TypeError(`opts.cose.${name} must be a finite number`);
      }
      return number;
    };
    const encoded = Buffer.alloc(koffi.sizeof(CoseDescriptor));
    koffi.encode(encoded, CoseDescriptor, {
      in_x: pointer(inX, "double *"),
      in_y: pointer(inY, "double *"),
      pinned: pointer(pinned, "uint8_t *"),
      parents: pointer(parents, "uint64_t *"),
      ideal_edge_length: coseNumber(cose.idealEdgeLength, 1.0, "idealEdgeLength"),
      repulsion_strength: coseNumber(cose.repulsionStrength, 1.25, "repulsionStrength"),
      gravity_strength: coseNumber(cose.gravityStrength, 0.08, "gravityStrength"),
      cooling_factor: coseNumber(cose.coolingFactor, 0.985, "coolingFactor"),
      overlap_padding: coseNumber(cose.overlapPadding, 0.35, "overlapPadding"),
      component_spacing: coseNumber(cose.componentSpacing, 2.5, "componentSpacing"),
      bounds: pointer(bounds, "double *"),
      has_bounds: bounds == null ? 0 : 1,
      reserved: 0,
    });
    code = xyGraphForceCreateCose(
      koffi.as(encoded, "const void *"),
      toU64(nodeCount, "nNodes"),
      toU64(sourceArray.length, "nEdges"),
      u64Ptr(sourceArray),
      u64Ptr(targetArray),
      toU64(opts.seed ?? 0, "opts.seed"),
      u64Ptr(handle),
    );
  } else {
    code = xyGraphForceCreate(
      toU64(nodeCount, "nNodes"),
      toU64(sourceArray.length, "nEdges"),
      u64Ptr(sourceArray),
      u64Ptr(targetArray),
      f64Ptr(inX),
      f64Ptr(inY),
      toU64(opts.seed ?? 0, "opts.seed"),
      toU32(algorithm, "algorithm"),
      u64Ptr(handle),
    );
  }
  if (code !== 0 || handle[0] === 0n) {
    const symbol = configuredCose ? "xyg_graph_force_create_cose" : "xyg_graph_force_create";
    throw new Error(`${symbol} failed with code ${code}`);
  }
  return handle[0];
}

export function graphIsProgressiveForce(layout) {
  return GRAPH_PROGRESSIVE_FORCE.has(graphLayoutId(layout));
}

export function graphForceTick(handle, nNodes, steps = 1) {
  const nodeCount = toLength(nNodes, "nNodes");
  const outX = new Float64Array(nodeCount);
  const outY = new Float64Array(nodeCount);
  const alpha = new Float64Array(1);
  const code = xyGraphForceTick(
    toU64(handle, "handle"),
    toU64(nodeCount, "nNodes"),
    toU32(steps, "steps"),
    f64Ptr(outX),
    f64Ptr(outY),
    f64Ptr(alpha),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_force_tick failed with code ${code}`);
  }
  return { x: outX, y: outY, alpha: alpha[0] };
}

export function graphForceDestroy(handle) {
  return xyGraphForceDestroy(toU64(handle, "handle")) === 1;
}

export function graphLodDecision(nNodes, nEdges, opts = {}) {
  const tier = new Uint32Array(1);
  const edgesKept = new BigUint64Array(1);
  const code = xyGraphLodDecision(
    toU64(nNodes, "nNodes"),
    toU64(nEdges, "nEdges"),
    toU64(opts.nodeBudget ?? 200_000, "opts.nodeBudget"),
    toU64(opts.edgeBudget ?? 500_000, "opts.edgeBudget"),
    u32Ptr(tier),
    u64Ptr(edgesKept),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_lod_decision failed with code ${code}`);
  }
  return { tier: tier[0], edgesKept: edgesKept[0] };
}

export function graphClusterAggregate(x, y, opts = {}) {
  const xArray = asF64Array(x, "x");
  const yArray = asF64Array(y, "y");
  requireEqualLength(xArray, yArray, "x", "y");
  const nNodes = xArray.length;
  const nodeBudget = toLength(opts.nodeBudget ?? nNodes, "opts.nodeBudget");
  const edgeBudget = toLength(opts.edgeBudget ?? 500_000, "opts.edgeBudget");
  const nEdges = toLength(opts.nEdges ?? 0, "opts.nEdges");
  if (nNodes > nodeBudget && nodeBudget === 0) {
    throw new Error("nodeBudget must be positive when clustering non-empty positions");
  }
  const outCap = nNodes <= nodeBudget ? nNodes : nodeBudget;
  const outX = new Float64Array(outCap);
  const outY = new Float64Array(outCap);
  const memberOf = new BigUint64Array(nNodes);
  const outCount = new BigUint64Array(1);
  const tier = new Uint32Array(1);
  const edgesKept = new BigUint64Array(1);
  const code = xyGraphClusterAggregate(
    toU64(nNodes, "nNodes"),
    toU64(nEdges, "nEdges"),
    f64Ptr(xArray),
    f64Ptr(yArray),
    toU64(nodeBudget, "opts.nodeBudget"),
    toU64(edgeBudget, "opts.edgeBudget"),
    f64Ptr(outX),
    f64Ptr(outY),
    u64Ptr(outCount),
    u64Ptr(memberOf),
    u32Ptr(tier),
    u64Ptr(edgesKept),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_cluster_aggregate failed with code ${code}`);
  }
  const count = Number(outCount[0]);
  return {
    x: outX.subarray(0, count),
    y: outY.subarray(0, count),
    memberOf,
    tier: tier[0],
    edgesKept: edgesKept[0],
  };
}

export function graphBuildRender(x, y, sources, targets, opts = {}) {
  const xArray = asF64Array(x, "x");
  const yArray = asF64Array(y, "y");
  requireEqualLength(xArray, yArray, "x", "y");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  const nNodes = xArray.length;
  const nodeBudget = toLength(opts.nodeBudget ?? 200_000, "opts.nodeBudget");
  const edgeBudget = toLength(opts.edgeBudget ?? 500_000, "opts.edgeBudget");
  const outNodeCap = nNodes === 0 ? 0 : Math.min(nNodes, Math.max(nodeBudget, 1));
  const outX = new Float64Array(outNodeCap);
  const outY = new Float64Array(outNodeCap);
  const memberOf = new BigUint64Array(nNodes);
  const edgeS = new BigUint64Array(Math.max(edgeBudget, 1));
  const edgeT = new BigUint64Array(Math.max(edgeBudget, 1));
  const outNNodes = new BigUint64Array(1);
  const outNEdges = new BigUint64Array(1);
  const tier = new Uint32Array(1);
  const edgesKept = new BigUint64Array(1);
  // CSR source-edge membership per render edge (#33); render edges never
  // outnumber source edges, so offsets need min(edgeBudget, |E|) + 1 slots.
  const memberOffsets = new BigUint64Array(Math.min(Math.max(edgeBudget, 1), sourceArray.length) + 1);
  const members = new BigUint64Array(Math.max(sourceArray.length, 1));
  const vp = opts.viewport;
  const vpEnabled = vp == null ? 0 : 1;
  const x0 = vp == null ? 0 : Number(vp.x0 ?? vp[0]);
  const y0 = vp == null ? 0 : Number(vp.y0 ?? vp[1]);
  const x1 = vp == null ? 0 : Number(vp.x1 ?? vp[2]);
  const y1 = vp == null ? 0 : Number(vp.y1 ?? vp[3]);
  const code = xyGraphBuildRender(
    toU64(nNodes, "nNodes"),
    toU64(sourceArray.length, "nEdges"),
    f64Ptr(xArray),
    f64Ptr(yArray),
    u64Ptr(sourceArray),
    u64Ptr(targetArray),
    toU64(Math.max(nodeBudget, 1), "opts.nodeBudget"),
    toU64(Math.max(edgeBudget, 1), "opts.edgeBudget"),
    vpEnabled,
    x0,
    y0,
    x1,
    y1,
    f64Ptr(outX),
    f64Ptr(outY),
    u64Ptr(memberOf),
    u64Ptr(edgeS),
    u64Ptr(edgeT),
    u64Ptr(outNNodes),
    u64Ptr(outNEdges),
    u32Ptr(tier),
    u64Ptr(edgesKept),
    u64Ptr(memberOffsets),
    u64Ptr(members),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_build_render failed with code ${code}`);
  }
  const nOut = Number(outNNodes[0]);
  const eOut = Number(outNEdges[0]);
  const edgeMemberOffsets = memberOffsets.subarray(0, eOut + 1);
  return {
    // Render edge r represents source edges
    // edgeMembers[edgeMemberOffsets[r] .. edgeMemberOffsets[r + 1]] (ascending).
    edgeMemberOffsets,
    edgeMembers: members.subarray(0, Number(edgeMemberOffsets[eOut])),
    x: outX.subarray(0, nOut),
    y: outY.subarray(0, nOut),
    memberOf,
    edgeSources: edgeS.subarray(0, eOut),
    edgeTargets: edgeT.subarray(0, eOut),
    tier: tier[0],
    edgesKept: edgesKept[0],
  };
}


// Per-edge route capacity: 8 curve-tessellation shaft pieces + 2 arrow wings
// when curved; a 3-sided self-loop or shaft + 2 wings when straight. Mirrors
// `edge_route_segments_per_edge` in crates/xyg-engine/src/edge_route.rs.
export const EDGE_ROUTE_SEGMENTS_PER_EDGE = 10;
export const STRAIGHT_EDGE_ROUTE_SEGMENTS_PER_EDGE = 3;

export function graphEdgeRouteSegments(x, y, sources, targets, opts = {}) {
  const xArray = asF64Array(x, "x");
  const yArray = asF64Array(y, "y");
  requireEqualLength(xArray, yArray, "x", "y");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  const nNodes = xArray.length;
  const nEdges = sourceArray.length;
  const curved = opts.curved ? 1 : 0;
  const cap = nEdges * (curved ? EDGE_ROUTE_SEGMENTS_PER_EDGE : STRAIGHT_EDGE_ROUTE_SEGMENTS_PER_EDGE);
  const outX0 = new Float64Array(cap);
  const outY0 = new Float64Array(cap);
  const outX1 = new Float64Array(cap);
  const outY1 = new Float64Array(cap);
  const outEdgeIndex = new BigUint64Array(cap);
  const outN = new BigUint64Array(1);
  const directed = opts.directed === false ? 0 : 1;
  const separation = Number(opts.separation ?? 0.08);
  const loopRadius = Number(opts.loopRadius ?? 0.35);
  const arrowSize = Number(opts.arrowSize ?? 0.12);
  const code = xyGraphEdgeRouteSegments(
    toU64(nNodes, "nNodes"),
    toU64(nEdges, "nEdges"),
    f64Ptr(xArray),
    f64Ptr(yArray),
    u64Ptr(sourceArray),
    u64Ptr(targetArray),
    directed,
    separation,
    loopRadius,
    arrowSize,
    curved,
    f64Ptr(outX0),
    f64Ptr(outY0),
    f64Ptr(outX1),
    f64Ptr(outY1),
    u64Ptr(outEdgeIndex),
    u64Ptr(outN),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_edge_route_segments failed with code ${code}`);
  }
  const nSeg = Number(outN[0]);
  return {
    x0: outX0.subarray(0, nSeg),
    y0: outY0.subarray(0, nSeg),
    x1: outX1.subarray(0, nSeg),
    y1: outY1.subarray(0, nSeg),
    edgeIndex: outEdgeIndex.subarray(0, nSeg),
  };
}

/**
 * Route edges for screen-space, border-aware paint (#33, ABI 368). Same
 * geometry as `graphEdgeRouteSegments` without data-space arrowheads, plus
 * `ends` (7 per segment: source center minus piece start x/y, source radius
 * px, target center minus piece start x/y, target radius px, flag byte — head
 * 0x40, terminal 0x20, target shape bits 0-1, source shape bits 2-3).
 */
export function graphEdgeRouteEnds(x, y, sources, targets, opts = {}) {
  const xArray = asF64Array(x, "x");
  const yArray = asF64Array(y, "y");
  requireEqualLength(xArray, yArray, "x", "y");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  const nNodes = xArray.length;
  const nEdges = sourceArray.length;
  const curved = opts.curved ? 1 : 0;
  const radius = opts.nodeRadiusPx == null ? null : asF64Array(opts.nodeRadiusPx, "nodeRadiusPx");
  const symbol = opts.nodeSymbol == null ? null : asU8Array(opts.nodeSymbol, "nodeSymbol");
  for (const [name, column] of [["nodeRadiusPx", radius], ["nodeSymbol", symbol]]) {
    if (column != null && column.length !== nNodes) {
      throw new RangeError(`${name} must have one value per node`);
    }
  }
  const cap = nEdges * (curved ? EDGE_ROUTE_SEGMENTS_PER_EDGE : STRAIGHT_EDGE_ROUTE_SEGMENTS_PER_EDGE);
  const outX0 = new Float64Array(cap);
  const outY0 = new Float64Array(cap);
  const outX1 = new Float64Array(cap);
  const outY1 = new Float64Array(cap);
  const outEdgeIndex = new BigUint64Array(cap);
  const outEnds = new Float64Array(cap * 7);
  const outN = new BigUint64Array(1);
  const code = xyGraphEdgeRouteEnds(
    toU64(nNodes, "nNodes"),
    toU64(nEdges, "nEdges"),
    f64Ptr(xArray),
    f64Ptr(yArray),
    u64Ptr(sourceArray),
    u64Ptr(targetArray),
    opts.directed === false ? 0 : 1,
    Number(opts.separation ?? 0.08),
    Number(opts.loopRadius ?? 0.35),
    curved,
    radius == null || nNodes === 0 ? null : f64Ptr(radius),
    symbol == null || nNodes === 0 ? null : u8Ptr(symbol),
    f64Ptr(outX0),
    f64Ptr(outY0),
    f64Ptr(outX1),
    f64Ptr(outY1),
    u64Ptr(outEdgeIndex),
    f64Ptr(outEnds),
    u64Ptr(outN),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_edge_route_ends failed with code ${code}`);
  }
  const nSeg = Number(outN[0]);
  return {
    x0: outX0.subarray(0, nSeg),
    y0: outY0.subarray(0, nSeg),
    x1: outX1.subarray(0, nSeg),
    y1: outY1.subarray(0, nSeg),
    edgeIndex: outEdgeIndex.subarray(0, nSeg),
    ends: outEnds.subarray(0, nSeg * 7),
  };
}

export function graphVisualStates(flags) {
  const input = asU32Array(flags, "flags");
  const out = new Uint8Array(input.length);
  const code = xyGraphVisualStateResolve(toU64(input.length, "flags.length"), u32Ptr(input), u8Ptr(out));
  if (code !== 0) throw new Error(`xyg_graph_visual_state_resolve failed with code ${code}`);
  return out;
}

function graphSemanticInputs(classes, epistemic, statuses, metric, flags, opts) {
  if (opts.edge !== undefined && typeof opts.edge !== "boolean") throw new TypeError("edge must be a bool");
  const theme = opts.theme ?? "light"; const themeId = theme === "light" ? 0 : theme === "dark" ? 1 : -1;
  if (themeId < 0) throw new RangeError("theme must be 'light' or 'dark'");
  const ca = asU8Array(classes, "classes"); const ea = asU8Array(epistemic, "epistemic");
  const sa = asU8Array(statuses, "statuses"); const ma = asF64Array(metric, "metric");
  const fa = asU32Array(flags, "flags"); const n = ca.length;
  for (const [name, value] of [["epistemic", ea], ["statuses", sa], ["metric", ma], ["flags", fa]]) {
    requireEqualLength(ca, value, "classes", name);
  }
  for (const [name, value] of [["classes", ca], ["epistemic", ea], ["statuses", sa]]) {
    if (value.some((code) => code > 7)) throw new RangeError(`${name} codes must be in the closed range 0..7`);
  }
  return { theme, themeId, ca, ea, sa, ma, fa, n };
}

export function graphSemanticStyles(classes, epistemic, statuses, metric, flags, opts = {}) {
  const { theme, themeId, ca, ea, sa, ma, fa, n } = graphSemanticInputs(classes, epistemic, statuses, metric, flags, opts);
  const fillRgba = new Uint8Array(n * 4); const strokeRgba = new Uint8Array(n * 4); const haloRgba = new Uint8Array(n * 4);
  const size = new Float32Array(n); const width = new Float32Array(n); const opacity = new Float32Array(n);
  const shape = new Uint8Array(n); const dash = new Uint8Array(n); const arrow = new Uint8Array(n); const state = new Uint8Array(n);
  const domain = new Float64Array(2);
  const code = xyGraphSemanticStyleResolve(1, themeId, toU64(n, "classes.length"), u8Ptr(ca), u8Ptr(ea), u8Ptr(sa), f64Ptr(ma), u32Ptr(fa), opts.edge ? 1 : 0, u8Ptr(fillRgba), u8Ptr(strokeRgba), u8Ptr(haloRgba), f32Ptr(size), f32Ptr(width), f32Ptr(opacity), u8Ptr(shape), u8Ptr(dash), u8Ptr(arrow), u8Ptr(state), f64Ptr(domain.subarray(0, 1)), f64Ptr(domain.subarray(1)));
  if (code !== 0) throw new Error(`xyg_graph_semantic_style_resolve failed with code ${code}`);
  return { version: 1, theme, fillRgba, strokeRgba, haloRgba, size, width, opacity, shape, dash, arrow, state, metricDomain: domain };
}

/** Lower the v1 GraphForge semantic contract into ordered paint layers in Rust
 * (#34). Colors carry row opacity and layer alpha; all-zero is an absent layer.
 * `haloExtent` is the node halo diameter or edge halo width (px); `dashPx` is
 * `(on, off)` px per row (`(0, 0)` is solid). Mirrors Python
 * `_native.graph_semantic_paint_layers`. */
export function graphSemanticPaintLayers(classes, epistemic, statuses, metric, flags, opts = {}) {
  const { theme, themeId, ca, ea, sa, ma, fa, n } = graphSemanticInputs(classes, epistemic, statuses, metric, flags, opts);
  const haloRgba = new Uint8Array(n * 4); const bodyRgba = new Uint8Array(n * 4); const strokeRgba = new Uint8Array(n * 4);
  const haloExtent = new Float32Array(n); const bodyWidth = new Float32Array(n); const dashPx = new Float32Array(n * 2);
  const head = new Uint8Array(n);
  const code = xyGraphSemanticPaintLayers(1, themeId, toU64(n, "classes.length"), u8Ptr(ca), u8Ptr(ea), u8Ptr(sa), f64Ptr(ma), u32Ptr(fa), opts.edge ? 1 : 0, u8Ptr(haloRgba), f32Ptr(haloExtent), u8Ptr(bodyRgba), f32Ptr(bodyWidth), u8Ptr(strokeRgba), f32Ptr(dashPx), u8Ptr(head));
  if (code !== 0) throw new Error(`xyg_graph_semantic_paint_layers failed with code ${code}`);
  return { version: 1, theme, haloRgba, haloExtent, bodyRgba, bodyWidth, strokeRgba, dashPx, head };
}

export function graphSemanticLegend(classes, epistemic, statuses, opts = {}) {
  const theme = opts.theme ?? "light"; const themeId = theme === "light" ? 0 : theme === "dark" ? 1 : -1;
  if (themeId < 0) throw new RangeError("theme must be 'light' or 'dark'");
  const ca = asU8Array(classes, "classes"); const ea = asU8Array(epistemic, "epistemic"); const sa = asU8Array(statuses, "statuses");
  requireEqualLength(ca, ea, "classes", "epistemic"); requireEqualLength(ca, sa, "classes", "statuses");
  for (const [name, input] of [["classes", ca], ["epistemic", ea], ["statuses", sa]]) if (input.some((code) => code > 7)) throw new RangeError(`${name} codes must be in the closed range 0..7`);
  const count = new BigUint64Array(1); const n = ca.length;
  let code = xyGraphSemanticLegend(1, themeId, toU64(n, "classes.length"), u8Ptr(ca), u8Ptr(ea), u8Ptr(sa), 0n, null, null, null, null, u64Ptr(count));
  if (code !== 0 || count[0] > 24n) throw new Error(`xyg_graph_semantic_legend query failed with code ${code}`);
  const cap = Number(count[0]); const field = new Uint8Array(cap); const value = new Uint8Array(cap); const rgba = new Uint8Array(cap * 4); const shape = new Uint8Array(cap);
  code = xyGraphSemanticLegend(1, themeId, toU64(n, "classes.length"), u8Ptr(ca), u8Ptr(ea), u8Ptr(sa), BigInt(cap), u8Ptr(field), u8Ptr(value), u8Ptr(rgba), u8Ptr(shape), u64Ptr(count));
  if (code !== 0 || count[0] !== BigInt(cap)) throw new Error(`xyg_graph_semantic_legend copy failed with code ${code}`);
  return { version: 1, theme, field, value, rgba, shape };
}

export function graphLabelAccept(priorities, budget, opts = {}) {
  const input = priorities instanceof Float64Array ? priorities : Float64Array.from(priorities ?? [], Number);
  const out = new Uint8Array(input.length);
  const count = new BigUint64Array(1);
  const floor = opts.minPriority == null ? Number.NaN : Number(opts.minPriority);
  const code = xyGraphLabelAccept(toU64(input.length, "priorities.length"), f64Ptr(input), toU64(budget, "budget"), floor, u8Ptr(out), u64Ptr(count));
  if (code !== 0) throw new Error(`xyg_graph_label_accept failed with code ${code}`);
  return { accepted: out, count: count[0] };
}

/** Rust-owned bounded, collision-free, zoom-monotone graph label plan (#34).
 * Mirrors Python `_native.graph_label_plan`: per label `keep` (characters
 * kept before an ellipsis; 0 when not accepted), `threshold` (smallest
 * isotropic zoom scale in px per data unit from which it paints; Infinity
 * never), the baseline `offsetX`/`offsetY` (px, y down), and the planned
 * `width`/`fontPx` the painter fits the text into. */
export function graphLabelPlan(kinds, x, y, radiusPx, chars, states, priorities, budget, opts = {}) {
  const ka = asU8Array(kinds, "kinds"); const n = ka.length;
  const xa = asF64Array(x, "x"); const ya = asF64Array(y, "y"); const ra = asF64Array(radiusPx, "radiusPx");
  const ca = asU32Array(chars, "chars"); const sa = asU8Array(states, "states");
  const pa = priorities instanceof Float64Array ? priorities : Float64Array.from(priorities ?? [], Number);
  for (const [name, value] of [["x", xa], ["y", ya], ["radiusPx", ra], ["chars", ca], ["states", sa], ["priorities", pa]]) {
    requireEqualLength(ka, value, "kinds", name);
  }
  const keep = new Uint32Array(n); const threshold = new Float64Array(n);
  const offsetX = new Float64Array(n); const offsetY = new Float64Array(n); const accepted = new BigUint64Array(1);
  const width = new Float64Array(n); const fontPx = new Float64Array(n);
  const floor = opts.minPriority == null ? Number.NaN : Number(opts.minPriority);
  const code = xyGraphLabelPlan(toU64(n, "kinds.length"), u8Ptr(ka), f64Ptr(xa), f64Ptr(ya), f64Ptr(ra), u32Ptr(ca), u8Ptr(sa), f64Ptr(pa), toU64(budget, "budget"), floor, u32Ptr(keep), f64Ptr(threshold), f64Ptr(offsetX), f64Ptr(offsetY), f64Ptr(width), f64Ptr(fontPx), u64Ptr(accepted));
  if (code !== 0) throw new Error(`xyg_graph_label_plan failed with code ${code}`);
  return { keep, threshold, offsetX, offsetY, width, fontPx, accepted: accepted[0] };
}

/** `levels` evenly spaced `#rrggbb` colors of a built-in colormap (#34).
 * Mirrors Python `_native.graph_ordinal_colors`. */
export function graphOrdinalColors(colormap, levels) {
  if (typeof colormap !== "string") throw new TypeError("colormap must be a built-in colormap name");
  if (!Number.isSafeInteger(levels) || levels < 1 || levels > 256) throw new RangeError("ordinal scales need 1..256 levels");
  const name = Buffer.from(colormap, "utf8");
  const out = new Uint8Array(levels * 3);
  const code = xyGraphOrdinalColors(u8Ptr(new Uint8Array(name)), BigInt(name.length), BigInt(levels), u8Ptr(out));
  if (code !== 0) throw new RangeError(`unknown colormap ${JSON.stringify(colormap)} for an ordinal scale`);
  const hex = (v) => v.toString(16).padStart(2, "0");
  return Array.from({ length: levels }, (_, i) => `#${hex(out[i * 3])}${hex(out[i * 3 + 1])}${hex(out[i * 3 + 2])}`);
}

/** Rust domain symmetric about `midpoint` covering every finite value (#34). */
export function graphDivergingDomain(values, midpoint) {
  const va = Float64Array.from(values, Number);
  const lo = new Float64Array(1); const hi = new Float64Array(1);
  const code = xyGraphDivergingDomain(f64Ptr(va), BigInt(va.length), Number(midpoint), f64Ptr(lo), f64Ptr(hi));
  if (code !== 0) throw new RangeError("diverging scale needs a finite midpoint, at least one finite value, and a domain representable in f64");
  return [lo[0], hi[0]];
}

/** Rust text of a semantic legend row (field 0-2) or its title (field 3). */
export function graphSemanticLegendText(field, value = 0) {
  const out = new Uint8Array(64); const length = new BigUint64Array(1);
  const code = xyGraphSemanticLegendText(field, value, u8Ptr(out), 64n, u64Ptr(length));
  if (code !== 0) throw new RangeError("invalid semantic legend field or value");
  return Buffer.from(out.subarray(0, Number(length[0]))).toString("utf8");
}

/** Rust compound collapse for the composed graph mark (#34). Mirrors Python
 * `_native.graph_compound_collapse`. */
export function graphCompoundCollapse(parents, parentValidity, collapsed, flags, sources, targets) {
  const pa = asU64Array(parents, "parents"); const n = pa.length;
  const va = asU8Array(parentValidity, "parentValidity"); const ca = asU8Array(collapsed, "collapsed");
  const fa = asU32Array(flags, "flags");
  const sa = asU64Array(sources, "sources"); const ta = asU64Array(targets, "targets"); const e = sa.length;
  requireEqualLength(pa, va, "parents", "parentValidity"); requireEqualLength(pa, ca, "parents", "collapsed");
  requireEqualLength(pa, fa, "parents", "flags"); requireEqualLength(sa, ta, "sources", "targets");
  const visible = new Uint8Array(n); const representative = new BigUint64Array(n); const outFlags = new Uint32Array(n);
  const edgeKeep = new Uint8Array(e); const edgeSource = new BigUint64Array(e); const edgeTarget = new BigUint64Array(e);
  const code = xyGraphCompoundCollapse(toU64(n, "parents.length"), u64Ptr(pa), u8Ptr(va), u8Ptr(ca), u32Ptr(fa), toU64(e, "sources.length"), u64Ptr(sa), u64Ptr(ta), u8Ptr(visible), u64Ptr(representative), u32Ptr(outFlags), u8Ptr(edgeKeep), u64Ptr(edgeSource), u64Ptr(edgeTarget));
  if (code !== 0) throw new RangeError("graph compound collapse failed: collapsed nodes must be groups in a valid acyclic parent forest");
  return { visible, representative, flags: outFlags, edgeKeep, edgeSource, edgeTarget };
}

/** Rust compound frames (#34): visible groups' transitive bounds, paint, and
 * screen padding. Mirrors Python `_native.graph_compound_frames`. */
export function graphCompoundFrames(x, y, radiusPx, parents, parentValidity, collapsed, strokeRgba, opacity, opts = {}) {
  const theme = opts.theme ?? "light"; const themeId = theme === "light" ? 0 : theme === "dark" ? 1 : -1;
  if (themeId < 0) throw new RangeError("theme must be 'light' or 'dark'");
  const xa = asF64Array(x, "x"); const n = xa.length;
  const ya = asF64Array(y, "y"); const ra = asF64Array(radiusPx, "radiusPx");
  const pa = asU64Array(parents, "parents"); const va = asU8Array(parentValidity, "parentValidity");
  const ca = asU8Array(collapsed, "collapsed"); const sa = asU8Array(strokeRgba, "strokeRgba");
  const oa = Float32Array.from(opacity, Number);
  for (const [name, value] of [["y", ya], ["radiusPx", ra], ["parents", pa], ["parentValidity", va], ["collapsed", ca], ["opacity", oa]]) {
    requireEqualLength(xa, value, "x", name);
  }
  if (sa.length !== n * 4) throw new RangeError("strokeRgba must hold 4 bytes per node");
  const node = new BigUint64Array(n); const bounds = new Float64Array(n * 4); const rgba = new Uint8Array(n * 4);
  const width = new Float64Array(n); const pad = new Float64Array(n); const count = new BigUint64Array(1);
  const code = xyGraphCompoundFrames(toU64(n, "x.length"), f64Ptr(xa), f64Ptr(ya), f64Ptr(ra), u64Ptr(pa), u8Ptr(va), u8Ptr(ca), u8Ptr(sa), f32Ptr(oa), themeId, u64Ptr(node), f64Ptr(bounds), u8Ptr(rgba), f64Ptr(width), f64Ptr(pad), u64Ptr(count));
  if (code !== 0) throw new Error(`xyg_graph_compound_frames failed with code ${code}`);
  const k = Number(count[0]);
  return { node: node.subarray(0, k), bounds: bounds.subarray(0, k * 4), rgba: rgba.subarray(0, k * 4), width: width.subarray(0, k), pad: pad.subarray(0, k) };
}

export function graphCompoundBounds(x, y, parents, parentValidity) {
  const xa = asF64Array(x, "x"); const ya = asF64Array(y, "y");
  const pa = asU64Array(parents, "parents"); const va = asU8Array(parentValidity, "parentValidity");
  requireEqualLength(xa, ya, "x", "y"); requireEqualLength(xa, pa, "x", "parents"); requireEqualLength(xa, va, "x", "parentValidity");
  for (let index = 0; index < pa.length; index += 1) {
    if (va[index] !== 0 && va[index] !== 1) throw new RangeError("parentValidity must contain only 0 or 1");
  }
  const n = xa.length; const parentOf = new BigUint64Array(n); const isCompound = new Uint8Array(n);
  const xmin = new Float64Array(n); const xmax = new Float64Array(n); const ymin = new Float64Array(n); const ymax = new Float64Array(n);
  const code = xyGraphCompoundBounds(toU64(n, "x.length"), f64Ptr(xa), f64Ptr(ya), u64Ptr(pa), u8Ptr(va), u64Ptr(parentOf), u8Ptr(isCompound), f64Ptr(xmin), f64Ptr(xmax), f64Ptr(ymin), f64Ptr(ymax));
  if (code !== 0) throw new Error(`xyg_graph_compound_bounds failed with code ${code}`);
  return { parentOf, isCompound, xmin, xmax, ymin, ymax };
}

export const GRAPH_COMPOUND_EXPAND = 0;
export const GRAPH_COMPOUND_COLLAPSE = 1;
export const GRAPH_COMPOUND_TOGGLE = 2;

export function graphCompoundTransition(nodeIds, parents, parentValidity, collapsed, targetId, action, lodTier = 0) {
  const ids = asU64Array(nodeIds, "nodeIds"); const pa = asU64Array(parents, "parents");
  const va = asU8Array(parentValidity, "parentValidity"); const ca = asU8Array(collapsed, "collapsed");
  requireEqualLength(ids, pa, "nodeIds", "parents"); requireEqualLength(ids, va, "nodeIds", "parentValidity"); requireEqualLength(ids, ca, "nodeIds", "collapsed");
  for (const plane of [va, ca]) for (const value of plane) if (value !== 0 && value !== 1) throw new RangeError("compound validity and collapse planes must contain only 0 or 1");
  if (!Number.isInteger(action) || action < 0 || action > 0xffffffff || !Number.isInteger(lodTier) || lodTier < 0 || lodTier > 0xffffffff) throw new RangeError("action and lodTier must be exact uint32 integers");
  const out = new Uint8Array(ids.length); const changed = new Uint8Array(1);
  const code = xyGraphCompoundTransition(toU64(ids.length, "nodeIds.length"), u64Ptr(ids), u64Ptr(pa), u8Ptr(va), u8Ptr(ca), toU64(targetId, "targetId"), action, lodTier, u8Ptr(out), u8Ptr(changed));
  if (code !== 0) throw new Error(`xyg_graph_compound_transition failed with code ${code}`);
  return { collapsed: out, changed: changed[0] !== 0 };
}

export function graphCompoundScene(input) {
  if (input == null || typeof input !== "object" || Array.isArray(input)) throw new TypeError("compound Scene input must be an object");
  const text = new TextEncoder();
  if (typeof input.title !== "string" || !Array.isArray(input.nodeLabels) || !Array.isArray(input.edgeLabels)
      || input.nodeLabels.some((value) => typeof value !== "string") || input.edgeLabels.some((value) => typeof value !== "string")) {
    throw new TypeError("title and graph labels must be strings");
  }
  const x = asF64Array(input.x, "x"), y = asF64Array(input.y, "y"), n = x.length;
  const sources = asU64Array(input.sources, "sources"), e = sources.length;
  const planes = {
    node_classes: asU8Array(input.nodeClasses, "nodeClasses"), node_epistemic: asU8Array(input.nodeEpistemic, "nodeEpistemic"),
    node_statuses: asU8Array(input.nodeStatuses, "nodeStatuses"), node_metric: asF64Array(input.nodeMetric, "nodeMetric"),
    node_flags: asU32Array(input.nodeFlags, "nodeFlags"), targets: asU64Array(input.targets, "targets"),
    edge_classes: asU8Array(input.edgeClasses, "edgeClasses"), edge_epistemic: asU8Array(input.edgeEpistemic, "edgeEpistemic"),
    edge_statuses: asU8Array(input.edgeStatuses, "edgeStatuses"), edge_metric: asF64Array(input.edgeMetric, "edgeMetric"),
    edge_flags: asU32Array(input.edgeFlags, "edgeFlags"), parents: asU64Array(input.parents, "parents"),
    parent_validity: asU8Array(input.parentValidity, "parentValidity"), collapsed: asU8Array(input.collapsed, "collapsed"),
  };
  if (y.length !== n || input.nodeLabels.length !== n || ["node_classes", "node_epistemic", "node_statuses", "node_metric", "node_flags", "parents", "parent_validity", "collapsed"].some((name) => planes[name].length !== n)) throw new RangeError("node and compound planes must have exactly node_count values");
  if (input.edgeLabels.length !== e || ["targets", "edge_classes", "edge_epistemic", "edge_statuses", "edge_metric", "edge_flags"].some((name) => planes[name].length !== e)) throw new RangeError("edge planes must have exactly edge_count values");
  const labels = [...input.nodeLabels, ...input.edgeLabels].map((value) => text.encode(value));
  const payload = new Uint8Array(labels.reduce((sum, value) => sum + value.length, 0)); let cursor = 0;
  for (const value of labels) { payload.set(value, cursor); cursor += value.length; }
  const nodeLengths = Uint32Array.from(labels.slice(0, n), (value) => value.length), edgeLengths = Uint32Array.from(labels.slice(n), (value) => value.length);
  const title = text.encode(input.title), encoded = Buffer.alloc(koffi.sizeof(GraphCompoundSceneDescriptor));
  koffi.encode(encoded, GraphCompoundSceneDescriptor, {
    version: 2, theme: input.theme === "dark" ? 1 : input.theme === "light" || input.theme == null ? 0 : 0xffffffff,
    width: Number(input.width), height: Number(input.height), node_count: BigInt(n), edge_count: BigInt(e), title: pointer(title, "uint8_t *"), title_len: BigInt(title.length),
    x: f64Ptr(x), y: f64Ptr(y), sources: u64Ptr(sources), ...Object.fromEntries(Object.entries(planes).map(([name, value]) => [name, pointer(value, "void *")])),
    node_label_lengths: u32Ptr(nodeLengths), edge_label_lengths: e ? u32Ptr(edgeLengths) : null,
    label_payload: payload.length ? u8Ptr(payload) : null, label_payload_len: BigInt(payload.length), reserved: 0n,
  });
  const descriptor = koffi.as(encoded, "const void *");
  const needed = Number(xyGraphCompoundScene(descriptor, null, 0));
  if (!Number.isSafeInteger(needed) || needed <= 0) throw new Error(`invalid compound graph Scene input (${needed})`);
  const output = new Uint8Array(needed);
  if (Number(xyGraphCompoundScene(descriptor, u8Ptr(output), output.length)) !== needed) throw new Error("compound graph Scene changed between bounded copies");
  return output;
}

// Composed graph planes (#34) and their extents per node (n) / segment (m).
const COMPOSED_GRAPH_PLANES = {
  x: ["n", 1, "f64"], y: ["n", 1, "f64"], fill: ["n", 4, "u8"], stroke: ["n", 4, "u8"],
  stroke_width: ["n", 1, "f64"], diameter: ["n", 1, "f64"], symbol: ["n", 1, "u8"],
  opacity: ["n", 1, "f64"], halo: ["n", 4, "u8"], halo_diameter: ["n", 1, "f64"],
  node_label_plan: ["n", 5, "f64"], frames: ["n", 10, "f64"],
  x0: ["m", 1, "f64"], y0: ["m", 1, "f64"], x1: ["m", 1, "f64"], y1: ["m", 1, "f64"],
  segment_rgba: ["m", 4, "u8"], segment_width: ["m", 1, "f64"], segment_opacity: ["m", 1, "f64"],
  segment_halo: ["m", 4, "u8"], segment_halo_width: ["m", 1, "f64"], segment_body: ["m", 4, "u8"],
  segment_body_width: ["m", 1, "f64"], segment_dash: ["m", 2, "f64"], edge_ends: ["m", 7, "f64"],
  segment_label_plan: ["m", 5, "f64"],
};
// Optional chart text paint (straight RGBA8).
const COMPOSED_TEXT_RGBA_BYTES = 4;

/**
 * Rebuild a composed graph chart's static Scene from its composed-graph
 * planes (#34; Python `_native.graph_composed_scene`). `planes` holds the
 * descriptor planes (optional ones may be omitted), `node_labels` /
 * `segment_labels` (string or null per item), and `legend` rows
 * `[label, rgba, symbol]` with `legend_title`.
 */
function composedGraphDescriptor(base, planes) {
  const n = planes.x.length;
  const m = planes.x0.length;
  const arrays = {};
  for (const [name, [axis, stride, kind]] of Object.entries(COMPOSED_GRAPH_PLANES)) {
    if (planes[name] == null) continue;
    const value = kind === "u8" ? asU8Array(planes[name], name) : asF64Array(planes[name], name);
    // Rust reads the declared count: every plane must cover exactly its extent.
    if (value.length !== (axis === "n" ? n : m) * stride) {
      throw new RangeError(`composed graph plane ${JSON.stringify(name)} must hold ${(axis === "n" ? n : m) * stride} values`);
    }
    arrays[name] = value;
  }
  const textRgba = planes.text_rgba == null ? null : asU8Array(planes.text_rgba, "text_rgba");
  if (textRgba != null && textRgba.length !== COMPOSED_TEXT_RGBA_BYTES) {
    throw new RangeError(`composed graph plane "text_rgba" must hold ${COMPOSED_TEXT_RGBA_BYTES} values`);
  }
  const text = new TextEncoder();
  const chunks = [];
  const lengths = (values, count, name) => {
    if (values == null) return null;
    if (values.length !== count) throw new RangeError(`composed graph ${JSON.stringify(name)} must hold ${count} entries`);
    return Uint32Array.from(values, (value) => {
      if (value == null) return 0xffffffff;
      const bytes = text.encode(String(value));
      chunks.push(bytes);
      return bytes.length;
    });
  };
  const nodeLengths = lengths(planes.node_labels, n, "node_labels");
  const segmentLengths = lengths(planes.segment_labels, m, "segment_labels");
  const concat = (parts) => {
    const out = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
    let at = 0;
    for (const part of parts) { out.set(part, at); at += part.length; }
    return out;
  };
  const payload = concat(chunks);
  const legend = planes.legend ?? [];
  const legendNames = legend.map(([label]) => text.encode(String(label)));
  const legendPayload = concat(legendNames);
  const legendRgba = Uint8Array.from(legend.flatMap(([, rgba]) => [...rgba]));
  const legendSymbol = Uint8Array.from(legend, ([, , symbol]) => symbol);
  const legendLengths = Uint32Array.from(legendNames, (bytes) => bytes.length);
  const title = text.encode(String(planes.legend_title ?? ""));
  const legendLoc = text.encode(String(planes.legend_loc ?? ""));
  const baseBytes = base == null ? null : base instanceof Uint8Array ? base : Uint8Array.from(base);
  const ptr = (value) => (value != null && value.length ? pointer(value, "void *") : null);
  const encoded = Buffer.alloc(koffi.sizeof(ComposedGraphSceneDescriptor));
  koffi.encode(encoded, ComposedGraphSceneDescriptor, {
    version: 1, reserved0: 0, base: ptr(baseBytes), base_len: BigInt(baseBytes?.length ?? 0),
    node_count: BigInt(n), segment_count: BigInt(m),
    ...Object.fromEntries(Object.keys(COMPOSED_GRAPH_PLANES).map((name) => [name, ptr(arrays[name])])),
    node_label_lengths: ptr(nodeLengths), segment_label_lengths: ptr(segmentLengths),
    label_payload: ptr(payload), label_payload_len: BigInt(payload.length),
    legend_count: BigInt(legend.length), legend_title: ptr(title), legend_title_len: BigInt(title.length),
    legend_rgba: ptr(legendRgba), legend_symbol: ptr(legendSymbol), legend_label_lengths: ptr(legendLengths),
    legend_payload: ptr(legendPayload), legend_payload_len: BigInt(legendPayload.length),
    legend_loc: ptr(legendLoc), legend_loc_len: BigInt(legendLoc.length), text_rgba: ptr(textRgba), reserved: 0n,
  });
  // The views stay referenced for the lifetime of the returned descriptor.
  return {
    descriptor: koffi.as(encoded, "const void *"),
    keep: [encoded, baseBytes, arrays, nodeLengths, segmentLengths, payload, legendPayload, legendRgba, legendSymbol, legendLengths, title, legendLoc, textRgba],
  };
}

/**
 * The composed graph home view (#910; Python `_native.graph_home_domain`):
 * `[xLo, xHi, yLo, yHi]` in which every marker, halo, edge stroke, compound
 * frame, and home-view label fits the hidden-axis graph plot, or null to keep
 * the autorange.
 */
export function graphHomeDomain(planes, { viewport, baseX, baseY, title = "", padding = null }) {
  const { descriptor, keep } = composedGraphDescriptor(null, planes);
  const titleBytes = new TextEncoder().encode(String(title));
  const pad = padding == null ? null : Float64Array.from(padding, Number);
  const layout = Buffer.alloc(koffi.sizeof(GraphHomeLayout));
  koffi.encode(layout, GraphHomeLayout, {
    version: 1, reserved0: 0, viewport_width: Number(viewport[0]), viewport_height: Number(viewport[1]),
    padding: pad == null ? null : f64Ptr(pad), title: titleBytes.length ? u8Ptr(titleBytes) : null,
    title_len: BigInt(titleBytes.length), base_x_lo: Number(baseX[0]), base_x_hi: Number(baseX[1]),
    base_y_lo: Number(baseY[0]), base_y_hi: Number(baseY[1]),
  });
  const out = new Float64Array(4);
  const status = Number(xyGraphHomeDomain(descriptor, koffi.as(layout, "const void *"), f64Ptr(out)));
  keep.length;
  if (status < 0) throw new RangeError("invalid composed graph home-view input");
  return status === 1 ? null : [...out];
}

export function graphComposedScene(base, planes) {
  const { descriptor, keep } = composedGraphDescriptor(base, planes);
  const reason = new Uint32Array([1]);
  const needed = Number(xyGraphComposedScene(descriptor, null, 0, u32Ptr(reason)));
  if (!Number.isSafeInteger(needed) || needed <= 0 || needed >= Number.MAX_SAFE_INTEGER) {
    // Reason 2: the explicit legend does not fit the plot.
    throw new RangeError(reason[0] === 2 ? "XYG_STATIC_UNSUPPORTED_LEGEND_FOOTPRINT" : "invalid composed graph Scene input");
  }
  const output = new Uint8Array(needed);
  if (Number(xyGraphComposedScene(descriptor, u8Ptr(output), output.length, u32Ptr(reason))) !== needed) {
    throw new Error("composed graph Scene changed between bounded copies");
  }
  keep.length;
  return output;
}

export function graphSampleEdges(nEdges, budget) {
  const requested = toLength(budget, "budget");
  const out = new BigUint64Array(requested);
  if (requested === 0) {
    return out;
  }
  const kept = xyGraphSampleEdges(toU64(nEdges, "nEdges"), toU64(requested, "budget"), u64Ptr(out));
  return out.subarray(0, Number(kept));
}

export function graphBuildCsr(nNodes, sources, targets, opts = {}) {
  const nodeCount = toLength(nNodes, "nNodes");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  const directed = opts.directed ?? true;
  const cap = Math.max(sourceArray.length * (directed ? 1 : 2), 1);
  const offsets = new BigUint64Array(nodeCount + 1);
  const neighbors = new BigUint64Array(cap);
  const neighborLen = new BigUint64Array(1);
  const code = xyGraphBuildCsr(
    toU64(nodeCount, "nNodes"),
    toU64(sourceArray.length, "nEdges"),
    u64Ptr(sourceArray),
    u64Ptr(targetArray),
    directed ? 1 : 0,
    u64Ptr(offsets),
    u64Ptr(neighbors),
    toU64(cap, "neighborsCap"),
    u64Ptr(neighborLen),
  );
  if (code !== 0) {
    throw new Error(`xyg_graph_build_csr failed with code ${code}`);
  }
  return { offsets, neighbors: neighbors.subarray(0, Number(neighborLen[0])) };
}

export function sankeyLayout(nNodes, sources, targets, values, opts = {}) {
  const nodeCount = toLength(nNodes, "nNodes");
  const sourceArray = asU64Array(sources, "sources");
  const targetArray = asU64Array(targets, "targets");
  const valueArray = asF64Array(values, "values");
  requireEqualLength(sourceArray, targetArray, "sources", "targets");
  requireEqualLength(sourceArray, valueArray, "sources", "values");
  const linkCount = sourceArray.length;
  const x0 = new Float64Array(nodeCount);
  const y0 = new Float64Array(nodeCount);
  const x1 = new Float64Array(nodeCount);
  const y1 = new Float64Array(nodeCount);
  const layer = new Uint32Array(nodeCount);
  const nodeValue = new Float64Array(nodeCount);
  const sourceY0 = new Float64Array(linkCount);
  const sourceY1 = new Float64Array(linkCount);
  const targetY0 = new Float64Array(linkCount);
  const targetY1 = new Float64Array(linkCount);
  const layers = new Uint32Array(1);
  const errNodes = new BigUint64Array(Math.max(nodeCount, 1));
  const errN = new BigUint64Array(1);
  const code = xySankeyLayout(
    toU64(nodeCount, "nNodes"),
    toU64(linkCount, "nLinks"),
    u64Ptr(sourceArray),
    u64Ptr(targetArray),
    f64Ptr(valueArray),
    Number(opts.nodeWidth ?? 0.02),
    Number(opts.nodePadding ?? 0.02),
    sankeyAlignId(opts.align ?? "justify"),
    toU32(opts.iterations ?? 6, "opts.iterations"),
    f64Ptr(x0),
    f64Ptr(y0),
    f64Ptr(x1),
    f64Ptr(y1),
    u32Ptr(layer),
    f64Ptr(nodeValue),
    f64Ptr(sourceY0),
    f64Ptr(sourceY1),
    f64Ptr(targetY0),
    f64Ptr(targetY1),
    u32Ptr(layers),
    u64Ptr(errNodes),
    u64Ptr(errN),
  );
  const detail = errNodes.slice(0, Number(errN[0]));
  if (code === -2) {
    throw new SankeyLayoutError(code, detail, "sankey links form a cycle");
  }
  if (code === -3) {
    throw new SankeyLayoutError(code, detail, "sankey nodePadding leaves no room");
  }
  if (code !== 0) {
    throw new Error(`xyg_sankey_layout failed with code ${code}`);
  }
  return {
    x0,
    y0,
    x1,
    y1,
    layer,
    value: nodeValue,
    sourceY0,
    sourceY1,
    targetY0,
    targetY1,
    layers: layers[0],
  };
}

export function graphLayoutId(layout) {
  if (typeof layout === "number") {
    return toU32(layout, "layout");
  }
  const key = String(layout).trim().toLowerCase();
  const id = GRAPH_LAYOUT_IDS[key];
  if (id == null) {
    throw new Error(`unknown graph layout ${JSON.stringify(layout)}; expected one of ${Object.keys(GRAPH_LAYOUT_IDS).join(", ")}`);
  }
  return id;
}

export function sankeyAlignId(align) {
  if (typeof align === "number") {
    return toU32(align, "align");
  }
  const key = String(align).trim().toLowerCase();
  const id = SANKEY_ALIGN_IDS[key];
  if (id == null) {
    throw new Error(`unknown sankey align ${JSON.stringify(align)}; expected one of ${Object.keys(SANKEY_ALIGN_IDS).join(", ")}`);
  }
  return id;
}

function requireEqualLength(a, b, aName, bName) {
  if (a.length !== b.length) {
    throw new RangeError(`${aName} and ${bName} must have equal length`);
  }
}

function asU64Array(value, name) {
  if (value instanceof BigUint64Array) {
    return value;
  }
  if (value == null) {
    return new BigUint64Array(0);
  }
  return BigUint64Array.from(value, (item) => toU64(item, name));
}

function asI64Array(value, name) {
  if (value instanceof BigInt64Array) {
    return value;
  }
  if (value == null) {
    return new BigInt64Array(0);
  }
  return BigInt64Array.from(value, (item) => {
    if (typeof item === "bigint") {
      return item;
    }
    if (!Number.isInteger(item) || !Number.isSafeInteger(item)) {
      throw new RangeError(`${name} must contain safe integers or bigints`);
    }
    return BigInt(item);
  });
}

function asI32Array(value, name) {
  if (value instanceof Int32Array) {
    return value;
  }
  if (value == null) {
    return new Int32Array(0);
  }
  return Int32Array.from(value, (item) => {
    const number = Number(item);
    if (!Number.isInteger(number) || number < -2147483648 || number > 2147483647) {
      throw new RangeError(`${name} must contain int32 values`);
    }
    return number;
  });
}

function asU8Array(value, name) {
  if (value instanceof Uint8Array) {
    return value;
  }
  if (value == null) {
    return new Uint8Array(0);
  }
  return Uint8Array.from(value, (item) => {
    const number = Number(item);
    if (!Number.isInteger(number) || number < 0 || number > 255) {
      throw new RangeError(`${name} must contain uint8 values`);
    }
    return number;
  });
}

function asU32Array(value, name) {
  if (value instanceof Uint32Array) {
    return value;
  }
  if (value == null) {
    return new Uint32Array(0);
  }
  return Uint32Array.from(value, (item) => {
    if (typeof item !== "number") {
      throw new RangeError(`${name} must contain exact uint32 numbers`);
    }
    const number = Number(item);
    if (!Number.isInteger(number) || number < 0 || number > 0xffffffff) {
      throw new RangeError(`${name} must contain uint32 values`);
    }
    return number;
  });
}

function asF64Array(value, name) {
  if (value instanceof Float64Array) {
    return value;
  }
  if (value == null) {
    return new Float64Array(0);
  }
  return Float64Array.from(value, (item) => {
    const number = Number(item);
    if (!Number.isFinite(number)) {
      throw new TypeError(`${name} must contain only finite numbers`);
    }
    return number;
  });
}

function toU64(value, name) {
  if (typeof value === "bigint") {
    if (value < 0n || value > U64_MAX) {
      throw new RangeError(`${name} must fit in uint64`);
    }
    return value;
  }
  if (!Number.isInteger(value) || value < 0 || !Number.isSafeInteger(value)) {
    throw new RangeError(`${name} must be a non-negative safe integer or bigint`);
  }
  return BigInt(value);
}

function toI64(value, name) {
  let converted;
  if (typeof value === "bigint") {
    converted = value;
  } else {
    if (typeof value !== "number" || !Number.isSafeInteger(value)) {
      throw new RangeError(`${name} must be a safe integer or bigint fitting in int64`);
    }
    converted = BigInt(value);
  }
  if (converted < I64_MIN || converted > I64_MAX) {
    throw new RangeError(`${name} must fit in int64`);
  }
  return converted;
}

function toStrictU32(value, name) {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > 0xffff_ffff) {
    throw new RangeError(`${name} must be a uint32 number`);
  }
  return value;
}

function toI32(value, name) {
  if (
    typeof value !== "number"
    || !Number.isInteger(value)
    || value < -0x8000_0000
    || value > 0x7fff_ffff
  ) {
    throw new RangeError(`${name} must be an int32 number`);
  }
  return value;
}

function toStrictBool(value, name) {
  if (typeof value !== "boolean") {
    throw new TypeError(`${name} must be a boolean`);
  }
  return value;
}

function toLength(value, name) {
  const asBigInt = toU64(value, name);
  if (asBigInt > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new RangeError(`${name} is too large for a JavaScript TypedArray length`);
  }
  return Number(asBigInt);
}

function toU32(value, name) {
  if (!Number.isInteger(Number(value)) || Number(value) < 0 || Number(value) > 0xffff_ffff) {
    throw new RangeError(`${name} must fit in uint32`);
  }
  return Number(value);
}

function u64Ptr(view) {
  return pointer(view, "uint64_t *");
}

function u32Ptr(view) {
  return pointer(view, "uint32_t *");
}

function u8Ptr(view) {
  return pointer(view, "uint8_t *");
}

function i32Ptr(view) {
  return pointer(view, "int32_t *");
}

function f64Ptr(view) {
  return pointer(view, "double *");
}

function f32Ptr(view) {
  return pointer(view, "float *");
}
