/** Thin Node adapter for the versioned Rust-owned canonical scene IR. */
import {
  pointer,
  xySceneAxisTicks,
  xySceneTickLabelLayout,
  xyTickWindow,
  xyTickWindowFilter,
  xyTickFormat,
  xyTickResolvePacked,
  xyLegendBoxLayout,
  xyTextBlockMeasure,
  xyTextBlockRotatedExtent,
  xyYTickLabelExtent,
  xyYAxisLeftRoom,
  xyXAxisTitleRoom,
  xyXTickLabelRoom,
  xyXTickLabelEdgeRooms,
  xyCompatIsCompact,
  xyCompatDefaultPadding,
  xyCompatTitleWrapWidth,
  xyCompatTitleRoom,
  xyCompatXAxisSideRoom,
  xyCompatColorbarExtra,
  xyCompatRightYRoom,
  xyPolarLegendRoom,
  xyPolarLegendReserve,
  xyPolarLabelRoom,
  xyPolarLayout,
  xyPolarProject,
  xyPolarWedgePoints,
  xyPolarHeatmapInverseMap,
  xyRecutPolarPlot,
  xyTightLayoutSolve,
  xyCompatCombinePlot,
  xyTightLayoutFigureExtra,
  xySceneBatchEncode,
  xySceneBrowserPainter,
  xyScenePackAnnotations,
  xyScenePackColorbar,
  xyScenePackNamedColorbar,
  xyScenePackLegend,
  xyScenePlotLayout,
  xyScenePublicExportReason,
  xySceneFigureSupportReason,
  xyScenePackProduct,
  xyScenePackProductFacts,
  xyScenePackAnnotationFacts,
  xyScenePackSceneExtras,
  xyScenePackSceneExtrasFromSidecars,
  xyScenePackDensityGrid,
  xyScenePackPublicExport,
  xyScenePackFigureChrome,
  xyScenePackFigureChromeFromSidecars,
  xyScenePackTraceCompile,
  xyScenePackTraceAttach,
  xyScenePackTraceRows,
  xyScenePackTraceSidecars,
  xyScenePackStyleSidecars,
  xySceneSpliceAnnotations,
  xySceneEncodeAssembled,
  xySceneEncodeAssembledFromSidecars,
  xySceneEncodeProduct,
  xyScenePackAnnotationMarks,
  xySceneRasterCommands,
  xySceneStaticExport,
  xyStaticAnnotationStyle,
  xyStaticDocumentExport,
  xyStaticDocumentLabels,
  xyStaticDocumentLayout,
  xyStaticDocumentLegend,
  xyStaticLegendFit,
  xyStaticPanelChrome,
  xySceneResolveChromeStyle,
  xySceneResolveMarkStyles,
  xySceneScaleMap,
  xySceneScatterSvg,
  xySceneSupportReason,
  xySceneSvg,
  xySvgToPdf,
  xyEncodeJpeg,
  xyEncodePng,
  xyEncodeWebp,
  xySceneVersion,
  polarAbiInputPointer,
  xyFoldCodesU8,
  xyDefaultPngExportScale,
} from "./native.js";

/** Default device-pixel ratio for raster PNG export; sourced from Rust (ABI 370). */
const DEFAULT_PNG_EXPORT_SCALE = Number(xyDefaultPngExportScale());
import { asF64Array, DEFAULT_PALETTE, graphDefaultEdgeColor, colormapStopBytes, COLOR2_CLASS_TO_CODE, f64Ptr, legendBestLoc, legendNormalize, sceneDashAdmit, sceneLinecapAdmit, sceneMarkerPathAdmit, sceneAnnotationStyleAdmit, sceneArraysEqual, sceneConstantColorAdmit, sceneChannelConstantCss, sceneHiddenOrPerItemAdmit, sceneRibbonColor2Classify, sceneScatterPaintChannelAdmit, sceneTickLabelStrategy, sceneTickAnchor, sceneFillGradientAdmit, sceneFiniteAll, sceneParseLinearGradient, sceneRectExtraFlags, sceneGradientDir, sceneLinearGradientPrefix, sceneGradientSpace, sceneGradientSolidCss, sceneGradientSpecPack, sceneMarkerBlobPack, sceneXytcSymbolIntPack, sceneXytcColor2FlagsPack, sceneXytcMetaFlagsPack, sceneXytcPaintPresencePack, sceneXytcDashPatternPack, sceneXytcOpacityPack, sceneXytcHexPitchPack, sceneXytcStrokePerimeterPack, sceneXytcNumericStylePack, sceneXytcColorChannelPack, sceneXytcRadiusPack, sceneXytcFigurePlan, sceneXytcTraceDispatchPlan, sceneXytcTracePack, sceneXytaFigurePlan, sceneXytaTraceDispatchPlan, sceneXytaTracePack, sceneFigureSupportFigurePlan, sceneFigureSupportTraceDispatchPlan, scenePublicExportFigurePlan, scenePublicExportTraceDispatchPlan, sceneXyafAnnotationDispatchPlan, sceneXycfFigurePlan, sceneXyclFigurePlan, sceneXynmFigurePlan, scenePolarFigurePlan, sceneEncodeProductAttachPlan, sceneHexbinReduceAdmit, sceneCurveClassify, sceneMarkerGlyphAdmit, sceneKindAdmit, sceneKindClass, sceneHexbinColormapPlaneAdmit, sceneHexbinPitchAdmit, sceneHexbinRgbaPlaneAdmit, sceneHeatmapExtentAdmit, sceneHeatmapColormapAdmit, sceneHeatmapShapeAdmit, sceneMeshPaintPlaneAdmit, sceneItemApplyOpacity, sceneItemWidthsAdmit, sceneItemFillT, sceneXytaColormapPack, sceneXyhfColormapPack, shouldUseDensity, u32Ptr, u8Ptr, colormapLutRgba8, colormapNamedStops, colormapRgba, densityMeanColorWireAdmit } from "./encode.js";
import { clipQuantizeU8, cssColorRgba8, paletteRowsRgba8, quantizeUnitU8 } from "./color.js";
import { graphComposedScene, graphHomeDomain } from "./abi.js";
import { sceneChromePack, sceneFigureSupportMaterialize, scenePolarInputPack, sceneXyafBulkPack, sceneXytaTraceObservationsMaterialize, sceneXyTcTraceObservationsMaterialize } from "./sceneBulkNative.js";

const USIZE_MAX_64 = (1n << 64n) - 1n;
const MAX_SCENE_MARKS = 2_000_000;
const MAX_SCENE_STYLES = 65_536;
const MAX_SCENE_TEXT_BYTES = 4_096;
const SYMBOL_CODES = new Map([
  "circle", "square", "diamond", "triangle", "cross", "hexagon", "pentagon", "star",
  "triangle_down", "triangle_left", "triangle_right", "x", "point", "pixel",
  "thin_diamond", "plus_line", "x_line", "horizontal_line", "vertical_line",
].map((name, code) => [name, code]));

function columnArg(column) {
  if (column == null || column.length === 0) return { ptr: 0, n: 0, keep: null };
  const arr = asF64Array(column, "trace column");
  return { ptr: f64Ptr(arr), n: arr.length, keep: arr };
}

function decodePackedRows(out, code) {
  if (code === -5) throw new RangeError("Scene v12 does not yet encode missing-data breaks or nonfinite coordinates");
  if (code === -6) throw new RangeError("Scene v12 does not support product kind");
  if (code < 0) throw new RangeError("invalid scene trace packing");
  const view = new DataView(out.buffer, out.byteOffset, Math.max(code, 0) * 56);
  const rows = { kinds: [], stableIds: [], styleRefs: [], diameter: [], symbols: [], expansion: [], x0: [], y0: [], x1: [], y1: [] };
  for (let index = 0; index < code; index += 1) {
    const at = index * 56;
    rows.kinds.push(out[at]);
    rows.symbols.push(out[at + 1]);
    rows.expansion.push(out[at + 2]);
    rows.styleRefs.push(view.getUint32(at + 4, true));
    rows.stableIds.push(view.getBigUint64(at + 8, true));
    rows.diameter.push(view.getFloat64(at + 16, true));
    rows.x0.push(view.getFloat64(at + 24, true));
    rows.y0.push(view.getFloat64(at + 32, true));
    rows.x1.push(view.getFloat64(at + 40, true));
    rows.y1.push(view.getFloat64(at + 48, true));
  }
  return rows;
}

const XYHF_HAS_NAMED_CMAP = 1 << 5;
const XYHF_HAS_STOPS = 1 << 6;

function packProduct({
  kind, flags = 0, stepMode = 0, symbol = 0, styleRef = 0, traceId = 0,
  diameter = 0, extra0 = 0, extra1 = 0, x = null, y = null, x0 = null, y0 = null,
  x1 = null, y1 = null, base = null,
}) {
  const args = [x, y, x0, y0, x1, y1, base].map(columnArg);
  const packedId = asU64(traceId, "stableIds value");
  const nRows = Math.max(Math.max(...args.map((column) => column.n), 1) * 2, 2);
  const out = new Uint8Array(nRows * 56);
  const encoded = new TextEncoder().encode(String(kind));
  const code = xyScenePackProduct(
    encoded.length ? u8Ptr(encoded) : 0, BigInt(encoded.length),
    flags, stepMode, symbol, styleRef, packedId,
    Number(diameter), Number(extra0), Number(extra1),
    args[0].ptr, BigInt(args[0].n),
    args[1].ptr, BigInt(args[1].n),
    args[2].ptr, BigInt(args[2].n),
    args[3].ptr, BigInt(args[3].n),
    args[4].ptr, BigInt(args[4].n),
    args[5].ptr, BigInt(args[5].n),
    args[6].ptr, BigInt(args[6].n),
    u8Ptr(out), BigInt(out.length),
  );
  if (code === -6) throw new RangeError(`Scene v12 does not support product kind ${JSON.stringify(kind)}`);
  return decodePackedRows(out, code);
}

function curveIsSmooth(style) {
  const curve = style?.curve;
  return curve != null && String(curve).trim().toLowerCase() === "smooth";
}

function packXyPk({
  kind, styleRef = 0, coords = 0, symbol = 0, authoredStep = 0, facts = 0,
  traceId = 0, diameter = 0, hexDx = 0, hexDy = 0, gridRows = 0, gridCols = 0,
}) {
  const name = new TextEncoder().encode(String(kind));
  const out = new Uint8Array(64 + name.length);
  const view = new DataView(out.buffer);
  out[0] = 88; out[1] = 89; out[2] = 80; out[3] = 75; // XYPK
  view.setUint32(4, 1, true);
  view.setUint32(8, styleRef >>> 0, true);
  out[12] = coords;
  out[13] = symbol;
  out[14] = authoredStep;
  out[15] = facts;
  view.setBigUint64(16, asU64(traceId, "stableIds value"), true);
  view.setFloat64(24, Number(diameter), true);
  view.setFloat64(32, Number(hexDx), true);
  view.setFloat64(40, Number(hexDy), true);
  view.setFloat64(48, Number(gridRows), true);
  view.setFloat64(56, Number(gridCols), true);
  out.set(name, 64);
  return out;
}

function packProductFacts({
  facts, x = null, y = null, x0 = null, y0 = null, x1 = null, y1 = null, base = null,
}) {
  const args = [x, y, x0, y0, x1, y1, base].map(columnArg);
  const nRows = Math.max(Math.max(...args.map((column) => column.n), 1) * 2, 2);
  const out = new Uint8Array(nRows * 56);
  const payload = facts instanceof Uint8Array ? facts : new Uint8Array(facts ?? []);
  const code = xyScenePackProductFacts(
    payload.length ? u8Ptr(payload) : 0, BigInt(payload.length),
    args[0].ptr, BigInt(args[0].n),
    args[1].ptr, BigInt(args[1].n),
    args[2].ptr, BigInt(args[2].n),
    args[3].ptr, BigInt(args[3].n),
    args[4].ptr, BigInt(args[4].n),
    args[5].ptr, BigInt(args[5].n),
    args[6].ptr, BigInt(args[6].n),
    u8Ptr(out), BigInt(out.length),
  );
  if (code === -6) throw new RangeError("Scene v12 does not support product kind");
  return decodePackedRows(out, code);
}

const XYAF_KIND_CODES = { text: 0, arrow: 1, callout: 2, rule: 3, band: 4, marker: 5 };
const XYAF_FACT_HAS_WRAP = 1 << 0;
const XYAF_FACT_HAS_TEXT = 1 << 1;
const XYAF_FACT_HAS_DX = 1 << 3;
const XYAF_FACT_HAS_DY = 1 << 4;
const XYAF_FACT_HAS_X = 1 << 5;
const XYAF_FACT_HAS_Y = 1 << 6;
const XYAF_FACT_HAS_X0 = 1 << 7;
const XYAF_FACT_HAS_Y0 = 1 << 8;
const XYAF_FACT_HAS_X1 = 1 << 9;
const XYAF_FACT_HAS_Y1 = 1 << 10;
const XYAF_FACT_HAS_VALUE = 1 << 11;
const XYAF_FACT_HAS_START = 1 << 12;
const XYAF_FACT_HAS_END = 1 << 13;
const XYAF_FACT_HAS_SIZE = 1 << 14;
const XYAF_FACT_HAS_AXIS = 1 << 15;
const XYAF_FACT_HAS_SYMBOL = 1 << 16;
const XYAF_FACT_HAS_ANCHOR = 1 << 17;
const XYAF_FACT_HAS_ROTATION = 1 << 18;
const XYAF_STYLE_COLOR = 1 << 0;
const XYAF_STYLE_OPACITY = 1 << 1;
const XYAF_STYLE_WIDTH = 1 << 2;
const XYAF_STYLE_DASH = 1 << 3;
const XYAF_STYLE_LINECAP = 1 << 4;
const XYAF_STYLE_STROKE_COLOR = 1 << 5;
const XYAF_STYLE_STROKE_WIDTH = 1 << 6;
const XYAF_STYLE_LABEL_COLOR = 1 << 7;
const XYAF_STYLE_LABEL_OPACITY = 1 << 8;
const XYAF_STYLE_LABEL_BACKGROUND = 1 << 9;
const XYAF_STYLE_LABEL_BORDER_COLOR = 1 << 10;
const XYAF_STYLE_LABEL_BORDER_WIDTH = 1 << 11;

function annotationHasMarkup(annotation) {
  if (annotation == null || typeof annotation !== "object") return false;
  if (annotation.markup != null && annotation.markup !== "") return true;
  const style = annotation.style ?? {};
  return style != null && typeof style === "object" && style.markup != null && style.markup !== "";
}

const ANNOTATION_TYPOGRAPHY_STYLE_KEYS = new Set([
  "font_family", "font_size", "font_weight", "font_style",
  "fontFamily", "fontSize", "fontWeight", "fontStyle",
]);

function annotationHasCustomTypography(annotation) {
  if (annotation == null || typeof annotation !== "object") return false;
  const style = annotation.style != null && typeof annotation.style === "object" ? annotation.style : {};
  for (const key of ANNOTATION_TYPOGRAPHY_STYLE_KEYS) {
    if (style[key] != null && style[key] !== "" && style[key] !== false) return true;
    if (annotation[key] != null && annotation[key] !== "" && annotation[key] !== false) return true;
  }
  return false;
}

function xyafDispatch(annotation) {
  const kind = String(annotation.kind ?? "");
  const style = { ...(annotation.style ?? {}) };
  const authoredWrap = ["text", "callout"].includes(kind) && Object.hasOwn(annotation, "wrap");
  const layoutText = kind === "text" && ["dx", "dy", "anchor", "rotation"].some((key) => Object.hasOwn(annotation, key));
  const dispatch = sceneXyafAnnotationDispatchPlan({
    kind,
    authored_wrap: authoredWrap,
    layout_text: layoutText,
  });
  const wrapped = Boolean(dispatch.wrapped);
  const labelled = annotation.text != null && annotation.text !== "";
  const kindLabel = wrapped ? "wrapped" : kind;
  return { kind, style, wrapped, labelled, kindLabel };
}

function validateXyafAnnotationStyle(annotation) {
  const { kind, style, wrapped, labelled } = xyafDispatch(annotation);
  const skipStyle = new Set(["markup", ...ANNOTATION_TYPOGRAPHY_STYLE_KEYS]);
  if (["text", "marker"].includes(kind)) skipStyle.add("rotation");
  const unsupported = Object.entries(style)
    .filter(([key, value]) => value != null && !skipStyle.has(key) && !sceneAnnotationStyleAdmit(kind, wrapped, labelled, key))
    .map(([key]) => key)
    .sort();
  if (unsupported.length) {
    if (wrapped) throw new RangeError(`Scene wrapped annotations do not encode ${JSON.stringify(unsupported)}`);
    if (kind === "arrow") throw new RangeError(`Scene arrow style does not encode ${JSON.stringify(unsupported)}`);
    if (kind === "callout") throw new RangeError(`Scene callout style does not encode ${JSON.stringify(unsupported)}`);
    if (kind === "text") throw new RangeError("Scene v23 text annotations support only color, opacity, label_background, and label_border_*");
    throw new RangeError(`Scene v12 ${kind} annotation style does not encode ${JSON.stringify(unsupported)}`);
  }
}

function validateXyafAnnotationValues(annotation) {
  const { kind, style, wrapped, labelled, kindLabel } = xyafDispatch(annotation);
  if (kind === "arrow" && labelled) {
    throw new RangeError("Scene arrows do not encode text or class_name");
  }
  const required = {
    arrow: [
      ["x0", "arrow x0"],
      ["y0", "arrow y0"],
      ["x1", "arrow x1"],
      ["y1", "arrow y1"],
    ],
    callout: [["x", "callout x"], ["y", "callout y"]],
    text: [["x", "text x"], ["y", "text y"]],
    rule: [["value", "rule value"]],
    band: [["start", "band start"], ["end", "band end"]],
    marker: [["x", "marker x"], ["y", "marker y"]],
  }[kind] ?? [];
  for (const [key, label] of (wrapped ? [["x", "wrapped x"], ["y", "wrapped y"]] : required)) {
    annotationNumber(annotation, key, null, label);
  }
  for (const [key, label] of [
    ["dx", wrapped ? "wrapped dx" : "callout dx"],
    ["dy", wrapped ? "wrapped dy" : "callout dy"],
    ["size", "marker size"],
  ]) {
    if (Object.hasOwn(annotation, key)) {
      const value = annotationNumber(annotation, key, null, label);
      if (kind === "marker" && key === "size" && (!Number.isFinite(value) || value <= 0)) {
        throw new RangeError("Scene v12 marker annotation size must be finite and positive");
      }
    }
  }
  if (kind === "text" && Object.hasOwn(annotation, "rotation")) {
    const rotation = annotationNumber(annotation, "rotation", null, "text rotation");
    if (!Number.isFinite(rotation)) throw new RangeError("Scene v16 text annotation rotation must be finite");
  }
  if (kind === "marker" && Object.hasOwn(annotation, "rotation")) {
    const rotation = annotationNumber(annotation, "rotation", null, "marker rotation");
    if (!Number.isFinite(rotation)) throw new RangeError("Scene v16 marker annotation rotation must be finite");
  }
  if (kind === "rule" || kind === "band") {
    const axisName = annotation.axis;
    if (axisName !== "x" && axisName !== "y") {
      throw new RangeError(`Scene v12 ${kind} annotation axis must be 'x' or 'y'`);
    }
  }
  if (kind === "marker" && Object.hasOwn(annotation, "symbol")) {
    annotationSymbolCode(annotation.symbol);
  }
  if (Object.hasOwn(annotation, "anchor") || kind === "callout" || wrapped) {
    const anchorName = annotation.anchor ?? "start";
    if (!["start", "middle", "end"].includes(anchorName)) {
      throw new RangeError(
        wrapped
          ? "Scene wrapped annotation anchor must be start, middle, or end"
          : "Scene callout anchor must be start, middle, or end",
      );
    }
  }
  for (const key of ["color", "stroke_color", "label_color", "label_background", "label_border_color"]) {
    if (Object.hasOwn(style, key)) {
      annotationColor(style, key, "", `${kindLabel} ${key.replaceAll("_", " ")}`);
    }
  }
  if (Object.hasOwn(style, "opacity")) {
    const opacity = annotationNumber(style, "opacity", null, `${kindLabel} opacity`);
    if (!Number.isFinite(opacity) || opacity < 0 || opacity > 1) {
      if (kind === "arrow") throw new RangeError("Scene arrow opacity must be in [0, 1] and width must be positive");
      if (wrapped) throw new RangeError("Scene wrapped annotation opacity must be in [0, 1]");
      if (kind === "callout") throw new RangeError("Scene callout opacity must be in [0, 1] and width must be positive");
      throw new RangeError(`Scene v12 ${kind} annotation opacity must be finite and in [0, 1]`);
    }
  }
  if (Object.hasOwn(style, "width")) {
    const width = annotationNumber(style, "width", null, `${kindLabel} width`);
    if ((kind === "arrow" || kind === "callout") && (!Number.isFinite(width) || width <= 0)) {
      throw new RangeError(
        kind === "arrow"
          ? "Scene arrow opacity must be in [0, 1] and width must be positive"
          : "Scene callout opacity must be in [0, 1] and width must be positive",
      );
    }
    if (kind === "rule" && (!Number.isFinite(width) || width <= 0)) {
      throw new RangeError("Scene v12 rule annotation width must be finite and nonnegative");
    }
  }
  if (Object.hasOwn(style, "stroke_width")) {
    const strokeWidth = annotationNumber(style, "stroke_width", null, `${kind} width`);
    if (!Number.isFinite(strokeWidth) || strokeWidth < 0) {
      throw new RangeError(`Scene v12 ${kind} annotation width must be finite and nonnegative`);
    }
  }
  if (Object.hasOwn(style, "label_opacity")) {
    const labelOpacity = annotationNumber(style, "label_opacity", null, `${kind} label opacity`);
    if (!Number.isFinite(labelOpacity) || labelOpacity < 0 || labelOpacity > 1) {
      throw new RangeError(`Scene v16 ${kind} annotation label opacity must be finite and in [0, 1]`);
    }
  }
  if (Object.hasOwn(style, "label_border_width")) {
    const borderWidth = annotationNumber(style, "label_border_width", null, `${kindLabel} label border width`);
    if (!Number.isFinite(borderWidth) || borderWidth <= 0) {
      throw new RangeError("Scene v23 label border width must be positive and finite");
    }
  }
}

function raiseXyafBulkError(error, annotations) {
  const code = Number(error.code ?? 0);
  const index = Number(error.index ?? 0);
  const annotation = annotations[index] ?? {};
  const kind = String(annotation.kind ?? "");
  const style = { ...(annotation.style ?? {}) };
  if (code === -3) {
    throw new RangeError(`Scene v12 annotations support rule, band, and unlabeled marker only; ${JSON.stringify(kind)} is deferred`);
  }
  if (code === -7) {
    throw new RangeError("Scene arrows do not encode text or class_name");
  }
  if (code === -5) {
    if (kind === "callout") throw new RangeError("Scene callouts require nonempty NUL-free text");
    if (kind === "text") throw new RangeError("Scene v16 text annotations require nonempty NUL-free text");
    throw new RangeError("Scene v16 annotation labels require nonempty NUL-free text");
  }
  if (code === -4) {
    if (kind === "text") {
      throw new RangeError("Scene v23 text annotations support only color, opacity, label_background, and label_border_*");
    }
    throw new RangeError(`Scene v12 ${kind} annotation style does not encode unsupported keys`);
  }
  if (code === -8) throw new RangeError("Scene v12 rule annotation dash is not a constant pattern");
  if (code === -9) throw new RangeError("Scene v12 rule annotation linecap is not a Scene cap");
  if (code === -10) {
    const symbolName = String(annotation.symbol ?? "circle");
    throw new RangeError(`Scene v12 does not support marker symbol ${JSON.stringify(symbolName)}`);
  }
  if (code === -11) throw new RangeError("Scene callout anchor must be start, middle, or end");
  if (code === -12) throw new RangeError("Scene v23 label border requires color and width");
  if (code === -13) throw new RangeError(`Scene v12 ${kind} annotation axis must be 'x' or 'y'`);
  if (code === -6) {
    if (Object.hasOwn(style, "label_opacity")) {
      throw new RangeError(`Scene v16 ${kind} annotation label opacity must be finite and in [0, 1]`);
    }
    if (Object.hasOwn(style, "opacity")) {
      throw new RangeError(`Scene v12 ${kind} annotation opacity must be finite and in [0, 1]`);
    }
    if (Object.hasOwn(style, "label_border_width")) {
      throw new RangeError("Scene v23 label border width must be positive and finite");
    }
    if (Object.hasOwn(style, "width") && kind === "rule") {
      throw new RangeError("Scene v12 rule annotation width must be finite and nonnegative");
    }
    throw new RangeError(`Scene v12 annotation values are invalid at index ${index}`);
  }
  throw error;
}

function packXyAfBulk(annotations) {
  if (!annotations.length) return new Uint8Array();
  const normalized = annotations.map((annotation) => {
    const ann = { ...annotation };
    const kind = ann.kind;
    const style = { ...(ann.style ?? {}) };
    if (["text", "marker"].includes(kind) && !Object.hasOwn(ann, "rotation") && style.rotation != null) {
      ann.rotation = style.rotation;
    }
    validateXyafAnnotationStyle(ann);
    validateXyafAnnotationValues(ann);
    return ann;
  });
  try {
    return sceneXyafBulkPack(normalized);
  } catch (error) {
    raiseXyafBulkError(error, normalized);
  }
}

function packXyAf(annotation, index) {
  annotation = { ...annotation };
  const kind = annotation.kind;
  const style = { ...(annotation.style ?? {}) };
  if (["text", "marker"].includes(kind) && !Object.hasOwn(annotation, "rotation") && style.rotation != null) {
    annotation.rotation = style.rotation;
  }
  return sceneXyafBulkPack([annotation], { indices: [Number(index)] });
}

function packAnnotationFacts(facts, styleRefBase, xDomain, yDomain) {
  const source = facts instanceof Uint8Array ? facts : new Uint8Array(facts ?? []);
  if (!source.length) return new Uint8Array();
  const out = new Uint8Array(Math.max(65536, source.length * 4));
  const code = xyScenePackAnnotationFacts(
    u8Ptr(source),
    BigInt(source.length),
    styleRefBase >>> 0,
    Number(xDomain[0]),
    Number(xDomain[1]),
    Number(yDomain[0]),
    Number(yDomain[1]),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -5) throw new RangeError("Scene annotation geometry must be finite");
  if (code === -6) throw new RangeError("Scene annotations require nonempty NUL-free text");
  if (code === -7) throw new RangeError("Scene v23 label border requires label_background");
  if (code === -3) throw new RangeError("Scene annotations are limited to 128 entries");
  if (code < 0) throw new RangeError("invalid scene annotation packing");
  return out.subarray(0, code);
}

function packTraceRowBytes(attached, columns) {
  const attachedBytes = attached instanceof Uint8Array ? attached : new Uint8Array();
  const columnsBytes = columns instanceof Uint8Array ? columns : new Uint8Array();
  let capacity = Math.max(65536, Math.floor(columnsBytes.length / 8) * 2 * 56 + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xyScenePackTraceRows(
      attachedBytes.length ? u8Ptr(attachedBytes) : 0,
      BigInt(attachedBytes.length),
      columnsBytes.length ? u8Ptr(columnsBytes) : 0,
      BigInt(columnsBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code < 0) {
      const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      raiseTraceRows(code, failing);
    }
    return out.subarray(0, code * 56);
  }
  raiseTraceRows(-4, 0);
}

function packAnnotationMarks(rowBytes, xDomain, yDomain) {
  const source = rowBytes instanceof Uint8Array ? rowBytes : new Uint8Array(rowBytes ?? []);
  const nIn = Math.floor(source.length / 40);
  const out = new Uint8Array(Math.max(nIn * 2, 1) * 56);
  const code = xyScenePackAnnotationMarks(
    source.length ? u8Ptr(source) : 0,
    BigInt(source.length),
    Number(xDomain[0]),
    Number(xDomain[1]),
    Number(yDomain[0]),
    Number(yDomain[1]),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -5) throw new RangeError("Scene v12 annotation geometry must be finite");
  if (code < 0) throw new RangeError("invalid scene annotation packing");
  const view = new DataView(out.buffer, out.byteOffset, Math.max(code, 0) * 56);
  const rows = { kinds: [], stableIds: [], styleRefs: [], diameter: [], symbols: [], expansion: [], x0: [], y0: [], x1: [], y1: [] };
  for (let index = 0; index < code; index += 1) {
    const at = index * 56;
    rows.kinds.push(out[at]);
    rows.symbols.push(out[at + 1]);
    rows.expansion.push(out[at + 2]);
    rows.styleRefs.push(view.getUint32(at + 4, true));
    rows.stableIds.push(view.getBigUint64(at + 8, true));
    rows.diameter.push(view.getFloat64(at + 16, true));
    rows.x0.push(view.getFloat64(at + 24, true));
    rows.y0.push(view.getFloat64(at + 32, true));
    rows.x1.push(view.getFloat64(at + 40, true));
    rows.y1.push(view.getFloat64(at + 48, true));
  }
  return rows;
}

function annotationMarkRow(kind, axis, symbol, styleRef, index, value0, value1, size) {
  const row = new Uint8Array(40);
  const view = new DataView(row.buffer);
  row[0] = kind;
  row[1] = axis;
  row[2] = symbol;
  view.setUint32(4, styleRef >>> 0, true);
  view.setUint32(8, index >>> 0, true);
  view.setFloat64(16, Number(value0), true);
  view.setFloat64(24, Number(value1), true);
  view.setFloat64(32, Number(size), true);
  return row;
}

function appendPacked(kinds, stableIds, styleRefs, diameter, symbols, expansionModes, x0, y0, x1, y1, packed) {
  kinds.push(...packed.kinds);
  stableIds.push(...packed.stableIds);
  styleRefs.push(...packed.styleRefs);
  diameter.push(...packed.diameter);
  symbols.push(...packed.symbols);
  expansionModes.push(...packed.expansion);
  x0.push(...packed.x0);
  y0.push(...packed.y0);
  x1.push(...packed.x1);
  y1.push(...packed.y1);
}

function sceneSymbolCode(value) {
  if (typeof value === "string") {
    const code = SYMBOL_CODES.get(value);
    if (code == null) throw new RangeError(`Scene v12 does not support scatter symbol ${JSON.stringify(value)}`);
    return code;
  }
  if (!Number.isInteger(value) || value < 0 || value >= SYMBOL_CODES.size) {
    throw new RangeError("Scene v12 scatter symbol code must be an integer from 0 through 18");
  }
  return value;
}

function annotationSymbolCode(value) {
  if (typeof value !== "string") {
    throw new RangeError("Scene v12 annotation marker symbol must be a supported string name");
  }
  return sceneSymbolCode(value);
}

function asU8Array(value, name) {
  if (value instanceof Uint8Array) return value;
  if (value == null) return new Uint8Array(0);
  try {
    return Uint8Array.from(value, (item) => Number(item));
  } catch (error) {
    throw new TypeError(`${name} must be an array-like byte sequence`, { cause: error });
  }
}

function asUnsignedArray(value, name, max, TypedArray) {
  if (value instanceof TypedArray) return value;
  let items;
  try {
    items = Array.from(value);
  } catch (error) {
    throw new TypeError(`${name} must be an array-like unsigned integer sequence`, { cause: error });
  }
  for (const item of items) {
    if (typeof item !== "number" || !Number.isInteger(item) || item < 0 || item > max) {
      throw new RangeError(`${name} values must be integers from 0 through ${max}`);
    }
  }
  return TypedArray.from(items);
}

function asU64(value, name) {
  if (typeof value === "bigint") {
    if (value < 0n || value > USIZE_MAX_64) throw new RangeError(`${name} must be an unsigned 64-bit integer`);
    return value;
  }
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    throw new RangeError(`${name} number must be a non-negative safe integer; use BigInt above 2^53 - 1`);
  }
  return BigInt(value);
}

function asStableIds(value) {
  if (value instanceof BigUint64Array) return value;
  let items;
  try {
    items = Array.from(value);
  } catch (error) {
    throw new TypeError("stableIds must be an array-like unsigned 64-bit integer sequence", { cause: error });
  }
  const converted = items.map((item) => asU64(item, "stableIds value"));
  return BigUint64Array.from(converted);
}

function requireLength(value, length, name) {
  if (value.length !== length) {
    throw new RangeError(`${name} must have length ${length}, got ${value.length}`);
  }
}

export function sceneVersion() {
  return xySceneVersion();
}

export function axisTicks({
  kind = "linear",
  lo,
  hi,
  target = 6,
  categories,
  unit,
  constant = 1,
}) {
  let kindCode = -1;
  let aux = 0;
  if (kind === "linear") kindCode = 0;
  else if (kind === "log") kindCode = 1;
  else if (kind === "category") {
    kindCode = 2;
    const count = Array.isArray(categories) ? categories.length : Number(categories);
    if (!Number.isFinite(count) || count < 1) {
      throw new RangeError("category ticks require a positive categories length");
    }
    aux = count;
  } else if (kind === "angular") {
    kindCode = unit === "degrees" ? 3 : unit === "radians" ? 4 : -1;
    if (kindCode < 0) throw new RangeError('angular unit must be "degrees" or "radians"');
  } else if (kind === "time") {
    kindCode = 5;
  } else if (kind === "symlog") {
    kindCode = 6;
    aux = Number(constant);
  }
  if (kindCode < 0) {
    throw new RangeError("kind must be linear, log, category, angular, time, or symlog");
  }
  // Calendar time ladders can emit up to ~1000 first-of-month ticks.
  const capacity = kindCode === 5 ? 1000 : 200;
  const ticks = new Float64Array(capacity);
  const labeled = new Float64Array(capacity);
  const labeledLength = new BigUint64Array(1);
  const step = new Float64Array(1);
  const rawWritten = xySceneAxisTicks(
    kindCode, Number(lo), Number(hi), BigInt(target), Number(aux),
    pointer(ticks, "double *"), pointer(labeled, "double *"),
    pointer(labeledLength, "size_t *"), pointer(step, "double *"), BigInt(capacity),
  );
  if (rawWritten === USIZE_MAX_64) throw new RangeError("invalid canonical axis tick request");
  const written = Number(rawWritten);
  const labels = Number(labeledLength[0]);
  if (!Number.isSafeInteger(written) || written > capacity || labels > written) {
    throw new RangeError("canonical axis ticks exceeded host output limits");
  }
  return { ticks: Array.from(ticks.subarray(0, written)), labeled: Array.from(labeled.subarray(0, labels)), step: step[0] };
}

/** Resolve canonical packed XYTK bytes through the native Rust twin. */
export function tickResolvePacked(request) {
  const input = request instanceof Uint8Array
    ? request
    : request instanceof ArrayBuffer
      ? new Uint8Array(request)
      : null;
  if (!input || input.byteLength === 0) {
    throw new TypeError("packed tick request must be a nonempty Uint8Array or ArrayBuffer");
  }
  const rawRequired = xyTickResolvePacked(
    pointer(input, "const uint8_t *"), BigInt(input.byteLength), null, 0n,
  );
  if (rawRequired === USIZE_MAX_64) {
    throw new RangeError("native packed tick resolver rejected the request");
  }
  const required = Number(rawRequired);
  if (!Number.isSafeInteger(required) || required < 0) {
    throw new RangeError("native packed tick output exceeds host limits");
  }
  const output = new Uint8Array(required);
  const rawWritten = xyTickResolvePacked(
    pointer(input, "const uint8_t *"), BigInt(input.byteLength),
    pointer(output, "uint8_t *"), BigInt(required),
  );
  if (rawWritten !== rawRequired) {
    throw new RangeError("native packed tick resolver returned an unstable size");
  }
  return output;
}

const TICK_LAYOUT_KIND = new Map([
  ["auto", 0], ["hide", 1], ["rotate", 2], ["stagger", 3],
  ["preserve", 4], ["none", 5], ["off", 6],
]);
const TICK_LAYOUT_SIDE = new Map([["bottom", 0], ["top", 1], ["left", 2], ["right", 3]]);
const TICK_LAYOUT_ANCHOR = new Map([["start", 0], ["center", 1], ["end", 2]]);

function tickLayoutEnum(value, mapping, name) {
  if (typeof value === "string") {
    const key = value.trim().toLowerCase().replaceAll("-", "_");
    if (!mapping.has(key)) {
      throw new RangeError(`${name} must be one of ${[...mapping.keys()].join(", ")}`);
    }
    return mapping.get(key);
  }
  const code = Number(value);
  if (!Number.isInteger(code)) {
    throw new RangeError(`${name} must be a string or integer code`);
  }
  return code;
}

export function tickLabelLayout({
  positions,
  labels,
  kind = "auto",
  side = "bottom",
  anchor = "center",
  isX = true,
  category = false,
  fontSize = 11,
  minGap = 8,
  explicitAngle,
} = {}) {
  const pos = asF64Array(positions ?? [], "positions");
  const texts = Array.from(labels ?? [], (label) => String(label));
  if (pos.length !== texts.length) {
    throw new RangeError("positions and labels must have the same length");
  }
  const encoder = new TextEncoder();
  const encoded = texts.map((text) => encoder.encode(text));
  const packedLen = encoded.reduce((sum, bytes) => sum + bytes.length, 0);
  const packed = new Uint8Array(packedLen);
  const lens = new Uint32Array(texts.length);
  let at = 0;
  for (const [index, bytes] of encoded.entries()) {
    lens[index] = bytes.length;
    packed.set(bytes, at);
    at += bytes.length;
  }
  const n = pos.length;
  const outIndex = new Uint32Array(n);
  const outAngle = new Float64Array(n);
  const outRow = new Uint32Array(n);
  const angle = explicitAngle == null ? Number.NaN : Number(explicitAngle);
  const flags = (isX ? 1 : 0) | (category ? 2 : 0);
  const rawWritten = xySceneTickLabelLayout(
    f64Ptr(pos),
    BigInt(n),
    u32Ptr(lens),
    packedLen ? u8Ptr(packed) : 0,
    BigInt(packedLen),
    tickLayoutEnum(kind, TICK_LAYOUT_KIND, "kind"),
    tickLayoutEnum(side, TICK_LAYOUT_SIDE, "side"),
    tickLayoutEnum(anchor, TICK_LAYOUT_ANCHOR, "anchor"),
    flags,
    Number(fontSize),
    Number(minGap),
    angle,
    n ? u32Ptr(outIndex) : 0,
    n ? f64Ptr(outAngle) : 0,
    n ? u32Ptr(outRow) : 0,
    BigInt(n),
  );
  if (rawWritten === USIZE_MAX_64) throw new RangeError("invalid tick-label layout request");
  const written = Number(rawWritten);
  if (!Number.isSafeInteger(written) || written > n) {
    throw new RangeError("tick-label layout exceeded host output limits");
  }
  return Array.from({ length: written }, (_, index) => ({
    index: outIndex[index],
    angle: outAngle[index],
    row: outRow[index],
  }));
}

function thetaUnitCode(thetaUnit) {
  if (thetaUnit == null) return 0;
  return thetaUnit === "degrees" ? 1 : 2;
}

export function tickWindow({
  rangeLo,
  rangeHi,
  thetaUnit = null,
  kind = "linear",
  nCategories = 0,
  sectorLo = Number.NaN,
  sectorHi = Number.NaN,
} = {}) {
  const outLo = new Float64Array(1);
  const outHi = new Float64Array(1);
  const written = xyTickWindow(
    Number(rangeLo),
    Number(rangeHi),
    thetaUnitCode(thetaUnit),
    kind === "category" ? 1 : 0,
    Number(nCategories) >>> 0,
    Number(sectorLo),
    Number(sectorHi),
    f64Ptr(outLo),
    f64Ptr(outHi),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid tick-window request");
  return [outLo[0], outHi[0]];
}

export function tickWindowFilter({
  values,
  lo,
  hi,
  thetaUnit = null,
  kind = "linear",
  requireFinite = false,
} = {}) {
  const arr = asF64Array(values ?? [], "values");
  const n = arr.length;
  const out = new Float64Array(n);
  const written = xyTickWindowFilter(
    n ? f64Ptr(arr) : 0,
    BigInt(n),
    Number(lo),
    Number(hi),
    thetaUnitCode(thetaUnit),
    kind === "category" ? 1 : 0,
    requireFinite ? 1 : 0,
    n ? f64Ptr(out) : 0,
    BigInt(n),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid tick-window filter request");
  const kept = Number(written);
  if (!Number.isSafeInteger(kept) || kept > n) {
    throw new RangeError("tick-window filter exceeded host output limits");
  }
  return Array.from(out.subarray(0, kept));
}

function tickFormatKind(kind) {
  if (kind === "category") return 2;
  if (kind === "time") return 1;
  return 0;
}

export function tickFormat({
  value,
  step,
  kind = "linear",
  scale = null,
  thetaUnit = null,
  format = null,
  categories = [],
} = {}) {
  const cats = Array.from(categories ?? [], (item) => String(item));
  const encoder = new TextEncoder();
  const encoded = cats.map((item) => encoder.encode(item));
  const packed = new Uint8Array(encoded.reduce((sum, item) => sum + item.length, 0));
  let packedOffset = 0;
  for (const item of encoded) {
    packed.set(item, packedOffset);
    packedOffset += item.length;
  }
  const lens = new Uint32Array(encoded.map((item) => item.length));
  const formatBytes = format == null ? new Uint8Array() : encoder.encode(String(format));
  let out = new Uint8Array(256);
  let written = xyTickFormat(
    Number(value),
    Number(step),
    tickFormatKind(kind),
    scale === "log" ? 1 : 0,
    thetaUnitCode(thetaUnit),
    formatBytes.length ? u8Ptr(formatBytes) : 0,
    BigInt(formatBytes.length),
    BigInt(cats.length),
    cats.length ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid tick-format request");
  let size = Number(written);
  if (!Number.isSafeInteger(size)) throw new RangeError("tick-format exceeded host output limits");
  if (size > out.length) {
    out = new Uint8Array(size);
    written = xyTickFormat(
      Number(value),
      Number(step),
      tickFormatKind(kind),
      scale === "log" ? 1 : 0,
      thetaUnitCode(thetaUnit),
      formatBytes.length ? u8Ptr(formatBytes) : 0,
      BigInt(formatBytes.length),
      BigInt(cats.length),
      cats.length ? u32Ptr(lens) : 0,
      packed.length ? u8Ptr(packed) : 0,
      BigInt(packed.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (written === USIZE_MAX_64) throw new RangeError("invalid tick-format request");
    size = Number(written);
    if (!Number.isSafeInteger(size) || size > out.length) {
      throw new RangeError("tick-format exceeded host output limits");
    }
  }
  return new TextDecoder().decode(out.subarray(0, size));
}

export function legendBoxLayout({
  plot,
  names = [],
  title = null,
  loc = "upper right",
  fontSize = 11,
  handleLength,
  handleTextPad,
  handleHeight,
  ncols = 1,
  paddingEm = 0.4,
  rowGapEm = 0.5,
  anchor,
  borderAxesPad = 0,
} = {}) {
  if (plot == null || typeof plot !== "object") {
    throw new TypeError("plot must be an object with x, y, w, and h");
  }
  const texts = Array.from(names ?? [], (name) => String(name));
  const encoder = new TextEncoder();
  const encoded = texts.map((text) => encoder.encode(text));
  const packedLen = encoded.reduce((sum, bytes) => sum + bytes.length, 0);
  const packed = new Uint8Array(packedLen);
  const lens = new Uint32Array(texts.length);
  let at = 0;
  for (const [index, bytes] of encoded.entries()) {
    lens[index] = bytes.length;
    packed.set(bytes, at);
    at += bytes.length;
  }
  const titleBytes = encoder.encode(title == null ? "" : String(title));
  const locBytes = encoder.encode(loc == null || loc === "" ? "upper right" : String(loc));
  const n = texts.length;
  const colCap = Math.max(n, 1);
  const metrics = new Float64Array(17);
  const widths = new Float64Array(colCap);
  const offsets = new Float64Array(colCap);
  const nameLens = new Uint32Array(colCap);
  const namesCap = packedLen + 3 * n;
  const namesOut = new Uint8Array(Math.max(namesCap, 1));
  const titleCap = Math.max(titleBytes.length + 8, 1);
  const titleOut = new Uint8Array(titleCap);
  const titleLen = new BigUint64Array(1);
  let anchorArr = null;
  let anchorLen = 0;
  if (anchor != null) {
    const vals = Array.from(anchor, (value) => Number(value));
    if (vals.length !== 2 && vals.length !== 4) {
      throw new RangeError("legend anchor must have length 2 or 4");
    }
    anchorArr = Float64Array.from(vals);
    anchorLen = vals.length;
  }
  const nan = Number.NaN;
  const rawWritten = xyLegendBoxLayout(
    Number(plot.x),
    Number(plot.y),
    Number(plot.w),
    Number(plot.h),
    n ? u32Ptr(lens) : 0,
    packedLen ? u8Ptr(packed) : 0,
    BigInt(packedLen),
    BigInt(n),
    titleBytes.length ? u8Ptr(titleBytes) : 0,
    BigInt(titleBytes.length),
    locBytes.length ? u8Ptr(locBytes) : 0,
    BigInt(locBytes.length),
    Number(fontSize),
    handleLength == null ? nan : Number(handleLength),
    handleTextPad == null ? nan : Number(handleTextPad),
    handleHeight == null ? nan : Number(handleHeight),
    Math.max(1, Number(ncols) | 0),
    Number(paddingEm),
    Number(rowGapEm),
    anchorArr ? f64Ptr(anchorArr) : 0,
    BigInt(anchorLen),
    Number(borderAxesPad),
    f64Ptr(metrics),
    f64Ptr(widths),
    f64Ptr(offsets),
    BigInt(colCap),
    u32Ptr(nameLens),
    u8Ptr(namesOut),
    BigInt(namesOut.length),
    u8Ptr(titleOut),
    BigInt(titleOut.length),
    pointer(titleLen, "size_t *"),
  );
  if (rawWritten === USIZE_MAX_64) throw new RangeError("invalid legend box layout request");
  const visible = Number(rawWritten);
  if (!Number.isSafeInteger(visible) || visible < 0) {
    throw new RangeError("legend box layout exceeded host output limits");
  }
  const decoder = new TextDecoder();
  const outNames = [];
  let nameAt = 0;
  for (let index = 0; index < visible; index += 1) {
    const length = nameLens[index];
    outNames.push(decoder.decode(namesOut.subarray(nameAt, nameAt + length)));
    nameAt += length;
  }
  const titleText = decoder.decode(titleOut.subarray(0, Number(titleLen[0])));
  const ncolsOut = metrics[9] | 0;
  return {
    pad: metrics[0],
    handle: metrics[1],
    gap: metrics[2],
    columnGap: metrics[3],
    rowGap: metrics[4],
    fontSize: metrics[5],
    textH: metrics[6],
    lineH: metrics[7],
    swatchH: metrics[8],
    ncols: ncolsOut,
    title: titleText || null,
    titleH: metrics[10],
    cellW: metrics[11],
    columnWidths: Array.from(widths.subarray(0, ncolsOut)),
    columnOffsets: Array.from(offsets.subarray(0, ncolsOut)),
    boxW: metrics[12],
    boxH: metrics[13],
    x: metrics[14],
    y: metrics[15],
    visibleCount: visible,
    names: outNames,
  };
}

function packUtf8Strings(values) {
  const encoder = new TextEncoder();
  const encoded = Array.from(values ?? [], (value) => encoder.encode(String(value)));
  const packedLen = encoded.reduce((sum, bytes) => sum + bytes.length, 0);
  const packed = new Uint8Array(packedLen);
  const lens = new Uint32Array(encoded.length);
  let at = 0;
  for (const [index, bytes] of encoded.entries()) {
    lens[index] = bytes.length;
    packed.set(bytes, at);
    at += bytes.length;
  }
  return { lens, packed, n: encoded.length };
}

function unpackUtf8Strings(lens, packed, count) {
  const decoder = new TextDecoder();
  const out = [];
  let at = 0;
  for (let index = 0; index < count; index += 1) {
    const length = lens[index];
    out.push(decoder.decode(packed.subarray(at, at + length)));
    at += length;
  }
  return out;
}

const ANCHOR_CODES = { start: 0, center: 1, end: 2 };

export function textBlockMeasure(text, fontSize, lineHeight = 1.2, maxWidth = null) {
  const encoder = new TextEncoder();
  const textBytes = encoder.encode(String(text ?? ""));
  let lineCap = Math.max(textBytes.length + 8, 8);
  let packedCap = Math.max(textBytes.length + 8, 8);
  const metrics = new Float64Array(6);
  let written = USIZE_MAX_64;
  let lineLens = new Uint32Array(lineCap);
  let packed = new Uint8Array(packedCap);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    lineLens = new Uint32Array(lineCap);
    packed = new Uint8Array(packedCap);
    written = xyTextBlockMeasure(
      textBytes.length ? u8Ptr(textBytes) : 0,
      BigInt(textBytes.length),
      Number(fontSize),
      Number(lineHeight),
      maxWidth == null ? Number.NaN : Number(maxWidth),
      f64Ptr(metrics),
      u32Ptr(lineLens),
      BigInt(lineCap),
      u8Ptr(packed),
      BigInt(packedCap),
    );
    if (written !== USIZE_MAX_64) break;
    lineCap *= 4;
    packedCap *= 4;
  }
  if (written === USIZE_MAX_64) throw new RangeError("invalid text-block measure request");
  const n = Number(written);
  if (!Number.isSafeInteger(n) || n < 0) {
    throw new RangeError("text-block measure exceeded host output limits");
  }
  return {
    lines: unpackUtf8Strings(lineLens, packed, n),
    width: metrics[0],
    height: metrics[1],
    lineStep: metrics[2],
    ascent: metrics[3],
    descent: metrics[4],
    lineCount: n,
  };
}

export function textBlockRotatedExtent(width, height, angleDegrees) {
  const outX = new Float64Array(1);
  const outY = new Float64Array(1);
  const written = xyTextBlockRotatedExtent(
    Number(width),
    Number(height),
    Number(angleDegrees),
    f64Ptr(outX),
    f64Ptr(outY),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid text-block rotation request");
  return [outX[0], outY[0]];
}

export function yTickLabelExtent(labels, fontSize, angle) {
  const { lens, packed, n } = packUtf8Strings(labels);
  const out = new Float64Array(1);
  const written = xyYTickLabelExtent(
    n ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    BigInt(n),
    Number(fontSize),
    Number(angle),
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid y tick-label extent request");
  return out[0];
}

export function yAxisLeftRoom(tickOffset, tickRoom, title, titleFontSize, titleGap) {
  const titleBytes = new TextEncoder().encode(title == null ? "" : String(title));
  const out = new Float64Array(1);
  const written = xyYAxisLeftRoom(
    Number(tickOffset),
    Number(tickRoom),
    titleBytes.length ? u8Ptr(titleBytes) : 0,
    BigInt(titleBytes.length),
    Number(titleFontSize),
    Number(titleGap),
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid y-axis left-room request");
  return out[0];
}

export function xAxisTitleRoom(title, fontSize, offset, top) {
  const titleBytes = new TextEncoder().encode(title == null ? "" : String(title));
  const out = new Float64Array(1);
  const written = xyXAxisTitleRoom(
    titleBytes.length ? u8Ptr(titleBytes) : 0,
    BigInt(titleBytes.length),
    Number(fontSize),
    Number(offset),
    top ? 1 : 0,
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid x-axis title-room request");
  return out[0];
}

export function xTickLabelRoom(labels, angles, rows, fontSize, labelOffset, titleRoom) {
  const texts = Array.from(labels ?? [], (label) => String(label));
  const n = texts.length;
  if (n !== (angles?.length ?? 0) || n !== (rows?.length ?? 0)) {
    throw new RangeError("x tick-label room arrays must have equal length");
  }
  const { lens, packed } = packUtf8Strings(texts);
  const angleArr = Float64Array.from(angles ?? [], (angle) => Number(angle));
  const rowArr = Uint32Array.from(rows ?? [], (row) => Number(row) >>> 0);
  const out = new Float64Array(1);
  const written = xyXTickLabelRoom(
    n ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    BigInt(n),
    n ? f64Ptr(angleArr) : 0,
    n ? u32Ptr(rowArr) : 0,
    Number(fontSize),
    Number(labelOffset),
    Number(titleRoom),
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid x tick-label room request");
  return out[0];
}

export function xTickLabelEdgeRooms(plotW, positions, labels, angles, anchors, fontSize) {
  const texts = Array.from(labels ?? [], (label) => String(label));
  const n = texts.length;
  if (n !== (positions?.length ?? 0) || n !== (angles?.length ?? 0) || n !== (anchors?.length ?? 0)) {
    throw new RangeError("x tick-label edge-room arrays must have equal length");
  }
  const { lens, packed } = packUtf8Strings(texts);
  const posArr = Float64Array.from(positions ?? [], (pos) => Number(pos));
  const angleArr = Float64Array.from(angles ?? [], (angle) => Number(angle));
  const anchorArr = new Uint32Array(n);
  for (let index = 0; index < n; index += 1) {
    const code = ANCHOR_CODES[String(anchors[index])];
    if (code === undefined) throw new RangeError("anchor must be start, center, or end");
    anchorArr[index] = code;
  }
  const outLeft = new Float64Array(1);
  const outRight = new Float64Array(1);
  const written = xyXTickLabelEdgeRooms(
    Number(plotW),
    n ? f64Ptr(posArr) : 0,
    BigInt(n),
    n ? u32Ptr(lens) : 0,
    packed.length ? u8Ptr(packed) : 0,
    BigInt(packed.length),
    n ? f64Ptr(angleArr) : 0,
    n ? u32Ptr(anchorArr) : 0,
    Number(fontSize),
    f64Ptr(outLeft),
    f64Ptr(outRight),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid x tick-label edge-room request");
  return [outLeft[0], outRight[0]];
}

const COLORBAR_KINDS = {
  none: 0,
  axes_horizontal: 1,
  axes_vertical: 2,
  figure_horizontal: 3,
  figure_vertical: 4,
};
const POLAR_LEGEND_SIDES = { 0: "", 1: "left", 2: "right", 3: "bottom" };
const POLAR_LEGEND_SIDE_CODES = { "": 0, left: 1, right: 2, bottom: 3 };

export function compatIsCompact(width) {
  const status = xyCompatIsCompact(Number(width));
  if (status === 1) return true;
  if (status === 0) return false;
  throw new RangeError("invalid compact-width request");
}

export function compatDefaultPadding(compact) {
  const out = new Float64Array(4);
  const written = xyCompatDefaultPadding(compact ? 1 : 0, f64Ptr(out));
  if (written === USIZE_MAX_64) throw new RangeError("invalid default-padding request");
  return [out[0], out[1], out[2], out[3]];
}

export function compatTitleWrapWidth(width, left, right) {
  const out = new Float64Array(1);
  const written = xyCompatTitleWrapWidth(Number(width), Number(left), Number(right), f64Ptr(out));
  if (written === USIZE_MAX_64) throw new RangeError("invalid title-wrap-width request");
  return out[0];
}

export function compatTitleRoom(compact, blockHeight, pad, automaticY, y) {
  const out = new Float64Array(1);
  const written = xyCompatTitleRoom(
    compact ? 1 : 0,
    Number(blockHeight),
    Number(pad),
    automaticY ? 1 : 0,
    Number(y),
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid title-room request");
  return out[0];
}

export function compatXAxisSideRoom(compact, top, measured) {
  const outRoom = new Float64Array(1);
  const outMeasured = new Float64Array(1);
  const written = xyCompatXAxisSideRoom(
    compact ? 1 : 0,
    top ? 1 : 0,
    Number(measured),
    f64Ptr(outRoom),
    f64Ptr(outMeasured),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid x-axis side-room request");
  return [outRoom[0], outMeasured[0]];
}

export function compatColorbarExtra(kind, hasLabel, padZero) {
  const code = COLORBAR_KINDS[kind];
  if (code === undefined) throw new RangeError("unknown colorbar layout kind");
  const outRight = new Float64Array(1);
  const outBottom = new Float64Array(1);
  const written = xyCompatColorbarExtra(
    code,
    hasLabel ? 1 : 0,
    padZero ? 1 : 0,
    f64Ptr(outRight),
    f64Ptr(outBottom),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid colorbar-extra request");
  return [outRight[0], outBottom[0]];
}

export function compatRightYRoom(compact) {
  const out = new Float64Array(1);
  const written = xyCompatRightYRoom(compact ? 1 : 0, f64Ptr(out));
  if (written === USIZE_MAX_64) throw new RangeError("invalid right-y-room request");
  return out[0];
}

export const POLAR_METRICS_LEN = 23;

const THETA_ZERO = {
  E: 0,
  N: Math.PI / 2,
  W: Math.PI,
  S: -Math.PI / 2,
};

function polarThetaUnit(unit = "radians") {
  return unit === "degrees" ? 1 : 0;
}

function polarThetaDirection(direction = "counterclockwise") {
  return direction === "clockwise" ? 1 : 0;
}

function polarThetaZero(zero = "E") {
  if (typeof zero === "string") return THETA_ZERO[zero] ?? 0;
  return Number(zero);
}

/** Polar r-axis origin. Python `_pack_polar_scene_input` / `polar_layout` read `r_axis.get("r_origin")` only. */
export function polarAxisROrigin(rAxis) {
  return (rAxis ?? {}).r_origin;
}

/** Polar r-axis hole. Python `_pack_polar_scene_input` / `polar_layout` read `r_axis.get("hole")` only. */
export function polarAxisHole(rAxis) {
  return (rAxis ?? {}).hole;
}

/** Polar theta-axis sector. Python `_pack_polar_scene_input` / `polar_layout` read `theta_axis.get("sector")` only. */
export function polarAxisSector(thetaAxis) {
  return (thetaAxis ?? {}).sector;
}

/** Polar theta-axis direction. Python `_pack_polar_scene_input` / `polar_layout` read `theta_axis.get("theta_direction")` only. */
export function polarAxisThetaDirection(thetaAxis) {
  return (thetaAxis ?? {}).theta_direction;
}

/** Polar theta-axis unit. Python `_pack_polar_scene_input` / `polar_layout` read `theta_axis.get("theta_unit", "radians")` only. */
export function polarAxisThetaUnit(thetaAxis) {
  return (thetaAxis ?? {}).theta_unit ?? "radians";
}

/** Polar theta-axis zero. Python `_pack_polar_scene_input` / `polar_layout` read `theta_axis.get("theta_zero", "E")` only. */
export function polarAxisThetaZero(thetaAxis) {
  return (thetaAxis ?? {}).theta_zero ?? "E";
}

/** Polar theta-axis grid. Python `_pack_polar_scene_input` reads `xa.get("grid_shape", "circular")` only. */
export function polarGridShape(thetaAxis) {
  return (thetaAxis ?? {}).grid_shape ?? "circular";
}

function polarRScale(axis = {}) {
  const scale = axis.scale ?? "";
  const kind = axis.kind ?? "linear";
  let code = 0;
  if (scale === "log" || kind === "log") code = 1;
  else if (scale === "symlog") code = 2;
  return {
    kind: code,
    constant: Number(axis.constant ?? 1),
    maskNonpositive: (axis.nonpositive ?? "clip") === "mask",
  };
}

export function packPolarSceneInput(figure) {
  const axes = figureAxisOptions(figure) ?? {};
  const xa = axes.x ?? {};
  const ya = axes.y ?? {};
  const unit = polarAxisThetaUnit(xa);
  const turn = unit === "degrees" ? 360 : Math.PI * 2;
  const sector = polarAxisSector(xa) ?? [0, turn];
  const [rLo, rHi] = figure._range("y");
  const origin = polarAxisROrigin(ya);
  const scale = polarRScale(ya);
  const grid = polarGridShape(xa);
  const thetaZero = polarAxisThetaZero(xa);
  const thetaZeroIsLabel = typeof thetaZero === "string";
  return scenePolarInputPack({
    polar: (figure.coords ?? "cartesian") === "polar",
    theta_unit: polarThetaUnit(unit),
    theta_direction: polarThetaDirection(polarAxisThetaDirection(xa)),
    n_categories: (xa.categories ?? []).length,
    grid_shape: grid === "linear" ? 1 : 0,
    r_scale_kind: scale.kind,
    r_mask_nonpositive: scale.maskNonpositive,
    sector_start: Number(sector[0]),
    sector_end: Number(sector[1]),
    r_lo: Number(rLo),
    r_hi: Number(rHi),
    r_origin_is_nan: origin == null,
    r_origin: origin == null ? Number.NaN : Number(origin),
    hole: Number(polarAxisHole(ya) || 0),
    r_constant: scale.constant,
    theta_zero_is_label: thetaZeroIsLabel,
    theta_zero_label: thetaZeroIsLabel ? String(thetaZero) : "",
    theta_zero_numeric: polarThetaZero(thetaZero),
  });
}


function encodeUtf8Magic(text) {
  return encodeUtf8(text).slice(0, 4);
}

function packF64Le(values) {
  const out = new Uint8Array(values.length * 8);
  const view = new DataView(out.buffer);
  for (let index = 0; index < values.length; index += 1) {
    view.setFloat64(index * 8, Number(values[index]), true);
  }
  return out;
}

export function xyHfColormap(style) {
  const packed = sceneXyhfColormapPack(style ?? {});
  if (packed == null) return null;
  return { flags: packed.flags, bytes: packed.cmap.length ? packed.cmap : packed.stops };
}

function packDensityGrid(x, y, x0, x1, y0, y1, source = null) {
  const xa = asF64Array(x, "x");
  const ya = asF64Array(y, "y");
  if (xa.length !== ya.length) throw new RangeError("Scene density columns must have equal length");
  if (!xa.length) return null;
  let idxPtr = 0;
  let rgbaPtr = 0;
  let lutPtr = 0;
  let lutLen = 0n;
  if (source?.rgba != null) {
    const rgba = source.rgba instanceof Uint8Array ? source.rgba : Uint8Array.from(source.rgba);
    if (rgba.length !== xa.length * 4) {
      throw new RangeError("Scene density mean-color rgba length must be 4 * n");
    }
    rgbaPtr = u8Ptr(rgba);
  } else if (source?.idx != null && source?.lut != null) {
    const idx = source.idx instanceof Uint8Array ? source.idx : Uint8Array.from(source.idx);
    const lut = source.lut instanceof Uint8Array ? source.lut : Uint8Array.from(source.lut);
    if (idx.length !== xa.length) throw new RangeError("Scene density mean-color idx length must match n");
    if (lut.length < 4 || lut.length % 4) throw new RangeError("Scene density mean-color lut must be RGBA8");
    idxPtr = u8Ptr(idx);
    lutPtr = u8Ptr(lut);
    lutLen = BigInt(lut.length / 4);
  }
  const out = new Uint8Array(32 + 512 * 384 * 5);
  const code = xyScenePackDensityGrid(
    f64Ptr(xa),
    f64Ptr(ya),
    BigInt(xa.length),
    Number(x0),
    Number(x1),
    Number(y0),
    Number(y1),
    idxPtr,
    rgbaPtr,
    lutPtr,
    lutLen,
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -5) throw new RangeError("Scene density columns must have equal length");
  if (code === -6) throw new RangeError("Scene density mean-color source is invalid");
  if (code < 0) throw new RangeError("invalid scene density packing");
  if (code === 0) return null;
  const view = new DataView(out.buffer, out.byteOffset, out.byteLength);
  const cols = view.getUint32(8, true);
  const rows = view.getUint32(12, true);
  const flags = view.getUint32(16, true);
  const maximum = view.getFloat64(24, true);
  const cells = rows * cols;
  const encoded = out.subarray(32, 32 + cells);
  let meanRgba = null;
  if (flags & 1) meanRgba = out.subarray(32 + cells, 32 + cells + cells * 4);
  return { encoded, max: maximum, meanRgba, rows, cols };
}

function packXyhp(planes) {
  if (!planes.length) return new Uint8Array();
  const bodyLen = planes.reduce((sum, plane) => sum + plane.length, 0);
  const out = new Uint8Array(16 + bodyLen);
  const view = new DataView(out.buffer);
  out.set(encodeUtf8Magic("XYHP"), 0);
  view.setUint32(4, 1, true);
  view.setUint32(8, planes.length, true);
  view.setUint32(12, 0, true);
  let offset = 16;
  for (const plane of planes) {
    out.set(plane, offset);
    offset += plane.length;
  }
  return out;
}

function parseSceneDash(value) {
  return sceneDashAdmit(value);
}

function parseSceneLinecap(value) {
  return sceneLinecapAdmit(value);
}

/** XYAF rule linecap. Python `_pack_xyaf` reads `style.get("linecap")` only. */
export function packXyAfLinecap(style) {
  return parseSceneLinecap((style ?? {}).linecap);
}

function validateMarkerPath(value) {
  return sceneMarkerPathAdmit(value);
}

export function fillIsGradientAuthoring(fill) {
  if (
    fill != null
    && typeof fill === "object"
    && !Array.isArray(fill)
    && !ArrayBuffer.isView(fill)
  ) return true;
  if (typeof fill !== "string") return false;
  return sceneLinearGradientPrefix(fill);
}

function parseLinearGradient(value, space = "mark") {
  if (typeof value !== "string") return null;
  return sceneParseLinearGradient(value, space);
}

function normalizeFillSpec(fill) {
  if (fill != null && typeof fill === "object" && fill.space != null && fill.dir != null && Array.isArray(fill.stops)) {
    return fill;
  }
  if (fill != null && typeof fill === "object") {
    const keys = Object.keys(fill).filter((key) => key !== "gradient" && key !== "space");
    if (keys.length) return null;
    return parseLinearGradient(fill.gradient, fill.space ?? "mark");
  }
  return parseLinearGradient(fill, "mark");
}

export function constantMarkColor(trace) {
  const channel = trace.color_ch;
  if (classifyRibbonColor2(trace) === "fail") return null;
  const hasChannel = channel != null && typeof channel === "object";
  const constantOk =
    hasChannel
    && channel.mode === "constant"
    && channel.constant != null;
  const scatterDensity = String(trace.kind ?? "") === "scatter" && scatterUsesDensity(trace);
  const packsPaint =
    hexbinPacksPaintPlane(trace)
    || ribbonPacksEndPaints(trace)
    || meshPacksPaintPlane(trace)
    || scatterPacksPaintPlane(trace);
  const code = sceneConstantColorAdmit(hasChannel, constantOk, scatterDensity, packsPaint);
  if (code === 2) return String(channel.constant);
  if (code === 1) return String(trace.style?.color ?? DEFAULT_PALETTE[0]);
  return null;
}

export function channelConstantCss(channel) {
  if (channel == null) return null;
  return sceneChannelConstantCss(channel.mode, channel.constant != null, channel.constant);
}

export function color2Channel(trace) {
  return trace.color2_ch ?? null;
}

/** Python `(trace.style or {}).get("color", default)` for item/hexbin fallbacks. */
function traceStyleColorDefault(trace, defaultCss = DEFAULT_PALETTE[0]) {
  const style = trace.style ?? {};
  if (!Object.hasOwn(style, "color")) return defaultCss;
  return String(style.color ?? defaultCss);
}

export function sourceColorCss(trace) {
  const css = channelConstantCss(trace.color_ch);
  if (css != null) return css;
  return String((trace.style ?? {}).color || DEFAULT_PALETTE[0]);
}

export function classifyRibbonColor2(trace) {
  const channel = color2Channel(trace);
  const hasColor2 = channel != null;
  const kindIsRibbon = String(trace.kind ?? "") === "ribbon";
  const target = hasColor2 ? channelConstantCss(channel) : null;
  const sourceConst = channelConstantCss(trace.color_ch);
  const sourcePaint = sourceColorCss(trace);
  const hasFill = Object.hasOwn(trace.style ?? {}, "fill");
  const bothConst = target != null && sourceConst != null;
  let hasEndPair = false;
  if (hasColor2 && kindIsRibbon && !bothConst && !hasFill) {
    hasEndPair = ribbonEndRgbaPair(trace) != null;
  }
  return sceneRibbonColor2Classify(
    hasColor2,
    kindIsRibbon,
    sourceConst,
    target,
    sourcePaint,
    hasFill,
    hasEndPair,
  );
}

function ribbonCount(trace) {
  const raw = trace.count;
  if (raw != null && Number.isFinite(Number(raw))) return Number(raw);
  const column = trace.x0;
  return column == null ? 0 : column.length;
}

export function channelEndRgba8(channel, n, fallback) {
  if (!(n >= 1)) return null;
  const replicate = (css) => {
    try {
      const rgba = cssColorRgba8(String(css), 1);
      const out = new Uint8Array(n * 4);
      for (let i = 0; i < n; i += 1) out.set(rgba, i * 4);
      return out;
    } catch {
      return null;
    }
  };
  if (channel == null) return replicate(fallback);
  if (typeof channel === "object" && !Array.isArray(channel) && !ArrayBuffer.isView(channel)) {
    if (channel.mode === "constant") {
      if (channel.constant == null) return null;
      return replicate(channel.constant);
    }
    if (channel.mode === "direct_rgba" && channel.rgba != null) {
      const raw = channel.rgba;
      if (raw instanceof Uint8Array && raw.length === n * 4) return raw;
      if (Array.isArray(raw) && raw.length === n && Array.isArray(raw[0])) {
        const flat = new Float64Array(n * 4);
        for (let i = 0; i < n; i += 1) {
          const row = raw[i];
          flat[i * 4] = Number(row[0]);
          flat[i * 4 + 1] = Number(row[1]);
          flat[i * 4 + 2] = Number(row[2]);
          flat[i * 4 + 3] = Number(row[3] ?? 1);
        }
        return clipQuantizeU8(flat);
      }
      if (ArrayBuffer.isView(raw) && raw.length === n * 4) {
        return clipQuantizeU8(raw);
      }
    }
    if (channel.mode === "categorical") {
      if (channel.codes == null) return null;
      try {
        const codes = channel.codes;
        const paletteSrc = channel.palette;
        const palette = [...(paletteSrc != null && paletteSrc.length ? paletteSrc : DEFAULT_PALETTE)];
        if (codes.length !== n) return null;
        const lut = paletteRowsRgba8(palette, palette.length);
        const out = new Uint8Array(n * 4);
        for (let i = 0; i < n; i += 1) {
          const code = Number(codes[i]);
          const idx = ((code % palette.length) + palette.length) % palette.length;
          out.set(lut.subarray(idx * 4, idx * 4 + 4), i * 4);
        }
        return out;
      } catch {
        return null;
      }
    }
  }
  return null;
}

export function ribbonEndRgbaPair(trace) {
  const n = ribbonCount(trace);
  if (n < 1) return null;
  const fallback = sourceColorCss(trace);
  const source = channelEndRgba8(trace.color_ch, n, fallback);
  const target = channelEndRgba8(color2Channel(trace), n, fallback);
  if (source == null || target == null) return null;
  return { source, target };
}

function ribbonPacksEndPaints(trace, polar = false) {
  if (polar || String(trace.kind ?? "") !== "ribbon") return false;
  return classifyRibbonColor2(trace) === "ends";
}

function ribbonColor2GradientSpec(trace) {
  if (classifyRibbonColor2(trace) !== "gradient") return null;
  const target = channelConstantCss(color2Channel(trace));
  if (target == null) return null;
  return {
    space: "mark",
    dir: "right",
    stops: [[0, sourceColorCss(trace)], [1, target]],
  };
}

function admitFillGradient(trace) {
  const fill = trace.style?.fill;
  if (!fillIsGradientAuthoring(fill)) return null;
  const spec = normalizeFillSpec(fill);
  const markColor = constantMarkColor(trace);
  if (spec == null || markColor == null) return null;
  if (!Array.isArray(spec.stops)) return null;
  const ts = [];
  const css = [];
  for (const stop of spec.stops) {
    if (!Array.isArray(stop) || stop.length !== 2) return null;
    ts.push(Number(stop[0]));
    css.push(String(stop[1]));
  }
  const rgba = sceneFillGradientAdmit(spec.space, spec.dir, ts, css, markColor);
  if (rgba == null) return null;
  return { space: spec.space, dir: spec.dir, stops: ts.map((t, i) => [t, rgba[i]]) };
}

function admitFillGradientFromFill(fill, markColor) {
  let spec = null;
  if (fill != null && typeof fill === "object" && fill.space != null && fill.dir != null && Array.isArray(fill.stops)) {
    spec = fill;
  } else if (fill != null && typeof fill === "object") {
    const extra = Object.keys(fill).filter((key) => key !== "gradient" && key !== "space");
    if (extra.length) return null;
    const gradient = fill.gradient;
    if (typeof gradient !== "string") return null;
    const space = fill.space == null ? "mark" : String(fill.space);
    spec = sceneParseLinearGradient(gradient, space);
  } else if (typeof fill === "string") {
    spec = sceneParseLinearGradient(fill, "mark");
  } else {
    return null;
  }
  if (spec == null) return null;
  const stops = spec.stops;
  if (!Array.isArray(stops)) return null;
  const ts = [];
  const css = [];
  for (const stop of stops) {
    if (!Array.isArray(stop) || stop.length !== 2) return null;
    const t = Number(stop[0]);
    if (!Number.isFinite(t)) return null;
    ts.push(t);
    css.push(String(stop[1]));
  }
  const rgba = sceneFillGradientAdmit(String(spec.space), String(spec.dir), ts, css, markColor);
  if (rgba == null) return null;
  return { space: spec.space, dir: spec.dir, stops: ts.map((t, i) => [t, rgba[i]]) };
}

function gradientSolidCss(gradient) {
  const packed = [];
  for (const [, rgba] of gradient.stops) {
    packed.push(Number(rgba[0]), Number(rgba[1]), Number(rgba[2]), Number(rgba[3]));
  }
  return sceneGradientSolidCss(packed) ?? "rgb(0,0,0)";
}

const XYSS_HAS_DASH = 1 << 0;
const XYSS_HAS_CAP = 1 << 1;
const XYSS_HAS_MARKER = 1 << 2;
const XYSS_HAS_GRAD = 1 << 3;

function packXySs(dashes, linecaps, markerPaths, gradients = []) {
  const nRecords = Math.max(dashes.length, linecaps.length, markerPaths.length, gradients.length);
  const records = [];
  for (let index = 0; index < nRecords; index += 1) {
    const pattern = dashes[index];
    const cap = linecaps[index];
    const path = markerPaths[index];
    const gradient = gradients[index];
    let flags = 0;
    let remainderLen = 0;
    if (pattern && pattern.length) {
      flags |= XYSS_HAS_DASH;
    }
    if (cap === 0 || cap === 2) flags |= XYSS_HAS_CAP;
    if (path) {
      flags |= XYSS_HAS_MARKER;
      remainderLen += path.contours.reduce((sum, contour) => sum + 8 + contour.length * 8, 0);
    }
    if (gradient) {
      flags |= XYSS_HAS_GRAD;
      remainderLen += gradient.stops.length * 8;
    }
    if (!flags) continue;
    const record = new Uint8Array(48 + remainderLen);
    const view = new DataView(record.buffer);
    view.setUint32(0, index, true);
    record[4] = flags;
    record[5] = pattern && pattern.length ? pattern.length : 0;
    record[6] = (cap === 0 || cap === 2) ? cap : 255;
    record[7] = path ? path.contours.length : 0;
    record[8] = gradient ? gradient.stops.length : 0;
    record[9] = gradient ? sceneGradientDir(gradient.dir) : 0;
    record[10] = gradient ? (sceneGradientSpace(gradient.space) === 1 ? 1 : 0) : 0;
    record[11] = path && path.filled === false ? 0 : (path ? 1 : 0);
    if (pattern && pattern.length) {
      for (let offset = 0; offset < pattern.length; offset += 1) {
        view.setFloat32(16 + offset * 4, pattern[offset], true);
      }
    }
    let cursor = 48;
    if (path) {
      for (const contour of path.contours) {
        view.setUint32(cursor, contour.length / 2, true);
        view.setUint32(cursor + 4, 0, true);
        cursor += 8;
        for (let vertex = 0; vertex < contour.length; vertex += 1) {
          view.setFloat64(cursor, contour[vertex], true);
          cursor += 8;
        }
      }
    }
    if (gradient) {
      for (const [t, rgba] of gradient.stops) {
        view.setFloat32(cursor, t, true);
        record[cursor + 4] = rgba[0];
        record[cursor + 5] = rgba[1];
        record[cursor + 6] = rgba[2];
        record[cursor + 7] = rgba[3];
        cursor += 8;
      }
    }
    records.push(record);
  }
  if (!records.length) return new Uint8Array();
  const out = new Uint8Array(16 + records.reduce((sum, record) => sum + record.length, 0));
  const view = new DataView(out.buffer);
  out.set(encodeUtf8Magic("XYSS"), 0);
  view.setUint32(4, 1, true);
  view.setUint32(8, records.length, true);
  view.setUint32(12, 0, true);
  let offset = 16;
  for (const record of records) {
    out.set(record, offset);
    offset += record.length;
  }
  return out;
}

function packSceneExtrasFromFacts(polar, paint, facts) {
  const polarBytes = polar instanceof Uint8Array ? polar : new Uint8Array();
  const paintBytes = paint instanceof Uint8Array ? paint : new Uint8Array();
  const factsBytes = facts instanceof Uint8Array ? facts : new Uint8Array();
  if (!polarBytes.length && !paintBytes.length && !factsBytes.length) return new Uint8Array();
  const out = new Uint8Array(Math.max(256, polarBytes.length + paintBytes.length + factsBytes.length + 64));
  const code = xyScenePackSceneExtras(
    polarBytes.length ? u8Ptr(polarBytes) : 0,
    BigInt(polarBytes.length),
    paintBytes.length ? u8Ptr(paintBytes) : 0,
    BigInt(paintBytes.length),
    factsBytes.length ? u8Ptr(factsBytes) : 0,
    BigInt(factsBytes.length),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -5) throw new RangeError("Scene extras polar or paint envelope is invalid");
  if (code === -6) throw new RangeError("Scene style sidecar facts are invalid");
  if (code < 0) throw new RangeError("invalid scene extras packing");
  return out.subarray(0, code);
}

function packSceneExtrasFromSidecars(polar, xysd, facts) {
  const polarBytes = polar instanceof Uint8Array ? polar : new Uint8Array();
  const xysdBytes = xysd instanceof Uint8Array ? xysd : new Uint8Array();
  const factsBytes = facts instanceof Uint8Array ? facts : new Uint8Array();
  if (!polarBytes.length && !xysdBytes.length && !factsBytes.length) return new Uint8Array();
  let capacity = Math.max(256, polarBytes.length + xysdBytes.length + factsBytes.length + 64);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xyScenePackSceneExtrasFromSidecars(
      polarBytes.length ? u8Ptr(polarBytes) : 0,
      BigInt(polarBytes.length),
      xysdBytes.length ? u8Ptr(xysdBytes) : 0,
      BigInt(xysdBytes.length),
      factsBytes.length ? u8Ptr(factsBytes) : 0,
      BigInt(factsBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code === -5) throw new RangeError("Scene extras polar or paint envelope is invalid");
    if (code === -6) throw new RangeError("Scene style sidecar facts are invalid");
    if (code < 0) throw new RangeError("invalid scene extras packing");
    return out.subarray(0, code);
  }
  throw new RangeError("invalid scene extras packing");
}

export function polarLayout(thetaAxis = {}, rAxis = {}, plot = {}) {
  const unit = polarAxisThetaUnit(thetaAxis);
  const turn = unit === "degrees" ? 360 : Math.PI * 2;
  const sector = polarAxisSector(thetaAxis) ?? [0, turn];
  const categories = thetaAxis.categories ?? [];
  const [rLo, rHi] = rAxis.range ?? [0, 1];
  const origin = polarAxisROrigin(rAxis);
  const scale = polarRScale(rAxis);
  const metrics = new Float64Array(POLAR_METRICS_LEN);
  const written = xyPolarLayout(
    Number(plot.x ?? 0),
    Number(plot.y ?? 0),
    Number(plot.w ?? 0),
    Number(plot.h ?? 0),
    polarThetaUnit(unit),
    polarThetaZero(polarAxisThetaZero(thetaAxis)),
    polarThetaDirection(polarAxisThetaDirection(thetaAxis)),
    Number(sector[0]),
    Number(sector[1]),
    categories.length,
    Number(rLo),
    Number(rHi),
    origin == null ? Number.NaN : Number(origin),
    Number(polarAxisHole(rAxis) || 0),
    scale.kind,
    scale.constant,
    scale.maskNonpositive ? 1 : 0,
    f64Ptr(metrics),
    POLAR_METRICS_LEN,
  );
  if (written !== POLAR_METRICS_LEN) throw new RangeError("invalid polar-layout request");
  return metrics;
}

export function polarProject(metrics, theta, r) {
  const packed = metrics instanceof Float64Array ? metrics : Float64Array.from(metrics);
  const th = Float64Array.from(Array.isArray(theta) ? theta : [theta]);
  const rv = Float64Array.from(Array.isArray(r) ? r : [r]);
  if (th.length !== rv.length) throw new RangeError("theta and r must have the same length");
  const outX = new Float64Array(th.length);
  const outY = new Float64Array(th.length);
  const written = xyPolarProject(
    f64Ptr(packed),
    packed.length,
    f64Ptr(th),
    f64Ptr(rv),
    th.length,
    f64Ptr(outX),
    f64Ptr(outY),
  );
  if (written === USIZE_MAX_64 || written !== th.length) {
    throw new RangeError("invalid polar-project request");
  }
  if (!Array.isArray(theta)) return [outX[0], outY[0]];
  return [outX, outY];
}

export function polarWedgePoints(
  metrics,
  theta0,
  theta1,
  r0,
  r1,
  {
    wedgeGap = 0,
    cornerRadius = 0,
    steps = 0,
    normalized = null,
  } = {},
) {
  const packed = metrics instanceof Float64Array ? metrics : Float64Array.from(metrics);
  const normLo = normalized == null ? Number.NaN : Number(normalized[0]);
  const normHi = normalized == null ? Number.NaN : Number(normalized[1]);
  const probed = xyPolarWedgePoints(
    packed.length ? f64Ptr(packed) : 0,
    packed.length,
    Number(theta0),
    Number(theta1),
    Number(r0),
    Number(r1),
    Number(wedgeGap),
    Number(cornerRadius),
    Number(steps),
    normLo,
    normHi,
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid polar-wedge request");
  const n = Number(probed);
  if (n === 0) return [];
  const outX = new Float64Array(n);
  const outY = new Float64Array(n);
  const written = xyPolarWedgePoints(
    packed.length ? f64Ptr(packed) : 0,
    packed.length,
    Number(theta0),
    Number(theta1),
    Number(r0),
    Number(r1),
    Number(wedgeGap),
    Number(cornerRadius),
    Number(steps),
    normLo,
    normHi,
    f64Ptr(outX),
    f64Ptr(outY),
    n,
  );
  if (written === USIZE_MAX_64 || Number(written) !== n) {
    throw new RangeError("invalid polar-wedge request");
  }
  return Array.from({ length: n }, (_, index) => [outX[index], outY[index]]);
}

export function polarHeatmapInverseMap(
  metrics,
  plot,
  gridW,
  gridH,
  xRange,
  yRange,
  outputScale = 1,
) {
  const packed = metrics instanceof Float64Array ? metrics : Float64Array.from(metrics);
  const outW = new Uint32Array(1);
  const outH = new Uint32Array(1);
  const probed = xyPolarHeatmapInverseMap(
    packed.length ? f64Ptr(packed) : 0,
    packed.length,
    Number(plot.x ?? 0),
    Number(plot.y ?? 0),
    Number(plot.w ?? 0),
    Number(plot.h ?? 0),
    Number(gridW),
    Number(gridH),
    Number(xRange[0]),
    Number(yRange[0]),
    Number(xRange[1]),
    Number(yRange[1]),
    Number(outputScale),
    u32Ptr(outW),
    u32Ptr(outH),
    0,
    0,
    0,
    0,
  );
  if (probed === USIZE_MAX_64) throw new RangeError("invalid polar-heatmap inverse-map request");
  const capacity = Number(outW[0]) * Number(outH[0]);
  const rows = new Uint32Array(capacity);
  const cols = new Uint32Array(capacity);
  const source = new Uint32Array(capacity);
  const written = xyPolarHeatmapInverseMap(
    packed.length ? f64Ptr(packed) : 0,
    packed.length,
    Number(plot.x ?? 0),
    Number(plot.y ?? 0),
    Number(plot.w ?? 0),
    Number(plot.h ?? 0),
    Number(gridW),
    Number(gridH),
    Number(xRange[0]),
    Number(yRange[0]),
    Number(xRange[1]),
    Number(yRange[1]),
    Number(outputScale),
    u32Ptr(outW),
    u32Ptr(outH),
    capacity ? u32Ptr(rows) : 0,
    capacity ? u32Ptr(cols) : 0,
    capacity ? u32Ptr(source) : 0,
    capacity,
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid polar-heatmap inverse-map request");
  const n = Number(written);
  return {
    width: Number(outW[0]),
    height: Number(outH[0]),
    rows: rows.subarray(0, n),
    cols: cols.subarray(0, n),
    sourceIndices: source.subarray(0, n),
  };
}

export function polarLegendRoom(width) {
  const out = new Float64Array(1);
  const written = xyPolarLegendRoom(Number(width), f64Ptr(out));
  if (written === USIZE_MAX_64) throw new RangeError("invalid polar-legend-room request");
  return out[0];
}

export function polarLegendReserve(compact, locHasLeft, width) {
  const side = new Uint32Array(1);
  const room = new Float64Array(1);
  const written = xyPolarLegendReserve(
    compact ? 1 : 0,
    locHasLeft ? 1 : 0,
    Number(width),
    u32Ptr(side),
    f64Ptr(room),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid polar-legend-reserve request");
  return [POLAR_LEGEND_SIDES[side[0]], room[0]];
}

export function polarLabelRoom(widest = null) {
  const out = new Float64Array(1);
  const written = xyPolarLabelRoom(widest == null ? Number.NaN : Number(widest), f64Ptr(out));
  if (written === USIZE_MAX_64) throw new RangeError("invalid polar-label-room request");
  return out[0];
}

/** Polar recut incoming top-axis room. Python `recut_polar_plot` reads `plot.get("top_axis_room", 0.0)` only. */
export function plotTopAxisRoom(plot) {
  return (plot ?? {}).top_axis_room;
}

export function recutPolarPlot(plot, width, height, {
  legendSide = "",
  legendRoom = 0,
  polarLabelRoom: labelRoom = 0,
  authoredPadding = false,
  yTitled = false,
  keepsBottom = false,
} = {}) {
  const side = POLAR_LEGEND_SIDE_CODES[legendSide];
  if (side === undefined) throw new RangeError("legendSide must be '', left, right, or bottom");
  const incoming = Float64Array.from([
    Number(plot.x),
    Number(plot.y),
    Number(plot.w),
    Number(plot.h),
    Number(plotTopAxisRoom(plot) ?? 0),
  ]);
  const out = new Float64Array(9);
  const written = xyRecutPolarPlot(
    f64Ptr(incoming),
    Number(width),
    Number(height),
    side,
    Number(legendRoom),
    Number(labelRoom),
    authoredPadding ? 1 : 0,
    yTitled ? 1 : 0,
    keepsBottom ? 1 : 0,
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid polar-recut request");
  const result = { x: out[0], y: out[1], w: out[2], h: out[3], topAxisRoom: out[4] };
  if (Number.isFinite(out[5])) {
    result.legendBoxX = out[5];
    result.legendBoxY = out[6];
    result.legendBoxW = out[7];
    result.legendBoxH = out[8];
  }
  return result;
}

export function compatCombinePlot(width, height, {
  authoredPadding = null,
  titleRoom = 0,
  xTopRoom = 0,
  xBottomRoom = 0,
  xMeasuredBottom = 0,
  colorbarKind = "none",
  colorbarHasLabel = false,
  colorbarPadZero = false,
  hasRightY = false,
  yLeftRoom = null,
  edgeLeft = null,
  edgeRight = null,
  xRoomsFinal = null,
  polar = null,
} = {}) {
  const code = COLORBAR_KINDS[colorbarKind];
  if (code === undefined) throw new RangeError("unknown colorbar layout kind");
  const pad = authoredPadding == null ? null : Float64Array.from(authoredPadding);
  if (pad != null && pad.length !== 4) {
    throw new RangeError("authoredPadding must be top, right, bottom, left");
  }
  const xFinal = xRoomsFinal == null ? null : Float64Array.from(xRoomsFinal);
  if (xFinal != null && xFinal.length !== 3) {
    throw new RangeError("xRoomsFinal must be top, bottom, measuredBottom");
  }
  const polarOn = polar != null;
  let side = 0;
  let legendRoom = 0;
  let labelRoom = 0;
  let authoredPaddingFlag = false;
  let yTitled = false;
  let keepsBottom = false;
  if (polarOn) {
    const legendSide = polar.legendSide ?? polar.legend_side ?? "";
    side = POLAR_LEGEND_SIDE_CODES[legendSide];
    if (side === undefined) throw new RangeError("legendSide must be '', left, right, or bottom");
    legendRoom = Number(polar.legendRoom ?? polar.legend_room ?? 0);
    labelRoom = Number(polar.polarLabelRoom ?? polar.polar_label_room ?? 0);
    authoredPaddingFlag = Boolean(polar.authoredPadding ?? polar.authored_padding);
    yTitled = Boolean(polar.yTitled ?? polar.y_titled);
    keepsBottom = Boolean(polar.keepsBottom ?? polar.keeps_bottom);
  }
  const out = new Float64Array(12);
  const written = xyCompatCombinePlot(
    Number(width),
    Number(height),
    pad == null ? 0 : f64Ptr(pad),
    Number(titleRoom),
    Number(xTopRoom),
    Number(xBottomRoom),
    Number(xMeasuredBottom),
    code,
    colorbarHasLabel ? 1 : 0,
    colorbarPadZero ? 1 : 0,
    hasRightY ? 1 : 0,
    yLeftRoom == null ? Number.NaN : Number(yLeftRoom),
    edgeLeft == null ? Number.NaN : Number(edgeLeft),
    edgeRight == null ? Number.NaN : Number(edgeRight),
    xFinal == null ? 0 : f64Ptr(xFinal),
    polarOn ? 1 : 0,
    side,
    legendRoom,
    labelRoom,
    authoredPaddingFlag ? 1 : 0,
    yTitled ? 1 : 0,
    keepsBottom ? 1 : 0,
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid static-export layout combination");
  const result = {
    x: out[0],
    y: out[1],
    w: out[2],
    h: out[3],
    titleRoom: out[4],
    titleWrapWidth: out[5],
    topAxisRoom: out[6],
    bottomAxisRoom: out[7],
  };
  if (Number.isFinite(out[8])) {
    result.legendBoxX = out[8];
    result.legendBoxY = out[9];
    result.legendBoxW = out[10];
    result.legendBoxH = out[11];
  }
  return result;
}

export function tightLayoutSolve({
  canvasW,
  canvasH,
  nrows,
  ncols,
  compact = false,
  panels = [],
  extra = [0, 0, 0, 0],
  pad = null,
  wPad = null,
  hPad = null,
  pointPx = 1,
  rect = [0, 0, 1, 1],
} = {}) {
  if (!Array.isArray(extra) || extra.length !== 4) {
    throw new RangeError("extra must be left, right, bottom, top");
  }
  if (!Array.isArray(rect) || rect.length !== 4) {
    throw new RangeError("rect must be left, bottom, right, top");
  }
  const packed = new Float64Array(panels.length * 8);
  for (let index = 0; index < panels.length; index += 1) {
    const panel = panels[index];
    const at = index * 8;
    packed[at] = Number(panel.row0);
    packed[at + 1] = Number(panel.row1);
    packed[at + 2] = Number(panel.col0);
    packed[at + 3] = Number(panel.col1);
    packed[at + 4] = Number(panel.left);
    packed[at + 5] = Number(panel.top);
    packed[at + 6] = Number(panel.right);
    packed[at + 7] = Number(panel.bottom);
  }
  const extraArr = Float64Array.from(extra, (value) => Number(value));
  const rectArr = Float64Array.from(rect, (value) => Number(value));
  const out = new Float64Array(6);
  const written = xyTightLayoutSolve(
    Number(canvasW),
    Number(canvasH),
    Number(nrows) >>> 0,
    Number(ncols) >>> 0,
    compact ? 1 : 0,
    packed.length ? f64Ptr(packed) : 0,
    BigInt(panels.length),
    f64Ptr(extraArr),
    pad == null ? Number.NaN : Number(pad),
    wPad == null ? Number.NaN : Number(wPad),
    hPad == null ? Number.NaN : Number(hPad),
    Number(pointPx),
    f64Ptr(rectArr),
    f64Ptr(out),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid tight-layout request");
  return { left: out[0], right: out[1], bottom: out[2], top: out[3], wspace: out[4], hspace: out[5] };
}

export function tightLayoutFigureExtra(canvasW, canvasH, {
  suptitleHeight = null,
  suptitleY = 0.98,
  xlabelSize = null,
  ylabelSize = null,
  legendBoxW = null,
} = {}) {
  const extra = new Float64Array(4);
  const written = xyTightLayoutFigureExtra(
    Number(canvasW),
    Number(canvasH),
    suptitleHeight == null ? Number.NaN : Number(suptitleHeight),
    Number(suptitleY),
    xlabelSize == null ? Number.NaN : Number(xlabelSize),
    ylabelSize == null ? Number.NaN : Number(ylabelSize),
    legendBoxW == null ? Number.NaN : Number(legendBoxW),
    f64Ptr(extra),
  );
  if (written === USIZE_MAX_64) throw new RangeError("invalid tight-layout figure-extra request");
  return { left: extra[0], right: extra[1], bottom: extra[2], top: extra[3] };
}

export function scaleMap({ values, kind = "linear", operation = "pixel", domain, range = [0, 1], constant = 1, nonpositive = "clip" }) {
  const kindCode = kind === "linear" ? 0 : kind === "log" ? 1 : kind === "symlog" ? 2 : -1;
  const operationCode = operation === "coord" ? 0 : operation === "pixel" ? 1 : operation === "value" ? 2 : -1;
  if (kindCode < 0) throw new RangeError("kind must be linear, log, or symlog");
  if (operationCode < 0) throw new RangeError("operation must be coord, pixel, or value");
  if (nonpositive !== "clip" && nonpositive !== "mask") {
    throw new RangeError("nonpositive must be clip or mask");
  }
  if (!Array.isArray(domain) || domain.length !== 2 || !Array.isArray(range) || range.length !== 2) {
    throw new RangeError("domain and range must each contain two values");
  }
  const source = asF64Array(values, "values");
  const output = new Float64Array(source.length);
  const status = xySceneScaleMap(
    f64Ptr(source), BigInt(source.length), kindCode, operationCode,
    Number(domain[0]), Number(domain[1]), Number(range[0]), Number(range[1]),
    Number(constant), nonpositive === "mask" ? 1 : 0, f64Ptr(output),
  );
  if (status !== 0) throw new RangeError("invalid canonical scene scale");
  return output;
}

function axisDescriptor(axis, name) {
  const { id, kind = "linear", domain, constant = 1, nonpositive = "clip" } = axis;
  const kindCode = kind === "linear" ? 0 : kind === "log" ? 1 : kind === "symlog" ? 2 : -1;
  if (kindCode < 0) throw new RangeError(`${name}.kind must be linear, log, or symlog`);
  if (nonpositive !== "clip" && nonpositive !== "mask") throw new RangeError(`${name}.nonpositive must be clip or mask`);
  if (!Array.isArray(domain) || domain.length !== 2) throw new RangeError(`${name}.domain must contain two values`);
  return [asU64(id, `${name}.id`), kindCode, Number(domain[0]), Number(domain[1]), Number(constant), nonpositive === "mask" ? 1 : 0];
}

const AXIS_STYLE_KEYS = new Set([
  "grid_color", "grid_width", "grid_opacity", "axis_color", "axis_width",
  "tick_color", "tick_width", "tick_length", "tick_direction", "tick_label_color", "label_color",
]);

/** Chrome axis style keys. Python `_SCENE_AXIS_STYLE_KEYS` is snake-case only. */
export function chromeAxisStyleKeys() {
  return AXIS_STYLE_KEYS;
}

/** Chrome axis style presence. Python `_pack_chrome_axis` uses `key in style` only. */
export function chromeAxisStyleHas(style, key) {
  return Object.hasOwn(style ?? {}, key);
}

/** Chrome axis style value. Python `_pack_chrome_axis` uses `style.get(key, fallback)` only. */
export function chromeAxisStyleValue(style, key, fallback) {
  if (Object.hasOwn(style ?? {}, key)) return style[key];
  return fallback;
}

function packChromeAxis(axis, options, sides) {
  const style = options.style ?? {};
  const minor = chromeAxisMinorStyle(options) ?? {};
  for (const [label, authored] of [["style", style], ["minor_style", minor]]) {
    const unsupported = Object.keys(authored).filter((key) => !AXIS_STYLE_KEYS.has(key));
    if (unsupported.length) {
      throw new RangeError(`Scene v12 does not yet encode ${axis} axis ${label} keys`);
    }
  }
  const side = options.side ?? sides[0];
  if (!sides.includes(side)) throw new RangeError(`Scene ${axis} axis side is invalid`);
  const sideCode = sides.indexOf(side);
  const mask = (values, name) => {
    if (values == null) return 1 << sideCode;
    return values.reduce((sum, value) => {
      const index = sides.indexOf(value);
      if (index < 0) throw new RangeError(`Scene ${axis} axis ${name} are invalid`);
      return sum | (1 << index);
    }, 0);
  };
  const direction = { out: 0, in: 1, inout: 2 };
  let paintFlags = 0;
  if (chromeAxisStyleHas(style, "axis_color")) paintFlags |= 1 << 0;
  if (chromeAxisStyleHas(style, "grid_color")) paintFlags |= 1 << 1;
  if (chromeAxisStyleHas(style, "tick_color")) paintFlags |= 1 << 2;
  if (chromeAxisStyleHas(minor, "grid_color")) paintFlags |= 1 << 3;
  if (chromeAxisStyleHas(minor, "tick_color")) paintFlags |= 1 << 4;
  if (chromeAxisStyleHas(style, "tick_label_color") || chromeAxisStyleHas(style, "label_color")) paintFlags |= 1 << 5;
  const widthSpecs = [
    [style, "axis_width", 1],
    [style, "grid_width", 1],
    [style, "tick_width", 1],
    [style, "tick_length", 4],
    [minor, "grid_width", 1],
    [minor, "tick_width", 1],
    [minor, "tick_length", 0],
  ];
  let widthFlags = 0;
  const widths = widthSpecs.map(([source, snake, fallback], index) => {
    if (chromeAxisStyleHas(source, snake)) {
      widthFlags |= 1 << index;
      return Number(chromeAxisStyleValue(source, snake, fallback));
    }
    return fallback;
  });
  const paints = [
    String(chromeAxisStyleValue(style, "axis_color", "#202020")),
    String(chromeAxisStyleValue(style, "grid_color", "#202020")),
    String(chromeAxisStyleValue(style, "tick_color", "#202020")),
    String(chromeAxisStyleValue(minor, "grid_color", "transparent")),
    String(chromeAxisStyleValue(minor, "tick_color", "#202020")),
    String(chromeAxisStyleValue(style, "tick_label_color", chromeAxisStyleValue(style, "label_color", "#202020"))),
  ].map(encodeUtf8);
  const prefix = new Uint8Array(84);
  const view = new DataView(prefix.buffer);
  prefix[0] = sideCode;
  prefix[1] = mask(chromeAxisTickSides(options), "tick_sides");
  prefix[2] = mask(chromeAxisTickLabelSides(options), "tick_label_sides");
  prefix[3] = direction[String(chromeAxisStyleValue(style, "tick_direction", "out"))] ?? 255;
  prefix[4] = direction[String(chromeAxisStyleValue(minor, "tick_direction", "out"))] ?? 255;
  prefix[5] = paintFlags;
  prefix[6] = widthFlags;
  view.setFloat32(8, Number(chromeAxisStyleValue(style, "grid_opacity", 1)), true);
  view.setFloat32(12, Number(chromeAxisStyleValue(minor, "grid_opacity", 1)), true);
  widths.forEach((value, index) => view.setFloat64(16 + index * 8, value, true));
  paints.forEach((bytes, index) => view.setUint16(72 + index * 2, bytes.length, true));
  return concatBytes([prefix, ...paints]);
}

function resolveChromeStyle(envelope) {
  const out = new Uint8Array(200);
  const code = xySceneResolveChromeStyle(u8Ptr(envelope), BigInt(envelope.length), u8Ptr(out), BigInt(out.length));
  if (code !== 200) throw new RangeError("invalid chrome style envelope");
  return out;
}

function defaultChromeStyle() {
  const envelope = new Uint8Array(16);
  envelope.set(encodeUtf8("XYCH").slice(0, 4), 0);
  new DataView(envelope.buffer).setUint32(4, 1, true);
  return resolveChromeStyle(envelope);
}

function packXyCh(figure) {
  const figureStyle = figure.style ?? {};
  let flags = 2 << 8;
  let chart = new Uint8Array(0);
  let plot = new Uint8Array(0);
  if (figureStyle.background != null) {
    flags |= 1;
    chart = encodeUtf8(figureStyle.background || "transparent");
  }
  if (figureStyle["--chart-bg"] != null) {
    flags |= 2;
    plot = encodeUtf8(figureStyle["--chart-bg"] || "transparent");
  }
  const axes = figureAxisOptions(figure) ?? {};
  const x = packChromeAxis("x", axes.x ?? {}, ["bottom", "top"]);
  const y = packChromeAxis("y", axes.y ?? {}, ["left", "right"]);
  const header = new Uint8Array(16);
  const view = new DataView(header.buffer);
  header.set(encodeUtf8("XYCH").slice(0, 4), 0);
  view.setUint32(4, 1, true);
  view.setUint32(8, flags >>> 0, true);
  view.setUint16(12, chart.length, true);
  view.setUint16(14, plot.length, true);
  return concatBytes([header, chart, plot, x, y]);
}

function figureChromeStyle(figure) {
  return resolveChromeStyle(packXyCh(figure));
}

/** Encode the shared backend-neutral Scene v12 typed batch. */
export function sceneBatchEncode({
  viewport, margins, xAxis, yAxis, kinds, stableIds, styleRefs, styles, diameter, symbols, x0, y0, x1, y1,
  expansionModes = null,
  title = "", xLabel = "", yLabel = "", chromeStyle = null,
  xMajorTicks = null, xMinorTicks = [], yMajorTicks = null, yMinorTicks = [],
  xTickLabels = null, yTickLabels = null,
  xFormat = null, yFormat = null,
  legendInput = null, colorbarInput = null, authoredTextAnnotations = null,
  polarInput = null,
}) {
  if (!Array.isArray(viewport) || viewport.length !== 2 || !Array.isArray(margins) || margins.length !== 4) {
    throw new RangeError("viewport and margins must contain two and four values");
  }
  if (styles.length > MAX_SCENE_STYLES) {
    throw new RangeError(`scene style tables are limited to ${MAX_SCENE_STYLES} entries`);
  }
  const kindArray = asUnsignedArray(kinds, "kinds", 255, Uint8Array);
  if (kindArray.length > MAX_SCENE_MARKS) {
    throw new RangeError(`scene batches are limited to ${MAX_SCENE_MARKS} records`);
  }
  const ids = asStableIds(stableIds);
  const styleRefArray = asUnsignedArray(styleRefs, "styleRefs", 0xffff_ffff, Uint32Array);
  const diameters = asF64Array(diameter, "diameter");
  const symbolCodes = asUnsignedArray(symbols, "symbols", 255, Uint8Array);
  const expansionModeCodes = expansionModes == null
    ? new Uint8Array(kindArray.length)
    : asUnsignedArray(expansionModes, "expansionModes", 12, Uint8Array);
  const fills = new Uint8Array(styles.length * 4);
  const strokes = new Uint8Array(styles.length * 4);
  const widths = new Float64Array(styles.length);
  for (const [index, style] of styles.entries()) {
    const fill = asUnsignedArray(style.fillRgba, `styles[${index}].fillRgba`, 255, Uint8Array);
    const stroke = asUnsignedArray(style.strokeRgba, `styles[${index}].strokeRgba`, 255, Uint8Array);
    requireLength(fill, 4, `styles[${index}].fillRgba`);
    requireLength(stroke, 4, `styles[${index}].strokeRgba`);
    fills.set(fill, index * 4);
    strokes.set(stroke, index * 4);
    widths[index] = Number(style.strokeWidth ?? 0);
  }
  const coordinates = [x0, y0, x1, y1].map((value, index) => asF64Array(value, ["x0", "y0", "x1", "y1"][index]));
  const length = kindArray.length;
  for (const [value, name] of [[ids, "stableIds"], [styleRefArray, "styleRefs"], [diameters, "diameter"], [symbolCodes, "symbols"], [expansionModeCodes, "expansionModes"], ...coordinates.map((value, index) => [value, ["x0", "y0", "x1", "y1"][index]])]) requireLength(value, length, name);
  const xd = axisDescriptor(xAxis, "xAxis");
  const yd = axisDescriptor(yAxis, "yAxis");
  const titleBytes = new TextEncoder().encode(String(title ?? ""));
  const xLabelBytes = new TextEncoder().encode(String(xLabel ?? ""));
  const yLabelBytes = new TextEncoder().encode(String(yLabel ?? ""));
  if ([titleBytes, xLabelBytes, yLabelBytes].some((value) => value.length > MAX_SCENE_TEXT_BYTES)) {
    throw new RangeError(`scene title and axis labels are limited to ${MAX_SCENE_TEXT_BYTES} UTF-8 bytes each`);
  }
  const chrome = chromeStyle == null
    ? defaultChromeStyle()
    : asUnsignedArray(chromeStyle, "chromeStyle", 255, Uint8Array);
  requireLength(chrome, 200, "chromeStyle");
  const tickArrays = [xMajorTicks, xMinorTicks, yMajorTicks, yMinorTicks].map((value, index) => value == null ? null : asF64Array(value, ["xMajorTicks", "xMinorTicks", "yMajorTicks", "yMinorTicks"][index]));
  const frameTickLabels = (labels, name) => {
    if (labels == null) return new Uint8Array();
    if (!Array.isArray(labels) || labels.length > 200) throw new RangeError(`${name} must contain at most 200 strings`);
    const texts = labels.map((value) => new TextEncoder().encode(String(value)));
    if (texts.some((value) => value.length === 0 || value.includes(0)) || texts.reduce((sum, value) => sum + value.length, 0) > MAX_SCENE_TEXT_BYTES) throw new RangeError(`${name} must contain nonempty bounded UTF-8 strings`);
    const out = new Uint8Array(12 + texts.reduce((sum, value) => sum + 4 + value.length, 0)); const view = new DataView(out.buffer);
    out.set(new TextEncoder().encode("XYTL")); view.setUint32(4, 1, true); view.setUint32(8, texts.length, true); let at = 12;
    for (const text of texts) { view.setUint32(at, text.length, true); at += 4; out.set(text, at); at += text.length; }
    return out;
  };
  const xTickLabelBytes = frameTickLabels(xTickLabels, "xTickLabels");
  const yTickLabelBytes = frameTickLabels(yTickLabels, "yTickLabels");
  const frameAxisFormat = (value, name) => {
    if (value == null) return new Uint8Array();
    if (typeof value !== "string") throw new TypeError(`${name} must be a string or null`);
    const encoded = new TextEncoder().encode(value);
    if (encoded.length > 256 || encoded.includes(0)) throw new RangeError(`${name} must be NUL-free and at most 256 UTF-8 bytes`);
    return encoded;
  };
  const xFormatBytes = frameAxisFormat(xFormat, "xFormat");
  const yFormatBytes = frameAxisFormat(yFormat, "yFormat");
  const legend = legendInput == null ? new Uint8Array() : asUnsignedArray(legendInput, "legendInput", 255, Uint8Array);
  const colorbar = colorbarInput == null ? new Uint8Array() : asUnsignedArray(colorbarInput, "colorbarInput", 255, Uint8Array);
  const polar = polarInput == null || polarInput.length === 0
    ? new Uint8Array()
    : asUnsignedArray(polarInput, "polarInput", 255, Uint8Array);
  if (polar.length) {
    const magic = String.fromCharCode(...polar.subarray(0, 4));
    if (!["XYPL", "XYHP", "XYEX", "XYDS", "XYLC", "XYMP", "XYGR"].includes(magic)) {
      throw new RangeError("polarInput must be empty, XYPL, XYHP, XYEX, XYDS, XYLC, XYMP, or XYGR");
    }
    if (magic === "XYPL" && polar.length !== 92) {
      throw new RangeError("polarInput must be empty or a 92-byte XYPL v1 envelope");
    }
  }
  const authoredText = authoredTextAnnotations == null ? new Uint8Array() : asUnsignedArray(authoredTextAnnotations, "authoredTextAnnotations", 255, Uint8Array);
  const authoredInput = xFormatBytes.length || yFormatBytes.length ? (() => {
    const out = new Uint8Array(20 + xFormatBytes.length + yFormatBytes.length + authoredText.length);
    const view = new DataView(out.buffer);
    out.set(new TextEncoder().encode("XYAF"));
    view.setUint32(4, 1, true);
    view.setUint32(8, xFormatBytes.length, true);
    view.setUint32(12, yFormatBytes.length, true);
    view.setUint32(16, authoredText.length, true);
    out.set(xFormatBytes, 20);
    out.set(yFormatBytes, 20 + xFormatBytes.length);
    out.set(authoredText, 20 + xFormatBytes.length + yFormatBytes.length);
    return out;
  })() : authoredText;
  if (colorbar.length > 4_600) throw new RangeError("scene colorbar input is limited to 4,600 bytes");
  if (tickArrays.some((value) => value != null && value.length > 200)) throw new RangeError("scene axis tick lists are limited to 200 values");
  const polarView = polarAbiInputPointer(polar);
  let capacity = 160 + widths.length * 16 + length * 56 + 248 + titleBytes.length + xLabelBytes.length + yLabelBytes.length + xTickLabelBytes.length + yTickLabelBytes.length + authoredInput.length + legend.length + colorbar.length + tickArrays.reduce((sum, value) => sum + (value?.byteLength ?? 0), 0);
  for (;;) {
    const output = new Uint8Array(capacity);
    const rawWritten = xySceneBatchEncode(
      Number(viewport[0]), Number(viewport[1]), ...margins.map(Number), ...xd, ...yd,
      u8Ptr(chrome), BigInt(chrome.length),
      f64Ptr(tickArrays[0]), BigInt(tickArrays[0]?.length ?? 0), tickArrays[0] == null ? 1 : 0,
      f64Ptr(tickArrays[1]), BigInt(tickArrays[1]?.length ?? 0),
      f64Ptr(tickArrays[2]), BigInt(tickArrays[2]?.length ?? 0), tickArrays[2] == null ? 1 : 0,
      f64Ptr(tickArrays[3]), BigInt(tickArrays[3]?.length ?? 0),
      xTickLabelBytes.length ? u8Ptr(xTickLabelBytes) : 0, BigInt(xTickLabelBytes.length),
      yTickLabelBytes.length ? u8Ptr(yTickLabelBytes) : 0, BigInt(yTickLabelBytes.length),
      authoredInput.length ? u8Ptr(authoredInput) : 0, BigInt(authoredInput.length),
      u8Ptr(kindArray), pointer(ids, "uint64_t *"), u32Ptr(styleRefArray),
      u8Ptr(fills), u8Ptr(strokes), f64Ptr(widths), BigInt(widths.length),
      f64Ptr(diameters), u8Ptr(symbolCodes), u8Ptr(expansionModeCodes),
      ...coordinates.map(f64Ptr), BigInt(length),
      titleBytes.length ? u8Ptr(titleBytes) : 0, BigInt(titleBytes.length),
      xLabelBytes.length ? u8Ptr(xLabelBytes) : 0, BigInt(xLabelBytes.length),
      yLabelBytes.length ? u8Ptr(yLabelBytes) : 0, BigInt(yLabelBytes.length),
      legend.length ? u8Ptr(legend) : 0, BigInt(legend.length),
      colorbar.length ? u8Ptr(colorbar) : 0, BigInt(colorbar.length),
      polarView.ptr,
      u8Ptr(output), BigInt(capacity),
    );
    if (rawWritten === USIZE_MAX_64) throw new RangeError("invalid canonical scene batch");
    const written = Number(rawWritten);
    if (!Number.isSafeInteger(written) || written < 0) throw new RangeError("canonical scene batch exceeded host output limits");
    if (written <= capacity) return output.slice(0, written);
    capacity = written;
  }
}

function sceneOutput(encoded, call, name, extra = []) {
  const source = asU8Array(encoded, "encoded scene");
  if (source.length === 0) throw new RangeError("encoded scene must not be empty");
  let capacity = Math.max(256, source.length * 3);
  for (;;) {
    const output = new Uint8Array(capacity);
    const rawWritten = call(u8Ptr(source), BigInt(source.length), ...extra, u8Ptr(output), BigInt(capacity));
    if (rawWritten === USIZE_MAX_64) throw new RangeError(`invalid canonical scene for ${name}`);
    const written = Number(rawWritten);
    if (!Number.isSafeInteger(written) || written < 0) throw new RangeError(`${name} output exceeded host limits`);
    if (written <= capacity) return output.slice(0, written);
    capacity = written;
  }
}

export function sceneSvg(encoded) {
  return new TextDecoder().decode(sceneOutput(encoded, xySceneSvg, "SVG"));
}

export function svgToPdf(svg) {
  const text = String(svg);
  const source = new TextEncoder().encode(text);
  let capacity = Math.max(256, source.length * 2);
  for (;;) {
    const output = new Uint8Array(capacity);
    const rawWritten = xySvgToPdf(
      source.length ? u8Ptr(source) : 0,
      BigInt(source.length),
      u8Ptr(output),
      BigInt(capacity),
    );
    if (rawWritten === USIZE_MAX_64) {
      const end = output.indexOf(0);
      const message = new TextDecoder().decode(end >= 0 ? output.subarray(0, end) : output).trim()
        || "unsupported SVG feature";
      throw new RangeError(message);
    }
    const written = Number(rawWritten);
    if (!Number.isSafeInteger(written) || written < 0) {
      throw new RangeError("svgToPdf output exceeded host limits");
    }
    if (written <= capacity) return output.slice(0, written);
    capacity = written;
  }
}

function encodePixels(fn, pixels, width, height, channels, extra = [], label = "image") {
  const source = pixels instanceof Uint8Array ? pixels : new Uint8Array(pixels);
  const w = Number(width);
  const h = Number(height);
  const c = Number(channels);
  if (!Number.isInteger(w) || !Number.isInteger(h) || !Number.isInteger(c)) {
    throw new RangeError(`${label} dimensions must be integers`);
  }
  let capacity = Math.max(256, source.length);
  for (;;) {
    const output = new Uint8Array(capacity);
    const rawWritten = fn(
      source.length ? u8Ptr(source) : 0,
      BigInt(source.length),
      BigInt(w),
      BigInt(h),
      BigInt(c),
      ...extra,
      u8Ptr(output),
      BigInt(capacity),
    );
    if (rawWritten === USIZE_MAX_64) {
      const end = output.indexOf(0);
      const message = new TextDecoder().decode(end >= 0 ? output.subarray(0, end) : output).trim()
        || `invalid ${label} input`;
      throw new RangeError(message);
    }
    const written = Number(rawWritten);
    if (!Number.isSafeInteger(written) || written < 0) {
      throw new RangeError(`${label} output exceeded host limits`);
    }
    if (written <= capacity) return output.slice(0, written);
    capacity = written;
  }
}

export function encodeJpeg(pixels, width, height, channels, quality = 90) {
  const q = Number(quality);
  if (!Number.isInteger(q)) throw new RangeError("quality must be an int in 1..100");
  return encodePixels(xyEncodeJpeg, pixels, width, height, channels, [q], "JPEG");
}

export function encodeWebp(pixels, width, height, channels) {
  return encodePixels(xyEncodeWebp, pixels, width, height, channels, [], "WebP");
}

export function encodePng(pixels, width, height, channels, mode = 0, compression = 6) {
  const m = Number(mode);
  const c = Number(compression);
  if (!Number.isInteger(m) || (m !== 0 && m !== 1)) {
    throw new RangeError("PNG mode must be 0 (auto) or 1 (truecolor)");
  }
  if (!Number.isInteger(c) || c < 0 || c > 9) {
    throw new RangeError("PNG compression must be an int in 0..9");
  }
  return encodePixels(xyEncodePng, pixels, width, height, channels, [m, c], "PNG");
}

export function sceneRasterCommands(encoded, scale = DEFAULT_PNG_EXPORT_SCALE) {
  const factor = Number(scale);
  if (!Number.isFinite(factor) || factor <= 0) throw new RangeError("scene raster scale must be positive and finite");
  return sceneOutput(encoded, xySceneRasterCommands, "raster commands", [factor]);
}

const SCENE_STATIC_FORMATS = { svg: 0, png: 1, pdf: 2, jpeg: 3, webp: 4 };

export function sceneStaticExport(encoded, format, { scale = DEFAULT_PNG_EXPORT_SCALE, width = 1, height = 1, quality = 90 } = {}) {
  const code = SCENE_STATIC_FORMATS[format];
  if (code == null) {
    throw new RangeError(`Scene public static format must be svg, png, pdf, jpeg, or webp, got ${String(format)}`);
  }
  let factor = Number(scale);
  if (format === "png" || format === "jpeg" || format === "webp") {
    if (!Number.isFinite(factor) || factor <= 0) throw new RangeError("scene raster scale must be positive and finite");
  } else if (!Number.isFinite(factor)) {
    factor = 1;
  }
  const w = Number(width);
  const h = Number(height);
  const q = Number(quality);
  if (!Number.isInteger(w) || w <= 0) throw new RangeError("scene static width must be a positive integer");
  if (!Number.isInteger(h) || h <= 0) throw new RangeError("scene static height must be a positive integer");
  if (!Number.isInteger(q)) throw new RangeError("quality must be an int in 1..100");
  return sceneOutput(encoded, xySceneStaticExport, "static export", [code, factor, BigInt(w), BigInt(h), q]);
}

function staticU32(value, label, positive = false) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < (positive ? 1 : 0) || number > 0xffff_ffff) {
    throw new RangeError(`${label} must be a ${positive ? "positive " : "non-negative "}u32 integer`);
  }
  return number;
}

function staticI32(value, label) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < -0x8000_0000 || number > 0x7fff_ffff) {
    throw new RangeError(`${label} must be a signed i32 integer`);
  }
  return number;
}

function staticLegendBytes(legend, encoder) {
  const items = Array.from(legend?.items ?? []);
  if (items.length === 0) return new Uint8Array();
  const style = legend?.style ?? {};
  const hasNumeric = (object, key) => Object.hasOwn(object, key) && object[key] != null;
  let flags = 0;
  if (hasNumeric(legend, "ncols")) flags |= 1;
  if (hasNumeric(legend, "handlelength")) flags |= 2;
  if (hasNumeric(legend, "handletextpad")) flags |= 4;
  if (hasNumeric(legend, "border_pad")) flags |= 8;
  const anchor = legend?.anchor == null ? null : Array.from(legend.anchor, Number);
  if (anchor != null) flags |= 16;
  const header = new Uint8Array(64);
  const headerView = new DataView(header.buffer);
  header.set([88, 89, 68, 76], 0); // XYDL
  headerView.setUint32(4, 1, true);
  headerView.setUint32(8, flags, true);
  headerView.setUint32(12, items.length, true);
  headerView.setInt32(16, flags & 1 ? staticI32(legend.ncols, "StaticDocument legend ncols") : 0, true);
  headerView.setFloat64(24, flags & 2 ? Number(legend.handlelength) : 0, true);
  headerView.setFloat64(32, flags & 4 ? Number(legend.handletextpad) : 0, true);
  headerView.setFloat64(40, flags & 8 ? Number(legend.border_pad) : 0, true);
  if (anchor != null && anchor.length === 2) {
    headerView.setFloat64(48, anchor[0], true);
    headerView.setFloat64(56, anchor[1], true);
  } else if (anchor != null) {
    throw new RangeError("XYG_STATIC_UNSUPPORTED_PANEL_LEGEND_ANCHOR");
  }
  const optionalText = (value) => {
    if (value == null) {
      const absent = new Uint8Array(4);
      new DataView(absent.buffer).setUint32(0, 0xffff_ffff, true);
      return absent;
    }
    const encoded = encoder.encode(String(value));
    const packed = new Uint8Array(4 + encoded.length);
    new DataView(packed.buffer).setUint32(0, encoded.length, true);
    packed.set(encoded, 4);
    return packed;
  };
  const chunks = [
    header,
    ...[
      legend?.title,
      legend?.loc,
      legend?.figure_loc,
      style.fontSize,
      style.padding,
      style.rowGap,
      style.color,
      style.background,
      style.borderColor,
      style["--xy-legend-frame-alpha"],
      style.fontFamily,
    ].map(optionalText),
  ];
  items.forEach((item) => {
    const itemStyle = item?.style ?? {};
    let itemFlags = 0;
    if (hasNumeric(itemStyle, "width")) itemFlags |= 1;
    if (hasNumeric(itemStyle, "stroke_width")) itemFlags |= 2;
    // XYDL requires a positive marker size for every item; default 8 px.
    itemFlags |= 4;
    if (hasNumeric(itemStyle, "opacity")) itemFlags |= 8;
    if (itemStyle.dash) itemFlags |= 16;
    const packed = new Uint8Array(40);
    const view = new DataView(packed.buffer);
    view.setUint32(0, itemFlags, true);
    view.setFloat64(8, itemFlags & 1 ? Number(itemStyle.width) : 0, true);
    view.setFloat64(16, itemFlags & 2 ? Number(itemStyle.stroke_width) : 0, true);
    view.setFloat64(24, Number(itemStyle.size ?? 8), true);
    view.setFloat64(32, itemFlags & 8 ? Number(itemStyle.opacity) : 0, true);
    chunks.push(
      packed,
      optionalText(item?.kind),
      optionalText(item?.name),
      optionalText(itemStyle.color),
      optionalText(itemStyle.symbol),
    );
  });
  const request = new Uint8Array(chunks.reduce((total, chunk) => total + chunk.length, 0));
  let at = 0;
  chunks.forEach((chunk) => {
    request.set(chunk, at);
    at += chunk.length;
  });
  return staticDocumentLegend(request);
}

function staticLabelBytes(labels, encoder) {
  const hasNumeric = (object, key) => Object.hasOwn(object, key) && object[key] != null;
  const header = new Uint8Array(16);
  const headerView = new DataView(header.buffer);
  header.set([88, 89, 68, 65], 0); // XYDA
  headerView.setUint32(4, 1, true);
  headerView.setUint32(8, labels.length, true);
  const optionalText = (value) => {
    if (value == null) {
      const absent = new Uint8Array(4);
      new DataView(absent.buffer).setUint32(0, 0xffff_ffff, true);
      return absent;
    }
    const encoded = encoder.encode(String(value));
    const packed = new Uint8Array(4 + encoded.length);
    new DataView(packed.buffer).setUint32(0, encoded.length, true);
    packed.set(encoded, 4);
    return packed;
  };
  const chunks = [header];
  labels.forEach((label) => {
    let flags = 0;
    if (hasNumeric(label, "x")) flags |= 1;
    if (hasNumeric(label, "y")) flags |= 2;
    if (hasNumeric(label, "size")) flags |= 4;
    if (hasNumeric(label, "rotation")) flags |= 8;
    if (hasNumeric(label, "opacity")) flags |= 16;
    const packed = new Uint8Array(48);
    const view = new DataView(packed.buffer);
    view.setUint32(0, flags, true);
    view.setFloat64(8, flags & 1 ? Number(label.x) : 0, true);
    view.setFloat64(16, flags & 2 ? Number(label.y) : 0, true);
    view.setFloat64(24, flags & 4 ? Number(label.size) : 0, true);
    view.setFloat64(32, flags & 8 ? Number(label.rotation) : 0, true);
    view.setFloat64(40, flags & 16 ? Number(label.opacity) : 0, true);
    chunks.push(
      packed,
      optionalText(label?.text),
      optionalText(label?.family),
      optionalText(label?.anchor),
      optionalText(label?.vertical_align),
      optionalText(label?.font_style),
      optionalText(label?.weight),
      optionalText(label?.color),
    );
  });
  const request = new Uint8Array(chunks.reduce((total, chunk) => total + chunk.length, 0));
  let at = 0;
  chunks.forEach((chunk) => {
    request.set(chunk, at);
    at += chunk.length;
  });
  return staticDocumentLabels(request);
}

export function staticDocumentEncode({
  panels,
  width,
  height,
  background = null,
  title = null,
  titleColor = "#262626",
  titleSize = 14,
  titleX = null,
  titleY = 16,
  titleAnchor = 1,
  titleFlags = 0,
  optimizePng = false,
  labels = [],
  tightCrop = false,
  cropPadding = 0,
  colorbar = null,
  legend = null,
}) {
  const documentWidth = staticU32(width, "StaticDocument width", true);
  const documentHeight = staticU32(height, "StaticDocument height", true);
  if (!Array.isArray(panels) || panels.length < 1 || panels.length > 256) {
    throw new RangeError("StaticDocument needs 1..256 panels");
  }
  const encoder = new TextEncoder();
  const titleBytes = encoder.encode(title == null ? "" : String(title));
  if (titleBytes.length > 4096 || titleBytes.includes(0)) {
    throw new RangeError("StaticDocument title must be NUL-free UTF-8 within 4096 bytes");
  }
  const anchor = staticU32(titleAnchor, "StaticDocument title anchor");
  if (anchor > 2) throw new RangeError("StaticDocument title anchor must be 0, 1, or 2");
  const normalizedTitleFlags = staticU32(titleFlags, "StaticDocument title flags");
  if (normalizedTitleFlags > 3) throw new RangeError("StaticDocument title flags must contain only italic/bold bits");
  const normalized = [];
  let sceneBytes = 0;
  for (let index = 0; index < panels.length; index += 1) {
    const panel = panels[index];
    const scene = panel?.scene instanceof Uint8Array ? panel.scene : new Uint8Array(panel?.scene ?? []);
    if (scene.length === 0) throw new RangeError(`StaticDocument panel ${index} has an empty Scene`);
    const record = {
      scene,
      x: staticI32(panel.x, `StaticDocument panel ${index} x`),
      y: staticI32(panel.y, `StaticDocument panel ${index} y`),
      width: staticU32(panel.width, `StaticDocument panel ${index} width`, true),
      height: staticU32(panel.height, `StaticDocument panel ${index} height`, true),
      offset: staticU32(sceneBytes, `StaticDocument panel ${index} offset`),
      chromeMetrics: panel.chromeMetrics == null
        ? null
        : Array.from(panel.chromeMetrics, Number),
      colorbarLayout: panel.colorbarLayout == null
        ? null
        : Array.from(panel.colorbarLayout, Number),
      annotationFontSize: panel.annotationFontSize == null ? null : Number(panel.annotationFontSize),
      arrowMetrics: panel.arrowMetrics == null ? null : Array.from(panel.arrowMetrics, Number),
      axisSides: panel.axisSides == null ? null : Array.from(panel.axisSides, Number),
      annotationTextFlags: panel.annotationTextFlags == null ? null : Number(panel.annotationTextFlags),
      annotationPadding: panel.annotationPadding == null ? null : Number(panel.annotationPadding),
      titleStyle: panel.titleStyle == null ? null : Array.from(panel.titleStyle),
      annotationVerticalAlign: panel.annotationVerticalAlign == null
        ? null : Number(panel.annotationVerticalAlign),
      colorbarScale: panel.colorbarScale == null ? null : String(panel.colorbarScale),
      colorbarExtend: panel.colorbarExtend == null ? null : String(panel.colorbarExtend),
      colorbarPyplotLabel: Boolean(panel.colorbarPyplotLabel),
      colorbarFillPlot: Boolean(panel.colorbarFillPlot),
      gridDash: panel.gridDash == null ? null : Array.from(panel.gridDash, Number),
    };
    if (record.chromeMetrics != null && record.chromeMetrics.length !== 6) {
      throw new RangeError(`StaticDocument panel ${index} chrome metrics must contain six numbers`);
    }
    if (record.colorbarLayout != null && record.colorbarLayout.length !== 3) {
      throw new RangeError(`StaticDocument panel ${index} colorbar layout must contain three numbers`);
    }
    if (record.arrowMetrics != null && record.arrowMetrics.length !== 3) {
      throw new RangeError(`StaticDocument panel ${index} arrow metrics must contain three numbers`);
    }
    if (record.axisSides != null && (record.axisSides.length !== 2
      || record.axisSides.some((value) => !Number.isInteger(value) || value < 0 || value > 3))) {
      throw new RangeError(`StaticDocument panel ${index} axis sides must contain two low/high masks`);
    }
    if (record.annotationTextFlags != null
      && (!Number.isInteger(record.annotationTextFlags) || record.annotationTextFlags < 0
        || record.annotationTextFlags > 3)) {
      throw new RangeError(`StaticDocument panel ${index} annotation text flags use only italic/bold bits`);
    }
    if (record.titleStyle != null && record.titleStyle.length !== 2) {
      throw new RangeError(`StaticDocument panel ${index} title style needs size/color`);
    }
    if (record.annotationVerticalAlign != null
      && (!Number.isInteger(record.annotationVerticalAlign)
        || record.annotationVerticalAlign < 0 || record.annotationVerticalAlign > 3)) {
      throw new RangeError(`StaticDocument panel ${index} annotation vertical align must be 0..3`);
    }
    if (record.colorbarScale != null && !["linear", "log"].includes(record.colorbarScale)) {
      throw new RangeError(`StaticDocument panel ${index} colorbar scale must be linear or log`);
    }
    if (record.gridDash != null
      && (record.gridDash.length !== 4
        || record.gridDash.some((code) => !Number.isInteger(code) || code < 0 || code > 3))) {
      throw new RangeError(`StaticDocument panel ${index} grid dash codes must be 0..3`);
    }
    if (record.colorbarExtend != null
      && !["neither", "min", "max", "both"].includes(record.colorbarExtend)) {
      throw new RangeError(`StaticDocument panel ${index} colorbar extend must be neither/min/max/both`);
    }
    staticU32(scene.length, `StaticDocument panel ${index} Scene length`, true);
    sceneBytes += scene.length;
    normalized.push(record);
  }
  if (!Array.isArray(labels) || labels.length > 64) {
    throw new RangeError("StaticDocument supports at most 64 XYDA labels");
  }
  const colorbarBytes = encoder.encode(colorbar == null ? "" : String(colorbar));
  if (colorbarBytes.length > 256 || colorbarBytes.includes(0)) {
    throw new RangeError("StaticDocument colorbar name is invalid");
  }
  const legendBytes = staticLegendBytes(legend, encoder);
  const labelBytes = staticLabelBytes(labels, encoder);
  const decorationLength = labels.length || legendBytes.length || colorbarBytes.length
    ? 32 + labelBytes.length + legendBytes.length + colorbarBytes.length
    : 0;
  const decorations = new Uint8Array(decorationLength);
  if (decorationLength) {
    const decorationView = new DataView(decorations.buffer);
    decorations.set([88, 89, 68, 68], 0);
    decorationView.setUint32(4, 1, true);
    decorationView.setUint32(8, labels.length, true);
    decorationView.setUint32(12, legendBytes.length, true);
    decorationView.setUint32(16, colorbarBytes.length, true);
    let decorationAt = 32;
    decorations.set(labelBytes, decorationAt);
    decorationAt += labelBytes.length;
    decorations.set(legendBytes, decorationAt);
    decorationAt += legendBytes.length;
    decorations.set(colorbarBytes, decorationAt);
  }
  const out = new Uint8Array(64 + panels.length * 108 + titleBytes.length + decorations.length + sceneBytes);
  const view = new DataView(out.buffer, out.byteOffset, out.byteLength);
  out.set([88, 89, 83, 84], 0);
  view.setUint32(4, 1, true);
  view.setUint32(8, documentWidth, true);
  view.setUint32(12, documentHeight, true);
  view.setUint32(16, (background != null ? 1 : 0) | (optimizePng ? 2 : 0)
    | (tightCrop ? 4 : 0) | (titleX == null ? 8 : 0), true);
  view.setUint32(20, panels.length, true);
  view.setUint32(24, titleBytes.length, true);
  out.set(background == null ? [0, 0, 0, 0] : cssColorRgba8(background === "transparent" ? "transparent" : String(background)), 28);
  out.set(cssColorRgba8(String(titleColor)), 32);
  view.setFloat32(36, Number(titleSize), true);
  view.setFloat32(40, Number(titleX == null ? 0 : titleX), true);
  view.setFloat32(44, Number(titleY), true);
  out[48] = anchor;
  out[49] = normalizedTitleFlags;
  view.setUint32(52, decorations.length, true);
  view.setUint32(56, staticU32(cropPadding, "StaticDocument crop padding"), true);
  let at = 64;
  for (const panel of normalized) {
    view.setInt32(at, panel.x, true);
    view.setInt32(at + 4, panel.y, true);
    at += 8;
    for (const value of [panel.width, panel.height, panel.offset, panel.scene.length]) {
      view.setUint32(at, value, true);
      at += 4;
    }
    view.setUint32(at, (panel.chromeMetrics == null ? 0 : 3)
      | (panel.colorbarLayout == null ? 0 : 4)
      | (panel.annotationFontSize == null ? 0 : 8)
      | (panel.arrowMetrics == null ? 0 : 16)
      | (panel.axisSides == null ? 0 : 32)
      | (panel.annotationTextFlags == null ? 0 : 64)
      | (panel.annotationPadding == null ? 0 : 128)
      | (panel.titleStyle == null ? 0 : 256)
      | (panel.annotationVerticalAlign == null ? 0 : 512)
      | (panel.colorbarScale === "log" ? 1 << 10 : 0)
      | (["min", "both"].includes(panel.colorbarExtend) ? 1 << 11 : 0)
      | (["max", "both"].includes(panel.colorbarExtend) ? 1 << 12 : 0)
      | (panel.colorbarPyplotLabel ? 1 << 13 : 0)
      | (panel.gridDash == null ? 0 : 1 << 14)
      | (panel.colorbarFillPlot ? 1 << 24 : 0), true);
    view.setFloat32(at + 4, panel.annotationFontSize ?? 0, true);
    at += 8;
    for (const value of panel.chromeMetrics ?? [0, 0, 0, 0, 0, 0]) {
      view.setFloat32(at, value, true);
      at += 4;
    }
    for (const value of panel.colorbarLayout ?? [0, 0, 0]) {
      view.setFloat32(at, value, true);
      at += 4;
    }
    for (const value of panel.arrowMetrics ?? [0, 0, 0]) {
      view.setFloat32(at, value, true);
      at += 4;
    }
    view.setUint32(at, panel.axisSides == null ? 0 : panel.axisSides[0] | (panel.axisSides[1] << 8), true);
    at += 4;
    view.setUint32(at, panel.annotationTextFlags ?? 0, true);
    at += 4;
    view.setFloat32(at, panel.annotationPadding ?? 0, true);
    at += 4;
    view.setFloat32(at, Number(panel.titleStyle?.[0] ?? 0), true);
    at += 4;
    out.set(panel.titleStyle == null ? [0, 0, 0, 0] : cssColorRgba8(String(panel.titleStyle[1])), at);
    at += 4;
    view.setUint32(at, panel.annotationVerticalAlign ?? 0, true);
    at += 4;
    const gridDash = panel.gridDash ?? null;
    view.setUint32(
      at,
      gridDash == null ? 0 : (gridDash[0] | (gridDash[1] << 4) | (gridDash[2] << 16) | (gridDash[3] << 24)) >>> 0,
      true,
    );
    at += 4;
  }
  out.set(titleBytes, at);
  at += titleBytes.length;
  out.set(decorations, at);
  at += decorations.length;
  for (const panel of normalized) {
    out.set(panel.scene, at);
    at += panel.scene.length;
  }
  return out;
}

const STATIC_ROOT_STYLE_KEYS = new Set([
  "background",
  "--chart-bg",
  "--chart-grid",
  "--chart-axis",
  "--chart-text",
  "font-family",
  "font-size",
]);
const STATIC_CHROME_SLOTS = new Set(["title", "axis_title", "tick_label"]);
const STATIC_CHROME_STYLE_KEYS = new Set(["font-size", "color", "font-weight", "font-family"]);
const STATIC_ROOT_FAMILIES = new Set([
  "dejavusans,sans-serif",
  "system-ui,sans-serif",
  "sans-serif",
]);
const STATIC_CHROME_FAMILIES = new Set(["dejavu sans", "dejavusans", "sans-serif"]);

const GRID_DASH_CODES = { solid: 0, dashed: 1, dotted: 2, dashdot: 3 };

function staticGridDashFact(major, minor) {
  if (major.x == null && major.y == null && minor.x == null && minor.y == null) return null;
  return [major.x ?? 0, major.y ?? 0, minor.x ?? 0, minor.y ?? 0];
}

/**
 * Project one public Figure onto the shared XYST product boundary (M2 #873).
 * Mirrors the Python adapter's literal facts: validate authored styles, extract
 * per-axis chrome metrics, resolve annotation styles through Rust, lift the
 * document legend, compile the canonical Scene, and encode one panel. Rust owns
 * every layout/tick/render decision; this projection only marshals authored
 * state into the versioned envelope.
 */
export function figureStaticDocument(figure, {
  width = null,
  height = null,
  background = null,
  optimizePng = false,
} = {}) {
  const documentWidth = width == null ? figure.width : width;
  const documentHeight = height == null ? figure.height : height;
  for (const [label, value] of [["StaticDocument width", documentWidth], ["StaticDocument height", documentHeight]]) {
    if (!Number.isInteger(value) || value <= 0) {
      throw new RangeError(`${label} must be a positive integer pixel count`);
    }
  }
  const rootStyle = { ...(figure.style ?? {}) };
  for (const key of Object.keys(rootStyle)) {
    if (!STATIC_ROOT_STYLE_KEYS.has(key)) throw new RangeError("XYG_STATIC_UNSUPPORTED_BROWSER_CSS");
  }
  const rootFamily = String(rootStyle["font-family"] ?? "DejaVu Sans, sans-serif").toLowerCase().replaceAll(" ", "");
  if (!STATIC_ROOT_FAMILIES.has(rootFamily)) throw new RangeError("XYG_STATIC_UNSUPPORTED_CUSTOM_FONT");
  const chromeStyles = {};
  for (const [slot, chromeStyle] of Object.entries(figure.chrome_styles ?? {})) {
    const keys = Object.keys(chromeStyle ?? {});
    if (!STATIC_CHROME_SLOTS.has(slot) || keys.some((key) => !STATIC_CHROME_STYLE_KEYS.has(key))) {
      throw new RangeError("XYG_STATIC_UNSUPPORTED_CHROME_STYLE");
    }
    const chromeFamily = String(chromeStyle["font-family"] ?? "DejaVu Sans").toLowerCase();
    if (!STATIC_CHROME_FAMILIES.has(chromeFamily)) throw new RangeError("XYG_STATIC_UNSUPPORTED_CUSTOM_FONT");
    chromeStyles[slot] = { ...chromeStyle };
  }
  const projectedStyle = {};
  for (const key of ["background", "--chart-bg"]) {
    if (key in rootStyle) projectedStyle[key] = rootStyle[key];
  }
  const axisOptions = {};
  const chromeMetrics = {};
  const gridDash = { x: null, y: null };
  const gridDashMinor = { x: null, y: null };
  for (const [axisId, options] of Object.entries(figure.axis_options ?? {})) {
    const next = { ...options };
    const style = { ...(options.style ?? {}) };
    const minor = { ...(options.minor_style ?? {}) };
    if (axisId === "x" || axisId === "y") {
      const tickLabel = "tick_label_size" in style ? style["tick_label_size"] : ("tick_size" in style ? style["tick_size"] : 12.0);
      delete style["tick_label_size"];
      delete style["tick_size"];
      const labelSize = "label_size" in style ? style["label_size"] : 12.0;
      delete style["label_size"];
      const tickPadding = "tick_padding" in style ? style["tick_padding"] : 4.0;
      delete style["tick_padding"];
      chromeMetrics[axisId] = [Number(tickLabel), Number(labelSize), Number(tickPadding)];
      const rawDash = "grid_dash" in style ? style["grid_dash"] : null;
      delete style["grid_dash"];
      if (rawDash != null) {
        if (!(rawDash in GRID_DASH_CODES)) throw new RangeError("XYG_STATIC_UNSUPPORTED_GRID_DASH");
        gridDash[axisId] = GRID_DASH_CODES[rawDash];
      }
      const rawMinorDash = "grid_dash" in minor ? minor["grid_dash"] : null;
      delete minor["grid_dash"];
      if (rawMinorDash != null) {
        if (!(rawMinorDash in GRID_DASH_CODES)) throw new RangeError("XYG_STATIC_UNSUPPORTED_GRID_DASH");
        gridDashMinor[axisId] = GRID_DASH_CODES[rawMinorDash];
      }
      for (const key of ["tick_label_size", "tick_size", "label_size", "tick_padding"]) delete minor[key];
    }
    if (rootStyle["--chart-grid"] != null) {
      style.grid_color = rootStyle["--chart-grid"];
      minor.grid_color = rootStyle["--chart-grid"];
    }
    if (rootStyle["--chart-axis"] != null) {
      style.axis_color = rootStyle["--chart-axis"];
      style.tick_color = rootStyle["--chart-axis"];
      minor.tick_color = rootStyle["--chart-axis"];
    }
    if (rootStyle["--chart-text"] != null) {
      if (style.label_color == null) style.label_color = rootStyle["--chart-text"];
      if (style.tick_label_color == null) style.tick_label_color = rootStyle["--chart-text"];
    }
    if (Object.keys(style).length) next.style = style;
    else delete next.style;
    if (Object.keys(minor).length) next.minor_style = minor;
    else delete next.minor_style;
    axisOptions[axisId] = next;
  }
  let traces = (figure.traces ?? []).map((trace) => {
    const style = {};
    for (const [key, value] of Object.entries(trace.style ?? {})) {
      if (!String(key).startsWith("_legend_")) style[key] = value;
    }
    return { ...trace, style };
  });
  // Composed graphs (#34): read the planes, then make the base pass plain.
  const graphPlanes = composedGraphPlanes(figure);
  let graphMetas = figure._graphMeta;
  let showLegend = Boolean(figure.show_legend);
  if (graphPlanes != null) {
    ({ traces, metas: graphMetas } = plainGraphTraces(figure, traces));
    if (figure.legend_options?.items?.length) showLegend = false;
  }
  const annotationFacts = staticAnnotationStyleFacts(figure.annotations ?? []);
  let legend = null;
  if (showLegend) {
    if (figure.extra_legends && (!Array.isArray(figure.extra_legends) || figure.extra_legends.length > 0)) {
      throw new RangeError("XYG_STATIC_UNSUPPORTED_MULTIPLE_PANEL_LEGENDS");
    }
    const items = [];
    for (const trace of traces) {
      if (!trace.name) continue;
      items.push({ kind: trace.kind, name: trace.name, style: { ...trace.style } });
    }
    if (items.length) legend = { ...(figure.legend_options ?? {}), items };
  }
  const projected = Object.create(Object.getPrototypeOf(figure));
  Object.assign(projected, figure);
  projected.width = documentWidth;
  projected.height = documentHeight;
  projected.style = projectedStyle;
  projected.chrome_styles = {};
  projected.axis_options = axisOptions;
  projected.traces = traces;
  projected._graphMeta = graphMetas;
  projected.annotations = annotationFacts.annotations;
  projected.show_legend = false;
  projected.legend_options = {};
  projected.extra_legends = Array.isArray(figure.extra_legends) ? [] : null;
  const reason = sceneExportSupportReason(projected);
  if (reason) throw new RangeError(reason);
  let scene = figureSceneV3(projected);
  if (graphPlanes != null) {
    try {
      scene = graphComposedScene(scene, graphPlanes);
    } catch (error) {
      if (error?.message === "XYG_STATIC_UNSUPPORTED_LEGEND_FOOTPRINT") throw error;
      throw new RangeError("XYG_STATIC_UNSUPPORTED_GRAPH");
    }
  }
  const frameSides = figure.frame_sides == null ? ["left", "bottom"] : figure.frame_sides;
  const sides = new Set(frameSides);
  const axisSides = [
    (sides.has("bottom") ? 1 : 0) | (sides.has("top") ? 2 : 0),
    (sides.has("left") ? 1 : 0) | (sides.has("right") ? 2 : 0),
  ];
  let titleStyle = null;
  if (figure.title) {
    const authored = chromeStyles.title ?? {};
    const rawSize = String(authored["font-size"] ?? "14px");
    if (!rawSize.endsWith("px")) throw new RangeError("XYG_STATIC_UNSUPPORTED_TITLE_STYLE");
    titleStyle = [
      Number(rawSize.slice(0, -2)),
      String(authored["color"] ?? rootStyle["--chart-text"] ?? "#262626"),
    ];
  }
  return staticDocumentEncode({
    panels: [{
      scene,
      x: 0,
      y: 0,
      width: documentWidth,
      height: documentHeight,
      chromeMetrics: [...chromeMetrics.x, ...chromeMetrics.y],
      annotationFontSize: annotationFacts.fontSize,
      axisSides,
      annotationTextFlags: annotationFacts.textFlags,
      annotationPadding: annotationFacts.padding,
      titleStyle,
      annotationVerticalAlign: annotationFacts.verticalAlign,
      gridDash: staticGridDashFact(gridDash, gridDashMinor),
    }],
    width: documentWidth,
    height: documentHeight,
    background,
    optimizePng: Boolean(optimizePng),
    legend,
  });
}

/** Style channels the plain Scene route admits on graph traces (#34). */
const GRAPH_PLAIN_CHANNELS = new Set(["edge_ends"]);

/** Per-item straight RGBA8 of a resolved color channel (Rust color math). */
function graphRgbaRows(channel, n, fallback) {
  if (channel == null || channel.mode === "constant") {
    const rgba = cssColorRgba8(channel?.constant ?? fallback);
    const out = new Uint8Array(n * 4);
    for (let i = 0; i < n; i += 1) out.set(rgba, i * 4);
    return out;
  }
  // Node direct_rgba channels already hold quantized RGBA8.
  if (channel.mode === "direct_rgba") {
    return channel.rgba instanceof Uint8Array ? channel.rgba : clipQuantizeU8(channel.rgba);
  }
  if (channel.mode === "categorical") {
    const palette = channel.palette?.length ? channel.palette : DEFAULT_PALETTE;
    const table = (channel.categories ?? []).map((_, i) => cssColorRgba8(palette[i % palette.length]));
    const out = new Uint8Array(n * 4);
    channel.codes.forEach((code, i) => out.set(table[Number(code)], i * 4));
    return out;
  }
  if (channel.mode === "continuous") {
    const [lo, hi] = channel.domain;
    const unit = Float64Array.from(channel.values, (v) => (hi > lo ? Math.min(Math.max((v - lo) / (hi - lo), 0), 1) : 0));
    const colormap = channel.colormap ?? "viridis";
    const stops = typeof colormap === "string" ? colormapNamedStops(colormap) : colormapStopBytes(colormap);
    if (stops == null) throw new RangeError("XYG_STATIC_UNSUPPORTED_GRAPH");
    return colormapRgba(unit, n, 1, stops, 255).rgba;
  }
  throw new RangeError("XYG_STATIC_UNSUPPORTED_GRAPH");
}

function graphStyleValues(trace, name, fallback, n) {
  const channel = trace.style_channels?.[name];
  if (channel != null) return Float64Array.from(channel.values, Number);
  return new Float64Array(n).fill(Number(trace.style?.[name] ?? fallback));
}

/**
 * One graph's composed planes off a graph-only figure, or null (#34). Mirrors
 * Python `_graph_static.composed_graph_planes`: the browser paints the same
 * resolved per-item planes; Rust rebuilds the plain Scene from them.
 */
function composedGraphPlanes(figure) {
  const metas = figure._graphMeta ?? [];
  if (metas.length !== 1 || !graphMarksOnly(figure)) return null;
  const meta = metas[0];
  const node = figure.traces[meta.node_trace];
  const edge = figure.traces[meta.edge_trace];
  const n = node.x.length;
  const m = edge.x0.length;
  const fill = graphRgbaRows(node.color_ch, n, node.style?.color ?? DEFAULT_PALETTE[0]);
  let stroke;
  if (node.stroke_ch?.mode === "direct_rgba") stroke = graphRgbaRows(node.stroke_ch, n, "#000000");
  else if (node.style?.stroke) stroke = graphRgbaRows({ mode: "constant", constant: node.style.stroke }, n, "#000000");
  else stroke = new Uint8Array(n * 4);
  const size = node.size_ch;
  let diameter;
  if (size?.mode === "continuous" && size.values != null) {
    const [lo, hi] = size.range_px;
    const [d0, d1] = size.domain;
    diameter = Float64Array.from(size.values, (v) => lo + (hi - lo) * (d1 > d0 ? Math.min(Math.max((v - d0) / (d1 - d0), 0), 1) : 0));
  } else {
    diameter = new Float64Array(n).fill(Number(size?.constant ?? 8));
  }
  const symbolChannel = node.style_channels?.symbol;
  const symbol = symbolChannel != null
    ? Uint8Array.from(symbolChannel.values)
    : new Uint8Array(n).fill(SYMBOL_CODES.get(String(node.style?.symbol ?? "circle")) ?? 0);
  const planes = {
    x: asF64Array(node.x),
    y: asF64Array(node.y),
    fill,
    stroke,
    stroke_width: graphStyleValues(node, "stroke_width", stroke.some((v) => v !== 0) ? 1 : 0, n),
    diameter,
    symbol,
    opacity: graphStyleValues(node, "opacity", 1, n),
    x0: asF64Array(edge.x0),
    y0: asF64Array(edge.y0),
    x1: asF64Array(edge.x1),
    y1: asF64Array(edge.y1),
    segment_rgba: graphRgbaRows(edge.color_ch, m, edge.style?.color || graphDefaultEdgeColor()),
    segment_width: graphStyleValues(edge, "width", 1.2, m),
    segment_opacity: graphStyleValues(edge, "opacity", 1, m),
  };
  for (const [key, trace, name] of [
    ["halo", node, "halo_rgba"],
    ["halo_diameter", node, "halo_size"],
    ["frames", node, "compound_frame"],
    ["node_label_plan", node, "label_plan"],
    ["segment_halo", edge, "halo_rgba"],
    ["segment_halo_width", edge, "halo_width"],
    ["segment_body", edge, "body_rgba"],
    ["segment_body_width", edge, "body_width"],
    ["segment_dash", edge, "edge_dash"],
    ["edge_ends", edge, "edge_ends"],
    ["segment_label_plan", edge, "label_plan"],
  ]) {
    const channel = trace.style_channels?.[name];
    if (channel != null) planes[key] = channel.values;
  }
  if (planes.node_label_plan != null) {
    planes.node_labels = (meta.node_labels ?? new Array(n).fill(null)).map((label) => (label == null ? null : String(label)));
  }
  if (planes.segment_label_plan != null) {
    const texts = new Array(m).fill(null);
    (meta.edge_label_segments ?? []).forEach((segment, i) => { texts[Number(segment)] = meta.edge_label_text[i]; });
    planes.segment_labels = texts;
  }
  // Labels and legend text paint in the chart text color, like the
  // browser's theme label (`--chart-text`).
  const chartText = figure.style?.["--chart-text"];
  if (chartText) planes.text_rgba = cssColorRgba8(String(chartText));
  const items = figure.legend_options?.items ?? [];
  if (items.length && figure.show_legend) {
    planes.legend_title = String(figure.legend_options.title ?? "");
    // Rust resolves the placement name; unknown names fail closed.
    planes.legend_loc = String(figure.legend_options.loc ?? "");
    planes.legend = items.map((item) => [
      String(item.name ?? ""),
      cssColorRgba8(String(item.style?.color || "#000000")),
      SYMBOL_CODES.get(String(item.style?.symbol ?? "circle")) ?? 0,
    ]);
  }
  return planes;
}

/**
 * Set a graph chart's home view (#910; Python `_graph_static.apply_home_view`):
 * Rust pads the node-center autorange so every marker, halo, edge stroke,
 * compound frame, and home-view label fits the plot of the hidden-axis graph
 * shell. Callers apply it only to the hidden default axes.
 */
export function applyGraphHomeView(figure) {
  if ((figure.coords ?? "cartesian") !== "cartesian" || (figure.title_options?.length ?? 0) > 0) return;
  const planes = composedGraphPlanes(figure);
  if (planes == null) return;
  const domain = graphHomeDomain(planes, {
    viewport: [figure.width, figure.height],
    baseX: figure._range("x"),
    baseY: figure._range("y"),
    title: figure.title ?? "",
    padding: figure.padding ?? null,
  });
  if (domain == null) return;
  figure.axis_options.x = { ...figure.axis_options.x, domain: [domain[0], domain[1]] };
  figure.axis_options.y = { ...figure.axis_options.y, domain: [domain[2], domain[3]] };
}

/**
 * Plain copies of a graph figure's traces for the base Scene pass (#34;
 * Python `_graph_static.strip_to_plain`): solid paint, no per-item channels,
 * no explicit legend (the rebuild owns them). Returns the traces and metas.
 */
function plainGraphTraces(figure, traces) {
  const meta = { ...figure._graphMeta[0] };
  const plain = traces.map((trace, index) => {
    if (index !== meta.node_trace && index !== meta.edge_trace) return trace;
    const next = {
      ...trace,
      style_channels: Object.fromEntries(
        Object.entries(trace.style_channels ?? {}).filter(([name]) => GRAPH_PLAIN_CHANNELS.has(name)),
      ),
      color_ch: { mode: "constant", constant: "#888888" },
    };
    delete next.stroke_ch;
    if (index === meta.node_trace) {
      next.size_ch = { mode: "constant", constant: 8.0 };
      next.style = Object.fromEntries(
        Object.entries(next.style ?? {}).filter(([key]) => !["stroke", "stroke_width", "symbol"].includes(key)),
      );
      delete next.forceDirect;
    }
    return next;
  });
  if (plain[meta.edge_trace].x0.length === 0) {
    // The Scene admits no empty trace; an edgeless graph's base pass is its
    // nodes alone (edges never widen the node autorange).
    plain.splice(meta.edge_trace, 1);
    if (meta.node_trace > meta.edge_trace) meta.node_trace -= 1;
    meta.edge_trace = null;
  }
  return { traces: plain, metas: [meta] };
}

/** Marshal authored annotations through the Rust XYAS/XYAO style contract. */
function staticAnnotationStyleFacts(sources) {
  const encoder = new TextEncoder();
  const chunks = [];
  const pushU32 = (value) => {
    const out = new Uint8Array(4);
    new DataView(out.buffer).setUint32(0, value >>> 0, true);
    chunks.push(out);
  };
  const pushF64 = (value) => {
    const out = new Uint8Array(8);
    new DataView(out.buffer).setFloat64(0, value, true);
    chunks.push(out);
  };
  const pushText = (value) => {
    const bytes = encoder.encode(String(value));
    pushU32(bytes.length);
    chunks.push(bytes);
  };
  const pushOptionalText = (value) => {
    if (value == null) pushU32(0xffffffff);
    else pushText(value);
  };
  pushU32(1);
  pushU32(sources.length);
  pushU32(0);
  for (const source of sources) {
    const annotation = typeof source === "object" && source != null ? source : {};
    const style = annotation.style ?? {};
    const keys = Object.keys(style).sort();
    pushU32(keys.length);
    pushU32(0);
    pushOptionalText(annotation.text);
    pushOptionalText(annotation.kind);
    for (const key of keys) {
      pushText(key);
      const value = style[key];
      if (value == null) pushU32(0);
      else if (typeof value === "string") { pushU32(1); pushText(value); }
      else if (typeof value === "boolean") { pushU32(3); pushU32(value ? 1 : 0); }
      else if (typeof value === "number" && Number.isFinite(value)) { pushU32(2); pushF64(value); }
      else pushU32(4);
    }
  }
  const request = concatBytes([new Uint8Array([88, 89, 65, 83]), ...chunks]);
  const output = staticAnnotationStyle(request);
  if (output.length < 32) throw new Error("invalid XYAO output");
  const view = new DataView(output.buffer, output.byteOffset, output.byteLength);
  const magic = String.fromCharCode(output[0], output[1], output[2], output[3]);
  const version = view.getUint32(4, true);
  const count = view.getUint32(8, true);
  const presence = view.getUint32(12, true);
  if (magic !== "XYAO" || version !== 1 || count !== sources.length || presence & ~0xf) {
    throw new Error("invalid XYAO output");
  }
  const size = view.getFloat32(16, true);
  const padding = view.getFloat32(20, true);
  const textFlags = view.getUint32(24, true);
  const vertical = view.getUint32(28, true);
  let at = 32;
  const takeU32 = () => {
    if (at + 4 > output.length) throw new Error("invalid XYAO output");
    const value = view.getUint32(at, true);
    at += 4;
    return value;
  };
  const takeText = () => {
    const length = takeU32();
    const end = at + length;
    if (end > output.length) throw new Error("invalid XYAO output");
    const value = new TextDecoder("utf-8", { fatal: true }).decode(output.subarray(at, end));
    at = end;
    return value;
  };
  const retained = [];
  for (const source of sources) {
    const drop = takeU32();
    const patchCount = takeU32();
    if (drop !== 0 && drop !== 1) throw new Error("invalid XYAO output");
    if (drop && patchCount) throw new Error("invalid XYAO output");
    const annotation = { ...source, style: { ...(source.style ?? {}) } };
    for (let index = 0; index < patchCount; index += 1) {
      const key = takeText();
      const operation = takeU32();
      if (operation === 0) delete annotation.style[key];
      else if (operation === 1) annotation.style[key] = takeText();
      else if (operation === 2) {
        if (at + 8 > output.length) throw new Error("invalid XYAO output");
        annotation.style[key] = view.getFloat64(at, true);
        at += 8;
      } else throw new Error("invalid XYAO output");
    }
    if (!drop) retained.push(annotation);
  }
  if (at !== output.length) throw new Error("invalid XYAO output");
  return {
    annotations: retained,
    fontSize: presence & 1 ? size : null,
    textFlags: presence & 2 ? textFlags : null,
    padding: presence & 4 ? padding : null,
    verticalAlign: presence & 8 ? vertical : null,
  };
}

export function staticDocumentExport(encoded, format, { scale = DEFAULT_PNG_EXPORT_SCALE, quality = 90 } = {}) {
  const code = SCENE_STATIC_FORMATS[format];
  if (code == null) {
    throw new RangeError(`StaticDocument format must be svg, png, pdf, jpeg, or webp, got ${String(format)}`);
  }
  let factor = Number(scale);
  if (format === "png" || format === "jpeg" || format === "webp") {
    if (!Number.isFinite(factor) || factor <= 0) throw new RangeError("static XYST raster scale must be positive and finite");
  } else if (!Number.isFinite(factor)) {
    factor = 1;
  }
  const q = Number(quality);
  if (!Number.isInteger(q) || q < 1 || q > 100) throw new RangeError("quality must be an int in 1..100");
  return sceneOutput(encoded, xyStaticDocumentExport, "StaticDocument export", [code, factor, q]);
}

export function staticDocumentLayout(encoded) {
  return sceneOutput(encoded, xyStaticDocumentLayout, "StaticDocument layout");
}

export function staticAnnotationStyle(encoded) {
  const output = sceneOutput(encoded, xyStaticAnnotationStyle, "StaticDocument annotation style");
  if (output.length >= 4 && new TextDecoder().decode(output.slice(0, 4)) === "XYG_") {
    throw new RangeError(new TextDecoder().decode(output));
  }
  return output;
}

export function staticDocumentLabels(encoded) {
  const output = sceneOutput(encoded, xyStaticDocumentLabels, "StaticDocument labels");
  if (output.length >= 4 && new TextDecoder().decode(output.slice(0, 4)) === "XYG_") {
    throw new RangeError(new TextDecoder().decode(output));
  }
  return output;
}

export function staticDocumentLegend(encoded) {
  const output = sceneOutput(encoded, xyStaticDocumentLegend, "StaticDocument legend");
  if (output.length >= 4 && new TextDecoder().decode(output.slice(0, 4)) === "XYG_") {
    throw new RangeError(new TextDecoder().decode(output));
  }
  return output;
}

export function staticPanelChrome(encoded) {
  const output = sceneOutput(encoded, xyStaticPanelChrome, "static panel chrome");
  if (output.length >= 4 && new TextDecoder().decode(output.slice(0, 4)) === "XYG_") {
    throw new RangeError(new TextDecoder().decode(output));
  }
  return output;
}

export function staticLegendFit(encoded) {
  const output = sceneOutput(encoded, xyStaticLegendFit, "static legend fit");
  if (output.length >= 4 && new TextDecoder().decode(output.slice(0, 4)) === "XYG_") {
    throw new RangeError(new TextDecoder().decode(output));
  }
  return output;
}

export function sceneBrowserPainter(encoded, maxBytes = 64 * 1024 * 1024) {
  const limit = Number(maxBytes);
  if (!Number.isSafeInteger(limit) || limit <= 0) throw new RangeError("scene painter byte limit must be a positive safe integer");
  return sceneOutput(encoded, xySceneBrowserPainter, "browser painter", [BigInt(limit)]);
}

function rgba8(css, opacity = 1) {
  return cssColorRgba8(css, opacity);
}

function annotationNumber(style, key, fallback, label) {
  const raw = Object.hasOwn(style, key) ? style[key] : fallback;
  if (raw == null || typeof raw === "boolean" || (typeof raw === "string" && raw.trim() === "")) throw new RangeError(`Scene v12 annotation ${label} must be numeric`);
  const value = Number(raw);
  if (!Number.isFinite(value)) throw new RangeError(`Scene v12 annotation ${label} must be numeric`);
  return value;
}

function annotationColor(style, key, fallback, label) {
  const raw = Object.hasOwn(style, key) ? style[key] : fallback;
  if (typeof raw !== "string" || raw.trim() === "") throw new RangeError(`Scene v12 annotation ${label} must be a nonempty CSS color`);
  return raw;
}

const SCENE_KIND_CLASS_RECT = 1 << 0;
const SCENE_KIND_CLASS_BAND = 1 << 2;
const SCENE_KIND_CLASS_RIBBON = 1 << 3;
const SCENE_KIND_CLASS_POLYFILL = 1 << 4;
const SCENE_KIND_CLASS_HEXBIN = 1 << 5;
const SCENE_KIND_CLASS_HEATMAP = 1 << 6;
const SCENE_KIND_CLASS_SCATTER = 1 << 8;
const SCENE_KIND_CLASS_LINE = 1 << 9;
const SCENE_KIND_CLASS_OPACITY = SCENE_KIND_CLASS_BAND | SCENE_KIND_CLASS_RIBBON | SCENE_KIND_CLASS_RECT | SCENE_KIND_CLASS_HEATMAP | SCENE_KIND_CLASS_SCATTER | SCENE_KIND_CLASS_HEXBIN | SCENE_KIND_CLASS_POLYFILL;
const XYFS_TRACE_UNSUPPORTED_KIND = 1 << 0;
const XYFS_TRACE_NON_PRIMARY_AXIS = 1 << 1;
const XYFS_TRACE_HIDDEN_OR_PER_ITEM = 1 << 2;
const XYFS_TRACE_DENSITY = 1 << 3;
const XYFS_TRACE_DASHED_MARKERS = 1 << 4;
const XYFS_TRACE_RECT_GRADIENT = 1 << 5;
const XYFS_TRACE_CORNER_RADIUS = 1 << 6;
const XYFS_TRACE_WEDGE_GAP = 1 << 7;
const XYFS_TRACE_JOINED_FILL = 1 << 8; // reserved; ABI 182 no longer fail-closes this bit
const XYFS_TRACE_CUSTOM_HEX_REDUCE = 1 << 9;
const XYFS_TRACE_HEATMAP_COLORMAP = 1 << 10;
const XYFS_TRACE_NON_CSS_FILL = 1 << 11;

/** Return Rust's stable diagnostic for authored Scene feature bits. */
export function sceneSupportReason(features, requestVersion = 1) {
  if (
    typeof requestVersion !== "number"
    || !Number.isInteger(requestVersion)
    || requestVersion < 0
    || requestVersion >= 0x1_0000_0000
  ) throw new TypeError("scene support requestVersion must be a u32 integer");
  if (
    typeof features !== "bigint"
    && (typeof features !== "number" || !Number.isSafeInteger(features) || features < 0)
  ) throw new TypeError("scene support features must be an exact nonnegative u64 integer");
  const mask = BigInt(features);
  if (mask < 0n || mask > 0xffff_ffff_ffff_ffffn) throw new RangeError("scene support features must be a u64 bit mask");
  const requiredRaw = xySceneSupportReason(Number(requestVersion), mask, 0, 0n);
  if (requiredRaw === USIZE_MAX_64) throw new RangeError("invalid Scene support request version or feature mask");
  const required = Number(requiredRaw);
  if (required === 0) return "";
  const output = new Uint8Array(required);
  const written = xySceneSupportReason(Number(requestVersion), mask, u8Ptr(output), BigInt(required));
  if (Number(written) !== required) throw new Error("native Scene support predicate returned an inconsistent length");
  return new TextDecoder("utf-8", { fatal: true }).decode(output);
}

const SCENE_TICK_STRATEGY_NAMES = ["auto", "hide", "rotate", "stagger", "preserve", "none", "off"];

function sceneTickStrategy(options) {
  const raw = axisTickLabelStrategy(options);
  const code = sceneTickLabelStrategy(String(raw ?? "auto"));
  return SCENE_TICK_STRATEGY_NAMES[code] ?? "auto";
}

/** Polar collision keys skipped when strategy is none/off/auto. Python `_POLAR_COLLISION_KEYS` is snake-case only. */
export function polarCollisionKeys() {
  return POLAR_COLLISION_KEYS;
}

const POLAR_COLLISION_KEYS = new Set([
  "tick_label_strategy",
  "collision",
  "tick_label_min_gap",
  "tick_label_angle",
  "tick_label_anchor",
]);

function significantSceneAxisKeys(options, polar = false) {
  let keys = Object.entries(options ?? {})
    .filter(([, value]) => {
      if (value == null || value === false) return false;
      if (Array.isArray(value) && value.length === 0) return false;
      if (typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === 0) return false;
      return true;
    })
    .map(([key]) => key);
  if (polar && ["none", "off", "auto"].includes(sceneTickStrategy(options))) {
    keys = keys.filter((key) => !polarCollisionKeys().has(key));
  }
  return keys;
}

function optionalStr(value) {
  if (value == null) return null;
  const text = String(value);
  return text ? text : null;
}

function marshalTraceSupportObs(trace, polar) {
  const kind = String(trace.kind || "mark");
  const style = trace.style ?? {};
  const fill = style.fill;
  let radiusValues;
  let radiusSeq;
  if (Array.isArray(style.corner_radius)) {
    radiusValues = style.corner_radius.map(Number);
    radiusSeq = true;
  } else {
    radiusValues = [Number(style.corner_radius ?? 0)];
    radiusSeq = false;
  }
  const markerPath = style.marker_path;
  let markerPathValid = false;
  let markerPathFilledSmall = false;
  if (markerPath != null && kind === "scatter") {
    const validated = validateMarkerPath(markerPath);
    if (validated != null) {
      markerPathValid = true;
      markerPathFilledSmall = validated.filled && validated.contours.some((contour) => contour.length < 6);
    }
  }
  let dashPresent = style.dash != null;
  let dashText = null;
  let dashIsArray = false;
  if (dashPresent) {
    const parsed = parseSceneDash(style.dash);
    if (parsed === false) {
      dashText = "";
    } else if (parsed == null) {
      dashPresent = false;
    } else if (Array.isArray(parsed)) {
      dashText = parsed.map((part) => String(part)).join(",");
    } else {
      dashText = optionalStr(style.dash);
    }
  }
  return {
    kind,
    x_axis: String(trace.x_axis ?? "x"),
    y_axis: String(trace.y_axis ?? "y"),
    hidden: Boolean(trace.hidden),
    has_per_item_channels: perItemChannelNames(trace).length > 0,
    density_aggregates_color: densityAggregatesColor(trace),
    marker_glyph_present: style.marker_glyph != null,
    marker_glyph: optionalStr(style.marker_glyph),
    marker_path_present: markerPath != null,
    marker_path_valid: markerPathValid,
    marker_path_filled_small: markerPathFilledSmall,
    curve_present: style.curve != null,
    curve: optionalStr(style.curve),
    linecap_present: style.linecap != null,
    linecap: optionalStr(style.linecap),
    dash_present: dashPresent,
    dash_text: dashText,
    dash_is_array: dashIsArray,
    fill_present: Object.hasOwn(style, "fill"),
    fill_is_string: typeof fill === "string",
    fill_gradient_admitted: admitFillGradient(trace) != null,
    hexbin_reduce: optionalStr(style.reduce),
    heatmap_truecolor: Boolean(trace.truecolor),
    heatmap_has_colormap: trace.colormap != null,
    heatmap_has_rgba_grid: trace.rgba_grid != null,
    heatmap_has_rgba: trace.rgba != null,
    rect_gradient_fail: typeof fill === "object" && fill != null && admitFillGradientFromFill(fill, DEFAULT_PALETTE[0]) == null,
    corner_radius_values: radiusValues,
    corner_radius_seq: radiusSeq,
    wedge_gap: Number(style.wedge_gap ?? 0),
    ribbon_color2_fail: classifyRibbonColor2(trace) === "fail",
    color_channel_unsupported: (
      trace.color_ch != null
      && typeof trace.color_ch === "object"
      && (trace.color_ch.mode !== "constant" || trace.color_ch.constant == null)
      && !(kind === "scatter" && scatterUsesDensity(trace))
      && !hexbinPacksPaintPlane(trace)
      && !meshPacksPaintPlane(trace)
      && !scatterPacksPaintPlane(trace)
      && !(!polar && ribbonPacksEndPaints(trace))
    ),
  };
}

function packFigureSupport(figure, { colorbarUnsupported = false } = {}) {
  const chromeStyles = figureChromeStyles(figure) ?? {};
  const annotations = [...(figure.annotations ?? [])];
  const polar = (figure.coords ?? "cartesian") === "polar";
  const annRows = annotations.map((annotation) => ({
    has_html: annotation.html != null && annotation.html !== "",
    has_collision: annotation.collision != null && annotation.collision !== "",
    has_markup: annotationHasMarkup(annotation),
    has_custom_typography: annotationHasCustomTypography(annotation),
    has_class_name: annotation.class_name != null && annotation.class_name !== "",
    kind_is_supported_text: ["callout", "arrow", "text"].includes(annotation.kind),
    has_text: annotation.text != null && annotation.text !== "",
  }));
  const axes = [];
  for (const [axisId, options] of Object.entries(figureAxisOptions(figure) ?? {})) {
    axes.push({
      axis_code: axisId === "x" ? 0 : axisId === "y" ? 1 : 255,
      keys: significantSceneAxisKeys(options, polar),
      tick_label_strategy: optionalStr(options.tick_label_strategy),
      collision: optionalStr(options.collision),
    });
  }
  const traces = (figure.traces ?? []).map((trace) => marshalTraceSupportObs(trace, polar));
  return sceneFigureSupportMaterialize({
    polar,
    colorbarUnsupported,
    hasCustomFont: Object.values(chromeStyles).some((style) => Object.hasOwn(style ?? {}, "font-family"))
      || annotations.some((annotation) => annotationHasCustomTypography(annotation)),
    hasBrowserCss: Boolean(
      figureClassName(figure)
      || Object.keys(figureClassNames(figure) ?? {}).length
      || Object.keys(chromeStyles).length
      || Object.keys(figure.style ?? {}).some((key) => !["background", "--chart-bg"].includes(key))
      || annotations.some((annotation) => {
        const name = annotationClassName(annotation);
        return name != null && name !== "";
      }),
    ),
    hasExtraLegends: (figureExtraLegends(figure) ?? []).length > 0,
    annotations: annRows,
    axes,
    traces,
  });
}
function sceneFigureSupportReason(figure, { colorbarUnsupported = false } = {}) {
  const envelope = packFigureSupport(figure, { colorbarUnsupported });
  const requiredRaw = xySceneFigureSupportReason(
    envelope.length ? u8Ptr(envelope) : 0,
    BigInt(envelope.length),
    0,
    0n,
  );
  if (requiredRaw === USIZE_MAX_64) throw new RangeError("invalid scene figure support envelope");
  const required = Number(requiredRaw);
  if (required === 0) return "";
  const output = new Uint8Array(required);
  const written = xySceneFigureSupportReason(
    envelope.length ? u8Ptr(envelope) : 0,
    BigInt(envelope.length),
    u8Ptr(output),
    BigInt(required),
  );
  if (Number(written) !== required) throw new Error("native Scene figure support predicate returned an inconsistent length");
  return new TextDecoder("utf-8", { fatal: true }).decode(output);
}

const PUBLIC_EXPORT_KIND_CODES = {
  scatter: 0, line: 1, bar: 2, column: 3, histogram: 4, violin: 5, box: 6,
  box_whisker: 7, box_median: 8, segments: 9, errorbar: 10, stem: 11, area: 12,
  error_band: 13, ribbon: 14, triangle_mesh: 15, hexbin: 16, heatmap: 17,
  contour: 18,
};
const STYLE_KIND_CODES = { ...PUBLIC_EXPORT_KIND_CODES, contour: 18 };
const MS_LINE_ONLY = 1 << 0;
const MS_HAS_FILL = 1 << 1;
const MS_HAS_STROKE = 1 << 2;
const MS_HAS_LINE_COLOR = 1 << 3;
const MS_HAS_STROKE_WIDTH = 1 << 5;
const MS_HAS_WIDTH = 1 << 6;
const MS_HAS_LINE_WIDTH = 1 << 7;

function encodeUtf8(value) {
  return new TextEncoder().encode(String(value ?? ""));
}

function packMarkStyleRecord(trace, opacity, fillOpacity, strokeOpacity, lineOpacity, symbolCode) {
  const style = trace.style ?? {};
  let flags = 0;
  if (trace.kind === "scatter" && symbolCode >= SYMBOL_CODES.get("plus_line")) flags |= MS_LINE_ONLY;
  const parts = [];
  let fill = new Uint8Array(0);
  if (Object.hasOwn(style, "fill")) {
    let fillValue = style.fill;
    if (typeof fillValue !== "string" || String(fillValue).trim().toLowerCase().startsWith("linear-gradient(")) {
      const admitted = admitFillGradient(trace);
      if (admitted == null) throw new RangeError(`Scene v12 does not yet encode ${trace.kind} non-CSS fills`);
      fillValue = gradientSolidCss(admitted);
    }
    flags |= MS_HAS_FILL;
    fill = encodeUtf8(fillValue);
  }
  let stroke = new Uint8Array(0);
  if (Object.hasOwn(style, "stroke")) {
    flags |= MS_HAS_STROKE;
    stroke = encodeUtf8(style.stroke);
  }
  let lineColor = new Uint8Array(0);
  if (Object.hasOwn(style, "line_color") || Object.hasOwn(style, "lineColor")) {
    flags |= MS_HAS_LINE_COLOR;
    lineColor = encodeUtf8(style.line_color ?? style.lineColor);
  }
  const color = constantMarkColor(trace);
  if (color == null) {
    if (classifyRibbonColor2(trace) === "fail") {
      throw new RangeError("Scene v12 does not yet encode two-ended ribbon gradients");
    }
    throw new RangeError("Scene v12 does not yet support data-driven paint channels");
  }
  const colorBytes = encodeUtf8(color);
  let strokeWidth = 0;
  let width = 0;
  let lineWidth = 0;
  if (Object.hasOwn(style, "stroke_width") || Object.hasOwn(style, "strokeWidth")) {
    flags |= MS_HAS_STROKE_WIDTH;
    strokeWidth = Number(style.stroke_width ?? style.strokeWidth);
  }
  if (Object.hasOwn(style, "width")) {
    flags |= MS_HAS_WIDTH;
    width = Number(style.width);
  }
  if (Object.hasOwn(style, "line_width") || Object.hasOwn(style, "lineWidth")) {
    flags |= MS_HAS_LINE_WIDTH;
    lineWidth = Number(style.line_width ?? style.lineWidth);
  }
  const prefix = new Uint8Array(52);
  const view = new DataView(prefix.buffer);
  prefix[0] = STYLE_KIND_CODES[trace.kind] ?? 255;
  prefix[1] = flags;
  view.setFloat32(4, Number(opacity), true);
  view.setFloat32(8, Number(fillOpacity), true);
  view.setFloat32(12, Number(strokeOpacity), true);
  view.setFloat32(16, Number(lineOpacity), true);
  view.setFloat64(20, strokeWidth, true);
  view.setFloat64(28, width, true);
  view.setFloat64(36, lineWidth, true);
  view.setUint16(44, fill.length, true);
  view.setUint16(46, stroke.length, true);
  view.setUint16(48, lineColor.length, true);
  view.setUint16(50, colorBytes.length, true);
  parts.push(prefix, fill, stroke, lineColor, colorBytes);
  return concatBytes(parts);
}

function resolveMarkStyle(trace, opacity, fillOpacity, strokeOpacity, lineOpacity, symbolCode) {
  const record = packMarkStyleRecord(trace, opacity, fillOpacity, strokeOpacity, lineOpacity, symbolCode);
  const envelope = new Uint8Array(16 + record.length);
  const view = new DataView(envelope.buffer);
  envelope.set(encodeUtf8("XYMS").slice(0, 4), 0);
  view.setUint32(4, 1, true);
  view.setUint32(8, 1, true);
  envelope.set(record, 16);
  const out = new Uint8Array(16);
  const code = xySceneResolveMarkStyles(u8Ptr(envelope), BigInt(envelope.length), u8Ptr(out), BigInt(out.length));
  if (code !== 1) throw new RangeError("invalid mark style envelope");
  return {
    fillRgba: Array.from(out.subarray(0, 4)),
    strokeRgba: Array.from(out.subarray(4, 8)),
    strokeWidth: new DataView(out.buffer, out.byteOffset + 8, 8).getFloat64(0, true),
  };
}

function canonicalExportKey(key) {
  return String(key).replace(/[A-Z]/g, (ch) => `_${ch.toLowerCase()}`);
}

function encodeExportKey(key) {
  const bytes = new TextEncoder().encode(canonicalExportKey(key).slice(0, 256));
  const out = new Uint8Array(2 + bytes.length);
  out[0] = bytes.length & 0xff;
  out[1] = (bytes.length >> 8) & 0xff;
  out.set(bytes, 2);
  return out;
}

function concatBytes(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function exportColumn(trace, name) {
  const value = trace[name];
  if (value == null) return null;
  // TypedArrays expose a `.values()` iterator; do not treat that as a column wrapper.
  if (ArrayBuffer.isView(value) || Array.isArray(value)) return value;
  return value.values ?? value;
}

function exportColumnLen(column) {
  return column == null ? 0 : column.length;
}

function exportColumnFinite(column) {
  if (column == null) return false;
  return sceneFiniteAll(column);
}

function exportArraysEqual(left, right) {
  if (left == null || right == null) return false;
  return sceneArraysEqual(left, right);
}

function significantExportKeys(record) {
  return Object.entries(record ?? {})
    .filter(([, value]) => value != null && value !== false)
    .map(([key]) => key);
}

function packPublicExportFromFacts(facts) {
  const factsBytes = facts instanceof Uint8Array ? facts : new Uint8Array();
  const out = new Uint8Array(Math.max(256, factsBytes.length + 64));
  const code = xyScenePackPublicExport(
    factsBytes.length ? u8Ptr(factsBytes) : 0,
    BigInt(factsBytes.length),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -2) throw new RangeError("invalid scene public export facts version");
  if (code < 0) throw new RangeError("invalid scene public export packing");
  return out.subarray(0, code);
}

function packF64s(values) {
  const out = new Uint8Array(values.length * 8);
  const view = new DataView(out.buffer);
  values.forEach((value, index) => view.setFloat64(index * 8, Number(value), true));
  return out;
}

function packTickLabels(labels) {
  if (labels == null) return new Uint8Array();
  const parts = [];
  for (const label of labels) {
    const encoded = encodeUtf8(String(label));
    const header = new Uint8Array(4);
    new DataView(header.buffer).setUint32(0, encoded.length, true);
    parts.push(header, encoded);
  }
  return concatBytes(parts);
}

function unpackXyTl(blob) {
  if (!blob.length) return null;
  if (blob.length < 12 || String.fromCharCode(...blob.subarray(0, 4)) !== "XYTL") {
    throw new RangeError("invalid scene chrome packing");
  }
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  const count = view.getUint32(8, true);
  let at = 12;
  const labels = [];
  for (let i = 0; i < count; i++) {
    const length = view.getUint32(at, true);
    at += 4;
    labels.push(new TextDecoder().decode(blob.subarray(at, at + length)));
    at += length;
  }
  if (at !== blob.length) throw new RangeError("invalid scene chrome packing");
  return labels;
}

function unpackXyCc(blob) {
  if (blob.length < 160 || String.fromCharCode(...blob.subarray(0, 4)) !== "XYCC") {
    throw new RangeError("invalid scene chrome packing");
  }
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  if (view.getUint32(4, true) !== 1) throw new RangeError("invalid scene chrome facts version");
  const margins = [view.getFloat64(16, true), view.getFloat64(24, true), view.getFloat64(32, true), view.getFloat64(40, true)];
  const lens = [];
  for (let i = 0; i < 16; i++) lens.push(view.getUint32(48 + i * 4, true));
  let at = 160;
  const take = (n) => { const chunk = blob.subarray(at, at + n); at += n; return chunk; };
  const takeF64 = (n) => {
    if (!n) return [];
    const raw = take(n * 8);
    const values = [];
    const data = new DataView(raw.buffer, raw.byteOffset, raw.byteLength);
    for (let i = 0; i < n; i++) values.push(data.getFloat64(i * 8, true));
    return values;
  };
  const chromeStyle = take(lens[0]);
  const title = new TextDecoder().decode(take(lens[1]));
  const xLabel = new TextDecoder().decode(take(lens[2]));
  const yLabel = new TextDecoder().decode(take(lens[3]));
  const xMajor = takeF64(lens[4]);
  const xMinor = takeF64(lens[6]);
  const yMajor = takeF64(lens[7]);
  const yMinor = takeF64(lens[9]);
  const xTickLabels = unpackXyTl(take(lens[10]));
  const yTickLabels = unpackXyTl(take(lens[11]));
  const xFormatB = take(lens[12]);
  const yFormatB = take(lens[13]);
  const legendInput = take(lens[14]);
  const colorbarInput = take(lens[15]);
  if (at !== blob.length) throw new RangeError("invalid scene chrome packing");
  return {
    margins,
    chromeStyle,
    title,
    xLabel,
    yLabel,
    xMajorTicks: lens[5] ? null : xMajor,
    xMinorTicks: xMinor,
    yMajorTicks: lens[8] ? null : yMajor,
    yMinorTicks: yMinor,
    xTickLabels,
    yTickLabels,
    xFormat: xFormatB.length ? new TextDecoder().decode(xFormatB) : null,
    yFormat: yFormatB.length ? new TextDecoder().decode(yFormatB) : null,
    legendInput,
    colorbarInput,
  };
}

function packFigureChrome(facts) {
  const factsBytes = facts instanceof Uint8Array ? facts : new Uint8Array();
  const out = new Uint8Array(Math.max(65536, factsBytes.length + 4096));
  const code = xyScenePackFigureChrome(
    factsBytes.length ? u8Ptr(factsBytes) : 0,
    BigInt(factsBytes.length),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -2) throw new RangeError("invalid scene chrome facts version");
  if (code === -5) throw new RangeError("invalid canonical scene plot layout");
  if (code === -7) throw new RangeError("Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content");
  if (code === -8) throw new RangeError("Scene v12 primary legends are static; toggle and highlight must be false");
  if (code === -9) throw new RangeError("Scene v12 does not support legend location");
  if (code === -10) throw new RangeError("legend font sizes must be finite and in [1, 1000]");
  if (code === -11) throw new RangeError("Scene v12 legends support only background, color, font_size, and title_font_size");
  if (code === -12) throw new RangeError("Scene v19 colorbars require literal bounded RGBA stops");
  if (code === -13) throw new RangeError("Scene v19 colorbars require a two-value domain and 2–16 stops");
  if (code === -14) throw new RangeError("Scene v19 colorbar side is right or bottom");
  if (code === -15) throw new RangeError("scene axis tick lists are limited to 200 values");
  if (code < 0) throw new RangeError("invalid scene chrome packing");
  return out.subarray(0, code);
}

function packFigureChromeFromSidecars(facts, xysd) {
  const factsBytes = facts instanceof Uint8Array ? facts : new Uint8Array();
  const xysdBytes = xysd instanceof Uint8Array ? xysd : new Uint8Array();
  let capacity = Math.max(65536, factsBytes.length + xysdBytes.length + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xyScenePackFigureChromeFromSidecars(
      factsBytes.length ? u8Ptr(factsBytes) : 0,
      BigInt(factsBytes.length),
      xysdBytes.length ? u8Ptr(xysdBytes) : 0,
      BigInt(xysdBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code === -2) throw new RangeError("invalid scene chrome facts version");
    if (code === -5) throw new RangeError("invalid canonical scene plot layout");
    if (code === -7) throw new RangeError("Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content");
    if (code === -8) throw new RangeError("Scene v12 primary legends are static; toggle and highlight must be false");
    if (code === -9) throw new RangeError("Scene v12 does not support legend location");
    if (code === -10) throw new RangeError("legend font sizes must be finite and in [1, 1000]");
    if (code === -11) throw new RangeError("Scene v12 legends support only background, color, font_size, and title_font_size");
    if (code === -12) throw new RangeError("Scene v19 colorbars require literal bounded RGBA stops");
    if (code === -13) throw new RangeError("Scene v19 colorbars require a two-value domain and 2–16 stops");
    if (code === -14) throw new RangeError("Scene v19 colorbar side is right or bottom");
    if (code === -15) throw new RangeError("scene axis tick lists are limited to 200 values");
    if (code < 0) throw new RangeError("invalid scene chrome packing");
    return out.subarray(0, code);
  }
  throw new RangeError("invalid scene chrome packing");
}

const XYTC_HAS_FILL = 1 << 0;
const XYTC_HAS_STROKE = 1 << 1;
const XYTC_HAS_LINE_COLOR = 1 << 2;
const XYTC_HAS_STROKE_WIDTH = 1 << 3;
const XYTC_HAS_WIDTH = 1 << 4;
const XYTC_HAS_LINE_WIDTH = 1 << 5;
const XYTC_HAS_SIZE = 1 << 6;
const XYTC_HAS_SIZE_CH = 1 << 7;
const XYTC_HAS_HEX = 1 << 8;
const XYTC_PERIMETER_TRUE = 1 << 9;
const XYTC_PERIMETER_INVALID = 1 << 10;
const XYTC_COLOR_CH = 1 << 11;
const XYTC_COLOR_CH_CONSTANT = 1 << 12;
const XYTC_COLOR2 = 1 << 13;
const XYTC_USE_DENSITY = 1 << 14;
const XYTC_SHOW_LEGEND = 1 << 15;
const XYTC_HAS_NAME = 1 << 16;
const XYTC_HAS_DASH_PATTERN = 1 << 17;
const XYTC_HAS_MARKER = 1 << 18;
const XYTC_HAS_GRADIENT_SPEC = 1 << 19;
const XYTC_HAS_FILL_DICT = 1 << 20;
const XYTC_SYMBOL_INT = 1 << 21;
const XYTC_HAS_CORNER_RADIUS = 1 << 22;
const XYTC_HAS_WEDGE_GAP = 1 << 23;
const XYTC_HAS_GLYPH = 1 << 24;
const XYTC_JOINED_FILL = 1 << 25;
const XYTO_LINECAP_NONE = 255;
const XYTA_HEATMAP = 1 << 0;
const XYTA_DENSITY = 1 << 1;
const XYTA_HAS_RGBA = 1 << 2;
const XYTA_HAS_RGBA_GRID = 1 << 3;
const XYTA_HAS_GRID = 1 << 4;
const XYTA_TRUECOLOR = 1 << 5;
const XYTA_HAS_NAMED_CMAP = 1 << 6;
const XYTA_HAS_STOPS = 1 << 7;
const XYTA_HAS_COLOR_CH = 1 << 8;
const XYTA_HAS_STYLE_COLOR = 1 << 9;
const XYTA_HAS_OPACITY = 1 << 10;
const XYTA_HAS_FILL_OPACITY = 1 << 11;
const XYTA_HAS_DOMAIN = 1 << 12;
const XYTA_SHAPE = 1 << 13;
const XYTA_RIBBON_ENDS = 1 << 14;
const XYTA_MESH_FACES = 1 << 15;
const XYTA_SCATTER_PAINT = 1 << 16;
const XYMG_MAX_UTF8 = 64;
const GRAD_DIR_FROM_CODE = { 0: "down", 1: "up", 2: "right", 3: "left" };

export function admittedMarkerGlyph(glyph) {
  if (typeof glyph !== "string") return null;
  if (!sceneMarkerGlyphAdmit(glyph)) return null;
  return encodeUtf8(glyph);
}

function packMarkerBlob(value) {
  return sceneMarkerBlobPack(value);
}

function packGradientSpec(fill) {
  return sceneGradientSpecPack(fill?.space, fill?.dir, fill?.stops);
}

/** XYTC color_ch. Python `_pack_xytc` reads `getattr(trace, "color_ch", None)` only. */
export function packXyTcColorChannel(trace) {
  const channel = (trace ?? {}).color_ch;
  if (
    channel == null
    || typeof channel !== "object"
    || Array.isArray(channel)
    || ArrayBuffer.isView(channel)
  ) {
    return { flags: 0, mode: new Uint8Array(), constant: new Uint8Array() };
  }
  const hasConstant = channel.constant != null ? 1 : 0;
  const flags = sceneXytcColorChannelPack(1, hasConstant);
  const mode = encodeUtf8(String(channel.mode ?? ""));
  let constant = new Uint8Array();
  if (hasConstant) {
    constant = encodeUtf8(String(channel.constant));
  }
  return { flags, mode, constant };
}

/** XYTC fill/stroke/line_color presence. Python `_pack_xytc` key-presence only. */
export function packXyTcPaintPresence(style) {
  const record = style ?? {};
  const hasFill = Object.hasOwn(record, "fill") ? 1 : 0;
  let fillKind = 0;
  if (hasFill) {
    const fill = record.fill;
    if (typeof fill === "string") fillKind = 1;
    else if (
      fill != null
      && typeof fill === "object"
      && fill.space != null
      && fill.dir != null
      && Array.isArray(fill.stops)
    ) {
      fillKind = 2;
    } else if (fill != null && typeof fill === "object") {
      fillKind = 3;
    } else {
      fillKind = 1;
    }
  }
  return sceneXytcPaintPresencePack(
    hasFill,
    fillKind,
    Object.hasOwn(record, "stroke") ? 1 : 0,
    Object.hasOwn(record, "line_color") ? 1 : 0,
  );
}

/** XYTC dash. Python `_pack_xytc` reads `style.get("dash")` only. */
export function packXyTcDash(style) {
  const record = style ?? {};
  const dash = record.dash;
  if (typeof dash === "string") {
    return { flags: 0, dashB: encodeUtf8(dash), pattern: [] };
  }
  if (Array.isArray(dash)) {
    let pattern = [];
    try {
      pattern = dash.map((part) => {
        const value = Number(part);
        if (!Number.isFinite(value)) throw new RangeError("invalid dash part");
        return value;
      });
    } catch {
      pattern = [];
    }
    return {
      flags: sceneXytcDashPatternPack(1),
      dashB: new Uint8Array(),
      pattern,
    };
  }
  return { flags: 0, dashB: new Uint8Array(), pattern: [] };
}

/** XYTC fill opacity. Python `_pack_xytc` uses `style.get("fill_opacity", 1.0)` only. */
export function packXyTcFillOpacity(style, kindClass) {
  const packed = sceneXytcOpacityPack(
    kindClass & SCENE_KIND_CLASS_OPACITY ? 1 : 0,
    kindClass & SCENE_KIND_CLASS_BAND ? 1 : 0,
    style,
  );
  return packed.fillOpacity;
}

/** XYTC scatter symbol. Python `_pack_xytc` symbol string vs int branch. */
export function packXyTcSymbol(style) {
  const record = style ?? {};
  if (typeof record.symbol === "number") {
    return {
      flags: sceneXytcSymbolIntPack(1),
      symbolB: new Uint8Array(),
      symbolInt: record.symbol,
    };
  }
  const symbol = String(record.symbol ?? "circle") || "circle";
  return { flags: sceneXytcSymbolIntPack(0), symbolB: encodeUtf8(symbol), symbolInt: 0 };
}

/** XYTC ribbon color2 flags. Python `_pack_xytc` color2 branch. */
export function packXyTcColor2(trace, paintFlags, gradientBlob) {
  const color2Class = classifyRibbonColor2(trace);
  let gradientPacked = 0;
  let outBlob = gradientBlob;
  if (
    color2Class === "gradient"
    && (paintFlags & (XYTC_HAS_FILL | XYTC_HAS_GRADIENT_SPEC)) === 0
  ) {
    const spec = ribbonColor2GradientSpec(trace);
    const packed = spec == null ? null : packGradientSpec(spec);
    if (packed && packed.length) {
      gradientPacked = 1;
      outBlob = packed;
    }
  }
  return {
    flags: sceneXytcColor2FlagsPack(
      COLOR2_CLASS_TO_CODE[color2Class] ?? 4,
      paintFlags,
      gradientPacked,
    ),
    gradientBlob: outBlob,
  };
}

/** XYTC joined fill. Python `_pack_xytc` reads `style.get("joined_fill")` only. */
export function packXyTcJoinedFill(trace) {
  const style = trace?.style ?? {};
  return sceneXytcMetaFlagsPack(
    0,
    0,
    String(trace?.kind ?? ""),
    0,
    style.joined_fill ? 1 : 0,
    0,
    0,
    0,
  ) & XYTC_JOINED_FILL;
}

/** XYTC trace meta flags. Python `_pack_xytc` name/legend/density/marker/joined bits. */
export function packXyTcMetaFlags(
  trace,
  showLegend,
  { markerPathPresent = 0, markerPacked = 0, glyphPacked = 0 } = {},
) {
  const name = trace?.name != null && String(trace.name).length ? String(trace.name) : "";
  const style = trace?.style ?? {};
  const useDensity = trace?.kind === "scatter" && scatterUsesDensity(trace) ? 1 : 0;
  const joinedFill = String(trace?.kind ?? "") === "triangle_mesh" && style.joined_fill ? 1 : 0;
  return sceneXytcMetaFlagsPack(
    name ? 1 : 0,
    showLegend ? 1 : 0,
    String(trace?.kind ?? ""),
    useDensity,
    joinedFill,
    markerPathPresent,
    markerPacked,
    glyphPacked,
  );
}

/** XYTC line color. Python `_pack_xytc` reads `"line_color" in style` only. */
export function packXyTcLineColor(style) {
  const record = style ?? {};
  const flags = packXyTcPaintPresence(record) & XYTC_HAS_LINE_COLOR;
  if (!flags) return { flags: 0, bytes: new Uint8Array() };
  return { flags, bytes: encodeUtf8(record.line_color) };
}

/** XYTC linecap. Python `_pack_xytc` reads `"linecap" in style` only. */
export function packXyTcLinecap(style) {
  const record = style ?? {};
  if (!Object.hasOwn(record, "linecap")) return new Uint8Array();
  return encodeUtf8(record.linecap);
}

/** XYTC line opacity. Python `_pack_xytc` uses `style.get("line_opacity", 1.0)` only. */
export function packXyTcLineOpacity(style, kindClass) {
  const packed = sceneXytcOpacityPack(
    kindClass & SCENE_KIND_CLASS_OPACITY ? 1 : 0,
    kindClass & SCENE_KIND_CLASS_BAND ? 1 : 0,
    style,
  );
  return packed.lineOpacity;
}

/** XYTC line width. Python `_pack_xytc` reads `"line_width" in style` only. */
export function packXyTcLineWidth(style) {
  const packed = sceneXytcNumericStylePack({}, style ?? {});
  return {
    flags: packed.flags & XYTC_HAS_LINE_WIDTH,
    value: packed.lineWidth,
  };
}

/** XYTC size. Python `_pack_xytc` reads `"size" in style` only. */
export function packXyTcSize(style) {
  const packed = sceneXytcNumericStylePack({}, style ?? {});
  return { flags: packed.flags & XYTC_HAS_SIZE, value: packed.size };
}

/** XYTC size_ch. Python `_pack_xytc` reads `getattr(trace, "size_ch", None)` only. */
export function packXyTcSizeChannel(trace) {
  const packed = sceneXytcNumericStylePack(trace ?? {}, {});
  return { flags: packed.flags & XYTC_HAS_SIZE_CH, value: packed.sizeCh };
}


/** XYTC stroke opacity. Python `_pack_xytc` uses `style.get("stroke_opacity", 1.0)` only. */
export function packXyTcStrokeOpacity(style, kindClass) {
  const packed = sceneXytcOpacityPack(
    kindClass & SCENE_KIND_CLASS_OPACITY ? 1 : 0,
    kindClass & SCENE_KIND_CLASS_BAND ? 1 : 0,
    style,
  );
  return packed.strokeOpacity;
}

/** XYTC stroke perimeter. Python `_pack_xytc` reads `"stroke_perimeter" in style` only. */
export function packXyTcStrokePerimeter(style, kindClass) {
  const band = kindClass & SCENE_KIND_CLASS_BAND ? 1 : 0;
  const record = style ?? {};
  const present = Object.hasOwn(record, "stroke_perimeter") ? 1 : 0;
  if (!present) {
    return sceneXytcStrokePerimeterPack(band, 0, 0, 0);
  }
  const perimeter = record.stroke_perimeter;
  const perimeterIsBool = typeof perimeter === "boolean" ? 1 : 0;
  const perimeterTrue = perimeterIsBool && perimeter === true ? 1 : 0;
  return sceneXytcStrokePerimeterPack(band, present, perimeterIsBool, perimeterTrue);
}

/** XYTC stroke width. Python `_pack_xytc` reads `"stroke_width" in style` only. */
export function packXyTcStrokeWidth(style) {
  const packed = sceneXytcNumericStylePack({}, style ?? {});
  return {
    flags: packed.flags & XYTC_HAS_STROKE_WIDTH,
    value: packed.strokeWidth,
  };
}

function xytcFillKind(style) {
  const record = style ?? {};
  if (!Object.hasOwn(record, "fill")) return 0;
  const fill = record.fill;
  if (typeof fill === "string") return 1;
  if (fill != null && typeof fill === "object" && fill.space != null && fill.dir != null && Array.isArray(fill.stops)) {
    return 2;
  }
  if (fill != null && typeof fill === "object") return 3;
  return 1;
}

export function marshalXyTcTraceObs(trace, showLegend) {
  const style = trace.style ?? {};
  const kindName = String(trace.kind ?? "");
  const nan = Number.NaN;
  const name = trace.name != null && String(trace.name).length ? String(trace.name) : "";
  const symbolRaw = style.symbol ?? "circle";
  let symbolIsInt = 0;
  let symbolInt = 0;
  let symbolText = String(symbolRaw || "circle");
  if (typeof symbolRaw === "number" && typeof symbolRaw !== "boolean") {
    symbolIsInt = 1;
    symbolInt = Number(symbolRaw);
    symbolText = null;
  }
  const sizeCh = trace.size_ch;
  const sizeChConstant = sizeCh?.constant;
  const rawDx = style.hex_dx ?? style.dx;
  const rawDy = style.hex_dy ?? style.dy;
  const dash = style.dash;
  let dashText = null;
  let dashValues = [];
  let dashIsArray = 0;
  if (typeof dash === "string") dashText = dash;
  else if (Array.isArray(dash)) {
    dashIsArray = 1;
    try {
      dashValues = dash.map((part) => {
        const value = Number(part);
        if (!Number.isFinite(value)) throw new RangeError("invalid dash part");
        return value;
      });
    } catch {
      dashValues = [];
    }
  }
  const perimeterPresent = Object.hasOwn(style, "stroke_perimeter");
  let perimeterIsBool = 0;
  let perimeterTrue = 0;
  if (perimeterPresent) {
    const perimeter = style.stroke_perimeter;
    perimeterIsBool = typeof perimeter === "boolean" ? 1 : 0;
    perimeterTrue = perimeterIsBool && perimeter === true ? 1 : 0;
  }
  const radius = style.corner_radius ?? 0;
  let radiusSeq = 1;
  let r0 = Number(radius) || 0;
  let r1 = 0;
  if (Array.isArray(radius) && radius.length === 2) {
    radiusSeq = 2;
    r0 = Number(radius[0]);
    r1 = Number(radius[1]);
  }
  const channel = trace.color_ch;
  const colorChPresent = channel != null && typeof channel === "object" ? 1 : 0;
  const colorChHasConstant = colorChPresent && channel.constant != null ? 1 : 0;
  const color2 = trace.color2_ch;
  const hasColor2 = color2 != null;
  const kindIsRibbon = kindName === "ribbon";
  const hasFill = Object.hasOwn(style, "fill");
  const color2SourceConst = channelConstantCss(trace.color_ch);
  const color2TargetConst = hasColor2 ? channelConstantCss(color2) : null;
  let hasEndPair = false;
  if (hasColor2 && kindIsRibbon) {
    const bothConst = color2TargetConst != null && color2SourceConst != null;
    if (!bothConst && !hasFill) hasEndPair = ribbonEndRgbaPair(trace) != null;
  }
  return {
    show_legend: showLegend,
    kind: kindName,
    has_name: Boolean(name),
    name,
    marker_path_present: kindName === "scatter" && style.marker_path != null,
    use_density: kindName === "scatter" && scatterUsesDensity(trace),
    joined_fill: kindName === "triangle_mesh" && Boolean(style.joined_fill),
    symbol_is_int: symbolIsInt,
    symbol_int: symbolInt,
    symbol_text: symbolText,
    opacity: Number(style.opacity ?? 1),
    fill_opacity: Number(style.fill_opacity ?? 1),
    stroke_opacity: Number(style.stroke_opacity ?? 1),
    line_opacity: Number(style.line_opacity ?? 1),
    has_stroke: Object.hasOwn(style, "stroke"),
    stroke: style.stroke,
    has_line_color: Object.hasOwn(style, "line_color"),
    line_color: style.line_color,
    has_color: Object.hasOwn(style, "color"),
    color: style.color,
    has_size: Object.hasOwn(style, "size"),
    size: Object.hasOwn(style, "size") ? Number(style.size) : nan,
    has_size_ch: sizeCh != null,
    has_size_ch_constant: sizeChConstant != null,
    size_ch_constant: sizeChConstant != null ? Number(sizeChConstant) : nan,
    has_stroke_width: Object.hasOwn(style, "stroke_width"),
    stroke_width: Object.hasOwn(style, "stroke_width") ? Number(style.stroke_width) : 0,
    has_width: Object.hasOwn(style, "width"),
    width: Object.hasOwn(style, "width") ? Number(style.width) : 0,
    has_line_width: Object.hasOwn(style, "line_width"),
    line_width: Object.hasOwn(style, "line_width") ? Number(style.line_width) : 0,
    has_hex_dx: rawDx != null,
    hex_dx: rawDx != null ? Number(rawDx) : nan,
    has_hex_dy: rawDy != null,
    hex_dy: rawDy != null ? Number(rawDy) : nan,
    has_stroke_perimeter: perimeterPresent,
    stroke_perimeter_is_bool: perimeterIsBool,
    stroke_perimeter_true: perimeterTrue,
    wedge_gap_raw: Number(style.wedge_gap ?? 0) || 0,
    dash_is_array: dashIsArray,
    dash_text: dashText,
    dash_values: dashValues,
    has_fill: hasFill,
    fill: hasFill ? style.fill : null,
    marker_path: style.marker_path,
    marker_glyph: style.marker_glyph,
    has_color2: hasColor2,
    kind_is_ribbon: kindIsRibbon,
    color2_source_const: color2SourceConst,
    color2_target_const: color2TargetConst,
    source_paint: sourceColorCss(trace),
    has_end_pair: hasEndPair,
    corner_radius_seq: radiusSeq,
    corner_radius_r0: r0,
    corner_radius_r1: r1,
    color_ch_present: colorChPresent,
    color_ch_has_constant: colorChHasConstant,
    color_ch_mode: channel == null || typeof channel !== "object" ? null : String(channel.mode ?? ""),
    color_ch_constant: colorChHasConstant ? String(channel.constant) : null,
    linecap: style.linecap,
    step: style.step,
    curve: style.curve,
  };
}

function marshalXyTcTraceRecord(trace, showLegend) {
  const obs = marshalXyTcTraceObs(trace, showLegend);
  const materialized = sceneXyTcTraceObservationsMaterialize(obs);
  return sceneXytcTracePack({
    showLegend: materialized.showLegend,
    kind: materialized.kind,
    hasName: materialized.hasName,
    name: materialized.name,
    markerPathPresent: materialized.markerPathPresent,
    useDensity: materialized.useDensity,
    joinedFill: materialized.joinedFill,
    markerPacked: materialized.markerPacked,
    glyphPacked: materialized.glyphPacked,
    markerBlob: materialized.markerBlob,
    color2Class: materialized.color2Class,
    color2GradientBlob: materialized.color2GradientBlob,
    color2GradientPacked: materialized.color2GradientPacked,
    style: {
      symbolIsInt: materialized.style.symbolIsInt,
      symbolInt: materialized.style.symbolInt,
      opacity: materialized.style.opacity,
      fillOpacity: materialized.style.fillOpacity,
      strokeOpacity: materialized.style.strokeOpacity,
      lineOpacity: materialized.style.lineOpacity,
      hasStroke: materialized.style.hasStroke,
      hasLineColor: materialized.style.hasLineColor,
      hasSize: materialized.style.hasSize,
      size: materialized.style.size,
      hasSizeCh: materialized.style.hasSizeCh,
      hasSizeChConstant: materialized.style.hasSizeChConstant,
      sizeChConstant: materialized.style.sizeChConstant,
      hasStrokeWidth: materialized.style.hasStrokeWidth,
      strokeWidth: materialized.style.strokeWidth,
      hasWidth: materialized.style.hasWidth,
      width: materialized.style.width,
      hasLineWidth: materialized.style.hasLineWidth,
      lineWidth: materialized.style.lineWidth,
      hasHexDx: materialized.style.hasHexDx,
      hexDx: materialized.style.hexDx,
      hasHexDy: materialized.style.hasHexDy,
      hexDy: materialized.style.hexDy,
      hasStrokePerimeter: materialized.style.hasStrokePerimeter,
      strokePerimeterIsBool: materialized.style.strokePerimeterIsBool,
      strokePerimeterTrue: materialized.style.strokePerimeterTrue,
      dashIsArray: materialized.style.dashIsArray,
      hasFill: materialized.style.hasFill,
      fillKind: materialized.style.fillKind,
      colorChPresent: materialized.style.colorChPresent,
      colorChHasConstant: materialized.style.colorChHasConstant,
      radiusSeq: materialized.style.radiusSeq,
      r0: materialized.style.r0,
      r1: materialized.style.r1,
      wedgeGapRaw: materialized.style.wedgeGapRaw,
    },
    symbolB: materialized.symbolB,
    dashB: materialized.dashB,
    dashPattern: materialized.dashPattern,
    linecapB: materialized.linecapB,
    stepB: materialized.stepB,
    curveB: materialized.curveB,
    fillCss: materialized.fillCss,
    fillSpace: materialized.fillSpace,
    fillGradientBlob: materialized.fillGradientBlob,
    strokeCss: materialized.strokeCss,
    lineColor: materialized.lineColor,
    colorCss: materialized.colorCss,
    colorMode: materialized.colorMode,
    colorConst: materialized.colorConst,
  });
}

function packXyTc(figure) {
  const traces = figure.traces ?? [];
  const records = [];
  const figurePlan = sceneXytcFigurePlan({ showLegend: figureShowLegend(figure) !== false });
  const showLegend = figurePlan.showLegend;
  for (const trace of traces) {
    records.push(marshalXyTcTraceRecord(trace, showLegend));
  }
  const header = new Uint8Array(16);
  const headerView = new DataView(header.buffer);
  header.set(encodeUtf8("XYTC").slice(0, 4), 0);
  headerView.setUint32(4, 1, true);
  headerView.setUint32(8, traces.length, true);
  return concatBytes([header, ...records]);
}

function unpackMarkerBlob(blob) {
  if (blob.length < 8) return null;
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  const nContours = view.getUint32(0, true);
  const filled = blob[4] !== 0;
  let at = 8;
  const contours = [];
  for (let i = 0; i < nContours; i += 1) {
    const nValues = view.getUint32(at, true);
    at += 4;
    const values = [];
    for (let j = 0; j < nValues; j += 1) {
      values.push(view.getFloat64(at, true));
      at += 8;
    }
    contours.push(values);
  }
  return { contours, filled: Boolean(filled) };
}

function unpackGradientBlob(blob) {
  if (blob.length < 4) return null;
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  const space = blob[0];
  const dir = blob[1];
  const nStops = blob[2];
  let at = 4;
  const stops = [];
  for (let i = 0; i < nStops; i += 1) {
    const t = view.getFloat32(at, true);
    stops.push([t, [blob[at + 4], blob[at + 5], blob[at + 6], blob[at + 7]]]);
    at += 8;
  }
  return { space: space ? "plot" : "mark", dir: GRAD_DIR_FROM_CODE[dir] ?? "down", stops };
}

function unpackXyTo(blob) {
  if (blob.length < 16 || blob[0] !== 88 || blob[1] !== 89 || blob[2] !== 84 || blob[3] !== 79) {
    throw new RangeError("invalid scene trace compile packing");
  }
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  if (view.getUint32(4, true) !== 1) throw new RangeError("invalid scene trace compile facts version");
  const nTraces = view.getUint32(8, true);
  let at = 16;
  const compiled = [];
  for (let i = 0; i < nTraces; i += 1) {
    if (blob[at] !== 88 || blob[at + 1] !== 89 || blob[at + 2] !== 84 || blob[at + 3] !== 79) {
      throw new RangeError("invalid scene trace compile packing");
    }
    const fillRgba = Array.from(blob.subarray(at + 8, at + 12));
    const strokeRgba = Array.from(blob.subarray(at + 12, at + 16));
    const strokeWidth = view.getFloat64(at + 16, true);
    const diameter = view.getFloat64(at + 24, true);
    const symbol = view.getUint16(at + 32, true);
    const legendKind = blob[at + 34];
    const legendInclude = blob[at + 35] !== 0;
    const legendSymbol = view.getUint16(at + 36, true);
    const authoredStep = view.getUint16(at + 38, true);
    const factBits = view.getUint32(at + 40, true);
    const dashCount = view.getUint32(at + 44, true);
    const linecap = blob[at + 48];
    const hasMarker = blob[at + 49];
    const hasGradient = blob[at + 50];
    const markerLen = view.getUint32(at + 52, true);
    const gradientLen = view.getUint32(at + 56, true);
    const hexDx = view.getFloat64(at + 60, true);
    const hexDy = view.getFloat64(at + 68, true);
    at += 160;
    let dash = null;
    if (dashCount) {
      dash = [];
      for (let j = 0; j < dashCount; j += 1) {
        dash.push(view.getFloat64(at, true));
        at += 8;
      }
    }
    const marker = blob.subarray(at, at + markerLen);
    at += markerLen;
    const gradient = blob.subarray(at, at + gradientLen);
    at += gradientLen;
    compiled.push({
      fillRgba, strokeRgba, strokeWidth, diameter, symbol, legendKind, legendInclude, legendSymbol,
      authoredStep, factBits, hexDx, hexDy,
      dash,
      linecap: linecap === XYTO_LINECAP_NONE ? null : linecap,
      markerPath: hasMarker && marker.length ? unpackMarkerBlob(marker) : null,
      fillGradient: hasGradient && gradient.length ? unpackGradientBlob(gradient) : null,
    });
  }
  if (at !== blob.length) throw new RangeError("invalid scene trace compile packing");
  return compiled;
}

function raiseTraceCompile(code, index, figure) {
  const trace = figure.traces?.[index];
  const style = trace?.style ?? {};
  if (code === -5) throw new RangeError("trace opacity must be in [0, 1]");
  if (code === -12) throw new RangeError("trace opacity channels must be in [0, 1]");
  if (code === -6) {
    const symbol = style.symbol ?? 0;
    throw new RangeError(`Scene v12 does not support scatter symbol ${typeof symbol === "string" ? JSON.stringify(symbol) : symbol}`);
  }
  if (code === -7) throw new RangeError(`Scene v12 does not support step mode ${JSON.stringify(style.step)}`);
  if (code === -8) throw new RangeError("Scene v25 area stroke_perimeter must be a boolean");
  if (code === -9) throw new RangeError("Scene v12 hexbin requires finite hex_dx/hex_dy cell pitch");
  if (code === -10) throw new RangeError("Scene v12 does not yet encode two-ended ribbon gradients");
  if (code === -11) throw new RangeError(`Scene v12 does not yet encode ${trace?.kind ?? "mark"} non-CSS fills`);
  if (code === -13) throw new RangeError("Scene v12 does not yet support data-driven paint channels");
  if (code === -2) throw new RangeError("invalid scene trace compile facts version");
  throw new RangeError("invalid scene trace compile packing");
}

function packTraceCompile(facts) {
  const factsBytes = facts instanceof Uint8Array ? facts : new Uint8Array();
  const out = new Uint8Array(Math.max(65536, factsBytes.length + 4096));
  const code = xyScenePackTraceCompile(
    factsBytes.length ? u8Ptr(factsBytes) : 0,
    BigInt(factsBytes.length),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code < 0) {
    const index = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
    const error = new RangeError("invalid scene trace compile packing");
    error.code = code;
    error.index = index;
    throw error;
  }
  return out.subarray(0, code);
}

export function packXyTaGrid(raw) {
  const source = raw != null
    && typeof raw === "object"
    && !Array.isArray(raw)
    && !ArrayBuffer.isView(raw)
    && raw.values != null
    ? raw.values
    : raw;
  const flat = flattenPlaneF64(source);
  if (flat == null) return new Uint8Array();
  return packF64Le(flat);
}

export function packXyTaRgba(packed) {
  if (packed instanceof Uint8Array) return packed;
  return Uint8Array.from(packed);
}

export function packXyTaRgbaGrid(planes) {
  if (planes == null || planes.length !== 4) return new Uint8Array();
  try {
    const channels = [];
    for (const plane of planes) {
      const raw = plane != null
        && typeof plane === "object"
        && !Array.isArray(plane)
        && !ArrayBuffer.isView(plane)
        && plane.values != null
        ? plane.values
        : plane;
      const flat = flattenPlaneF64(raw);
      if (flat == null) return new Uint8Array();
      channels.push(flat);
    }
    const n = channels[0].length;
    if (!channels.every((channel) => channel.length === n)) return new Uint8Array();
    const interleaved = new Float64Array(n * 4);
    for (let i = 0; i < n; i += 1) {
      for (let c = 0; c < 4; c += 1) interleaved[i * 4 + c] = channels[c][i];
    }
    return new Uint8Array(interleaved.buffer);
  } catch {
    return new Uint8Array();
  }
}

function flattenPlaneF64(raw) {
  if (raw == null) return null;
  if (ArrayBuffer.isView(raw) && !(raw instanceof DataView)) {
    return Float64Array.from(raw, Number);
  }
  if (!Array.isArray(raw)) return null;
  if (raw.length > 0 && (Array.isArray(raw[0]) || ArrayBuffer.isView(raw[0]))) {
    const rows = raw.map((row) => Array.from(row, Number));
    const width = rows[0].length;
    const out = new Float64Array(rows.length * width);
    let k = 0;
    for (const row of rows) {
      if (row.length !== width) return null;
      for (const value of row) out[k++] = value;
    }
    return out;
  }
  return Float64Array.from(raw, Number);
}

export function packXyTaColormap(trace) {
  const packed = sceneXytaColormapPack(trace.style ?? {});
  return { flags: packed.flags, cmap: packed.cmap, stops: packed.stops };
}

/** Density XYTA constant color_ch. Python `_pack_xyta` reads `getattr(trace, "color_ch", None)` only. */
export function packXyTaDensityColorCh(trace) {
  const channel = trace.color_ch;
  if (channel != null && channel.mode === "constant" && channel.constant != null) {
    return { flags: XYTA_HAS_COLOR_CH, bytes: encodeUtf8(String(channel.constant)) };
  }
  return { flags: 0, bytes: new Uint8Array() };
}

/** Density XYTA fill opacity. Python `_pack_xyta` reads `fill_opacity` only. */
export function packXyTaFillOpacity(style) {
  const record = style ?? {};
  if (!Object.hasOwn(record, "fill_opacity")) return { flags: 0, value: Number.NaN };
  return { flags: XYTA_HAS_FILL_OPACITY, value: Number(record.fill_opacity) };
}

export function hexbinXyTaColorChannel(trace) {
  return (trace ?? {}).color_ch;
}

export function hexbinXyTaColormap(trace) {
  const channel = hexbinXyTaColorChannel(trace);
  return packXyTaColormap({ style: { colormap: channel?.colormap } });
}

/** Heatmap lattice shape. Python `_heatmap_shape` / `_pack_xyta` read `trace.grid_shape` only. */
export function heatmapGridShape(trace) {
  return (trace ?? {}).grid_shape;
}

/** Hexbin cell pitch. Python `_hexbin_pitch` / `_pack_xytc` read `style.get("hex_dx", style.get("dx"))` only. */
export function hexbinStylePitch(style) {
  const record = style ?? {};
  return {
    hex_dx: record.hex_dx ?? record.dx,
    hex_dy: record.hex_dy ?? record.dy,
  };
}

function xytaHexbinPlaneObservations(trace) {
  const channel = trace.color_ch;
  if (channel == null) return { hexbinColormapPlane: false, hexbinRgbaPlaneReady: false };
  const hexbinColormapPlane = sceneHexbinColormapPlaneAdmit(
    channel.mode,
    channel.values != null,
  );
  let hexbinRgbaPlaneReady = false;
  if (sceneHexbinRgbaPlaneAdmit(channel.mode)) {
    hexbinRgbaPlaneReady = hexbinCellRgba8(trace) != null;
  }
  return { hexbinColormapPlane, hexbinRgbaPlaneReady };
}

function marshalXytaColorChannel(channel) {
  if (channel == null || typeof channel === "string") {
    return {
      present: false,
      mode: "",
      constant: null,
      colormap: null,
      has_domain: false,
      domain_lo: 0,
      domain_hi: 0,
      values_f64: new Float64Array(),
      rgba_u8: new Uint8Array(),
      codes_u8: new Uint8Array(),
      codes_i64: [],
      palette: [],
      n_categories: 0,
    };
  }
  const mode = String(channel.mode ?? "");
  const domain = channel.domain;
  const hasDomain = domain != null && domain.length === 2;
  let valuesF64 = new Float64Array();
  let rgbaU8 = new Uint8Array();
  if (channel.values != null) {
    valuesF64 = Float64Array.from(channel.values, Number);
  } else if (channel.rgba != null) {
    const rgba = channel.rgba;
    if (rgba instanceof Uint8Array) rgbaU8 = rgba;
    else valuesF64 = Float64Array.from(rgba, Number);
  }
  let codesU8 = new Uint8Array();
  let codesI64 = [];
  if (channel.codes != null) {
    const codes = channel.codes;
    if (codes instanceof Uint8Array) codesU8 = codes;
    else codesI64 = [...codes].map((value) => Number(value));
  }
  const palette = channel.palette?.length ? [...channel.palette] : (channel.colors ?? []);
  return {
    present: true,
    mode,
    constant: channel.constant ?? null,
    colormap: typeof channel.colormap === "string" ? channel.colormap : null,
    has_domain: hasDomain,
    domain_lo: hasDomain ? Number(domain[0]) : 0,
    domain_hi: hasDomain ? Number(domain[1]) : 0,
    values_f64: valuesF64,
    rgba_u8: rgbaU8,
    codes_u8: codesU8,
    codes_i64: codesI64,
    palette: palette.map(String),
    n_categories: channel.categories?.length ?? 0,
  };
}

function marshalXytaStyleChannel(channel) {
  if (channel?.values == null) {
    return { present: false, values_f64: new Float64Array() };
  }
  return {
    present: true,
    values_f64: Float64Array.from(channel.values, Number),
  };
}

export function marshalXytaTraceObs(trace, figure, xDomain, yDomain, polar) {
  const style = trace.style ?? {};
  const kindName = String(trace.kind ?? "");
  const { hexbinColormapPlane, hexbinRgbaPlaneReady } = xytaHexbinPlaneObservations(trace);
  const dispatch = sceneXytaTraceDispatchPlan({
    kind: kindName,
    polar,
    useDensity: kindName === "scatter" && scatterUsesDensity(trace),
    hexbinColormapPlane,
    hexbinRgbaPlaneReady,
    ribbonColor2Class: COLOR2_CLASS_TO_CODE[classifyRibbonColor2(trace)] ?? 4,
    meshPaintPlane: meshPacksPaintPlane(trace),
    scatterPaintPlane: scatterPacksPaintPlane(trace),
  });
  const nan = Number.NaN;
  const domainX0 = dispatch.packDensity ? Number(xDomain[0]) : nan;
  const domainX1 = dispatch.packDensity ? Number(xDomain[1]) : nan;
  const domainY0 = dispatch.packDensity ? Number(yDomain[0]) : nan;
  const domainY1 = dispatch.packDensity ? Number(yDomain[1]) : nan;
  let pointCount = 0;
  if (kindName === "hexbin") pointCount = trace.x?.length ?? trace.count ?? 0;
  else if (kindName === "ribbon") pointCount = trace.count ?? trace.x0?.length ?? 0;
  else if (kindName === "triangle_mesh") pointCount = trace.x0?.length ?? trace.count ?? 0;
  else if (kindName === "scatter") pointCount = trace.x?.length ?? trace.count ?? 0;
  const colormap = style.colormap;
  let styleColormapMode = 0;
  let styleColormapNamed = "";
  let styleColormapStops = new Uint8Array();
  if (typeof colormap === "string") {
    styleColormapMode = 1;
    styleColormapNamed = colormap;
  } else if (colormap != null) {
    styleColormapMode = 2;
    try {
      const stops = [];
      for (const stop of colormap) {
        stops.push(Number(stop[0]), Number(stop[1]), Number(stop[2]));
      }
      styleColormapStops = new Uint8Array(stops);
    } catch {
      styleColormapStops = new Uint8Array();
    }
  }
  const shape = heatmapGridShape(trace);
  const hasGridShape = shape != null && shape.length === 2;
  const gridShapeRows = hasGridShape ? Number(shape[0]) : 0;
  const gridShapeCols = hasGridShape ? Number(shape[1]) : 0;
  const gridBytes = trace.grid == null ? new Uint8Array() : packXyTaGrid(trace.grid);
  const gridValues = gridBytes.length
    ? new Float64Array(gridBytes.buffer, gridBytes.byteOffset, gridBytes.length / 8)
    : new Float64Array();
  const rgbaU8 = trace.rgba == null ? new Uint8Array() : packXyTaRgba(trace.rgba);
  const rgbaGridBytes = trace.rgba_grid == null ? new Uint8Array() : packXyTaRgbaGrid(trace.rgba_grid);
  const rgbaGridF64 = rgbaGridBytes.length
    ? new Float64Array(rgbaGridBytes.buffer, rgbaGridBytes.byteOffset, rgbaGridBytes.length / 8)
    : new Float64Array();
  // Rust owns ABI 323's complete-record capacity admission. Both hosts marshal
  // the same observations without duplicating its source-plane cutoff.
  const xValues = trace.x == null ? new Float64Array() : asF64Array(trace.x, "x");
  const yValues = trace.y == null ? new Float64Array() : asF64Array(trace.y, "y");
  const styleChannels = trace.style_channels ?? {};
  const packedFill = packXyTaFillOpacity(style);
  return {
    trace_id: Number(trace.id ?? 0) >>> 0,
    dispatch,
    domain_x0: domainX0,
    domain_x1: domainX1,
    domain_y0: domainY0,
    domain_y1: domainY1,
    point_count: pointCount,
    fallback_color: traceStyleColorDefault(trace),
    style_color: style.color ?? null,
    style_stroke: style.stroke ?? null,
    style_stroke_width: Number(style.stroke_width ?? 0),
    has_style_stroke_width: Object.hasOwn(style, "stroke_width"),
    style_opacity: Object.hasOwn(style, "opacity") ? Number(style.opacity) : Number.NaN,
    has_style_opacity: Object.hasOwn(style, "opacity"),
    style_fill_opacity: packedFill.flags ? packedFill.value : Number.NaN,
    has_style_fill_opacity: packedFill.flags !== 0,
    style_truecolor: Boolean(style.truecolor),
    style_domain: style.domain ?? null,
    style_colormap_mode: styleColormapMode,
    style_colormap_named: styleColormapNamed,
    style_colormap_stops: styleColormapStops,
    grid_shape_rows: gridShapeRows,
    grid_shape_cols: gridShapeCols,
    has_grid_shape: hasGridShape,
    grid_values: gridValues,
    rgba_u8: rgbaU8,
    rgba_grid_f64: rgbaGridF64,
    x_values: xValues,
    y_values: yValues,
    color_ch: marshalXytaColorChannel(trace.color_ch),
    stroke_ch: marshalXytaColorChannel(trace.stroke_ch),
    color2_ch: marshalXytaColorChannel(trace.color2_ch),
    opacity_ch: marshalXytaStyleChannel(styleChannels.opacity),
    artist_alpha_ch: marshalXytaStyleChannel(styleChannels.artist_alpha),
    stroke_width_ch: marshalXytaStyleChannel(styleChannels.stroke_width),
  };
}

function marshalXyTaTraceRecord(trace, traceIndex, figure, xDomain, yDomain, polar) {
  const obs = marshalXytaTraceObs(trace, figure, xDomain, yDomain, polar);
  const materialized = sceneXytaTraceObservationsMaterialize(obs);
  return sceneXytaTracePack({
    traceId: materialized.traceId,
    packHeatmap: materialized.packHeatmap,
    packHexbinColormap: materialized.packHexbinColormap,
    packHexbinRgba: materialized.packHexbinRgba,
    packRibbonEnds: materialized.packRibbonEnds,
    packMeshFaces: materialized.packMeshFaces,
    packScatterPaint: materialized.packScatterPaint,
    packDensity: materialized.packDensity,
    gridShapeRows: materialized.gridShapeRows,
    gridShapeCols: materialized.gridShapeCols,
    hasGridShape: materialized.hasGridShape,
    hasGrid: materialized.hasGrid,
    hasRgba: materialized.hasRgba,
    hasRgbaGrid: materialized.hasRgbaGrid,
    truecolor: materialized.truecolor,
    hasCmapDomain: materialized.hasCmapDomain,
    cmapLo: materialized.cmapLo,
    cmapHi: materialized.cmapHi,
    hasColorCh: materialized.hasColorCh,
    hasStyleColor: materialized.hasStyleColor,
    hasOpacity: materialized.hasOpacity,
    hasFillOpacity: materialized.hasFillOpacity,
    opacity: materialized.opacity,
    fillOpacity: materialized.fillOpacity,
    domainX0: materialized.domainX0,
    domainX1: materialized.domainX1,
    domainY0: materialized.domainY0,
    domainY1: materialized.domainY1,
    cmapFlags: materialized.cmapFlags,
    rows: materialized.rows,
    cols: materialized.cols,
    grid: materialized.grid,
    rgba: materialized.rgba,
    rgbaGrid: materialized.rgbaGrid,
    x: materialized.x,
    y: materialized.y,
    meanRgba: materialized.meanRgba,
    idx: materialized.idx,
    lut: materialized.lut,
    cmap: materialized.cmap,
    stops: materialized.stops,
    colorCh: materialized.colorCh,
    styleColor: materialized.styleColor,
  });
}

function packXyTa(figure, xDomain, yDomain) {
  const traces = figure.traces ?? [];
  const records = [new Uint8Array(16)];
  const header = new DataView(records[0].buffer);
  records[0].set(new TextEncoder().encode("XYTA"), 0);
  header.setUint32(4, 1, true);
  header.setUint32(8, traces.length, true);
  const figurePlan = sceneXytaFigurePlan({ polar: figure.coords === "polar" });
  const polar = figurePlan.polar;
  for (const [traceIndex, trace] of traces.entries()) {
    records.push(marshalXyTaTraceRecord(trace, traceIndex, figure, xDomain, yDomain, polar));
  }
  return concatBytes(records);
}

function unpackXyTt(blob) {
  if (blob.length < 16 || blob[0] !== 88 || blob[1] !== 89 || blob[2] !== 84 || blob[3] !== 84) {
    throw new RangeError("invalid scene trace attach packing");
  }
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  if (view.getUint32(4, true) !== 1) throw new RangeError("invalid scene trace attach facts version");
  const nTraces = view.getUint32(8, true);
  let at = 16;
  const attached = [];
  for (let i = 0; i < nTraces; i += 1) {
    if (blob[at] !== 88 || blob[at + 1] !== 89 || blob[at + 2] !== 84 || blob[at + 3] !== 79) {
      throw new RangeError("invalid scene trace attach packing");
    }
    const fillRgba = Array.from(blob.subarray(at + 8, at + 12));
    const strokeRgba = Array.from(blob.subarray(at + 12, at + 16));
    const strokeWidth = view.getFloat64(at + 16, true);
    const diameter = view.getFloat64(at + 24, true);
    const symbol = view.getUint16(at + 32, true);
    const legendKind = blob[at + 34];
    const legendInclude = blob[at + 35] !== 0;
    const legendSymbol = view.getUint16(at + 36, true);
    const authoredStep = view.getUint16(at + 38, true);
    const factBits = view.getUint32(at + 40, true);
    const dashCount = view.getUint32(at + 44, true);
    const linecap = blob[at + 48];
    const hasMarker = blob[at + 49];
    const hasGradient = blob[at + 50];
    const markerLen = view.getUint32(at + 52, true);
    const gradientLen = view.getUint32(at + 56, true);
    const hexDx = view.getFloat64(at + 60, true);
    const hexDy = view.getFloat64(at + 68, true);
    const heatmapLen = view.getUint32(at + 160, true);
    const densityLen = view.getUint32(at + 164, true);
    const gridRows = view.getUint32(at + 168, true);
    const gridCols = view.getUint32(at + 172, true);
    const rewriteX0 = view.getFloat64(at + 176, true);
    const rewriteX1 = view.getFloat64(at + 184, true);
    const rewriteY0 = view.getFloat64(at + 192, true);
    const rewriteY1 = view.getFloat64(at + 200, true);
    at += 208;
    let dash = null;
    if (dashCount) {
      dash = [];
      for (let j = 0; j < dashCount; j += 1) {
        dash.push(view.getFloat64(at, true));
        at += 8;
      }
    }
    const marker = blob.subarray(at, at + markerLen);
    at += markerLen;
    const gradient = blob.subarray(at, at + gradientLen);
    at += gradientLen;
    const heatmap = blob.subarray(at, at + heatmapLen);
    at += heatmapLen;
    const density = blob.subarray(at, at + densityLen);
    at += densityLen;
    attached.push({
      fillRgba, strokeRgba, strokeWidth, diameter, symbol, legendKind, legendInclude, legendSymbol,
      authoredStep, factBits, hexDx, hexDy,
      dash,
      linecap: linecap === XYTO_LINECAP_NONE ? null : linecap,
      markerPath: hasMarker && marker.length ? unpackMarkerBlob(marker) : null,
      fillGradient: hasGradient && gradient.length ? unpackGradientBlob(gradient) : null,
      heatmap: heatmapLen ? heatmap : new Uint8Array(),
      density: densityLen ? density : new Uint8Array(),
      gridRows,
      gridCols,
      packX: densityLen ? [rewriteX0, rewriteX1] : null,
      packY: densityLen ? [rewriteY0, rewriteY1] : null,
    });
  }
  if (at !== blob.length) throw new RangeError("invalid scene trace attach packing");
  return attached;
}

function raiseTraceAttach(code, index, figure) {
  const trace = figure.traces?.[index];
  if (code === -5) throw new RangeError("Scene v12 heatmap requires a rows x cols grid_shape");
  if (code === -6) throw new RangeError("Scene v12 heatmap requires a positive grid_shape");
  if (code === -7) throw new RangeError("heatmap Scene v12 compilation requires a scalar grid");
  if (code === -8) throw new RangeError("Scene v12 heatmap grid must match rows x cols");
  if (code === -9) throw new RangeError("Scene v12 does not yet encode missing-data breaks or nonfinite coordinates");
  if (code === -10) throw new RangeError("Scene heatmap RGBA plane must match rows x cols");
  if (code === -11) throw new RangeError("Scene heatmap truecolor requires four RGBA planes");
  if (code === -12) {
    const label = trace?.kind === "scatter" ? "density" : "heatmap";
    throw new RangeError(`Scene ${label} colormap requires RGB stops`);
  }
  if (code === -13) throw new RangeError("Scene density columns must have equal length");
  if (code === -14) throw new RangeError("Scene density mean-color source is invalid");
  if (code === -2) throw new RangeError("invalid scene trace attach facts version");
  throw new RangeError("invalid scene trace attach packing");
}

function packTraceAttach(compiled, attach) {
  const compiledBytes = compiled instanceof Uint8Array ? compiled : new Uint8Array();
  const attachBytes = attach instanceof Uint8Array ? attach : new Uint8Array();
  let capacity = Math.max(65536, compiledBytes.length + attachBytes.length + 32 + 512 * 384 * 5 + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xyScenePackTraceAttach(
      compiledBytes.length ? u8Ptr(compiledBytes) : 0,
      BigInt(compiledBytes.length),
      attachBytes.length ? u8Ptr(attachBytes) : 0,
      BigInt(attachBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code < 0) {
      const index = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      const error = new RangeError("invalid scene trace attach packing");
      error.code = code;
      error.index = index;
      throw error;
    }
    return out.subarray(0, code);
  }
  const error = new RangeError("invalid scene trace attach packing");
  error.code = -4;
  error.index = 0;
  throw error;
}

function packXyCl(figure) {
  const traces = figure.traces ?? [];
  const figurePlan = sceneXyclFigurePlan({ polar: figure.coords === "polar" });
  const coords = figurePlan.polar ? 1 : 0;
  const records = [new Uint8Array(16)];
  const header = new DataView(records[0].buffer);
  records[0][0] = 88; records[0][1] = 89; records[0][2] = 67; records[0][3] = 76; // XYCL
  header.setUint32(4, 1, true);
  header.setUint32(8, traces.length, true);
  for (const trace of traces) {
    const kind = new TextEncoder().encode(String(trace.kind ?? ""));
    // XYCL prefix byte 3 bit 0: `base` carries graph edge-end triples (#33).
    const ends = trace.style_channels?.edge_ends;
    const edgeEnds = ends?.values != null && String(trace.kind) === "segments" && coords === 0;
    const base = edgeEnds ? ends.values : trace.base;
    const cols = [trace.x, trace.y, trace.x0, trace.y0, trace.x1, trace.y1, base].map((column) => {
      if (column == null || column.length === 0) return new Uint8Array();
      const arr = asF64Array(column, "trace column");
      return new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
    });
    const prefix = new Uint8Array(48);
    const view = new DataView(prefix.buffer);
    view.setUint16(0, kind.length, true);
    prefix[2] = coords;
    prefix[3] = edgeEnds ? 1 : 0;
    view.setBigUint64(8, asU64(Number(trace.id), "stableIds value"), true);
    view.setUint32(16, cols[0].length / 8, true);
    view.setUint32(20, cols[1].length / 8, true);
    view.setUint32(24, cols[2].length / 8, true);
    view.setUint32(28, cols[3].length / 8, true);
    view.setUint32(32, cols[4].length / 8, true);
    view.setUint32(36, cols[5].length / 8, true);
    view.setUint32(40, cols[6].length / 8, true);
    records.push(prefix, kind, ...cols);
  }
  return concatBytes(records);
}

function raiseTraceRows(code, index) {
  if (code === -5) throw new RangeError("Scene v12 does not yet encode missing-data breaks or nonfinite coordinates");
  if (code === -6) throw new RangeError("Scene v12 does not support product kind");
  if (code === -1) throw new RangeError("invalid scene trace packing");
  if (code === -2) throw new RangeError("invalid scene trace column facts version");
  const error = new RangeError("invalid scene trace column packing");
  error.code = code;
  error.index = index;
  throw error;
}

function packTraceRows(attached, columns) {
  const packed = packTraceRowBytes(attached, columns);
  return decodePackedRows(packed, packed.length / 56);
}

function packXyNm(traces, figure = null) {
  if (figure != null) {
    sceneXynmFigurePlan({ showLegend: figureShowLegend(figure) !== false });
  }
  const records = [new Uint8Array(16)];
  const header = new DataView(records[0].buffer);
  records[0][0] = 88; records[0][1] = 89; records[0][2] = 78; records[0][3] = 77; // XYNM
  header.setUint32(4, 1, true);
  header.setUint32(8, traces.length, true);
  for (const trace of traces) {
    const raw = encodeUtf8(trace.name == null ? "" : String(trace.name));
    const prefix = new Uint8Array(2);
    new DataView(prefix.buffer).setUint16(0, raw.length, true);
    records.push(prefix, raw);
  }
  return concatBytes(records);
}

function unpackXySd(blob) {
  if (blob.length < 16 || blob[0] !== 88 || blob[1] !== 89 || blob[2] !== 83 || blob[3] !== 68) {
    throw new RangeError("invalid scene sidecar packing");
  }
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  if (view.getUint32(4, true) !== 1) throw new RangeError("invalid scene sidecar facts version");
  const nTraces = view.getUint32(8, true);
  let at = 16;
  const styles = [];
  const dashes = [];
  const linecaps = [];
  const markerPaths = [];
  const fillGradients = [];
  const planes = [];
  const legend = [];
  for (let i = 0; i < nTraces; i += 1) {
    if (at + 48 > blob.length) throw new RangeError("invalid scene sidecar packing");
    const fillRgba = Array.from(blob.subarray(at, at + 4));
    const strokeRgba = Array.from(blob.subarray(at + 4, at + 8));
    const strokeWidth = view.getFloat64(at + 8, true);
    const linecap = blob[at + 16];
    const legendKind = blob[at + 17];
    const legendSymbol = view.getUint16(at + 18, true);
    const dashLen = view.getUint32(at + 20, true);
    const markerLen = view.getUint32(at + 24, true);
    const gradientLen = view.getUint32(at + 28, true);
    const planeLen = view.getUint32(at + 32, true);
    const nameLen = view.getUint32(at + 36, true);
    at += 48;
    if (at + dashLen + markerLen + gradientLen + planeLen + nameLen > blob.length) {
      throw new RangeError("invalid scene sidecar packing");
    }
    let dash = null;
    if (dashLen) {
      dash = [];
      for (let j = 0; j < dashLen / 8; j += 1) {
        dash.push(view.getFloat64(at + j * 8, true));
      }
    }
    at += dashLen;
    const marker = blob.subarray(at, at + markerLen);
    at += markerLen;
    const gradient = blob.subarray(at, at + gradientLen);
    at += gradientLen;
    const plane = blob.subarray(at, at + planeLen);
    at += planeLen;
    const name = blob.subarray(at, at + nameLen);
    at += nameLen;
    styles.push({ fillRgba, strokeRgba, strokeWidth });
    dashes.push(dash);
    linecaps.push(linecap === XYTO_LINECAP_NONE ? null : linecap);
    markerPaths.push(marker.length ? unpackMarkerBlob(marker) : null);
    fillGradients.push(gradient.length ? unpackGradientBlob(gradient) : null);
    if (plane.length) planes.push(Uint8Array.from(plane));
    if (name.length) {
      legend.push({
        styleRef: i,
        kind: legendKind,
        symbol: legendSymbol,
        label: new TextDecoder().decode(name),
      });
    }
  }
  if (at !== blob.length) throw new RangeError("invalid scene sidecar packing");
  return { styles, dashes, linecaps, markerPaths, fillGradients, planes, legend };
}

function raiseTraceSidecars(code, index) {
  if (code === -2) throw new RangeError("invalid scene sidecar facts version");
  const error = new RangeError("invalid scene sidecar packing");
  error.code = code;
  error.index = index;
  throw error;
}

function packTraceSidecars(attached, names) {
  const attachedBytes = attached instanceof Uint8Array ? attached : new Uint8Array();
  const namesBytes = names instanceof Uint8Array ? names : new Uint8Array();
  let capacity = Math.max(65536, attachedBytes.length + namesBytes.length + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xyScenePackTraceSidecars(
      attachedBytes.length ? u8Ptr(attachedBytes) : 0,
      BigInt(attachedBytes.length),
      namesBytes.length ? u8Ptr(namesBytes) : 0,
      BigInt(namesBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code < 0) {
      const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      raiseTraceSidecars(code, failing);
    }
    return out.subarray(0, code);
  }
  raiseTraceSidecars(-4, 0);
}

function packStyleSidecars(sidecars, annotations) {
  const sidecarBytes = sidecars instanceof Uint8Array ? sidecars : new Uint8Array();
  const annotationBytes = annotations instanceof Uint8Array ? annotations : new Uint8Array();
  let capacity = Math.max(65536, sidecarBytes.length + annotationBytes.length + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xyScenePackStyleSidecars(
      sidecarBytes.length ? u8Ptr(sidecarBytes) : 0,
      BigInt(sidecarBytes.length),
      annotationBytes.length ? u8Ptr(annotationBytes) : 0,
      BigInt(annotationBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code < 0) {
      const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      const error = new RangeError(code === -2 ? "invalid scene style sidecar facts version" : "invalid scene style sidecar packing");
      error.code = code;
      error.index = failing;
      throw error;
    }
    return out.subarray(0, code);
  }
  const error = new RangeError("invalid scene style sidecar packing");
  error.code = -4;
  error.index = 0;
  throw error;
}

function spliceAnnotations(rows, sidecars, annotations) {
  const rowBytes = rows instanceof Uint8Array ? rows : new Uint8Array();
  const sidecarBytes = sidecars instanceof Uint8Array ? sidecars : new Uint8Array();
  const annotationBytes = annotations instanceof Uint8Array ? annotations : new Uint8Array();
  let capacity = Math.max(65536, rowBytes.length + sidecarBytes.length + annotationBytes.length + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xySceneSpliceAnnotations(
      rowBytes.length ? u8Ptr(rowBytes) : 0,
      BigInt(rowBytes.length),
      sidecarBytes.length ? u8Ptr(sidecarBytes) : 0,
      BigInt(sidecarBytes.length),
      annotationBytes.length ? u8Ptr(annotationBytes) : 0,
      BigInt(annotationBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code < 0) {
      const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      const error = new RangeError(code === -2 ? "invalid scene annotation splice version" : "invalid scene annotation splice packing");
      error.code = code;
      error.index = failing;
      throw error;
    }
    return out.subarray(0, code);
  }
  const error = new RangeError("invalid scene annotation splice packing");
  error.code = -4;
  error.index = 0;
  throw error;
}

function encodeAssembled(xyas, chrome, extras, { viewport, xAxis, yAxis }) {
  if (!Array.isArray(viewport) || viewport.length !== 2) {
    throw new RangeError("viewport must contain two values");
  }
  const xyasBytes = xyas instanceof Uint8Array ? xyas : new Uint8Array();
  const chromeBytes = chrome instanceof Uint8Array ? chrome : new Uint8Array();
  const extrasBytes = extras instanceof Uint8Array ? extras : new Uint8Array();
  const xd = axisDescriptor(xAxis, "xAxis");
  const yd = axisDescriptor(yAxis, "yAxis");
  let capacity = Math.max(65536, xyasBytes.length + chromeBytes.length + extrasBytes.length + 4096);
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xySceneEncodeAssembled(
      xyasBytes.length ? u8Ptr(xyasBytes) : 0,
      BigInt(xyasBytes.length),
      chromeBytes.length ? u8Ptr(chromeBytes) : 0,
      BigInt(chromeBytes.length),
      extrasBytes.length ? u8Ptr(extrasBytes) : 0,
      BigInt(extrasBytes.length),
      Number(viewport[0]),
      Number(viewport[1]),
      ...xd,
      ...yd,
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code < 0) {
      const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      const error = new RangeError(code === -2 ? "invalid scene encode assembled version" : "invalid canonical scene batch");
      error.code = code;
      error.index = failing;
      throw error;
    }
    return out.subarray(0, code);
  }
  const error = new RangeError("invalid canonical scene batch");
  error.code = -4;
  error.index = 0;
  throw error;
}

function encodeAssembledFromSidecars(xyas, chromeFacts, xysd, polar, extrasFacts) {
  const xyasBytes = xyas instanceof Uint8Array ? xyas : new Uint8Array();
  const chromeBytes = chromeFacts instanceof Uint8Array ? chromeFacts : new Uint8Array();
  const xysdBytes = xysd instanceof Uint8Array ? xysd : new Uint8Array();
  const polarBytes = polar instanceof Uint8Array ? polar : new Uint8Array();
  const extrasBytes = extrasFacts instanceof Uint8Array ? extrasFacts : new Uint8Array();
  let capacity = Math.max(
    65536,
    xyasBytes.length + chromeBytes.length + xysdBytes.length + polarBytes.length + extrasBytes.length + 4096,
  );
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xySceneEncodeAssembledFromSidecars(
      xyasBytes.length ? u8Ptr(xyasBytes) : 0,
      BigInt(xyasBytes.length),
      chromeBytes.length ? u8Ptr(chromeBytes) : 0,
      BigInt(chromeBytes.length),
      xysdBytes.length ? u8Ptr(xysdBytes) : 0,
      BigInt(xysdBytes.length),
      polarBytes.length ? u8Ptr(polarBytes) : 0,
      BigInt(polarBytes.length),
      extrasBytes.length ? u8Ptr(extrasBytes) : 0,
      BigInt(extrasBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code === -2) throw new RangeError("invalid scene chrome facts version");
    if (code === -5) throw new RangeError("invalid canonical scene plot layout");
    if (code === -7) throw new RangeError("Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content");
    if (code === -8) throw new RangeError("Scene v12 primary legends are static; toggle and highlight must be false");
    if (code === -9) throw new RangeError("Scene v12 does not support legend location");
    if (code === -10) throw new RangeError("legend font sizes must be finite and in [1, 1000]");
    if (code === -11) throw new RangeError("Scene v12 legends support only background, color, font_size, and title_font_size");
    if (code === -12) throw new RangeError("Scene v19 colorbars require literal bounded RGBA stops");
    if (code === -13) throw new RangeError("Scene v19 colorbars require a two-value domain and 2–16 stops");
    if (code === -14) throw new RangeError("Scene v19 colorbar side is right or bottom");
    if (code === -15) throw new RangeError("scene axis tick lists are limited to 200 values");
    if (code === -16) {
      const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      const error = new RangeError("invalid canonical scene batch");
      error.code = code;
      error.index = failing;
      throw error;
    }
    if (code === -20) throw new RangeError("Scene extras polar or paint envelope is invalid");
    if (code === -21) throw new RangeError("Scene style sidecar facts are invalid");
    if (code === -17 || code === -18 || code === -19) throw new RangeError("invalid scene extras packing");
    if (code < 0) throw new RangeError("invalid scene chrome packing");
    return out.subarray(0, code);
  }
  const error = new RangeError("invalid canonical scene batch");
  error.code = -4;
  error.index = 0;
  throw error;
}

function encodeProduct(
  compileFacts,
  attachFacts,
  names,
  columns,
  annotationFacts,
  styleRefBase,
  xDomain,
  yDomain,
  chromeFacts,
  polar,
  figureSupport,
) {
  const compileBytes = compileFacts instanceof Uint8Array ? compileFacts : new Uint8Array();
  const attachBytes = attachFacts instanceof Uint8Array ? attachFacts : new Uint8Array();
  const namesBytes = names instanceof Uint8Array ? names : new Uint8Array();
  const columnBytes = columns instanceof Uint8Array ? columns : new Uint8Array();
  const annotationBytes = annotationFacts instanceof Uint8Array ? annotationFacts : new Uint8Array();
  const chromeBytes = chromeFacts instanceof Uint8Array ? chromeFacts : new Uint8Array();
  const polarBytes = polar instanceof Uint8Array ? polar : new Uint8Array();
  const supportBytes = figureSupport instanceof Uint8Array ? figureSupport : new Uint8Array();
  let capacity = Math.max(
    65536,
    compileBytes.length
      + attachBytes.length
      + namesBytes.length
      + columnBytes.length
      + annotationBytes.length
      + chromeBytes.length
      + polarBytes.length
      + supportBytes.length
      + 32
      + 512 * 384 * 5
      + 4096,
  );
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const out = new Uint8Array(capacity);
    const code = xySceneEncodeProduct(
      compileBytes.length ? u8Ptr(compileBytes) : 0,
      BigInt(compileBytes.length),
      attachBytes.length ? u8Ptr(attachBytes) : 0,
      BigInt(attachBytes.length),
      namesBytes.length ? u8Ptr(namesBytes) : 0,
      BigInt(namesBytes.length),
      columnBytes.length ? u8Ptr(columnBytes) : 0,
      BigInt(columnBytes.length),
      annotationBytes.length ? u8Ptr(annotationBytes) : 0,
      BigInt(annotationBytes.length),
      styleRefBase >>> 0,
      Number(xDomain[0]),
      Number(xDomain[1]),
      Number(yDomain[0]),
      Number(yDomain[1]),
      chromeBytes.length ? u8Ptr(chromeBytes) : 0,
      BigInt(chromeBytes.length),
      polarBytes.length ? u8Ptr(polarBytes) : 0,
      BigInt(polarBytes.length),
      supportBytes.length ? u8Ptr(supportBytes) : 0,
      BigInt(supportBytes.length),
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -4) {
      capacity *= 2;
      continue;
    }
    if (code === -801) {
      const n = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
      throw new RangeError(new TextDecoder("utf-8", { fatal: true }).decode(out.subarray(4, 4 + n)));
    }
    if (code === -802) throw new RangeError("invalid scene figure support envelope");
    const failing = new DataView(out.buffer, out.byteOffset, 4).getUint32(0, true);
    const magnitude = Math.abs(code);
    if (code < 0 && magnitude >= 100) {
      const error = new RangeError("invalid product encode");
      error.code = -(magnitude % 100);
      error.index = failing;
      error.stage = Math.floor(magnitude / 100);
      throw error;
    }
    if (code === -2) throw new RangeError("invalid scene chrome facts version");
    if (code === -5) throw new RangeError("invalid canonical scene plot layout");
    if (code === -7) throw new RangeError("Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content");
    if (code === -8) throw new RangeError("Scene v12 primary legends are static; toggle and highlight must be false");
    if (code === -9) throw new RangeError("Scene v12 does not support legend location");
    if (code === -10) throw new RangeError("legend font sizes must be finite and in [1, 1000]");
    if (code === -11) throw new RangeError("Scene v12 legends support only background, color, font_size, and title_font_size");
    if (code === -12) throw new RangeError("Scene v19 colorbars require literal bounded RGBA stops");
    if (code === -13) throw new RangeError("Scene v19 colorbars require a two-value domain and 2–16 stops");
    if (code === -14) throw new RangeError("Scene v19 colorbar side is right or bottom");
    if (code === -15) throw new RangeError("scene axis tick lists are limited to 200 values");
    if (code === -16) {
      const error = new RangeError("invalid canonical scene batch");
      error.code = code;
      error.index = failing;
      throw error;
    }
    if (code === -20) throw new RangeError("Scene extras polar or paint envelope is invalid");
    if (code === -21) throw new RangeError("Scene style sidecar facts are invalid");
    if (code === -17 || code === -18 || code === -19) throw new RangeError("invalid scene extras packing");
    if (code < 0) throw new RangeError("invalid scene chrome packing");
    return out.subarray(0, code);
  }
  const error = new RangeError("invalid canonical scene batch");
  error.code = -4;
  error.index = 0;
  throw error;
}

function unpackXyAs(blob) {
  if (blob.length < 24 || blob[0] !== 88 || blob[1] !== 89 || blob[2] !== 65 || blob[3] !== 83) {
    throw new RangeError("invalid scene annotation splice packing");
  }
  const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
  if (view.getUint32(4, true) !== 1) throw new RangeError("invalid scene annotation splice version");
  const nStyles = view.getUint32(8, true);
  const nRows = view.getUint32(12, true);
  const xyadLen = view.getUint32(16, true);
  let at = 24;
  const need = nStyles * 16 + nRows * 56 + xyadLen;
  if (at + need > blob.length) throw new RangeError("invalid scene annotation splice packing");
  const styles = [];
  for (let i = 0; i < nStyles; i += 1) {
    styles.push({
      fillRgba: Array.from(blob.subarray(at, at + 4)),
      strokeRgba: Array.from(blob.subarray(at + 4, at + 8)),
      strokeWidth: view.getFloat64(at + 8, true),
    });
    at += 16;
  }
  const packed = blob.subarray(at, at + nRows * 56);
  at += nRows * 56;
  const xyad = blob.subarray(at, at + xyadLen);
  if (at + xyadLen !== blob.length) throw new RangeError("invalid scene annotation splice packing");
  const rows = nRows
    ? decodePackedRows(packed, nRows)
    : { kinds: [], stableIds: [], styleRefs: [], diameter: [], symbols: [], expansion: [], x0: [], y0: [], x1: [], y1: [] };
  return { styles, xyad, ...rows };
}

const LEGEND_ALLOWED_STYLE = new Set(["background", "color", "font_size", "title_font_size"]);

/** Legend style font sizes. Python `_legend_input` / XYCF observations read `style.get("font_size")` / `style.get("title_font_size")` only. */
export function legendStyleFontSizes(style) {
  const record = style ?? {};
  return {
    font_size: record.font_size,
    title_font_size: record.title_font_size,
  };
}

/** Chrome authored major ticks. Python `_pack_figure_chrome` reads `axis.get("tick_values")` only. */
export function axisTickValues(axis) {
  return (axis ?? {}).tick_values;
}

/** Axis scale name. Python `_axis_scale` reads `type` in {log,symlog}, else linear. */
export function axisScaleName(axis) {
  const scale = (axis ?? {}).type;
  return scale === "log" || scale === "symlog" ? scale : "linear";
}

/** Chrome authored minor ticks. Python `_pack_figure_chrome` reads `axis.get("minor_tick_values")` only. */
export function axisMinorTickValues(axis) {
  return (axis ?? {}).minor_tick_values;
}

/** Chrome tick-label anchor. Python `_scene_tick_anchor_code` reads `options.get("tick_label_anchor")` only. */
export function axisTickLabelAnchor(axis) {
  return (axis ?? {}).tick_label_anchor;
}

/** Chrome tick-label angle. Python `_pack_tick_collision` reads `axis.get("tick_label_angle")` only. */
export function axisTickLabelAngle(axis) {
  return (axis ?? {}).tick_label_angle;
}

/** Chrome tick-label min gap. Python `_pack_tick_collision` reads `axis.get("tick_label_min_gap")` only. */
export function axisTickLabelMinGap(axis) {
  return (axis ?? {}).tick_label_min_gap;
}

/** Chrome tick-label strategy. Python `_scene_tick_label_strategy` reads `tick_label_strategy` then `collision`. */
export function axisTickLabelStrategy(options) {
  const record = options ?? {};
  return record.tick_label_strategy ?? record.collision;
}

/** Chrome authored tick labels. Python `_pack_figure_chrome` reads `axis.get("tick_labels")` only. */
export function axisTickLabels(axis) {
  return (axis ?? {}).tick_labels;
}

/** Chrome axis minor style. Python `_pack_chrome_axis` reads `options.get("minor_style")` only. */
export function chromeAxisMinorStyle(options) {
  return (options ?? {}).minor_style;
}

/** Chrome axis tick sides. Python `_pack_chrome_axis` reads `options.get("tick_sides")` only. */
export function chromeAxisTickSides(options) {
  return (options ?? {}).tick_sides;
}

/** Chrome axis tick-label sides. Python `_pack_chrome_axis` reads `options.get("tick_label_sides")` only. */
export function chromeAxisTickLabelSides(options) {
  return (options ?? {}).tick_label_sides;
}

/** Chrome styles record. Python `_pack_figure_support` / XYEF observations read `chrome_styles` only. */
export function figureChromeStyles(figure) {
  return (figure ?? {}).chrome_styles;
}

/** Chrome custom-font observation. Python `_pack_figure_support` checks `"font-family" in style` only. */
export function chromeStyleHasFontFamily(style) {
  return Object.prototype.hasOwnProperty.call(style ?? {}, "font-family");
}

/** Chart root CSS class. Python `_pack_figure_support` reads `class_name` only. */
export function figureClassName(figure) {
  return (figure ?? {}).class_name;
}

/** Chart slot CSS classes. Python `_pack_figure_support` reads `class_names` only. */
export function figureClassNames(figure) {
  return (figure ?? {}).class_names;
}

/** Extra legends. Python `_pack_figure_support` reads `figure.extra_legends` only. */
export function figureExtraLegends(figure) {
  return (figure ?? {}).extra_legends;
}

/** Title options. Python `_pack_public_export_support` reads `title_options` only. */
export function figureTitleOptions(figure) {
  return (figure ?? {}).title_options;
}

/** Primary legend options. Python `_legend_input` / XYEF read `legend_options` only. */
export function figureLegendOptions(figure) {
  return (figure ?? {}).legend_options;
}

/** Colorbar options. Python `_colorbar_input` / XYEF read `colorbar_options` only. */
export function figureColorbarOptions(figure) {
  return (figure ?? {}).colorbar_options;
}

/** Legend visibility. Python `_legend_input` / XYTC read `show_legend` only. */
export function figureShowLegend(figure) {
  return (figure ?? {}).show_legend;
}

/** Axis option records. Python `_pack_figure_chrome` / polar / XYFS / XYEF read `axis_options` only. */
export function figureAxisOptions(figure) {
  return (figure ?? {}).axis_options;
}

/** XYCF tick kind. Python `_pack_figure_chrome` uses `figure._axis_kind(axis_id)`. */
export function chromeAxisTickKind(figure, axisId) {
  const kind = figure._axisKind(axisId);
  if (kind === "time") return 1;
  if (kind === "category") return 2;
  return 0;
}

/** Annotation CSS class. Python `_pack_figure_support` reads `annotation.get("class_name")` only. */
export function annotationClassName(annotation) {
  return (annotation ?? {}).class_name;
}

/** Chrome x-axis label. Python `_pack_figure_chrome` reads `figure.x_label` then `axis.get("label")`. */
export function figureXLabel(figure, xAxis) {
  return (figure ?? {}).x_label || (xAxis ?? {}).label;
}

/** Chrome y-axis label. Python `_pack_figure_chrome` reads `figure.y_label` then `axis.get("label")`. */
export function figureYLabel(figure, yAxis) {
  return (figure ?? {}).y_label || (yAxis ?? {}).label;
}

function sceneSideMask(values, name, axisId, allowed, sideCode) {
  if (values == null) return 1 << sideCode;
  for (const value of values) {
    if (!allowed.includes(value)) {
      throw new RangeError(`Scene v12 ${axisId} axis ${name} must contain only ${JSON.stringify(allowed)}`);
    }
  }
  return allowed.reduce((mask, candidate, index) => (
    values.includes(candidate) ? mask | (1 << index) : mask
  ), 0);
}

function marshalChromeAxis(axisId, options) {
  const style = { ...(options.style ?? {}) };
  const minor = { ...(options.minor_style ?? {}) };
  for (const [label, authored] of [["style", style], ["minor_style", minor]]) {
    const unsupported = Object.keys(authored).filter((key) => !AXIS_STYLE_KEYS.has(key));
    if (unsupported.length) {
      throw new RangeError(`Scene v12 does not yet encode ${axisId} axis ${label} keys`);
    }
  }
  const side = options.side ?? (axisId === "x" ? "bottom" : "left");
  const allowed = axisId === "x" ? ["bottom", "top"] : ["left", "right"];
  if (!allowed.includes(side)) throw new RangeError(`Scene v12 ${axisId} axis side is invalid`);
  const sideCode = side === allowed[0] ? 0 : 1;
  const marshalStyle = (src) => {
    const out = {};
    for (const key of [
      "grid_color", "grid_width", "grid_opacity", "axis_color", "axis_width",
      "tick_color", "tick_width", "tick_length", "tick_direction", "tick_label_color", "label_color",
    ]) {
      if (!Object.hasOwn(src, key)) continue;
      if (["grid_width", "axis_width", "tick_width", "tick_length"].includes(key)) out[key] = Number(src[key]);
      else if (key === "grid_opacity") out.grid_opacity = Number(src[key]);
      else out[key] = String(src[key]);
    }
    return out;
  };
  return {
    side_code: sideCode,
    tick_sides_mask: sceneSideMask(options.tick_sides, "tick_sides", axisId, allowed, sideCode),
    label_sides_mask: sceneSideMask(options.tick_label_sides, "tick_label_sides", axisId, allowed, sideCode),
    style: marshalStyle(style),
    minor_style: marshalStyle(minor),
  };
}

function packChromeFacts(figure, { width, height, margins = null, colorbarOk = true } = {}) {
  const axes = figureAxisOptions(figure) ?? {};
  const xa = axes.x ?? {};
  const ya = axes.y ?? {};
  const kindCodes = { linear: 0, log: 1, symlog: 2 };
  const tickKindCode = { linear: 0, time: 1, category: 2 };
  const [xLo, xHi] = figure._range("x");
  const [yLo, yHi] = figure._range("y");
  const pad = figure.padding;
  const hasPadding = Array.isArray(pad) && pad.length === 4;
  const figureStyle = figure.style ?? {};
  const legendOptions = { ...(figureLegendOptions(figure) ?? {}) };
  const legendStyle = { ...(legendOptions.style ?? {}) };
  const allowedLegend = new Set(["loc", "title", "ncols", "style", "highlight", "toggle"]);
  if (Object.keys(legendOptions).some((key) => !allowedLegend.has(key)) || Number(legendOptions.ncols ?? 1) !== 1) {
    throw new RangeError("Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content");
  }
  if (["toggle", "highlight"].some((key) => Object.hasOwn(legendOptions, key) && legendOptions[key] !== false)) {
    throw new RangeError("Scene v12 primary legends are static; toggle and highlight must be false");
  }
  if (Object.hasOwn(legendOptions, "loc") && !String(legendOptions.loc)) {
    throw new RangeError(`Scene v12 does not support legend location ${JSON.stringify(String(legendOptions.loc))}`);
  }
  const colorbar = colorbarOk ? figureColorbarOptions(figure) : null;
  let colorbarPayload = null;
  if (colorbar) {
    const packed = colorbarInput(figure);
    const view = new DataView(packed.buffer, packed.byteOffset, packed.byteLength);
    const flags = packed[8];
    const stopCount = view.getUint32(12, true);
    const tickCount = view.getUint32(16, true);
    const titleLength = view.getUint32(20, true);
    const stopsAt = 56;
    const ticksAt = stopsAt + stopCount * 12;
    const titleAt = ticksAt + tickCount * 8;
    const stops = Array.from({ length: stopCount }, (_, index) => {
      const at = stopsAt + index * 12;
      return [view.getFloat64(at, true), packed.slice(at + 8, at + 12)];
    });
    const ticks = Array.from(
      { length: tickCount },
      (_, index) => view.getFloat64(ticksAt + index * 8, true),
    );
    colorbarPayload = {
      domain_lo: view.getFloat64(24, true),
      domain_hi: view.getFloat64(32, true),
      stops,
      side_bottom: Boolean(flags & 1),
      invalid_side: false,
      minor_ticks: Boolean(flags & 4),
      title: optionalStr(new TextDecoder("utf-8", { fatal: true }).decode(
        packed.subarray(titleAt, titleAt + titleLength),
      )),
      text_rgba: packed.slice(40, 44),
      ticks: tickCount ? ticks : null,
    };
  }
  return sceneChromePack({
    width: Number(width),
    height: Number(height),
    show_legend: figureShowLegend(figure) !== false,
    colorbar_ok: Boolean(colorbarOk && colorbarPayload),
    polar: (figure.coords ?? "cartesian") === "polar",
    has_margins: margins != null,
    margins: margins == null ? [0, 0, 0, 0] : margins.map(Number),
    has_padding: hasPadding,
    padding: hasPadding ? pad.map(Number) : [0, 0, 0, 0],
    title: String(figure.title ?? ""),
    x_label: String(figureXLabel(figure, xa) ?? ""),
    y_label: String(figureYLabel(figure, ya) ?? ""),
    x_format: optionalStr(xa.format),
    y_format: optionalStr(ya.format),
    x_scale_kind: kindCodes[axisScaleName(xa)] ?? 0,
    y_scale_kind: kindCodes[axisScaleName(ya)] ?? 0,
    x_lo: Number(xLo),
    x_hi: Number(xHi),
    x_constant: Number(xa.constant ?? 1),
    y_lo: Number(yLo),
    y_hi: Number(yHi),
    y_constant: Number(ya.constant ?? 1),
    x_nonpositive_mask: (xa.nonpositive ?? "clip") === "mask" ? 1 : 0,
    y_nonpositive_mask: (ya.nonpositive ?? "clip") === "mask" ? 1 : 0,
    x_tick_kind: tickKindCode[figure._axisKind("x")] ?? 0,
    y_tick_kind: tickKindCode[figure._axisKind("y")] ?? 0,
    x_axis: marshalChromeAxis("x", xa),
    y_axis: marshalChromeAxis("y", ya),
    x_major: axisTickValues(xa) == null ? null : Array.from(axisTickValues(xa), Number),
    y_major: axisTickValues(ya) == null ? null : Array.from(axisTickValues(ya), Number),
    x_minor: Array.from(axisMinorTickValues(xa) ?? [], Number),
    y_minor: Array.from(axisMinorTickValues(ya) ?? [], Number),
    x_tick_labels: axisTickLabels(xa) == null ? null : Array.from(axisTickLabels(xa), String),
    y_tick_labels: axisTickLabels(ya) == null ? null : Array.from(axisTickLabels(ya), String),
    x_collision: {
      strategy: optionalStr(xa.tick_label_strategy),
      collision: optionalStr(xa.collision),
      anchor: optionalStr(xa.tick_label_anchor),
      min_gap: xa.tick_label_min_gap == null ? null : Number(xa.tick_label_min_gap),
      angle: xa.tick_label_angle == null ? null : Number(xa.tick_label_angle),
      tick_kind_category: figure._axisKind("x") === "category",
    },
    y_collision: {
      strategy: optionalStr(ya.tick_label_strategy),
      collision: optionalStr(ya.collision),
      anchor: optionalStr(ya.tick_label_anchor),
      min_gap: ya.tick_label_min_gap == null ? null : Number(ya.tick_label_min_gap),
      angle: ya.tick_label_angle == null ? null : Number(ya.tick_label_angle),
      tick_kind_category: figure._axisKind("y") === "category",
    },
    chart_background: optionalStr(figureStyle.background),
    plot_background: optionalStr(figureStyle["--chart-bg"]),
    legend: {
      unsupported_keys: Object.keys(legendOptions).some((key) => !allowedLegend.has(key)),
      toggle: Object.hasOwn(legendOptions, "toggle") && legendOptions.toggle !== false,
      highlight: Object.hasOwn(legendOptions, "highlight") && legendOptions.highlight !== false,
      loc: Object.hasOwn(legendOptions, "loc") ? String(legendOptions.loc) : null,
      title: optionalStr(typeof legendOptions.title === "boolean" ? String(legendOptions.title).toLowerCase() : legendOptions.title),
      ncols: Number(legendOptions.ncols ?? 1),
      unsupported_style: Object.keys(legendStyle).some((key) => !LEGEND_ALLOWED_STYLE.has(key)),
      font_size: legendStyle.font_size,
      title_font_size: legendStyle.title_font_size,
      color: optionalStr(legendStyle.color),
      background: optionalStr(legendStyle.background),
    },
    colorbar: colorbarPayload,
  });
}

/** XYEF resolved axis kind. Python `_pack_public_export_support` uses `figure._axis_kind(axis_id)`. */
export function xyEfResolvedKind(figure, axisId) {
  const kind = figure._axisKind(axisId);
  if (kind === "time") return 1;
  if (kind === "category") return 2;
  if (kind === "linear") return 0;
  return 255;
}

/** XYEF joined-fill observation. Python uses `style.get("joined_fill")` only. */
export function xyEfJoinedFill(style) {
  return Boolean((style ?? {}).joined_fill);
}

/** XYEF stroke-width-only observation. Python uses `style.get("stroke_width")` only. */
export function xyEfStrokeWidthOnly(style) {
  const record = style ?? {};
  return record.stroke_width != null && record.stroke == null;
}

/** Every trace belongs to a recorded graph mark: edge `segments` immediately
 * followed by node `scatter` (#33). Python `_graph_marks_only`; Rust re-verifies
 * the kinds (XYEP `FLAG_GRAPH_MARKS`). */
function graphMarksOnly(figure) {
  const metas = figure._graphMeta ?? [];
  const owned = [];
  for (const meta of metas) {
    const edge = meta.edge_trace;
    if (!Number.isInteger(edge) || meta.node_trace !== edge + 1) return false;
    owned.push(edge, edge + 1);
  }
  const n = (figure.traces ?? []).length;
  owned.sort((a, b) => a - b);
  return owned.length > 0 && owned.length === n && owned.every((v, i) => v === i);
}

function packPublicExportSupport(figure, { width = null, height = null } = {}) {
  const exportPlan = scenePublicExportFigurePlan({
    polar: (figure.coords ?? "cartesian") === "polar",
    hasChromeStyles: Boolean(figureChromeStyles(figure) && Object.keys(figureChromeStyles(figure)).length),
    hasTitleOptions: Boolean(figureTitleOptions(figure) && (Array.isArray(figureTitleOptions(figure)) ? figureTitleOptions(figure).length : figureTitleOptions(figure))),
  });
  const OBS_HAS_X = 1 << 0;
  const OBS_HAS_Y = 1 << 1;
  const OBS_X_FINITE = 1 << 2;
  const OBS_Y_FINITE = 1 << 3;
  const OBS_HAS_X0 = 1 << 4;
  const OBS_HAS_Y0 = 1 << 5;
  const OBS_HAS_X1 = 1 << 6;
  const OBS_HAS_Y1 = 1 << 7;
  const OBS_X0_FINITE = 1 << 8;
  const OBS_Y0_FINITE = 1 << 9;
  const OBS_X1_FINITE = 1 << 10;
  const OBS_Y1_FINITE = 1 << 11;
  const OBS_JOINED_FILL = 1 << 12;
  const OBS_HEATMAP_TRUECOLOR = 1 << 13;
  const OBS_HEATMAP_RGBA_GRID = 1 << 16;
  const OBS_HEATMAP_SHAPE_OK = 1 << 17;
  const OBS_HEATMAP_EXTENT_OK = 1 << 18;
  const OBS_HEATMAP_FINITE = 1 << 19;
  const OBS_STROKE_WIDTH_ONLY = 1 << 20;
  const OBS_COMPANION_XY_MATCH = 1 << 21;
  const OBS_COMPANION_AXES_MATCH = 1 << 22;
  const OBS_SYMBOL_NON_STRING = 1 << 23;
  const OBS_DENSITY_BLIT = 1 << 24;
  let flags = 0;
  if (width == null && !Number.isInteger(figure.width)) flags |= 1 << 0;
  if (height == null && !Number.isInteger(figure.height)) flags |= 1 << 1;
  if (exportPlan.hasChromeStyles) flags |= 1 << 2;
  const titleOptions = figureTitleOptions(figure);
  if (exportPlan.hasTitleOptions) flags |= 1 << 3;
  if (exportPlan.polar) flags |= 1 << 4;
  if (graphMarksOnly(figure)) flags |= 1 << 5;
  const styleKeys = Object.keys(figure.style ?? {});
  const legend = figureLegendOptions(figure) ?? {};
  const legendKeys = Object.keys(legend);
  const colorbar = figureColorbarOptions(figure) ?? {};
  const colorbarKeys = Object.keys(colorbar ?? {});
  const annotations = [...(figure.annotations ?? [])];
  const traces = [...(figure.traces ?? [])];
  const axisEntries = [];
  const seenAxes = new Set();
  const addAxis = (axisId, options) => {
    if (seenAxes.has(axisId)) return;
    seenAxes.add(axisId);
    axisEntries.push([axisId, options ?? {}]);
  };
  const axes = figureAxisOptions(figure) ?? {};
  if (axes && typeof axes === "object") {
    for (const [axisId, options] of Object.entries(axes)) addAxis(axisId, options);
  }
  addAxis("x", axes.x ?? {});
  addAxis("y", axes.y ?? {});

  const parts = [new Uint8Array(36)];
  const header = new DataView(parts[0].buffer);
  parts[0].set([88, 89, 69, 70]);
  header.setUint32(4, 1, true);
  header.setUint32(8, flags, true);
  header.setUint32(12, styleKeys.length, true);
  header.setUint32(16, legendKeys.length, true);
  header.setUint32(20, colorbarKeys.length, true);
  header.setUint32(24, axisEntries.length, true);
  header.setUint32(28, annotations.length, true);
  header.setUint32(32, traces.length, true);
  for (const key of styleKeys) parts.push(encodeExportKey(key));
  for (const key of legendKeys) parts.push(encodeExportKey(key));
  for (const key of colorbarKeys) parts.push(encodeExportKey(key));

  for (const [axisId, options] of axisEntries) {
    const axisCode = axisId === "x" ? 0 : axisId === "y" ? 1 : 255;
    const authored = options.type;
    const authoredCode = authored == null ? 0 : authored === "linear" ? 1 : authored === "log" ? 2 : authored === "symlog" ? 3 : 255;
    const resolvedCode = xyEfResolvedKind(figure, axisId);
    const domain = figure._axisDomain(axisId);
    const side = options.side;
    const sideCode = side == null ? 0 : side === "bottom" ? 1 : side === "left" ? 2 : side === "top" ? 3 : side === "right" ? 4 : 255;
    const keys = significantExportKeys(options);
    const axis = new Uint8Array(8);
    axis[0] = axisCode;
    axis[1] = resolvedCode;
    axis[2] = authoredCode;
    axis[3] = Number(domain != null);
    axis[4] = sideCode;
    axis[5] = 0;
    axis[6] = keys.length & 0xff;
    axis[7] = (keys.length >> 8) & 0xff;
    parts.push(axis);
    for (const key of keys) parts.push(encodeExportKey(key));
  }

  for (const annotation of annotations) {
    if (annotation == null || typeof annotation !== "object" || Array.isArray(annotation)) {
      parts.push(new Uint8Array(8));
      parts[parts.length - 1][0] = 1;
      continue;
    }
    const kindBytes = encodeUtf8(annotation.kind == null ? "" : String(annotation.kind)).slice(0, 256);
    const fields = Object.keys(annotation);
    if (annotationHasMarkup(annotation) && !fields.includes("markup")) fields.push("markup");
    const row = new Uint8Array(8);
    const view = new DataView(row.buffer);
    view.setUint16(4, kindBytes.length, true);
    view.setUint16(6, fields.length, true);
    parts.push(row, kindBytes);
    for (const key of fields) parts.push(encodeExportKey(key));
  }

  for (const [traceIndex, trace] of traces.entries()) {
    const style = trace.style ?? {};
    const exportDispatch = scenePublicExportTraceDispatchPlan({
      kind: String(trace.kind ?? ""),
      polar: exportPlan.polar,
      useDensity: scatterUsesDensity(trace),
    });
    const opacity = Number(style.opacity ?? 1);
    if (!Number.isFinite(opacity) || opacity < 0 || opacity > 1) {
      throw new RangeError("trace opacity must be finite and in [0, 1]");
    }
    const prev = traceIndex ? traces[traceIndex - 1] : null;
    const prev2 = traceIndex >= 2 ? traces[traceIndex - 2] : null;
    const prev3 = traceIndex >= 3 ? traces[traceIndex - 3] : null;
    const xv = exportColumn(trace, "x");
    const yv = exportColumn(trace, "y");
    const x0 = exportColumn(trace, "x0");
    const y0 = exportColumn(trace, "y0");
    const x1 = exportColumn(trace, "x1");
    const y1 = exportColumn(trace, "y1");
    let obs = 0;
    if (xv != null) obs |= OBS_HAS_X;
    if (yv != null) obs |= OBS_HAS_Y;
    if (exportColumnFinite(xv)) obs |= OBS_X_FINITE;
    if (exportColumnFinite(yv)) obs |= OBS_Y_FINITE;
    if (x0 != null) obs |= OBS_HAS_X0;
    if (y0 != null) obs |= OBS_HAS_Y0;
    if (x1 != null) obs |= OBS_HAS_X1;
    if (y1 != null) obs |= OBS_HAS_Y1;
    if (exportColumnFinite(x0)) obs |= OBS_X0_FINITE;
    if (exportColumnFinite(y0)) obs |= OBS_Y0_FINITE;
    if (exportColumnFinite(x1)) obs |= OBS_X1_FINITE;
    if (exportColumnFinite(y1)) obs |= OBS_Y1_FINITE;
    if (xyEfJoinedFill(style)) obs |= OBS_JOINED_FILL;
    let heatmapRows = 0, heatmapCols = 0, heatmapValues = 0;
    if (trace.kind === "heatmap") {
      if (style.truecolor) obs |= OBS_HEATMAP_TRUECOLOR;
      if (trace.rgba_grid != null) obs |= OBS_HEATMAP_RGBA_GRID;
      const shape = heatmapGridShape(trace);
      const grid = exportColumn(trace, "grid");
      const hx = xv, hy = yv;
      if (Array.isArray(shape) && shape.length === 2) {
        const rows = Number(shape[0]), cols = Number(shape[1]);
        if (sceneHeatmapShapeAdmit(rows, cols)) {
          heatmapRows = rows;
          heatmapCols = cols;
          obs |= OBS_HEATMAP_SHAPE_OK;
          if (grid != null) heatmapValues = grid.length;
          if (
            hx != null && hy != null && hx.length === 2 && hy.length === 2
            && sceneHeatmapExtentAdmit(Number(hx[0]), Number(hx[1]), Number(hy[0]), Number(hy[1]))
          ) obs |= OBS_HEATMAP_EXTENT_OK;
          if (grid != null && exportColumnFinite(grid)) obs |= OBS_HEATMAP_FINITE;
        }
      }
    }
    if (xyEfStrokeWidthOnly(style)) obs |= OBS_STROKE_WIDTH_ONLY;
    const prevX1 = prev && exportColumn(prev, "x1");
    const prevY1 = prev && exportColumn(prev, "y1");
    if (prev != null && xv != null && yv != null && prevX1 != null && prevY1 != null && exportArraysEqual(xv, prevX1) && exportArraysEqual(yv, prevY1)) {
      obs |= OBS_COMPANION_XY_MATCH;
    }
    if (prev != null && (trace.x_axis ?? "x") === (prev.x_axis ?? "x") && (trace.y_axis ?? "y") === (prev.y_axis ?? "y")) {
      obs |= OBS_COMPANION_AXES_MATCH;
    }
    let symbol = style.symbol ?? "circle";
    if (typeof symbol !== "string") {
      obs |= OBS_SYMBOL_NON_STRING;
      symbol = "";
    }
    if (exportDispatch.packDensityBlit) {
      obs |= OBS_DENSITY_BLIT;
    }
    const role = style.role == null ? "" : String(style.role);
    const reduce = style.reduce == null ? "" : String(style.reduce);
    let hexDx = Number.NaN, hexDy = Number.NaN;
    if (exportDispatch.packHexbinPitch) {
      const pitch = hexbinStylePitch(style);
      hexDx = Number(pitch.hex_dx);
      hexDy = Number(pitch.hex_dy);
      if (!sceneHexbinPitchAdmit(hexDx, hexDy)) {
        hexDx = Number.NaN;
        hexDy = Number.NaN;
      }
    }
    const styleKeysTrace = Object.entries(style).filter(([, value]) => value != null).map(([key]) => canonicalExportKey(key));
    const kindBytes = encodeUtf8(trace.kind == null ? "" : String(trace.kind)).slice(0, 256);
    const stepBytes = encodeUtf8(style.step == null ? "" : String(style.step)).slice(0, 256);
    const roleBytes = encodeUtf8(role).slice(0, 256);
    const symbolBytes = encodeUtf8(symbol).slice(0, 256);
    const reduceBytes = encodeUtf8(reduce).slice(0, 256);
    const prevBytes = encodeUtf8(prev == null ? "" : String(prev.kind ?? "")).slice(0, 256);
    const prev2Bytes = encodeUtf8(prev2 == null ? "" : String(prev2.kind ?? "")).slice(0, 256);
    const prev3Bytes = encodeUtf8(prev3 == null ? "" : String(prev3.kind ?? "")).slice(0, 256);
    const row = new Uint8Array(80);
    const view = new DataView(row.buffer);
    view.setUint32(0, obs, true);
    view.setUint32(4, exportColumnLen(xv), true);
    view.setUint32(8, exportColumnLen(yv), true);
    view.setUint32(12, exportColumnLen(x0), true);
    view.setUint32(16, exportColumnLen(y0), true);
    view.setUint32(20, exportColumnLen(x1), true);
    view.setUint32(24, exportColumnLen(y1), true);
    view.setUint32(28, heatmapRows, true);
    view.setUint32(32, heatmapCols, true);
    view.setUint32(36, heatmapValues, true);
    view.setUint16(40, styleKeysTrace.length, true);
    view.setUint16(42, kindBytes.length, true);
    view.setUint16(44, stepBytes.length, true);
    view.setUint16(46, roleBytes.length, true);
    view.setUint16(48, symbolBytes.length, true);
    view.setUint16(50, reduceBytes.length, true);
    view.setUint16(52, prevBytes.length, true);
    view.setUint16(54, prev2Bytes.length, true);
    view.setUint16(56, prev3Bytes.length, true);
    view.setFloat64(64, hexDx, true);
    view.setFloat64(72, hexDy, true);
    parts.push(row, kindBytes, stepBytes, roleBytes, symbolBytes, reduceBytes, prevBytes, prev2Bytes, prev3Bytes);
    for (const key of styleKeysTrace) parts.push(encodeExportKey(key));
  }
  return packPublicExportFromFacts(concatBytes(parts));
}

/** Return Rust's public-export diagnostic, or null when the Scene route applies. */
export function sceneExportSupportReason(figure, { width = null, height = null } = {}) {
  const envelope = packPublicExportSupport(figure, { width, height });
  const requiredRaw = xyScenePublicExportReason(u8Ptr(envelope), BigInt(envelope.length), 0, 0n);
  if (requiredRaw === USIZE_MAX_64) throw new RangeError("invalid scene public export support envelope");
  const required = Number(requiredRaw);
  let reason = "";
  if (required !== 0) {
    const output = new Uint8Array(required);
    const written = xyScenePublicExportReason(u8Ptr(envelope), BigInt(envelope.length), u8Ptr(output), BigInt(required));
    if (Number(written) !== required) throw new Error("native Scene public export predicate returned an inconsistent length");
    reason = new TextDecoder("utf-8", { fatal: true }).decode(output);
  }
  if (reason) return reason;
  try {
    figureSceneV3(figure);
  } catch (err) {
    if (err instanceof RangeError) {
      if (err.message === "invalid canonical scene plot layout") return "XYG_SCENE_UNSUPPORTED_VIEWPORT";
      if (
        err.message.includes("axis tick lists are limited")
        || err.message === "legend font sizes must be finite and in [1, 1000]"
        || err.message === "invalid scene chrome packing"
        || err.message === "invalid scene chrome facts version"
      ) {
        throw err;
      }
      return err.message;
    }
    throw err;
  }
  return null;
}

const LEGEND_LOCATIONS = new Map([["upper right", 0], ["upper left", 1], ["lower left", 2], ["lower right", 3], ["center right", 4], ["center left", 5], ["upper center", 6], ["lower center", 7], ["center", 8]]);

function legendColumnValues(column) {
  if (column == null) return null;
  if (ArrayBuffer.isView(column) || Array.isArray(column)) return asF64Array(column);
  if (column.values != null && typeof column.values !== "function") return asF64Array(column.values);
  return null;
}

/** Legend occupancy axis scale. Python legend best-loc uses `_axis_scale` (axis `type` only). */
export function legendAxisScale(options) {
  return axisScaleName(options);
}

function legendAxisSpec(figure, axisId) {
  const options = figureAxisOptions(figure)?.[axisId] ?? {};
  let lo, hi;
  try {
    [lo, hi] = figure._range(axisId);
  } catch {
    return null;
  }
  const reverse = lo > hi;
  if (reverse) [lo, hi] = [hi, lo];
  if (!(Number.isFinite(lo) && Number.isFinite(hi)) || hi <= lo) return null;
  const scale = legendAxisScale(options);
  const constant = options.constant == null || Number(options.constant) === 0 ? 1 : Number(options.constant);
  return { domain: [lo, hi], reverse, scale, constant };
}

export function resolveLegendBestLoc(figure) {
  const series = [];
  const labelLens = [];
  for (const trace of figure.traces ?? []) {
    if (trace.hidden) continue;
    if (trace.name != null && String(trace.name).length > 0) labelLens.push(String(trace.name).length);
    const xv = legendColumnValues(trace.x);
    const yv = legendColumnValues(trace.y);
    if (xv == null || yv == null || xv.length !== yv.length) continue;
    const xSpec = legendAxisSpec(figure, trace.x_axis ?? "x");
    const ySpec = legendAxisSpec(figure, trace.y_axis ?? "y");
    if (xSpec == null || ySpec == null) continue;
    const projected = legendNormalize(xv, yv, {
      xDomain: xSpec.domain,
      yDomain: ySpec.domain,
      xReverse: xSpec.reverse,
      yReverse: ySpec.reverse,
      xScale: xSpec.scale,
      yScale: ySpec.scale,
      xConstant: xSpec.constant,
      yConstant: ySpec.constant,
    });
    if (projected != null) series.push(projected);
  }
  return legendBestLoc(series, labelLens);
}

function legendInput(figure, entries, styles) {
  if (figureShowLegend(figure) === false || entries.length === 0) return new Uint8Array();
  const options = figureLegendOptions(figure) ?? {};
  const allowed = new Set(["loc", "title", "ncols", "style", "highlight", "toggle"]);
  if (Object.keys(options).some((key) => !allowed.has(key)) || Number(options.ncols ?? 1) !== 1) throw new RangeError("Scene v12 primary legends do not yet encode anchors, multiple columns, or custom content");
  if (["toggle", "highlight"].some((key) => Object.hasOwn(options, key) && options[key] !== false)) throw new RangeError("Scene v12 primary legends are static; toggle and highlight must be false");
  const authoredLoc = options.loc;
  let loc = authoredLoc ?? "upper right";
  if (loc === "best") loc = resolveLegendBestLoc(figure);
  if (!LEGEND_LOCATIONS.has(loc)) throw new RangeError(`Scene v12 does not support legend location ${JSON.stringify(loc)}`);
  const style = options.style ?? {};
  if (Object.keys(style).some((key) => !LEGEND_ALLOWED_STYLE.has(key))) throw new RangeError("Scene v12 legends support only background, color, font_size, and title_font_size");
  const { font_size: authoredFontSize, title_font_size: authoredTitleFontSize } = legendStyleFontSizes(style);
  const fontSize = authoredFontSize == null ? 0 : Number(authoredFontSize), titleFontSize = authoredTitleFontSize == null ? 0 : Number(authoredTitleFontSize);
  if (!((authoredFontSize == null || (fontSize >= 1 && fontSize <= 1000)) && (authoredTitleFontSize == null || (titleFontSize >= 1 && titleFontSize <= 1000)))) throw new RangeError("legend font sizes must be finite and in [1, 1000]");
  const encoder = new TextEncoder(), title = encoder.encode(String(options.title ?? "")), labels = entries.map((entry) => encoder.encode(entry.label));
  const textLength = title.length + labels.reduce((sum, label) => sum + label.length, 0);
  if (entries.length > 128 || title.length > 4096 || textLength > 16384 || labels.some((label) => label.length === 0 || label.length > 4096)) throw new RangeError("Scene v12 legend text exceeds its bounded UTF-8 limits");
  const flags = Number(authoredLoc != null) | (Number(authoredFontSize != null) << 1) | (Number(authoredTitleFontSize != null) << 2) | (Number(Object.hasOwn(style, "color")) << 3) | (Number(Object.hasOwn(style, "background")) << 4);
  const textRgba = Object.hasOwn(style, "color") ? rgba8(style.color, 1, "legend color") : new Uint8Array(4);
  const frameFill = Object.hasOwn(style, "background") ? rgba8(style.background, 1, "legend background") : new Uint8Array(4);
  const meta = new Uint8Array(entries.length * 16);
  const metaView = new DataView(meta.buffer);
  const concatenated = new Uint8Array(textLength - title.length);
  const labelLens = new Uint32Array(entries.length);
  let labelAt = 0;
  for (const [index, entry] of entries.entries()) {
    const paint = styles[entry.styleRef];
    const offset = index * 16;
    metaView.setUint32(offset, entry.styleRef, true);
    meta[offset + 4] = entry.kind;
    meta[offset + 5] = entry.symbol;
    meta.set(paint.fillRgba, offset + 8);
    meta.set(paint.strokeRgba, offset + 12);
    const label = labels[index];
    labelLens[index] = label.length;
    concatenated.set(label, labelAt);
    labelAt += label.length;
  }
  const out = new Uint8Array(48 + entries.length * 24 + textLength);
  const code = xyScenePackLegend(
    LEGEND_LOCATIONS.get(loc),
    flags,
    fontSize,
    titleFontSize,
    u8Ptr(textRgba),
    u8Ptr(frameFill),
    title.length ? u8Ptr(title) : 0,
    BigInt(title.length),
    entries.length,
    meta.length ? u8Ptr(meta) : 0,
    BigInt(meta.length),
    u32Ptr(labelLens),
    concatenated.length ? u8Ptr(concatenated) : 0,
    BigInt(concatenated.length),
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -5) throw new RangeError("legend font sizes must be finite and in [1, 1000]");
  if (code < 0) throw new RangeError("invalid scene legend packing");
  return out.subarray(0, code);
}

function colorbarInput(figure) {
  const options = figureColorbarOptions(figure);
  if (options == null) return new Uint8Array();
  if (typeof options !== "object" || Array.isArray(options)) throw new RangeError("Scene v19 colorbar requires literal RGBA stops");
  const namedAllowed = new Set(["domain", "colormap", "orientation", "label", "ticks", "minor_ticks"]);
  if (Object.keys(options).every((key) => namedAllowed.has(key))) {
    const domain = options.domain;
    if (!Array.isArray(domain) || domain.length !== 2) {
      throw new RangeError("Scene named colorbars require a two-value domain");
    }
    const lo = Number(domain[0]);
    const hi = Number(domain[1]);
    const orientation = String(options.orientation ?? "vertical");
    if (orientation !== "vertical" && orientation !== "horizontal") {
      throw new RangeError("Scene named colorbars support vertical or horizontal");
    }
    const title = options.label ?? "";
    if (typeof title !== "string") throw new TypeError("Scene named colorbar label must be a string");
    const titleBytes = new TextEncoder().encode(title);
    if (titleBytes.length > 4096) {
      throw new RangeError("Scene v19 colorbar title is limited to 4,096 UTF-8 bytes");
    }
    const nameBytes = new TextEncoder().encode(String(options.colormap ?? "viridis"));
    if (!nameBytes.length || nameBytes.includes(0)) {
      throw new RangeError("Scene named colorbar colormap must be nonempty and NUL-free");
    }
    const rawTicks = options.ticks;
    if (rawTicks != null && (!Array.isArray(rawTicks) || rawTicks.length > 32)) {
      throw new RangeError("Scene v19 colorbar ticks are limited to 32 finite ordered values");
    }
    const tickValues = Float64Array.from(rawTicks ?? [], Number);
    const minorTicks = options.minor_ticks ?? false;
    if (typeof minorTicks !== "boolean") throw new TypeError("Scene v19 colorbar minor_ticks must be a boolean");
    const text = Uint8Array.from([32, 32, 32, 255]);
    const out = new Uint8Array(56 + 16 * 12 + tickValues.length * 8 + titleBytes.length);
    const code = xyScenePackNamedColorbar(
      Number(orientation === "horizontal") | (Number(minorTicks) << 2),
      lo,
      hi,
      u8Ptr(text),
      titleBytes.length ? u8Ptr(titleBytes) : 0,
      BigInt(titleBytes.length),
      u8Ptr(nameBytes),
      BigInt(nameBytes.length),
      tickValues.length,
      tickValues.length ? f64Ptr(tickValues) : 0,
      u8Ptr(out),
      BigInt(out.length),
    );
    if (code === -5) throw new RangeError("Scene named colorbar domain/ticks must be finite");
    if (code === -7) throw new RangeError("Scene v19 colorbar ticks are limited to 32 finite ordered values");
    if (code < 0) throw new RangeError("invalid named scene colorbar packing");
    return out.subarray(0, code);
  }
  const allowed = new Set(["domain", "stops", "side", "title", "text_rgba", "ticks", "minor_ticks"]);
  if (Object.keys(options).some((key) => !allowed.has(key))) throw new RangeError("Scene v19 colorbar requires bounded literal RGBA stops");
  const domain = options.domain, stops = options.stops;
  if (!Array.isArray(domain) || domain.length !== 2 || !Array.isArray(stops) || stops.length < 2 || stops.length > 16) throw new RangeError("Scene v19 colorbar requires a domain and 2–16 stops");
  const lo = Number(domain[0]), hi = Number(domain[1]);
  const title = options.title ?? "";
  if (typeof title !== "string") throw new TypeError("Scene v19 colorbar title must be a string");
  const titleBytes = new TextEncoder().encode(title), text = asUnsignedArray(options.text_rgba ?? [32, 32, 32, 255], "colorbar text_rgba", 255, Uint8Array);
  requireLength(text, 4, "colorbar text_rgba"); if (titleBytes.length > 4096) throw new RangeError("Scene v19 colorbar title is limited to 4,096 UTF-8 bytes");
  const rawTicks = options.ticks;
  if (rawTicks != null && (!Array.isArray(rawTicks) || rawTicks.length > 32)) throw new RangeError("Scene v19 colorbar ticks are limited to 32 finite ordered values");
  const ticks = rawTicks == null ? [] : rawTicks.map(Number);
  const minorTicks = options.minor_ticks ?? false;
  if (typeof minorTicks !== "boolean") throw new TypeError("Scene v19 colorbar minor_ticks must be a boolean");
  const side = options.side ?? "right"; if (side !== "right" && side !== "bottom") throw new RangeError("Scene v19 colorbar side is right or bottom");
  const stopValues = new Float64Array(stops.length);
  const stopRgba = new Uint8Array(stops.length * 4);
  for (const [index, stop] of stops.entries()) {
    if (!Array.isArray(stop) || stop.length !== 2) throw new TypeError("colorbar stops are [value, RGBA]");
    stopValues[index] = Number(stop[0]);
    const rgba = asUnsignedArray(stop[1], `colorbar stops[${index}]`, 255, Uint8Array);
    requireLength(rgba, 4, `colorbar stops[${index}]`);
    stopRgba.set(rgba, index * 4);
  }
  const tickValues = Float64Array.from(ticks);
  const out = new Uint8Array(56 + stops.length * 12 + ticks.length * 8 + titleBytes.length);
  const code = xyScenePackColorbar(
    Number(side === "bottom") | (Number(minorTicks) << 2),
    lo,
    hi,
    u8Ptr(text),
    titleBytes.length ? u8Ptr(titleBytes) : 0,
    BigInt(titleBytes.length),
    stops.length,
    f64Ptr(stopValues),
    u8Ptr(stopRgba),
    BigInt(stopRgba.length),
    ticks.length,
    ticks.length ? f64Ptr(tickValues) : 0,
    u8Ptr(out),
    BigInt(out.length),
  );
  if (code === -5) throw new RangeError("Scene v19 colorbar domain must be finite and ordered");
  if (code === -6) throw new RangeError("colorbar stops must span the domain");
  if (code === -7) throw new RangeError("Scene v19 colorbar ticks are limited to 32 finite ordered values");
  if (code < 0) throw new RangeError("invalid scene colorbar packing");
  return out.subarray(0, code);
}

const MAX_SCENE_ANNOTATION_INPUT_BYTES = 28
  + 12 + 128 * 40 + 4096
  + 12 + 128 * 32 + 4096
  + 12 + 128 * 60
  + 12 + 128 * 76 + 8192
  + 12 + 128 * 68 + 8192;

function packAnnotationEnvelope({ texts, attached, arrows, callouts, wrapped }) {
  if (!texts.length && !attached.length && !arrows.length && !callouts.length && !wrapped.length) {
    return new Uint8Array();
  }
  const textMeta = new Uint8Array(texts.length * 40);
  const textView = new DataView(textMeta.buffer);
  const textLens = new Uint32Array(texts.length);
  texts.forEach((row, index) => {
    const at = index * 40;
    textView.setFloat64(at, row.x, true);
    textView.setFloat64(at + 8, row.y, true);
    textMeta.set(row.rgba, at + 16);
    textMeta.set(row.labelFill ?? [0, 0, 0, 0], at + 20);
    textMeta.set(row.labelBorder?.rgba ?? [0, 0, 0, 0], at + 24);
    textView.setFloat64(at + 28, row.labelBorder?.width ?? 0, true);
    textMeta[at + 36] = (row.labelFill ? 1 : 0) | (row.labelBorder ? 2 : 0);
    textLens[index] = row.text.length;
  });
  const textBytes = concatBytes(texts.map((row) => row.text));
  const attachedMeta = new Uint8Array(attached.length * 32);
  const attachedView = new DataView(attachedMeta.buffer);
  const attachedLens = new Uint32Array(attached.length);
  attached.forEach((row, index) => {
    const at = index * 32;
    attachedView.setBigUint64(at, row.stableId, true);
    attachedMeta.set(row.rgba, at + 8);
    attachedMeta.set(row.labelFill ?? [0, 0, 0, 0], at + 12);
    attachedMeta.set(row.labelBorder?.rgba ?? [0, 0, 0, 0], at + 16);
    attachedView.setFloat64(at + 20, row.labelBorder?.width ?? 0, true);
    attachedMeta[at + 28] = (row.labelFill ? 1 : 0) | (row.labelBorder ? 2 : 0);
    attachedLens[index] = row.text.length;
  });
  const attachedBytes = concatBytes(attached.map((row) => row.text));
  const arrowMeta = new Uint8Array(arrows.length * 60);
  const arrowView = new DataView(arrowMeta.buffer);
  arrows.forEach((row, index) => {
    const at = index * 60;
    arrowView.setBigUint64(at, row.stableId, true);
    arrowView.setFloat64(at + 8, row.x0, true);
    arrowView.setFloat64(at + 16, row.y0, true);
    arrowView.setFloat64(at + 24, row.x1, true);
    arrowView.setFloat64(at + 32, row.y1, true);
    arrowMeta.set(row.rgba, at + 40);
    arrowView.setFloat64(at + 44, row.opacity, true);
    arrowView.setFloat64(at + 52, row.width, true);
  });
  const calloutMeta = new Uint8Array(callouts.length * 76);
  const calloutView = new DataView(calloutMeta.buffer);
  const calloutLens = new Uint32Array(callouts.length);
  callouts.forEach((row, index) => {
    const at = index * 76;
    calloutView.setFloat64(at, row.x, true);
    calloutView.setFloat64(at + 8, row.y, true);
    calloutView.setFloat64(at + 16, row.dx, true);
    calloutView.setFloat64(at + 24, row.dy, true);
    calloutMeta.set(row.rgba, at + 32);
    calloutView.setFloat64(at + 36, row.opacity, true);
    calloutView.setFloat64(at + 44, row.width, true);
    calloutMeta[at + 52] = row.anchorCode;
    calloutMeta.set(row.labelFill ?? [0, 0, 0, 0], at + 56);
    calloutMeta.set(row.labelBorder?.rgba ?? [0, 0, 0, 0], at + 60);
    calloutView.setFloat64(at + 64, row.labelBorder?.width ?? 0, true);
    calloutMeta[at + 72] = (row.labelFill ? 1 : 0) | (row.labelBorder ? 2 : 0);
    calloutLens[index] = row.text.length;
  });
  const calloutBytes = concatBytes(callouts.map((row) => row.text));
  const wrappedMeta = new Uint8Array(wrapped.length * 64);
  const wrappedView = new DataView(wrappedMeta.buffer);
  const wrappedLens = new Uint32Array(wrapped.length);
  wrapped.forEach((row, index) => {
    const at = index * 64;
    wrappedView.setFloat64(at, row.x, true);
    wrappedView.setFloat64(at + 8, row.y, true);
    wrappedView.setFloat64(at + 16, row.dx, true);
    wrappedView.setFloat64(at + 24, row.dy, true);
    wrappedView.setFloat64(at + 32, row.wrap, true);
    wrappedMeta.set(rgba8(annotationColor(row.a.style ?? {}, "color", row.a.kind === "callout" ? "#344054" : "#667085", "wrapped color"), row.opacity, "wrapped"), at + 40);
    wrappedMeta.set(row.fill, at + 44);
    wrappedMeta.set(row.border?.rgba ?? [0, 0, 0, 0], at + 48);
    wrappedView.setFloat64(at + 52, row.border?.width ?? 0, true);
    wrappedMeta[at + 60] = row.a.kind === "callout" ? 1 : 0;
    wrappedMeta[at + 61] = row.anchor;
    wrappedLens[index] = row.text.length;
  });
  const wrappedBytes = concatBytes(wrapped.map((row) => row.text));
  const out = new Uint8Array(MAX_SCENE_ANNOTATION_INPUT_BYTES);
  const code = xyScenePackAnnotations(
    texts.length, textMeta.length ? u8Ptr(textMeta) : 0, BigInt(textMeta.length),
    texts.length ? u32Ptr(textLens) : 0, textBytes.length ? u8Ptr(textBytes) : 0, BigInt(textBytes.length),
    attached.length, attachedMeta.length ? u8Ptr(attachedMeta) : 0, BigInt(attachedMeta.length),
    attached.length ? u32Ptr(attachedLens) : 0, attachedBytes.length ? u8Ptr(attachedBytes) : 0, BigInt(attachedBytes.length),
    arrows.length, arrowMeta.length ? u8Ptr(arrowMeta) : 0, BigInt(arrowMeta.length),
    callouts.length, calloutMeta.length ? u8Ptr(calloutMeta) : 0, BigInt(calloutMeta.length),
    callouts.length ? u32Ptr(calloutLens) : 0, calloutBytes.length ? u8Ptr(calloutBytes) : 0, BigInt(calloutBytes.length),
    wrapped.length, wrappedMeta.length ? u8Ptr(wrappedMeta) : 0, BigInt(wrappedMeta.length),
    wrapped.length ? u32Ptr(wrappedLens) : 0, wrappedBytes.length ? u8Ptr(wrappedBytes) : 0, BigInt(wrappedBytes.length),
    u8Ptr(out), BigInt(out.length),
  );
  if (code === -5) throw new RangeError("Scene annotation geometry must be finite");
  if (code === -6) throw new RangeError("Scene annotations require nonempty NUL-free text");
  if (code === -7) throw new RangeError("Scene v23 label border requires label_background");
  if (code < 0) throw new RangeError("invalid scene annotation packing");
  return out.subarray(0, code);
}

/** Per-item channel names. Python `per_item_channel_names` reads `color_ch` / `stroke_ch` / `size_ch` / `style_channels` only. */
function perItemChannelNames(trace) {
  const names = [];
  const color = trace.color_ch;
  if (color != null && typeof color === "object" && color.mode !== "constant") names.push("color");
  const stroke = trace.stroke_ch;
  if (
    stroke != null
    && typeof stroke === "object"
    && stroke.mode !== "constant"
    && stroke.mode !== "match_fill"
  ) names.push("stroke");
  const size = trace.size_ch;
  if (size != null && typeof size === "object" && size.mode !== "constant") names.push("size");
  const channels = trace.style_channels ?? {};
  if (channels != null && typeof channels === "object" && !Array.isArray(channels) && !ArrayBuffer.isView(channels)) {
    // Graph edge ends are Scene-packed geometry (PACK_EDGE_SEGMENT, #33).
    // edge_ends (#33) and the Rust label plan (#34) are placement, not paint.
    names.push(...Object.keys(channels).filter((name) => name !== "edge_ends" && name !== "label_plan"));
  }
  return names;
}

function densityAggregatesColor(trace) {
  if (String(trace.kind ?? "") !== "scatter" || !scatterUsesDensity(trace)) return false;
  return perItemChannelNames(trace).every((name) => name === "color");
}

export function scatterHasNonConstantColor(trace) {
  const color = trace.color_ch;
  if (color == null || typeof color !== "object") return false;
  return color.mode !== "constant" || color.constant == null;
}

export function scatterUsesDensity(trace) {
  if (String(trace.kind || "") !== "scatter") return false;
  return shouldUseDensity(trace.x?.length ?? 0, {
    forceDensity: trace.force_density,
    coords: "cartesian",
    perItemChannels: perItemChannelNames(trace).length > 0,
  });
}

function foldedCodesU8(codes, paletteLen) {
  const n = codes.length;
  if (n === 0) {
    return new Uint8Array(0);
  }
  const src = codes instanceof Uint32Array ? codes : Uint32Array.from(codes);
  const out = new Uint8Array(n);
  const ok = xyFoldCodesU8(u32Ptr(src), BigInt(n), BigInt(paletteLen), u8Ptr(out));
  if (!ok) {
    throw new RangeError("native fold_codes_u8 rejected the code array");
  }
  return out;
}

export function resolveDensityBinColors(trace) {
  const color = trace.color_ch;
  if (color == null || typeof color !== "object") return null;
  const mode = String(color.mode ?? "");
  if (!densityMeanColorWireAdmit({ hasChannel: true, mode })) return null;
  if (mode === "direct_rgba" && color.rgba != null) {
    return { rgba: color.rgba instanceof Uint8Array ? color.rgba : Uint8Array.from(color.rgba) };
  }
  if (mode === "continuous" && color.values != null) {
    const values = color.values;
    const domain = color.domain ?? [0, 1];
    const lo = Number(domain[0]);
    const hi = Number(domain[1]);
    const idx = quantizeUnitU8(values, lo, hi);
    return { idx, lut: colormapLutRgba8(color.colormap ?? "viridis") };
  }
  if (mode === "categorical" && color.codes != null && color.categories != null) {
    const palette = color.palette?.length ? color.palette : DEFAULT_PALETTE;
    const codes = color.codes;
    if (codes instanceof Uint8Array) {
      return { idx: codes, lut: paletteRowsRgba8(palette, color.categories.length) };
    }
    return {
      idx: foldedCodesU8(codes, palette.length),
      lut: paletteRowsRgba8(palette, palette.length),
    };
  }
  return null;
}

export function rectExtraFlags(style, kind, polar) {
  const fill = style.fill;
  const fillIsMapping =
    fill != null
    && typeof fill === "object"
    && !Array.isArray(fill)
    && !ArrayBuffer.isView(fill);
  const gradientFail = fillIsMapping && admitFillGradient({ style }) == null;
  const radius = style.corner_radius ?? 0;
  const radiusSeq = Array.isArray(radius);
  const values = radiusSeq ? radius.map(Number) : [Number(radius)];
  const gap = Number(style.wedge_gap ?? 0);
  return sceneRectExtraFlags(kind, polar, gradientFail, values, radiusSeq, gap);
}

export function figureTraceSupport(figure, trace) {
  const style = trace.style ?? {};
  const kind = String(trace.kind || "mark");
  const dispatch = sceneFigureSupportTraceDispatchPlan({
    kind,
    markerGlyphPresent: style.marker_glyph != null,
    markerPathPresent: style.marker_path != null,
    curvePresent: style.curve != null,
    fillPresent: Object.hasOwn(style, "fill"),
  });
  let flags = 0;
  if (!sceneKindAdmit(kind)) flags |= XYFS_TRACE_UNSUPPORTED_KIND;
  if ((trace.x_axis ?? "x") !== "x" || (trace.y_axis ?? "y") !== "y") flags |= XYFS_TRACE_NON_PRIMARY_AXIS;
  if (sceneHiddenOrPerItemAdmit(
    Boolean(trace.hidden),
    perItemChannelNames(trace).length > 0,
    densityAggregatesColor(trace),
  )) flags |= XYFS_TRACE_HIDDEN_OR_PER_ITEM;
  if (dispatch.probeMarkerGlyph) {
    if (kind !== "scatter" || style.marker_path != null || admittedMarkerGlyph(style.marker_glyph) == null) {
      flags |= XYFS_TRACE_DASHED_MARKERS;
    }
  }
  if (dispatch.probeMarkerPath) {
    if (kind !== "scatter") flags |= XYFS_TRACE_DASHED_MARKERS;
    else {
      const validated = validateMarkerPath(style.marker_path);
      if (validated == null || (validated.filled && validated.contours.some((contour) => contour.length < 6))) {
        flags |= XYFS_TRACE_DASHED_MARKERS;
      }
    }
  }
  const curve = style.curve;
  if (curve != null) {
    const curveCode = sceneCurveClassify(curve);
    if (curveCode === 1) {
      if (!dispatch.probeCurveSmooth) flags |= XYFS_TRACE_DASHED_MARKERS;
    } else if (curveCode !== 0) {
      flags |= XYFS_TRACE_DASHED_MARKERS;
    }
  }
  const linecap = style.linecap;
  if (linecap != null && parseSceneLinecap(linecap) === false) {
    flags |= XYFS_TRACE_DASHED_MARKERS;
  }
  if (style.dash != null && parseSceneDash(style.dash) === false) flags |= XYFS_TRACE_DASHED_MARKERS;
  if (dispatch.probeRectExtra) flags |= rectExtraFlags(style, kind, figure.coords === "polar");
  if (dispatch.probeHexbinReduce && !sceneHexbinReduceAdmit(style.reduce)) flags |= XYFS_TRACE_CUSTOM_HEX_REDUCE;
  if (
    dispatch.probeHeatmapColormap
    && sceneHeatmapColormapAdmit(
      style.truecolor ? 1 : 0,
      style.colormap != null ? 1 : 0,
      trace.rgba_grid != null ? 1 : 0,
      trace.rgba != null ? 1 : 0,
    )
  ) flags |= XYFS_TRACE_HEATMAP_COLORMAP;
  if (dispatch.probeNonCssFill && typeof style.fill !== "string") {
    if (admitFillGradient(trace) == null) flags |= XYFS_TRACE_NON_CSS_FILL;
  }
  return { flags, kind };
}

export function hexbinPacksColormapPlane(trace) {
  if (!(sceneKindClass(trace.kind) & SCENE_KIND_CLASS_HEXBIN)) return false;
  const channel = trace.color_ch;
  if (channel == null) return false;
  return sceneHexbinColormapPlaneAdmit(channel.mode, channel.values != null);
}

function hexbinCount(trace) {
  return trace.x?.length ?? 0;
}

export function hexbinCellRgba8(trace) {
  return channelEndRgba8(
    trace.color_ch,
    hexbinCount(trace),
    traceStyleColorDefault(trace),
  );
}

export function hexbinPacksRgbaPlane(trace) {
  if (!(sceneKindClass(trace.kind) & SCENE_KIND_CLASS_HEXBIN)) return false;
  const channel = trace.color_ch;
  if (channel == null) return false;
  if (!sceneHexbinRgbaPlaneAdmit(channel.mode)) return false;
  return hexbinCellRgba8(trace) != null;
}

function hexbinPacksPaintPlane(trace) {
  return hexbinPacksColormapPlane(trace) || hexbinPacksRgbaPlane(trace);
}

export function scatterPaintChannelNames(trace) {
  return perItemChannelNames(trace);
}

export function scatterPacksPaintPlane(trace) {
  if (String(trace.kind || "") !== "scatter" || scatterUsesDensity(trace)) return false;
  const names = scatterPaintChannelNames(trace);
  if (!names.length) return false;
  return names.every((name) => sceneScatterPaintChannelAdmit(name));
}

function scatterCount(trace) {
  return trace.x?.length ?? trace.count ?? 0;
}

export function itemApplyOpacity(trace, packed, n) {
  const channels = trace.style_channels ?? {};
  const opacityCh = channels.opacity;
  const artistCh = channels.artist_alpha;
  if (opacityCh == null && artistCh == null) return packed;
  return sceneItemApplyOpacity(
    packed,
    n,
    artistCh == null ? null : (artistCh.values != null ? artistCh.values : [Number.NaN]),
    opacityCh == null ? null : (opacityCh.values != null ? opacityCh.values : [Number.NaN]),
  );
}

export function itemFillRgba8(trace, n) {
  const fallback = traceStyleColorDefault(trace);
  const channel = trace.color_ch;
  let packed = channelEndRgba8(channel, n, fallback);
  if (packed == null && channel != null && typeof channel === "object" && channel.mode === "continuous" && channel.values != null) {
    const values = [...channel.values].map(Number);
    const domain = channel.domain;
    const t = sceneItemFillT(
      values,
      n,
      Array.isArray(domain) && domain.length === 2 ? [Number(domain[0]), Number(domain[1])] : null,
    );
    if (t == null) return null;
    try {
      const stops = colormapNamedStops(channel.colormap ?? "viridis");
      packed = colormapRgba(t, n, 1, stops, 255).rgba;
    } catch {
      return null;
    }
  }
  if (packed == null) return null;
  return itemApplyOpacity(trace, packed, n);
}

export function itemStrokeRgba8(trace, fills, n) {
  const strokeCh = trace.stroke_ch;
  if (strokeCh != null && strokeCh.mode === "match_fill") return fills;
  const fallback = String((trace.style ?? {}).stroke || "transparent");
  const packed = channelEndRgba8(strokeCh, n, fallback);
  if (packed != null) return packed;
  if (strokeCh == null) return channelEndRgba8(null, n, fallback);
  return null;
}

export function itemWidths(trace, n) {
  const widthCh = (trace.style_channels ?? {}).stroke_width;
  if (widthCh != null) {
    const values = widthCh.values != null
      ? [...widthCh.values].map(Number)
      : [Number.NaN];
    if (!sceneItemWidthsAdmit(values, n, 0)) return null;
    return packF64Le(values);
  }
  const width = Number((trace.style ?? {}).stroke_width ?? 0);
  if (!sceneItemWidthsAdmit(null, n, width)) return null;
  return packF64Le(new Float64Array(n).fill(width));
}

export function scatterPointStrokeRgba8(trace, fills) {
  const n = scatterCount(trace);
  const packed = itemStrokeRgba8(trace, fills, n);
  if (packed == null) return null;
  const strokeCh = trace.stroke_ch;
  if (strokeCh != null && strokeCh.mode === "match_fill") return packed;
  return itemApplyOpacity(trace, packed, n);
}

function scatterPointPaints(trace) {
  const n = scatterCount(trace);
  const packedFills = itemFillRgba8(trace, n);
  const packedStrokes = scatterPointStrokeRgba8(trace, packedFills);
  const packedWidths = itemWidths(trace, n);
  if (packedFills == null || packedStrokes == null || packedWidths == null) return null;
  return { fills: packedFills, strokes: packedStrokes, widths: packedWidths };
}

function meshCount(trace) {
  return trace.x0?.length ?? trace.count ?? 0;
}

/** Mesh joined_fill. Python `_mesh_joined_fill` reads `style.get("joined_fill")` only. */
export function meshJoinedFill(trace) {
  const style = (trace ?? {}).style ?? {};
  return Boolean(style.joined_fill);
}

export function meshHasPerItem(trace) {
  return perItemChannelNames(trace).length > 0;
}

function meshPacksPaintPlane(trace) {
  return sceneMeshPaintPlaneAdmit(
    String(trace.kind ?? ""),
    meshJoinedFill(trace),
    meshHasPerItem(trace),
  );
}

function meshFaceFillRgba8(trace) {
  return itemFillRgba8(trace, meshCount(trace));
}

function meshFaceStrokeRgba8(trace, fills) {
  return itemStrokeRgba8(trace, fills, meshCount(trace));
}

function meshFaceWidths(trace) {
  return itemWidths(trace, meshCount(trace));
}

function meshFacePaints(trace) {
  const fills = meshFaceFillRgba8(trace);
  const strokes = meshFaceStrokeRgba8(trace, fills);
  const widths = meshFaceWidths(trace);
  if (fills == null || strokes == null || widths == null) return null;
  return { fills, strokes, widths };
}

/** Compile migrated cartesian marks to Scene v12. */
/** Host-parity tests compare `_pack_xyta` / `packXyTa` bytes against Python fixtures. */
export function packFigureXyTa(figure) {
  return packXyTa(figure, figure._range("x"), figure._range("y"));
}

/** Host-parity tests compare `_pack_xytc` / `packXyTc` bytes against Python fixtures. */
export function packFigureXyTc(figure) {
  return packXyTc(figure);
}

export function figureSceneV3(figure, { margins = null } = {}) {
  let colorbarUnsupported = false;
  try { colorbarInput(figure); } catch { colorbarUnsupported = Boolean(figureColorbarOptions(figure)); }
  const attachPlan = sceneEncodeProductAttachPlan({ polar: figure.coords === "polar" });
  const xDomain = figure._range("x");
  const yDomain = figure._range("y");
  const annotationFacts = packXyAfBulk(figure.annotations ?? []);
  try {
    return encodeProduct(
      packXyTc(figure),
      packXyTa(figure, xDomain, yDomain),
      packXyNm(figure.traces ?? [], figure),
      packXyCl(figure),
      concatBytes([annotationFacts]),
      (figure.traces ?? []).length,
      xDomain,
      yDomain,
      packChromeFacts(figure, {
        width: figure.width, height: figure.height, margins, colorbarOk: !colorbarUnsupported,
      }),
      attachPlan.attachXypl ? packPolarSceneInput(figure) : new Uint8Array(),
      packFigureSupport(figure, { colorbarUnsupported }),
    );
  } catch (error) {
    if (error.stage === 1) raiseTraceCompile(error.code, error.index ?? 0, figure);
    if (error.stage === 2) raiseTraceAttach(error.code, error.index ?? 0, figure);
    if (error.stage === 3) raiseTraceSidecars(error.code, error.index ?? 0);
    if (error.stage === 4) raiseTraceRows(error.code, error.index ?? 0);
    if (error.stage === 5) {
      if (error.code === -5) throw new RangeError("Scene annotation geometry must be finite");
      if (error.code === -6) throw new RangeError("Scene annotations require nonempty NUL-free text");
      if (error.code === -7) throw new RangeError("Scene v23 label border requires label_background");
      if (error.code === -3) throw new RangeError("Scene annotations are limited to 128 entries");
      throw new RangeError("invalid scene annotation packing");
    }
    if (error.stage === 6) {
      throw new RangeError(error.code === -2 ? "invalid scene style sidecar facts version" : "invalid scene style sidecar packing");
    }
    if (error.stage === 7) {
      throw new RangeError(error.code === -2 ? "invalid scene annotation splice version" : "invalid scene annotation splice packing");
    }
    throw error;
  }
}

/** Serialize built-in scatter marks through the shared Rust scene schema. */
export function scatterSceneSvg({
  x,
  y,
  diameter,
  fillRgba,
  strokeRgba,
  strokeWidth,
  symbols,
  visible = null,
  fillCss = null,
  strokeCss = null,
}) {
  const xa = asF64Array(x, "x");
  const ya = asF64Array(y, "y");
  const diameters = asF64Array(diameter, "diameter");
  const widths = asF64Array(strokeWidth, "strokeWidth");
  const fills = asU8Array(fillRgba, "fillRgba");
  const strokes = asU8Array(strokeRgba, "strokeRgba");
  const symbolCodes = asU8Array(symbols, "symbols");
  const visibility = visible == null ? null : asU8Array(visible, "visible");
  const fillCssBytes = fillCss == null ? null : new TextEncoder().encode(String(fillCss));
  const strokeCssBytes = strokeCss == null ? null : new TextEncoder().encode(String(strokeCss));
  const length = xa.length;
  requireLength(ya, length, "y");
  requireLength(diameters, length, "diameter");
  requireLength(widths, length, "strokeWidth");
  requireLength(symbolCodes, length, "symbols");
  requireLength(fills, length * 4, "fillRgba");
  requireLength(strokes, length * 4, "strokeRgba");
  if (visibility != null) requireLength(visibility, length, "visible");

  let capacity = Math.max(32, length * 160);
  for (;;) {
    const output = new Uint8Array(capacity);
    const rawWritten = xySceneScatterSvg(
      f64Ptr(xa),
      f64Ptr(ya),
      f64Ptr(diameters),
      u8Ptr(fills),
      u8Ptr(strokes),
      f64Ptr(widths),
      u8Ptr(symbolCodes),
      u8Ptr(visibility),
      u8Ptr(fillCssBytes),
      BigInt(fillCssBytes?.length ?? 0),
      u8Ptr(strokeCssBytes),
      BigInt(strokeCssBytes?.length ?? 0),
      BigInt(length),
      pointer(output, "uint8_t *"),
      BigInt(capacity),
    );
    if (rawWritten === USIZE_MAX_64) {
      throw new RangeError("invalid canonical scatter scene");
    }
    const written = Number(rawWritten);
    if (!Number.isSafeInteger(written) || written < 0) {
      throw new RangeError("canonical scatter scene exceeded host output limits");
    }
    if (written <= capacity) {
      return new TextDecoder().decode(output.subarray(0, written));
    }
    capacity = written;
  }
}
